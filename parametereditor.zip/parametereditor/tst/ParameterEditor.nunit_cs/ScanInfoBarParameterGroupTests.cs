#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: SummaryParameterGroupTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using NUnit.Framework;
using Philips.PmsMR.Methods.PdfInterface;
using Philips.PmsMR.ParameterEditor.BusinessLayer;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System.Collections.Generic;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Unit Test class for ScanInfoBarParameterGroup
    /// </summary>
    public class ScanInfoBarParameterGroupTests
    {
        private IUnityContainer _container;
        private GroupInfo _groupInfo;
        private ScanInfoBarParameterGroup _scanInfoBarParameterGroup;
        private ParameterSessionInfo _parameterSessionInfo;
        private IScanProtocalWrapper _scanProtocalWrapper;

        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            _container = new UnityContainer();
            _groupInfo = new GroupInfo { name = "d", id = (int)GroupIds.ScanInfoParameterGroupId, parameterCount = 3 };
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());
            XmlParseUtility.InitializeXmlParse();
            var objIntVector = new IntVector();
            objIntVector.Add(1);
            objIntVector.Add(2);
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(objIntVector);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");

            var objFloatVector = new FloatVector();
            objFloatVector.Add(1);
            objFloatVector.Add(2);

            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");

            var kVpNodeMock = MockRepository.GenerateMock<IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(objIntVector);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(objFloatVector);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");

            var _scanProtocol = MockRepository.GenerateMock<ScanProtocolMock>();

            _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);


            _parameterSessionInfo = new ParameterSessionInfo();
            _parameterSessionInfo.ScanProtocol = _scanProtocol;
            _parameterSessionInfo.BaselineProtocol = _scanProtocol;
            _parameterSessionInfo.ScanProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.BaselineProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.IsEditMode = true;
            _parameterSessionInfo.IsInConflict = false;


            foreach (var tabNameMapping in ScanProtocolMetaDataMock.tabNameMapping)
            {
                _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
            }
            _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(2);
        }

        /// <summary>
        /// Test ScanInfoBarParameterGroup are always enabled
        /// </summary>
        [Test]
        public void VerifyScanInfoBarParameterGroupAlwaysEnabled()
        {
            _scanInfoBarParameterGroup = new ScanInfoBarParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            var isEnabled = false;
            bool.TryParse(
                Utility.GetInstanceProperty(typeof(ScanInfoBarParameterGroup), _scanInfoBarParameterGroup, "Enabled")
                    .ToString(), out isEnabled);
            //Verify ScanInfoBarParameterGroup is enabled
            Assert.AreEqual(isEnabled, true);
        }

        /// <summary>
        /// Test  ScanInfoBarParameterGroup Parameters are filled or not.
        /// </summary>
        [Test]
        public void VerifyScanInfoBarParameterGroupParametersAreFilled()
        {
            var dic2 = new Dictionary<string, IParameterMetaData>();
            var uniqueIds = new List<string>();
            var invaliduniqueIds = new List<string>();
            uniqueIds.Add("EX_ACQ.imaging_sequence");
            uniqueIds.Add("IF.str_total_scan_time");
            uniqueIds.Add("IF.nr_breathholds");
            uniqueIds.Add("IF.breathhold_scan_time");
            uniqueIds.Add("IF.resp_trig_dur");
            uniqueIds.Add("IF.str_dyna_scan_time");
            uniqueIds.Add("IF.str_dyn_keyh_scan_time");
            uniqueIds.Add("EX_ACQ.scan_mode");
            uniqueIds.Add("EX_GEO.orient_name");
            uniqueIds.Add("EX_STACKS[0].orientation");
            uniqueIds.Add("IF.echo_spacing_shot_dur");
            uniqueIds.Add("IF.relative_SNR");
            uniqueIds.Add("IF.wf_shift_bw_per_pix_echo1");
            uniqueIds.Add("IF.wf_shift_bw_per_pix_echo2");
            uniqueIds.Add("IF.bw_per_pix_EPI_read_out");
            uniqueIds.Add("IF.meas_matrix_size");
            uniqueIds.Add("IF.meas_voxel_size");
            uniqueIds.Add("IF.cardiac_freq");
            uniqueIds.Add("IF.no_trig_period_trig_del");
            uniqueIds.Add("IF.act_rep_time_echo_time");
            uniqueIds.Add("IF.act_SE_echo_time");
            uniqueIds.Add("IF.SPY_act_steam_tr_te_tm");
            uniqueIds.Add("IF.sar_lvl_whole_body");
            uniqueIds.Add("IF.sar_lvl_head");
            uniqueIds.Add("IF.sar_lvl_local");
            uniqueIds.Add("IF.sar_lvl_extremities");
            uniqueIds.Add("IF.sar_info_whole_body");
            uniqueIds.Add("IF.sar_info_head");
            uniqueIds.Add("IF.sar_info_extremities");
            uniqueIds.Add("IF.pns_info");
            uniqueIds.Add("IF.B1_rms");
            uniqueIds.Add("EX_STACKS[0].slices");
            uniqueIds.Add("IF.sound_pressure_level");
            uniqueIds.Add("IF.act_slice_gap");
            uniqueIds.Add("EX_STACKS[0].slice_gap");

            invaliduniqueIds.Add("InvalidA");
            invaliduniqueIds.Add("InvalidB");
            invaliduniqueIds.Add("InvalidC");


            foreach (var uniqueId in uniqueIds)
            {
                dic2.Add(uniqueId, Utility.GetIntTypeParameter(uniqueId));
            }
            foreach (var invaliduniqueId in invaliduniqueIds)
            {
                dic2.Add(invaliduniqueId, Utility.GetIntTypeParameter(invaliduniqueId));
            }
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);

            _scanInfoBarParameterGroup = new ScanInfoBarParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            var dto = _scanInfoBarParameterGroup.PopulateGroup();
            //Verify all the parameters are successfully added
            Assert.AreEqual(dto.Parameters.Count, uniqueIds.Count);
            foreach (var uniqueId in uniqueIds)
            {
                Assert.AreEqual(dto.Parameters.ContainsKey(uniqueId), true);
            }
            foreach (var invaliduniqueId in invaliduniqueIds)
            {
                //Verify all the invalid parameters are not added
                Assert.AreEqual(dto.Parameters.ContainsKey(invaliduniqueId), false);
            }
        }
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History