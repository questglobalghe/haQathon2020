#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: PdfParameterMocks.cs
//

#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.Methods.PdfInterface;
using Philips.PmsMR.Platform.OSInterface;
using Rhino.Mocks;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Mock class for all the variants for PdfParameter types.
    /// </summary>
    public static class PdfParameterMocks
    {
        /// <summary>
        ///     Create a mock of StringPdfParameter populated with argument values and returns it.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="visibility"></param>
        /// <param name="readOnly"></param>
        /// <param name="conflict"></param>
        /// <param name="values"></param>
        /// <param name="baselineValues"></param>
        /// <param name="actualDimension"></param>
        /// <param name="valueElementCount"></param>
        /// <param name="rangeConflict"></param>
        /// <param name="uniqueId"></param>
        /// <param name="help"></param>
        /// <param name="internalName"></param>
        /// <returns>
        ///     Returns an instance of StringPdfParameter populated with argument values.
        /// </returns>
        public static IPdfParameter CreateStringPdfParameterMock(IUnityContainer container,
            string name, bool visibility, string[] values = null, string[] baselineValues = null,
            bool readOnly = false, bool conflict = false,
            int actualDimension = 0, int valueElementCount = 2, bool rangeConflict = false,
            string uniqueId = "string",
            string help = null, string internalName = null)
        {
            var stringPdfParameter = MockRepository.GenerateMock<IStringPdfParameter>();
            container.RegisterInstance(stringPdfParameter, new ContainerControlledLifetimeManager());
            stringPdfParameter.Stub(x => x.Visible).Return(visibility);
            stringPdfParameter.Stub(x => x.Name).Return(name);
            stringPdfParameter.Stub(x => x.Values).Return(values);
            stringPdfParameter.Stub(x => x.Conflict).Return(conflict);
            stringPdfParameter.Stub(x => x.ReadOnly).Return(readOnly);
            stringPdfParameter.Stub(x => x.ActualDimension).Return(actualDimension);
            stringPdfParameter.Stub(x => x.BaseLineValues).Return(baselineValues);
            stringPdfParameter.Stub(x => x.UniqueID).Return(uniqueId);
            stringPdfParameter.Stub(x => x.Help).Return(help);
            stringPdfParameter.Stub(x => x.InternalName).Return(internalName);
            stringPdfParameter.Stub(x => x.ValueElementCount).Return(valueElementCount);
            stringPdfParameter.Stub(x => x.RangeConflict).Return(rangeConflict);
            return stringPdfParameter;
        }

        /// <summary>
        ///     Create a mock of StringPdfParameter with default necessary array parameters.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="visibility"></param>
        /// <param name="readOnly"></param>
        /// <param name="conflict"></param>
        /// <param name="values"></param>
        /// <param name="baselineValues"></param>
        /// <param name="actualDimension"></param>
        /// <param name="valueElementCount"></param>
        /// <param name="rangeConflict"></param>
        /// <param name="uniqueId"></param>
        /// <param name="help"></param>
        /// <param name="internalName"></param>
        /// <returns>
        ///     Returns an instance of StringPdfParameter
        /// </returns>
        public static IPdfParameter CreateStringPdfParameterMockWithDefaultArrayParameters(IUnityContainer container,
            string name, bool visibility, string[] values = null, string[] baselineValues = null,
            bool readOnly = false, bool conflict = false,
            int actualDimension = 0, int valueElementCount = 2, bool rangeConflict = false,
            string uniqueId = "string",
            string help = null, string internalName = null)
        {
            return CreateStringPdfParameterMock(
                container, name, visibility,
                new[] {"1", "2"}, new[] {"1", "2"},
                readOnly, conflict, actualDimension, valueElementCount,
                rangeConflict, uniqueId, help, internalName);
        }

        /// <summary>
        ///     Create a mock of EnumPdfParameter populated with argument values and returns it.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="visibility"></param>
        /// <param name="readOnly"></param>
        /// <param name="conflict"></param>
        /// <param name="values"></param>
        /// <param name="baselineValues"></param>
        /// <param name="actualDimension"></param>
        /// <param name="valueElementCount"></param>
        /// <param name="rangeConflict"></param>
        /// <param name="enumNames"></param>
        /// <param name="enumTexts"></param>
        /// <param name="ranges"></param>
        /// <param name="uniqueId"></param>
        /// <param name="help"></param>
        /// <param name="internalName"></param>
        /// <returns>
        ///     Returns an instance of EnumPdfParameter populated with argument values.
        /// </returns>
        public static IPdfParameter CreateEnumPdfParameterMock(IUnityContainer container,
            string name, bool visibility, int[] values = null, int[] baselineValues = null,
            string[] enumNames = null, string[] enumTexts = null, IntRange[] ranges = null,
            int actualDimension = 0,
            bool readOnly = false, bool conflict = false, int valueElementCount = 2, bool rangeConflict = false,
            string uniqueId = "enum",
            string help = null, string internalName = null)
        {
            var enumPdfParameter = MockRepository.GenerateMock<IEnumPdfParameter>();
            container.RegisterInstance(enumPdfParameter, new ContainerControlledLifetimeManager());
            enumPdfParameter.Stub(x => x.Visible).Return(visibility);
            enumPdfParameter.Stub(x => x.Name).Return(name);
            enumPdfParameter.Stub(x => x.Values).Return(values);
            enumPdfParameter.Stub(x => x.Conflict).Return(conflict);
            enumPdfParameter.Stub(x => x.ReadOnly).Return(readOnly);
            enumPdfParameter.Stub(x => x.ActualDimension).Return(actualDimension);
            enumPdfParameter.Stub(x => x.BaseLineValues).Return(baselineValues);
            enumPdfParameter.Stub(x => x.UniqueID).Return(uniqueId);
            enumPdfParameter.Stub(x => x.Help).Return(help);
            enumPdfParameter.Stub(x => x.InternalName).Return(internalName);
            enumPdfParameter.Stub(x => x.ValueElementCount).Return(valueElementCount);
            enumPdfParameter.Stub(x => x.RangeConflict).Return(rangeConflict);
            enumPdfParameter.Stub(x => x.EnumNames).Return(enumNames);
            enumPdfParameter.Stub(x => x.EnumTexts).Return(enumTexts);
            enumPdfParameter.Stub(x => x.Ranges).Return(ranges);
            return enumPdfParameter;
        }

        /// <summary>
        ///     Create a mock of EnumPdfParameter with default necessary array parameters.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="visibility"></param>
        /// <param name="readOnly"></param>
        /// <param name="conflict"></param>
        /// <param name="values"></param>
        /// <param name="baselineValues"></param>
        /// <param name="actualDimension"></param>
        /// <param name="valueElementCount"></param>
        /// <param name="rangeConflict"></param>
        /// <param name="enumNames"></param>
        /// <param name="enumTexts"></param>
        /// <param name="ranges"></param>
        /// <param name="uniqueId"></param>
        /// <param name="help"></param>
        /// <param name="internalName"></param>
        /// <returns>
        ///     Returns an instance of EnumPdfParameter
        /// </returns>
        public static IPdfParameter CreateEnumPdfParameterMockWithDefaultArrayParameters(IUnityContainer container,
            string name, bool visibility, int[] values = null, int[] baselineValues = null,
            string[] enumNames = null, string[] enumTexts = null, IntRange[] ranges = null,
            int actualDimension = 0,
            bool readOnly = false, bool conflict = false, int valueElementCount = 2, bool rangeConflict = false,
            string uniqueId = "enum",
            string help = null, string internalName = null)
        {
            return CreateEnumPdfParameterMock(container, name, visibility, new[] {0, 1},
                new[] {2, 3},
                new[] {"a", "b"}, new[] {"a", "b"}, new IntRange[2], actualDimension,
                readOnly, conflict, valueElementCount, rangeConflict, uniqueId,
                help, internalName);
        }

        /// <summary>
        ///     Create a mock of FloatPdfParameter populated with argument values and returns it.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="visibility"></param>
        /// <param name="readOnly"></param>
        /// <param name="conflict"></param>
        /// <param name="values"></param>
        /// <param name="baselineValues"></param>
        /// <param name="actualDimension"></param>
        /// <param name="valueElementCount"></param>
        /// <param name="rangeConflict"></param>
        /// <param name="accuracy"></param>
        /// <param name="adjustValue"></param>
        /// <param name="ranges"></param>
        /// <param name="uniqueId"></param>
        /// <param name="help"></param>
        /// <param name="internalName"></param>
        /// <returns>
        ///     Returns an instance of FloatPdfParameter populated with argument values.
        /// </returns>
        public static IPdfParameter CreateFloatPdfParameterMock(IUnityContainer container,
            string name, bool visibility, float[] values = null, float[] baselineValues = null,
            FloatRange[] ranges = null,
            bool readOnly = false, bool conflict = false,
            int actualDimension = 0, int valueElementCount = 2, bool rangeConflict = false,
            int accuracy = 2, float adjustValue = 2,
            string uniqueId = "float",
            string help = null, string internalName = null)
        {
            var floatPdfParameter = MockRepository.GenerateMock<IFloatPdfParameter>();
            container.RegisterInstance(floatPdfParameter, new ContainerControlledLifetimeManager());
            floatPdfParameter.Stub(x => x.Visible).Return(visibility);
            floatPdfParameter.Stub(x => x.Name).Return(name);
            floatPdfParameter.Stub(x => x.Values).Return(values);
            floatPdfParameter.Stub(x => x.Conflict).Return(conflict);
            floatPdfParameter.Stub(x => x.ReadOnly).Return(readOnly);
            floatPdfParameter.Stub(x => x.ActualDimension).Return(actualDimension);
            floatPdfParameter.Stub(x => x.BaseLineValues).Return(baselineValues);
            floatPdfParameter.Stub(x => x.UniqueID).Return(uniqueId);
            floatPdfParameter.Stub(x => x.Help).Return(help);
            floatPdfParameter.Stub(x => x.InternalName).Return(internalName);
            floatPdfParameter.Stub(x => x.ValueElementCount).Return(valueElementCount);
            floatPdfParameter.Stub(x => x.RangeConflict).Return(rangeConflict);
            floatPdfParameter.Stub(x => x.Accuracy).Return(accuracy);
            floatPdfParameter.Stub(x => x.AdjustValue).Return(adjustValue);
            floatPdfParameter.Stub(x => x.Ranges).Return(ranges);
            return floatPdfParameter;
        }

        /// <summary>
        ///     Create a mock of FloatPdfParameter with default necessary array parameters.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="visibility"></param>
        /// <param name="readOnly"></param>
        /// <param name="conflict"></param>
        /// <param name="values"></param>
        /// <param name="baselineValues"></param>
        /// <param name="actualDimension"></param>
        /// <param name="valueElementCount"></param>
        /// <param name="rangeConflict"></param>
        /// <param name="accuracy"></param>
        /// <param name="adjustValue"></param>
        /// <param name="ranges"></param>
        /// <param name="uniqueId"></param>
        /// <param name="help"></param>
        /// <param name="internalName"></param>
        /// <returns>
        ///     Returns an instance of FloatPdfParameter
        /// </returns>
        public static IPdfParameter CreateFloatPdfParameterMockWithDefaultArrayParameters(IUnityContainer container,
            string name, bool visibility, float[] values = null, float[] baselineValues = null,
            FloatRange[] ranges = null,
            bool readOnly = false, bool conflict = false,
            int actualDimension = 0, int valueElementCount = 2, bool rangeConflict = false,
            int accuracy = 2, float adjustValue = 2,
            string uniqueId = "float",
            string help = null, string internalName = null)
        {
            return CreateFloatPdfParameterMock(container, name, visibility, new float[] {2, 3},
                new float[] {2, 3},
                new FloatRange[2], readOnly, conflict, actualDimension,
                valueElementCount, rangeConflict,accuracy, adjustValue,
                uniqueId,
                help, internalName);
        }

        /// <summary>
        ///     Create a mock of IntPdfParameter populated with argument values and returns it.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="visibility"></param>
        /// <param name="readOnly"></param>
        /// <param name="conflict"></param>
        /// <param name="values"></param>
        /// <param name="baselineValues"></param>
        /// <param name="actualDimension"></param>
        /// <param name="valueElementCount"></param>
        /// <param name="rangeConflict"></param>
        /// <param name="uniqueId"></param>
        /// <param name="help"></param>
        /// <param name="adjustValue"></param>
        /// <param name="ranges"></param>
        /// <param name="internalName"></param>
        /// <returns>
        ///     Returns an instance of IntPdfParameter populated with argument values.
        /// </returns>
        public static IPdfParameter CreateIntPdfParameterMock(IUnityContainer container,
            string name, bool visibility, int[] values = null, int[] baselineValues = null,
            IntRange[] ranges = null, bool readOnly = false, bool conflict = false,
            int actualDimension = 0, int valueElementCount = 2, bool rangeConflict = false,
            int adjustValue = 2,
            string uniqueId = "int",
            string help = null, string internalName = null)
        {
            var intPdfParameter = MockRepository.GenerateMock<IIntPdfParameter>();
            container.RegisterInstance(intPdfParameter, new ContainerControlledLifetimeManager());
            intPdfParameter.Stub(x => x.Visible).Return(visibility);
            intPdfParameter.Stub(x => x.Name).Return(name);
            intPdfParameter.Stub(x => x.Values).Return(values);
            intPdfParameter.Stub(x => x.Conflict).Return(conflict);
            intPdfParameter.Stub(x => x.ReadOnly).Return(readOnly);
            intPdfParameter.Stub(x => x.ActualDimension).Return(actualDimension);
            intPdfParameter.Stub(x => x.BaseLineValues).Return(baselineValues);
            intPdfParameter.Stub(x => x.UniqueID).Return(uniqueId);
            intPdfParameter.Stub(x => x.Help).Return(help);
            intPdfParameter.Stub(x => x.InternalName).Return(internalName);
            intPdfParameter.Stub(x => x.ValueElementCount).Return(valueElementCount);
            intPdfParameter.Stub(x => x.RangeConflict).Return(rangeConflict);
            intPdfParameter.Stub(x => x.AdjustValue).Return(adjustValue);
            intPdfParameter.Stub(x => x.Ranges).Return(ranges);
            return intPdfParameter;
        }

        /// <summary>
        ///     Create a mock of IntPdfParameter with default necessary array parameters.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="visibility"></param>
        /// <param name="readOnly"></param>
        /// <param name="conflict"></param>
        /// <param name="values"></param>
        /// <param name="baselineValues"></param>
        /// <param name="actualDimension"></param>
        /// <param name="valueElementCount"></param>
        /// <param name="rangeConflict"></param>
        /// <param name="uniqueId"></param>
        /// <param name="help"></param>
        /// <param name="adjustValue"></param>
        /// <param name="ranges"></param>
        /// <param name="internalName"></param>
        /// <returns>
        ///     Returns an instance of IntPdfParameter
        /// </returns>
        public static IPdfParameter CreateIntPdfParameterMockWithDefaultArrayParameters(IUnityContainer container,
            string name, bool visibility, int[] values = null, int[] baselineValues = null,
            IntRange[] ranges = null, bool readOnly = false, bool conflict = false,
            int actualDimension = 0, int valueElementCount = 2, bool rangeConflict = false,
            int adjustValue = 2,
            string uniqueId = "int",
            string help = null, string internalName = null)
        {
            return CreateIntPdfParameterMock(container, name, visibility, new[] {2, 3},
                new[] {2, 3},
                new IntRange[2], readOnly, conflict, actualDimension,
                valueElementCount, rangeConflict, adjustValue, uniqueId,
                help, internalName);
        }
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History