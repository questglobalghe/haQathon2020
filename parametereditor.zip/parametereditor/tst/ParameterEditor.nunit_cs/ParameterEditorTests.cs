﻿#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterEditorTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using NUnit.Framework;
using Philips.PmsMR.ParameterEditor.BusinessLayer;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Philips.DI.Interfaces.Services.Messaging;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Unit Test class for ParameterEditor
    /// </summary>
    public class ParameterEditorTests
    {
        private int _five = 5;
        private int _nine = 9;
        private IUnityContainer _container;
        private ParameterEditorDto _parameterEditorDto;
        private IScanProtocolMetaData _protocolMetaDataMock;
        private IScanProtocol _scanProtocol;
        private IScanProtocalWrapper _scanProtocalWrapper;
        private ParameterSessionInfo _parameterSessionInfo;
        private IMessagingService _messagingServiceMock;
        private const string DefaultSuggestion = "Restore last values without conflicts";

        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            _container = new UnityContainer();
            _messagingServiceMock = MockRepository.GenerateMock<IMessagingService>();
            var mqService = MockRepository.GenerateMock<IMQService>();
            var broker = MockRepository.GenerateMock<IBroker>();
            mqService.Stub(x => x.ConvertTo<IBroker>()).Return(broker);
            _messagingServiceMock.Stub(x => x.Proxy("ParameterEditorBroker")).IgnoreArguments().Return(mqService);
            _container.RegisterInstance(_messagingServiceMock, new ContainerControlledLifetimeManager());
            var parameterGroupFactory = _container.Resolve<ParameterGroupFactory>();
            _container.RegisterInstance(parameterGroupFactory, new ContainerControlledLifetimeManager());
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());
            _container.RegisterType<IPlanEditor, BusinessLayer.ParameterEditor>();
            _container.RegisterType<IParameterEditor, BusinessLayer.ParameterEditor>();
        }

        /// <summary>
        ///     Shutdown the Scan modification Service
        /// </summary>
        [TearDown]
        public virtual void TearDown()
        {
            _container.Dispose();
        }

        /// <summary>
        /// Called whenever there is any change in scanprotocol from UI.
        /// </summary>
        /// <param name="sender">sender of this event</param>
        /// <param name="modifiedScanProtocol">Holds the modified scanprotocol</param>
        private void OnScanProtocolChanged(object sender, IScanProtocol modifiedScanProtocol)
        {
            _parameterSessionInfo = new ParameterSessionInfo
            {
                ScanProtocol = modifiedScanProtocol
            };
        }

        private void ParameterEditorUpdated(object sender, ParameterEditorUpdateArgs e)
        {
            _parameterEditorDto = e.EditorDto;
        }

        private void GetProtocolMetaDataMock(uint currentNodeValueSize = 2)
        {
            _protocolMetaDataMock = MockRepository.GenerateMock<Utility.ScanProtocolMetaDataMock>();
            _protocolMetaDataMock.Stub(x => x.GetTabNames()).Return(Utility.tabNameMapping.Keys.ToList());
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _protocolMetaDataMock.Stub(x => x.GetTabHierarchy(tabNameMapping.Key))
                    .Return(Utility.GetTabHierarchyValue(tabNameMapping.Value));
            }
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _protocolMetaDataMock.Stub(x =>
                        x.GetParametersPath(Utility.GetTabHierarchyValue(tabNameMapping.Value)))
                    .Return(Utility.GetParametersPathValue(
                        Utility.GetTabHierarchyValue(tabNameMapping.Value)));
            }
            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(new StringVector())).IgnoreArguments()
                .Return(null);
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
            }
            _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(currentNodeValueSize);
        }

        private ParameterSessionInfo GetParameterSessionInfo(bool resolveFields = true)
        {
            var objIntVector = new IntVector();
            objIntVector.Add(1);
            objIntVector.Add(2);
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(objIntVector);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");

            var objFloatVector = new FloatVector();
            objFloatVector.Add(_five);
            objFloatVector.Add(_nine);

            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");

            var kVpNodeMock = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(objIntVector);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(objFloatVector);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");

            _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();
            if (resolveFields)
            {
                _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);
            }

            var parameterSessionInfo = new ParameterSessionInfo();
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            return parameterSessionInfo;
        }

        /// <summary>
        /// Verify StartSession
        /// </summary>
        [Test]
        public void VerifyStartSession()
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_PROC.image_types", Utility.GetEnumTypeParameter("EX_PROC.image_types"));
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            GetProtocolMetaDataMock(2);
            var parameterSessionInfo = GetParameterSessionInfo();
            var planEditor = new BusinessLayer.ParameterEditor(_container);

            //Act
            planEditor.StartSession(parameterSessionInfo);

            //Assert?
            var lastActiveGroupId = -1;
            int.TryParse(
                Utility.GetInstanceField(typeof(BusinessLayer.ParameterEditor), planEditor, "_lastActiveGroupId")
                    .ToString(), out lastActiveGroupId);
            //Verify whether LastActiveGroupId is saved.
            Assert.AreNotEqual(lastActiveGroupId, -1);
        }

        /// <summary>
        /// Verify StartSession
        /// </summary>
        [Test]
        public void VerifyStartSessionWithConflictPresent()
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_PROC.image_types", Utility.GetEnumTypeParameter("EX_PROC.image_types"));
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            GetProtocolMetaDataMock(2);
            var parameterSessionInfo = GetParameterSessionInfo();
            parameterSessionInfo.ScanProtocolMetaData.Stub(x => x.GetConflictParameters())
                .Return(new StringVector() { "EX_GEO.fov" });
            parameterSessionInfo.IsInConflict = true;
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            planEditor.ParameterEditorUpdated += ParameterEditorUpdated;
            _parameterEditorDto = null;

            //Act
            planEditor.StartSession(parameterSessionInfo);

            //Assert?
            Assert.IsNotNull(_parameterEditorDto);
            Assert.IsTrue(_parameterEditorDto.ConflictPresent);
            planEditor.ParameterEditorUpdated -= ParameterEditorUpdated;
        }

        /// <summary>
        /// Verify RefreshSession
        /// </summary>
        [Test]
        public void VerifyRefreshSession()
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_PROC.image_types", Utility.GetEnumTypeParameter("EX_PROC.image_types"));
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            GetProtocolMetaDataMock(2);
            var parameterSessionInfo = GetParameterSessionInfo();
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            planEditor.StartSession(parameterSessionInfo);
            planEditor.ParameterEditorUpdated += ParameterEditorUpdated;
            _parameterEditorDto = null;

            //Act
            planEditor.RefreshSession(parameterSessionInfo);

            //Assert?
            Assert.IsNotNull(_parameterEditorDto);
            Assert.IsFalse(_parameterEditorDto.ConflictPresent);
            planEditor.ParameterEditorUpdated -= ParameterEditorUpdated;
        }

        /// <summary>
        /// Verify EndSession 
        /// </summary>
        [Test]
        [TestCaseSource(nameof(TestEndSessionSource))]
        public void VerifyEndSession(bool isEventErrorOccuredBinded)
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_PROC.image_types", Utility.GetEnumTypeParameter("EX_PROC.image_types"));
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            GetProtocolMetaDataMock(2);
            var parameterSessionInfo = GetParameterSessionInfo();
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            if (isEventErrorOccuredBinded)
            {
                planEditor.ErrorOccured += PlanEditor_ErrorOccured;
            }
            planEditor.StartSession(parameterSessionInfo);

            //Act
            planEditor.EndSession();


            //Assert
            Assert.AreEqual(isEventErrorOccuredBinded, errorOccurred);
            var lastActiveGroupId = 11;
            int.TryParse(
                Utility.GetInstanceField(typeof(BusinessLayer.ParameterEditor), planEditor, "_lastActiveGroupId")
                    .ToString(), out lastActiveGroupId);
            //Verify whether LastActiveGroupId is saved.
            Assert.AreEqual(lastActiveGroupId, -1);
            planEditor.ErrorOccured -= PlanEditor_ErrorOccured;
        }



        /// <summary>
        /// Verify UpdateScanProtocol
        /// </summary>
        [Test]
        [TestCaseSource(nameof(TestUpdateScanProtocol))]
        public void VerifyUpdateScanProtocol(bool isScanProtocolChangedBinded)
        {
            //Arrange
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            if (isScanProtocolChangedBinded)
            {
                planEditor.ScanProtocolChanged += OnScanProtocolChanged;
            }
            _parameterSessionInfo = null;

            //Act
            planEditor.UpdateScanProtocol();

            //Assert
            if (isScanProtocolChangedBinded)
            {
                Assert.IsNotNull(_parameterSessionInfo);
            }
            else
            {
                Assert.IsNull(_parameterSessionInfo);
            }
            planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
        }


        /// <summary>
        /// Verify SetParameter
        /// </summary>
        [Test]
        public void VerifySetParameter()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            GetProtocolMetaDataMock();
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic2);
            var parameterSessionInfo = GetParameterSessionInfo();
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            planEditor.StartSession(parameterSessionInfo);


            ////Act
            planEditor.SetParameter("EX_ACQ.patient_weight", new[] { 2.0f, 3.0f });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_ACQ.patient_weight"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_ACQ.patient_weight"));

            ////Act 
            planEditor.SetParameter("EX_ACQ.patient_weight", new[] { 2.0f });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_ACQ.patient_weight"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_ACQ.patient_weight"));

            //Act
            planEditor.SetParameter("EX_CARD.sync", new[] { 2, 4 });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.sync"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.sync"));

            //Act
            planEditor.SetParameter("EX_CARD.sync", new[] { 2 });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.sync"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.sync"));

            //Act
            planEditor.SetParameter("EX_CARD.str", new[] { "", "" });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.str"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.str"));

            //Act
            planEditor.SetParameter("EX_CARD.str", new[] { "" });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.str"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.str"));

            //Act
            planEditor.SetParameter("EX_CARD.str", new[] { new object() });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.str"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.str"));
        }

        /// <summary>
        /// Verify SetActiveGroup
        /// </summary>
        [Test]
        public void VerifySetActiveGroup()
        {
            //Arrange
            var planEditor = GetPlanEditor();

            //Act
            planEditor.SetActiveGroup((int)GroupIds.Summary);

            //Assert
            var lastActiveGroupId = -1;
            int.TryParse(
                Utility.GetInstanceField(typeof(BusinessLayer.ParameterEditor), planEditor, "_lastActiveGroupId")
                    .ToString(), out lastActiveGroupId);
            Assert.AreEqual(lastActiveGroupId == (int)GroupIds.Summary, true);
        }



        /// <summary>
        /// Verify ResetAll
        /// </summary>
        [Test]
        public void VerifyResetAll()
        {
            var planEditor = GetPlanEditor();

            //Act
            planEditor.ResetAll();

            //Assert?
        }



        /// <summary>
        /// VerifyLoadConflictInfoToDto
        /// </summary>
        [Test]
        public void VerifyLoadConflictInfoToDto()
        {
            //Arrange
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            var parameterSessionInfo = GetParameterSessionInfo();
            parameterSessionInfo.ConflictGuidanceInfo = new ParameterConflictGuidanceInfo(IntPtr.Zero, false);
            parameterSessionInfo.ConflictGuidanceInfo.conflictKey = "EX_PROC.image_types";
            parameterSessionInfo.ConflictGuidanceInfo.suggestionInfo = new List<SuggestionStruct>();
            var singleParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var intParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var stringParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var enumParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var defaultParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceParameterStructs(null)).IgnoreArguments().Return(
                new List<ParameterStruct>()
                {
                    singleParameterStruct,
                    intParameterStruct,
                    stringParameterStruct,
                    enumParameterStruct,
                    defaultParameterStruct
                }
            );
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(singleParameterStruct)).Return("System.Single");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(intParameterStruct)).Return("System.Int32");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(stringParameterStruct)).Return("System.String");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(enumParameterStruct)).Return("System.Enum");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(defaultParameterStruct)).Return("System.Custom");
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(3);
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments()
                .Return(new List<SuggestionStruct>() { new SuggestionStruct(IntPtr.Zero, false) });
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("DummySuggestionKey");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(null)).IgnoreArguments().Return("System.Int32");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(null)).IgnoreArguments().Return(true);
            Utility.SetFieldValue(planEditor, "_editorDto", new ParameterEditorDto());
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);

            //Act
            var privateHelperObject = new Microsoft.VisualStudio.TestTools.UnitTesting.PrivateObject(planEditor);
            privateHelperObject.Invoke("LoadConflictInfoToDto");
        }

        /// <summary>
        /// VerifyLoadCoilSelectionToDto
        /// </summary>
        [Test]
        public void VerifyLoadCoilSelectionToDto()
        {
            //Arrange
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            var parameterSessionInfo = GetParameterSessionInfo();
            parameterSessionInfo.ConflictGuidanceInfo = new ParameterConflictGuidanceInfo(IntPtr.Zero, false);
            parameterSessionInfo.ConflictGuidanceInfo.conflictKey = "EX_PROC.image_types";
            parameterSessionInfo.ConflictGuidanceInfo.suggestionInfo = new List<SuggestionStruct>();
            parameterSessionInfo.ScanProtocol.Stub(x => x.GetNrStacks()).Return(2);
            var coilSelection = MockRepository.GenerateMock<Utility.ICoilSelectionMock>();
            coilSelection.Stub(x => x.GetSelectedCoilElements()).Return(new List<CoilSelectionElement>()
            {
                new CoilSelectionElement("c", "s", 23),
                new CoilSelectionElement("c", "s", 24)
            });
            parameterSessionInfo.ScanProtocol.Stub(x => x.GetCoilSelectionStack(0, null)).IgnoreArguments().Return(coilSelection);

            _scanProtocalWrapper.Stub(x => x.GetCoils(null, null)).IgnoreArguments().Return(new List<Coil>() {
            new Coil("coilName1","coilStocket1"), new Coil("coilName2","coilStocket2")});
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(3);
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments()
                .Return(new List<SuggestionStruct>() { new SuggestionStruct(IntPtr.Zero, false) });
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("DummySuggestionKey");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(null)).IgnoreArguments().Return("System.Int32");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(null)).IgnoreArguments().Return(true);
            Utility.SetFieldValue(planEditor, "_editorDto", new ParameterEditorDto());
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);

            //Act
            var privateHelperObject = new Microsoft.VisualStudio.TestTools.UnitTesting.PrivateObject(planEditor);
            privateHelperObject.Invoke("LoadCoilSelectionToDto");

            //Assert?
        }



        /// <summary>
        /// Verify ResolveConflict
        /// </summary>
        /// <param name="str"></param>
        /// <param name="suggestionKey"></param>
        /// <param name="throwException"></param>
        [TestCaseSource(nameof(ResolveConflictTestSource))]
        public void VerifyResolveConflict(string str, string suggestionKey, bool throwException)
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            var dic1 = new Dictionary<string, IParameterMetaData>();
            dic1.Add("EX_CARD.sync", Utility.GetStringTypeParameter("EX_CARD.sync"));
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            GetProtocolMetaDataMock();
            var parameterSessionInfo = GetParameterSessionInfo(false);
            var singleKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            singleKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeFloat);
            singleKVPNode.Stub(x => x.GetFloatArrayValue()).Return(new FloatVector() { _five, _nine });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_GEO.fov")).Return(singleKVPNode);
            var stringKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            stringKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeString);
            singleKVPNode.Stub(x => x.GetStringArrayValue()).Return(new StringVector() { @"String1", "String2" });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_CARD.sync")).Return(stringKVPNode);
            var int32KVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            int32KVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeInteger);
            singleKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { 1, 2 });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_CARD.IntSync")).Return(int32KVPNode);
            var customKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            customKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeComposite);
            _scanProtocol.Stub(x => x.GetChildByPath("CustomId")).Return(customKVPNode);
            var enumKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            enumKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
            _scanProtocol.Stub(x => x.GetChildByPath("EnumId")).Return(enumKVPNode);
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic);
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            _protocolMetaDataMock.Stub(x => x.GetConflictParameters()).Return(new StringVector { "EX_PROC.image_types" });
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = true;
            _scanProtocalWrapper.Stub(x => x.GetConflictKey(null)).IgnoreArguments().Return("EX_PROC.image_types");
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments().Return(
                new List<SuggestionStruct>()
                {
                    new SuggestionStruct(IntPtr.Zero, false),
                    new SuggestionStruct(IntPtr.Zero, false)
                });
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(2);
            var singleParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var intParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var stringParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var enumParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var defaultParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceParameterStructs(null)).IgnoreArguments().Return(
                new List<ParameterStruct>()
                {
                    singleParameterStruct,
                    intParameterStruct,
                    stringParameterStruct,
                    enumParameterStruct,
                    defaultParameterStruct
                }
            );
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(singleParameterStruct)).Return("System.Single");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(singleParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(singleParameterStruct)).Return(2.0f);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(singleParameterStruct)).Return("EX_GEO.fov");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(intParameterStruct)).Return("System.Int32");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(intParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(intParameterStruct)).Return(4);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(intParameterStruct)).Return("EX_CARD.IntSync");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(stringParameterStruct)).Return("System.String");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(stringParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(stringParameterStruct)).Return(3);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(stringParameterStruct)).Return("EX_CARD.sync");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(enumParameterStruct)).Return("System.Enum");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(enumParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(enumParameterStruct)).Return(4);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(enumParameterStruct)).Return("EnumId");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(defaultParameterStruct)).Return("System.Custom");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(defaultParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(defaultParameterStruct)).Return(3);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(defaultParameterStruct)).Return("CustomId");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("key").Repeat.Once();
            var c = new Utility.ConflictGuidanceSuggestionsMock();
            parameterSessionInfo.ConflictGuidanceInfo = new ParameterConflictGuidanceInfo(IntPtr.Zero, false);
            parameterSessionInfo.ConflictGuidanceInfo.conflictKey = "EX_PROC.image_types";
            parameterSessionInfo.ConflictGuidanceInfo.suggestionInfo = new List<SuggestionStruct>();
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments().Return(new List<SuggestionStruct>()
            {
                new SuggestionStruct(IntPtr.Zero, false),
                new SuggestionStruct(IntPtr.Zero, false)
            });

            if (throwException)
            {
                _scanProtocol.Stub(x => x.ApplyDelta((IKVPDocument)null)).IgnoreArguments().Throw(new Exception());

                //Act
                Assert.Throws<Exception>(() => planEditor.ResolveConflict("EX_PROC.image_types", suggestionKey));
            }
            else
            {
                //Act
                planEditor.ResolveConflict("EX_PROC.image_types", suggestionKey);

                //Assert
                if (suggestionKey == DefaultSuggestion)
                {
                    _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
                }
                else
                {
                    _scanProtocol.AssertWasNotCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
                }
            }

        }


        /// <summary>
        /// Verify ResolveConflict
        /// </summary>
        public void VerifySetResolvedParameter()
        {
            // Test TabNames
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            var parameterSessionInfo = GetParameterSessionInfo();
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments()
                .Return(new List<SuggestionStruct>());
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("");
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceParameters(null)).IgnoreArguments()
                .Return(new List<ParameterStruct>() { new ParameterStruct(IntPtr.Zero, false) });

            //Act
            var privateHelperObject = new Microsoft.VisualStudio.TestTools.UnitTesting.PrivateObject(planEditor);
            privateHelperObject.Invoke("SetResolvedParameter", new object[] { "parameterId", 2.0f });

            //Assert
        }
        /// <summary>
        /// Verify SetStackSelection
        /// </summary>
        [Test]
        [TestCaseSource(nameof(SetCoilSmartSelectionTestSource))]
        public void VerifySetStackSelection(bool isStackSelect, bool throwExpection)
        {
            //Arrage
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            var parameterSessionInfo = GetParameterSessionInfo();
            if (throwExpection)
            {
                if (isStackSelect)
                {
                    parameterSessionInfo.ScanProtocol.Stub(x => x.EnableStackSelect()).IgnoreArguments()
                        .Throw(new Exception());

                }
                else
                {
                    parameterSessionInfo.ScanProtocol.Stub(x => x.DisableStackSelect()).IgnoreArguments()
                        .Throw(new Exception());
                }
            }
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);

            if (throwExpection)
            {
                //Act -- Assert
                Assert.Throws<Exception>(() => planEditor.SetStackSelect(true));
            }
            else
            {
                planEditor.ScanProtocolChanged += OnScanProtocolChanged;

                //Act
                planEditor.SetStackSelect(isStackSelect);

                //Assert?
                if (isStackSelect)
                {
                    parameterSessionInfo.ScanProtocol.AssertWasCalled(x => x.EnableStackSelect(),
                        op => op.IgnoreArguments());
                }
                else
                {
                    parameterSessionInfo.ScanProtocol.AssertWasCalled(x => x.DisableStackSelect(),
                        op => op.IgnoreArguments());
                }
                Assert.IsNotNull(_parameterSessionInfo.ScanProtocol);
                planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
            }
        }

        /// <summary>
        /// Verify SetSmartSelection
        /// </summary>
        [Test]
        [TestCaseSource(nameof(SetCoilSmartSelectionTestSource))]
        public void VerifySetSmartSelection(bool isSmartSelect, bool throwExpection)
        {
            //Arrage
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            var parameterSessionInfo = GetParameterSessionInfo();
            if (throwExpection)
            {
                parameterSessionInfo.ScanProtocol.Stub(x => x.SetAutoCoilSelect(true)).IgnoreArguments()
                    .Throw(new Exception());
            }
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);

            if (throwExpection)
            {
                //Act -- Assert
                Assert.Throws<Exception>(() => planEditor.SetSmartSelect(true));
            }
            else
            {
                planEditor.ScanProtocolChanged += OnScanProtocolChanged;

                //Act
                planEditor.SetSmartSelect(isSmartSelect);

                //Assert?
                parameterSessionInfo.ScanProtocol.AssertWasCalled(x => x.SetAutoCoilSelect(true),
                    op => op.IgnoreArguments());
                Assert.IsNotNull(_parameterSessionInfo.ScanProtocol);
                planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
            }
        }

        /// <summary>
        /// Verify SetStackCoilSelection
        /// </summary>
        [Test]
        [TestCaseSource(nameof(SetCoilSmartSelectionTestSource))]
        public void VerifySetStackCoilSelection(bool throwExpection1, bool throwExpection)
        {
            //Arrange
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            var parameterSessionInfo = GetParameterSessionInfo();
            if (throwExpection)
            {
                parameterSessionInfo.ScanProtocol.Stub(x => x.SetCoilSelectionStack(0, null, null)).IgnoreArguments()
                    .Throw(new Exception());
            }
            else
            {
                var validationContextMock = MockRepository.GenerateMock<Utility.IValidationContextMock>();
                validationContextMock.Stub(x => x.GetICoilLogic()).Return(new ICoilLogic(IntPtr.Zero, false));
                _scanProtocalWrapper.Stub(x => x.CreateValidationContext()).Return(validationContextMock);
                var stackDetailsDto = new StackDetailsDto();
                stackDetailsDto.CoilStackDetailsCollection = new ObservableCollection<CoilDetailsDto>()
                {
                    new CoilDetailsDto() {IsCoilSelected = true, CoilName = "CoilName"}
                };
            }
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);


            if (throwExpection)
            {
                //Act -- Assert
                Assert.Throws<Exception>(() => planEditor.SetStackCoilSelection(1, new StackDetailsDto()));
            }
            else
            {
                planEditor.ScanProtocolChanged -= OnScanProtocolChanged;

                //Act
                planEditor.SetStackCoilSelection(1, new StackDetailsDto());

                //Assert
                parameterSessionInfo.ScanProtocol.AssertWasCalled(x => x.GetCoilSelectionStack(0, null),
                    op => op.IgnoreArguments());
                parameterSessionInfo.ScanProtocol.AssertWasCalled(x => x.SetCoilSelectionStack(0, null, null),
                    op => op.IgnoreArguments());
                Assert.IsNotNull(_parameterSessionInfo.ScanProtocol);
                planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
            }
        }

        /// <summary>
        /// Verify UndoParameter
        /// </summary>
        [Test]
        public void VerifyUndoParameter()
        {
            // Test TabNames
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            Utility.SetFieldValue(planEditor, "_currentParameterStack", 2);
            var parameterSessionInfo = GetParameterSessionInfo();
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);
            var parameterStacks = Utility.GetInstanceField(typeof(BusinessLayer.ParameterEditor), planEditor, "_parameterStacks")
                as List<ParameterEditorStack>;
            ParameterEditorStack stack = new ParameterEditorStack();
            stack.KvpDocument = new IKVPDocument(IntPtr.Zero, false);
            stack.StackId = 1;
            parameterStacks.Add(stack);

            //Act
            planEditor.UndoParameter();


            //Assert?
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
            var currentParameterStack = (int)Utility.GetInstanceField(typeof(BusinessLayer.ParameterEditor),
                planEditor, "_currentParameterStack");
            Assert.AreEqual(1, currentParameterStack);
        }

        /// <summary>
        /// Verify RedoParameter
        /// </summary>
        [Test]
        public void VerifyRedoParameter()
        {
            //Arrange
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            Utility.SetFieldValue(planEditor, "_currentParameterStack", 0);
            var parameterSessionInfo = GetParameterSessionInfo();
            Utility.SetFieldValue(planEditor, "_currentParameterSessionInfo", parameterSessionInfo);
            var parameterStacks = Utility.GetInstanceField(typeof(BusinessLayer.ParameterEditor), planEditor, "_parameterStacks") as List<ParameterEditorStack>;
            ParameterEditorStack stack = new ParameterEditorStack();
            stack.KvpDocument = new IKVPDocument(IntPtr.Zero, false);
            stack.StackId = 1;
            parameterStacks.Add(stack);

            //Act
            planEditor.RedoParameter();

            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
            var currentParameterStack = (int)Utility.GetInstanceField(typeof(BusinessLayer.ParameterEditor),
                planEditor, "_currentParameterStack");
            Assert.AreEqual(1, currentParameterStack);
        }

        /// <summary>
        /// Verify Dispose
        /// </summary>
        [Test]
        public void VerifyDispose()
        {
            var planEditor = GetPlanEditor();
            planEditor.Dispose();
        }


        /// <summary>
        /// Test SetActiveGroup With Same Id
        /// </summary>
        [Test]
        [TestCaseSource(nameof(SetActiveGroupTestSource))]
        public void VerifySetActiveGroupWithSameId(GroupIds groupId)
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_PROC.image_types", Utility.GetEnumTypeParameter("EX_PROC.image_types"));
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            GetProtocolMetaDataMock(2);
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            var parameterSessionInfo = GetParameterSessionInfo();

            var planEditor = new BusinessLayer.ParameterEditor(_container);
            planEditor.ParameterEditorUpdated += ParameterEditorUpdated;
            planEditor.StartSession(parameterSessionInfo);

            //Act
            planEditor.SetActiveGroup((int)groupId);

            //Assert
            var lastActiveGroupId = -1;
            int.TryParse(
                Utility.GetInstanceField(typeof(BusinessLayer.ParameterEditor), planEditor, "_lastActiveGroupId")
                    .ToString(), out lastActiveGroupId);
            //Verify that the lastactivegroupid is same as the new id passed.
            Assert.AreEqual(lastActiveGroupId == (int)groupId, true);

        }

        /// <summary>
        /// Test Populating GroupParameterEditorDto
        /// </summary>
        [Test]
        public void VerifyPopulatingParameterEditorDto()
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_PROC.image_types", Utility.GetEnumTypeParameter("EX_PROC.image_types"));
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            GetProtocolMetaDataMock(2);
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            var parameterSessionInfo = GetParameterSessionInfo();
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            planEditor.ParameterEditorUpdated += ParameterEditorUpdated;

            //Act
            planEditor.StartSession(parameterSessionInfo);

            //Assert
            Assert.AreNotEqual(_parameterEditorDto, null);
            if (_parameterEditorDto != null)
            {
                //Verify whether the instances of ScanInfoBarDto, InfoParameterGroupDto and ParameterGroups is same as mocked values or not.
                Assert.NotNull(_parameterEditorDto.ScanInfoBarDto);
                Assert.NotNull(_parameterEditorDto.InfoParameterGroupDto);
            }
            planEditor.ParameterEditorUpdated -= ParameterEditorUpdated;
        }

        private bool errorOccurred = false;
        private void PlanEditor_ErrorOccured(object sender, EventArgs e)
        {
            errorOccurred = true;
        }

        private BusinessLayer.ParameterEditor GetPlanEditor()
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_PROC.image_types", Utility.GetEnumTypeParameter("EX_PROC.image_types"));
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            GetProtocolMetaDataMock(2);
            var parameterSessionInfo = GetParameterSessionInfo();
            var planEditor = new BusinessLayer.ParameterEditor(_container);
            planEditor.StartSession(parameterSessionInfo);
            return planEditor;
        }


        private static IEnumerable<TestCaseData> TestEndSessionSource
        {
            get
            {
                yield return
                    new TestCaseData(false);
                yield return
                    new TestCaseData(true);

            }
        }


        private static IEnumerable<TestCaseData> SetCoilSmartSelectionTestSource
        {
            get
            {
                yield return
                    new TestCaseData(false, false);
                yield return
                    new TestCaseData(true, false);
                yield return
                    new TestCaseData(true, true);

            }
        }

        private static IEnumerable<TestCaseData> SetActiveGroupTestSource
        {
            get
            {
                yield return new TestCaseData(GroupIds.ScanInfoParameterGroupId);
                yield return new TestCaseData(GroupIds.Summary);
                yield return new TestCaseData(GroupIds.Physio);
            }
        }

        private static IEnumerable<TestCaseData> TestUpdateScanProtocol
        {
            get
            {
                yield return
                    new TestCaseData(false);
                yield return
                    new TestCaseData(true);

            }
        }

        internal static IEnumerable ResolveConflictTestSource
        {
            get
            {
                yield return new TestCaseData("", "Key", false);
                yield return new TestCaseData("", DefaultSuggestion, false);
                yield return new TestCaseData("", DefaultSuggestion, true);
            }
        }
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History