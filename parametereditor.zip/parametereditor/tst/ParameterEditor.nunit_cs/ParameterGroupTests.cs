#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterGroupTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using NUnit.Framework;
using Philips.PmsMR.ParameterEditor.BusinessLayer;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Unit Test class for ParameterGroup
    /// </summary>
    public class ParameterGroupTests
    {
        private ConflictParameterGroup _conflictParameterGroup;
        private IUnityContainer _container;
        private GroupInfo _groupInfo;
        private ParameterGroup _initialParameterGroup;
        private ParameterGroup _parameterGroup;
        private ParameterSessionInfo _parameterSessionInfo;
        private IScanProtocalWrapper _scanProtocalWrapper;

        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            _container = new UnityContainer();
            _groupInfo = new GroupInfo { name = "d", id = 1, parameterCount = 3 };
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());

            var objIntVector = new IntVector();
            objIntVector.Add(1);
            objIntVector.Add(2);
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(objIntVector);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");

            var objFloatVector = new FloatVector();
            objFloatVector.Add(1);
            objFloatVector.Add(2);

            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");

            var kVpNodeMock = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(objIntVector);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(objFloatVector);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");

            var _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();

            _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);


            _parameterSessionInfo = new ParameterSessionInfo();
            _parameterSessionInfo.ScanProtocol = _scanProtocol;
            _parameterSessionInfo.BaselineProtocol = _scanProtocol;
            _parameterSessionInfo.ScanProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.BaselineProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.IsEditMode = true;
            _parameterSessionInfo.IsInConflict = false;


            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
            }
            _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(2);
        }

        /// <summary>
        /// Test whether only the enabled GroupParameters are populated
        /// </summary>
        [Test]
        public void VerifyEnabledGroupParametersArePopulated()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            dic2.Add("EX_CARD.EnumSync", Utility.GetEnumTypeParameter("EX_CARD.EnumSync"));
            dic2.Add("EX_CARD.FloatSync", Utility.GetFloatTypeParameter("EX_CARD.FloatSync"));
            dic2.Add("EX_CARD.StringSync", Utility.GetStringTypeParameter("EX_CARD.StringSync"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            _parameterGroup = new ParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _parameterGroup.Active = true;

            //Act
            var parameterGroupDtoactive = _parameterGroup.PopulateGroup();

            //Assert
            Assert.AreEqual(parameterGroupDtoactive.Parameters.Count, 4);
            Assert.AreEqual(parameterGroupDtoactive.Parameters.ContainsKey("EX_CARD.IntSync"), true);
            Assert.AreEqual(parameterGroupDtoactive.Parameters.ContainsKey("EX_CARD.EnumSync"), true);
            Assert.AreEqual(parameterGroupDtoactive.Parameters.ContainsKey("EX_CARD.FloatSync"), true);
            Assert.AreEqual(parameterGroupDtoactive.Parameters.ContainsKey("EX_CARD.StringSync"), true);

            //Test if parameters are not populated if group is disabled
            //Arrange
            _parameterGroup.Active = false;

            //Act
            var parameterGroupDto = _parameterGroup.PopulateGroup();

            //Assert
            Assert.AreEqual( 0, parameterGroupDto.Parameters.Count);
        }

        /// <summary>
        /// Test Conflict ParameterGroupIndex
        /// </summary>
        [Test]
        public void VerifyConflictParameterGroupIndex()
        {
            //Arrange
            _groupInfo.id = (int)GroupIds.Conflicts;

            //Act
            _conflictParameterGroup = new ConflictParameterGroup(_container, _groupInfo, _parameterSessionInfo);

            //Assert
            var groupIndex = -1;
            int.TryParse(
                Utility.GetInstanceField(typeof(ParameterGroup), _conflictParameterGroup, "_index").ToString(),
                out groupIndex);
            //Verify conflict ParameterGroupIndex
            Assert.AreEqual(groupIndex, ParameterGroupConstants.TopMostGroupIndex);
        }

        /// <summary>
        /// Test Initial ParameterGroupIndex
        /// </summary>
        [Test]
        public void VerifyInitialParameterGroupIndex()
        {
            //Arrange
            _groupInfo.id = (int)GroupIds.Initial;

            //Act
            _initialParameterGroup = new ParameterGroup(_container, _groupInfo, _parameterSessionInfo);

            //Assert
            var groupIndex = -1;
            int.TryParse(Utility.GetInstanceField(typeof(ParameterGroup), _initialParameterGroup, "_index").ToString(),
                out groupIndex);
            //Verify inital ParameterGroupIndex
            Assert.AreEqual(groupIndex, ParameterGroupConstants.TopMostGroupIndex + 1);
        }
        /// <summary>
        /// Test Only Visible Parameters Are Added
        /// </summary>
        [Test]
        public void VerifyOnlyVisibleParametersAreAdded()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.StringSync", Utility.GetStringTypeParameter("EX_CARD.StringSync"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            _parameterGroup = new ParameterGroup(_container, _groupInfo, _parameterSessionInfo);

            
            //Act
            _parameterGroup.Active = true;
            var parameterGroupDtoactive = _parameterGroup.PopulateGroup();

            //Test Only Visible Parameters Are Added
            //Assert
            Assert.AreEqual( 1, parameterGroupDtoactive.Parameters.Count);
            Assert.AreEqual(parameterGroupDtoactive.Parameters.ContainsKey("invisibleParam"), false);
            Assert.AreEqual(parameterGroupDtoactive.Parameters.ContainsKey("EX_CARD.StringSync"), true);

        }
        /// <summary>
        /// Test SetActiveGroup if active 
        /// </summary>
        [Test]
        public void VerifySetActiveGroupIfActive()
        {
            //Arrange
            _parameterGroup = new ParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _parameterGroup.Active = false;

            //Test SetActiveGroup if active 
            //Act
            _parameterGroup.SetActiveGroup();

            //Assert
            Assert.IsTrue(_parameterGroup.Active);
        }
        /// <summary>
        /// Test SetActiveGroup if not active 
        /// </summary>
        [Test]
        public void VerifySetActiveGroupIfNotActive()
        {
            //Arrange
            _parameterGroup = new ParameterGroup(_container, _groupInfo, _parameterSessionInfo);

            //Act
            _parameterGroup.Active = false;
            _parameterGroup.SetActiveGroup();

            //Test SetActiveGroup if not active 
            Assert.IsTrue(_parameterGroup.Active);

        }
        /// <summary>
        /// Test ParameterGroupIdToIndexConverter
        /// </summary>
        [Test]
        public void VerifyParameterGroupIdToIndexConverter()
        {
            //Create a map of GroupId's to index
            Dictionary<int, int> idToIndexMap = new Dictionary<int, int>();
            idToIndexMap.Add((int)GroupIds.Physio, ParameterGroupConstants.TopMostGroupIndex + 2);
            idToIndexMap.Add((int)GroupIds.Initial, ParameterGroupConstants.TopMostGroupIndex + 1);
            idToIndexMap.Add((int)GroupIds.Summary, ParameterGroupConstants.TopMostGroupIndex + 1);
            idToIndexMap.Add((int)GroupIds.Conflicts, ParameterGroupConstants.TopMostGroupIndex);
            idToIndexMap.Add((int)GroupIds.Protocols, (int)GroupIds.Protocols);
            idToIndexMap.Add((int)GroupIds.ScanInfoParameterGroupId, (int)GroupIds.ScanInfoParameterGroupId);
            idToIndexMap.Add((int)GroupIds.InfoParameterGroupId, (int)GroupIds.InfoParameterGroupId);
            //Verify the map with the returned index.
            foreach (var id in idToIndexMap.Keys)
            {
                Assert.AreEqual(ParameterGroupIdToIndexConverter.Convert(id), idToIndexMap[id]);
            }
        }
        /// <summary>
        /// Verify Order of Index
        /// </summary>
        [Test]
        public void VerifyOrderofIndex()
        {
            //Create a map of GroupId's to index
            Dictionary<int, int> idToIndexMap = new Dictionary<int, int>();
            //Add id's for the groups
            idToIndexMap.Add((int)GroupIds.Summary, ParameterGroupIdToIndexConverter.Convert((int)GroupIds.Summary));
            idToIndexMap.Add((int)GroupIds.Physio, ParameterGroupIdToIndexConverter.Convert((int)GroupIds.Physio));
            idToIndexMap.Add((int)GroupIds.Conflicts, ParameterGroupIdToIndexConverter.Convert((int)GroupIds.Conflicts));

            //Geometry Group
            idToIndexMap.Add(1, ParameterGroupIdToIndexConverter.Convert(1));
            //Contrast
            idToIndexMap.Add(2, ParameterGroupIdToIndexConverter.Convert(2));

            var sortedDictionary = idToIndexMap.OrderBy(x => x.Value).ToDictionary(x => x.Key, x => x.Value); 
            var sortedKeys = new List<int>(sortedDictionary.Keys);
            //Creating a expected List of Id's in the correct expected order.
            var expectedTop3SortedGroups = new List<int> { (int)GroupIds.Conflicts, (int)GroupIds.Summary, (int)GroupIds.Physio};
            int i = 0;
            foreach (var expectedSortedGroup in expectedTop3SortedGroups)
            {
                Assert.AreEqual(expectedSortedGroup, sortedKeys[i]);
                i++;
            }
        }
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History