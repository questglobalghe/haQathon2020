#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: Utility.cs
//

#endregion

using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Utility class to combine all the commonly used methods across the project.
    /// </summary>
    public static class Utility
    {
        #region Private Static Fields
        static StringVector Initialvectors = new StringVector { "Initial" };
        static StringVector Physiologyvectors = new StringVector { "Physiology" };
        static StringVector Geometryvectors = new StringVector { "Geometry" };
        static StringVector PostprocVectors = new StringVector { "Postproc" };
        static StringVector Defaultvectors = new StringVector { "Default" };
        static IKVPNodeMock kvpInitialNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpPhysiologyNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpGeometryNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpSDelayedReconNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpDefaultNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static string InfoBar = "Info Bar";
        #endregion

        #region Public Static Fields
        /// <summary>
        /// tabNameMapping
        /// </summary>
        public static Dictionary<string, string> tabNameMapping;
        #endregion

        #region Static Constructor
        static Utility()
        {
            tabNameMapping = new Dictionary<string, string>();


            tabNameMapping.Add("MGG_SOFTKEY_0", "Geometry");
            tabNameMapping.Add("MGG_SOFTKEY_1", "Summary");
            tabNameMapping.Add("MGG_SOFTKEY_ALL", "Physiology");
            tabNameMapping.Add("MGG_SOFTKEY_CONFL", "Physiology");
            tabNameMapping.Add("MGG_SOFTKEY_2", "Physiology");
            tabNameMapping.Add("MGG_SOFTKEY_3", "Geometry");
            tabNameMapping.Add("MGG_SOFTKEY_4", "Contrast");
            tabNameMapping.Add("MGG_SOFTKEY_5", "Dyn/Ang");
            tabNameMapping.Add("MGG_SOFTKEY_6", "Initial");
            tabNameMapping.Add("MGG_SOFTKEY_ROUTINE", "Summary");
            tabNameMapping.Add("MGG_SOFTKEY_PHYSIO", "Postproc");
            tabNameMapping.Add("MGG_SOFTKEY_INFO", InfoBar);

        }

        #endregion

        #region Public Static Methods

        /// <summary>
        ///     Uses reflection to set the field value from an object.
        /// </summary>
        /// <param name="instance">The instance object.</param>
        /// <param name="fieldName">The field's name whose value has to be set</param>
        /// <param name="settingValue">The value to be set</param>
        public static void SetFieldValue(object instance, string fieldName, object settingValue)
        {
            var bindFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
            var field = instance.GetType().GetField(fieldName, bindFlags);
            if (field != null) field.SetValue(instance, settingValue);
        }


        /// <summary>
        ///     Uses reflection to get the property value from an object.
        /// </summary>
        /// <param name="type">The instance type.</param>
        /// <param name="instance">The instance object.</param>
        /// <param name="propertyName">The property's name which is to be fetched.</param>
        /// <returns>The field value from the object.</returns>
        /// <returns></returns>
        internal static object GetInstanceProperty(Type type, object instance, string propertyName)
        {
            var bindFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic
                            | BindingFlags.Static;
            var property = type.GetProperty(propertyName, bindFlags);
            if (property == null)
            {
                return null;
            }
            return property.GetValue(instance);
        }

        /// <summary>
        ///     Uses reflection to get the field value from an object.
        /// </summary>
        /// <param name="type">The instance type.</param>
        /// <param name="instance">The instance object.</param>
        /// <param name="fieldName">The field's name which is to be fetched.</param>
        /// <returns>The field value from the object.</returns>
        internal static object GetInstanceField(Type type, object instance, string fieldName)
        {
            var bindFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic
                            | BindingFlags.Static | BindingFlags.FlattenHierarchy;
            var field = type.GetField(fieldName, bindFlags);
            if (field == null)
            {
                return null;
            }
            return field.GetValue(instance);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="getTabHierarchyValue"></param>
        /// <returns></returns>
        public static StringVector GetParametersPathValue(IKVPNode getTabHierarchyValue)
        {
            if (getTabHierarchyValue.GetName() == "Initial")
            {
                return Initialvectors;
            }
            else if (getTabHierarchyValue.GetName() == "Physiology")
            {
                return Physiologyvectors;
            }
            else if (getTabHierarchyValue.GetName() == "Geometry")
            {
                return Geometryvectors;
            }
            else if (getTabHierarchyValue.GetName() == "Postproc")
            {
                return PostprocVectors;
            }
            else
            {
                return Defaultvectors;
            }
        }

        /// <summary>
        /// GetTabNames
        /// </summary>
        /// <returns></returns>
        public static StringVector GetTabNames()
        {
            StringVector tabNames = new StringVector();
            tabNames.Add("MGG_SOFTKEY_0");
            tabNames.Add("MGG_SOFTKEY_1");
            tabNames.Add("MGG_SOFTKEY_ALL");
            tabNames.Add("MGG_SOFTKEY_CONFL");
            tabNames.Add("MGG_SOFTKEY_2");
            tabNames.Add("MGG_SOFTKEY_3");
            tabNames.Add("MGG_SOFTKEY_4");
            tabNames.Add("MGG_SOFTKEY_5");
            tabNames.Add("MGG_SOFTKEY_6");
            tabNames.Add("MGG_SOFTKEY_ROUTINE");
            tabNames.Add("MGG_SOFTKEY_PHYSIO");
            tabNames.Add("MGG_SOFTKEY_INFO");
            return tabNames;

        }

        /// <summary>
        /// GetTabHierarchy
        /// </summary>
        /// <param name="tabName"></param>
        /// <returns>IKVPNode</returns>
        public static IKVPNode GetTabHierarchyValue(string tabName)
        {
            if (tabName == "Initial")
            {
                kvpInitialNode.Stub(x => x.GetName()).Return(tabName);
                return kvpInitialNode;
            }
            else if (tabName == "Physiology")
            {
                kvpPhysiologyNode.Stub(x => x.GetName()).Return(tabName);
                return kvpPhysiologyNode;
            }
            else if (tabName == "Geometry")
            {
                kvpGeometryNode.Stub(x => x.GetName()).Return(tabName);
                return kvpGeometryNode;
            }
            else if (tabName == "Postproc")
            {
                kvpSDelayedReconNode.Stub(x => x.GetName()).Return(tabName);
                return kvpSDelayedReconNode;
            }
            else
            {
                kvpDefaultNode.Stub(x => x.GetName()).Return(tabName);
                return kvpDefaultNode;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isVisible"></param>
        /// <param name="range"></param>
        /// <param name="type"></param>
        /// <param name="nameTag"></param>
        /// <param name="helpTag"></param>
        /// <param name="isConflict"></param>
        /// <param name="enumDataType"></param>
        /// <param name="adjustValue"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetParameterMetaDataMock(bool isVisible, string range, Scanning.IMethods.TypeInfo type, string nameTag, string helpTag,
            bool isConflict, string enumDataType, double adjustValue = 1.0f)
        {
            var parametaData = MockRepository.GenerateMock<ParameterMetaDataMock>();
            parametaData.Stub(x => x.GetVisible()).Return(isVisible);
            parametaData.Stub(x => x.GetRange()).Return(range);
            parametaData.Stub(x => x.GetDataType()).Return(type);
            parametaData.Stub(x => x.GetNameTag()).Return(nameTag);
            parametaData.Stub(x => x.GetHelpTag()).Return(helpTag);
            parametaData.Stub(x => x.GetConflict()).Return(isConflict);
            parametaData.Stub(x => x.GetEnumDataType()).Return(enumDataType);
            parametaData.Stub(x => x.GetAdjustValue()).Return(adjustValue);
            // parametaData.Stub(x=> x.)
            return parametaData;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetIntTypeParameter(string fieldName)
        {
            return GetParameterMetaDataMock(true, "1-1,2-2,3-3", Scanning.IMethods.TypeInfo.TypeInteger, fieldName, fieldName + ".help",
                false, "int", 3);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="isVisisble"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetEnumTypeParameter(string fieldName, bool isVisisble = true)
        {
            return GetParameterMetaDataMock(isVisisble, "1-1,2-2", Scanning.IMethods.TypeInfo.TypeEnum, fieldName, fieldName + ".help",
                false, "string");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="enumNames"></param>
        /// <param name="enumTexts"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetEnumTypeParameter(string fieldName, string[] enumNames, string[] enumTexts)
        {
            return GetParameterMetaDataMock(true, "1-1,2-2", Scanning.IMethods.TypeInfo.TypeEnum, fieldName, fieldName + ".help",
                false, "string");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetFloatTypeParameter(string fieldName)
        {
            return GetParameterMetaDataMock(true, "5.0-5.0,560.0-560.0", Scanning.IMethods.TypeInfo.TypeFloat, fieldName, fieldName + ".help",
                false, "string", 34.0f);
        }

        /// <summary>
        /// GetStringTypeParameter
        /// </summary>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetStringTypeParameter(string fieldName)
        {
            return GetParameterMetaDataMock(true, "5.0-5.0,560.0-560.0", Scanning.IMethods.TypeInfo.TypeString, "", fieldName + ".help",
                false, "string");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="currentNodeValueSize"></param>
        public static ScanProtocolMetaDataMock GetProtocolMetaDataMock(uint currentNodeValueSize = 2)
        {
            var _protocolMetaDataMock = MockRepository.GenerateMock<ScanProtocolMetaDataMock>();
            _protocolMetaDataMock.Stub(x => x.GetTabNames()).Return(Utility.tabNameMapping.Keys.ToList());
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _protocolMetaDataMock.Stub(x => x.GetTabHierarchy(tabNameMapping.Key))
                    .Return(Utility.GetTabHierarchyValue(tabNameMapping.Value));
            }

            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _protocolMetaDataMock.Stub(x =>
                        x.GetParametersPath(Utility.GetTabHierarchyValue(tabNameMapping.Value)))
                    .Return(Utility.GetParametersPathValue(
                        Utility.GetTabHierarchyValue(tabNameMapping.Value)));
            }

            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(new StringVector())).IgnoreArguments()
                .Return(null);

            return _protocolMetaDataMock;
        }

        /// <summary>
        /// GetParametersPath
        /// </summary>
        /// <param name="kvpNode"></param>
        /// <returns>StringVector</returns>
        public static StringVector GetParametersPath(IKVPNode kvpNode)
        {

            StringVector vectors = new StringVector();
            foreach (var vector in kvpNode.GetLeaves())
            {
                vectors.Add(vector.Remove(vector.IndexOf("ProtocolBuffer"), "ProtocolBuffer".Length + 1));
            }
            return vectors;
        }
        #endregion
        
        #region Mocked Entities
        /// <summary>
        ///     ScanProtocolMetaDataMock
        /// </summary>
        [Serializable]
        public class ScanProtocolMetaDataMock : IScanProtocolMetaData
        {
            /// <summary>
            /// ScanProtocolMetaDataMock
            /// </summary>
            /// <returns></returns>
            public ScanProtocolMetaDataMock() : base(IntPtr.Zero, false)
            {

            }

        }

        /// <summary>
        ///     ParameterMetaDataMock
        /// </summary>
        public class ParameterMetaDataMock : IParameterMetaData
        {
            /// <summary>
            /// 
            /// </summary>
            public ParameterMetaDataMock() : base(IntPtr.Zero, false)
            {

            }

            /// <summary>
            /// 
            /// </summary>
            public string ParameterPath { get; internal set; }
        }

        /// <summary>
        /// IKVPNodeMock
        /// </summary>
        public class IKVPNodeMock : IKVPNode
        {
            /// <summary>
            /// 
            /// </summary>
            public IKVPNodeMock() : base(IntPtr.Zero, false)
            {

            }
        }

        /// <summary>
        ///     ScanProtocolMock
        /// </summary>
        [Serializable]

        public class ScanProtocolMock : IScanProtocol
        {
            /// <summary>
            /// ScanProtocolMock
            /// </summary>
            public ScanProtocolMock() : base(IntPtr.Zero, false)
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        public class ConflictGuidanceSuggestionsMock : ConflictGuidanceSuggestions
        {
            /// <summary>
            /// 
            /// </summary>
            public ConflictGuidanceSuggestionsMock() : base(0)
            {


            }
        }

        /// <summary>
        /// 
        /// </summary>
        public class ICoilSelectionMock : ICoilSelection
        {
            /// <summary>
            /// 
            /// </summary>
            public ICoilSelectionMock() : base(IntPtr.Zero, false)
            {


            }
        }

        /// <summary>
        /// 
        /// </summary>
        public class IValidationContextMock : IValidationContext
        {
            /// <summary>
            /// 
            /// </summary>
            public IValidationContextMock() : base(IntPtr.Zero, false)
            {

            }
        }

        #endregion
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History