#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: PhysiologyParameterGroupTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using NUnit.Framework;
using Philips.PmsMR.ParameterEditor.BusinessLayer;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System.Collections.Generic;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Unit Test class for PhysiologyParameterGroup
    /// </summary>
    public class PhysiologyParameterGroupTests
    {
        #region Private fields
        private readonly IUnityContainer _container = new UnityContainer();
        private GroupInfo _groupInfo;
        private PhysiologyParameterGroup _physiologyParameterGroup;
        private ParameterSessionInfo _parameterSessionInfo;
        private IScanProtocalWrapper _scanProtocalWrapper;
        #endregion


        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            _groupInfo = new GroupInfo { name = "d", id = (int)GroupIds.Physio, parameterCount = 3 };
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());
            XmlParseUtility.InitializeXmlParse();

            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
            }
            _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(1);

        }
        
        #region Tests
        /// <summary>
        /// Check Physiology Parameters are getting filled or not.
        /// </summary>
        [Test]
        public void VerifyPhysiologyParametersAreFilled()
        {
            //Arrange
            var uniqueIds = new List<string>();
            uniqueIds.Add("EX_CARD.device");
            uniqueIds.Add("EX_CARD.rr_interval_window");
            uniqueIds.Add("EX_CARD.arrhythmia_rej");
            uniqueIds.Add("EX_CARD.nr_heart_phases");
            uniqueIds.Add("EX_CARD.heart_phase_control");
            uniqueIds.Add("EX_CARD.trig_delay_enum");
            uniqueIds.Add("EX_CARD.gate_delay_ms");
            uniqueIds.Add("EX_CARD.gate_delay");
            uniqueIds.Add("EX_CARD.sync");
            uniqueIds.Add("EX_RESP.hold");
            uniqueIds.Add("EX_RESP.trig_delay");
            uniqueIds.Add("EX_RESP.slices_per_package");
            uniqueIds.Add("EX_RESP.user_def_bh_time_enum");
            uniqueIds.Add("EX_RESP.user_def_bh_time_sec");
            uniqueIds.Add("EX_ACQ.partial_matrix");
            uniqueIds.Add("EX_ACQ.scan_mode");
            uniqueIds.Add("EX_RNAV.gating_level_drift");
            uniqueIds.Add("EX_RESP.breathhold_instr");
            uniqueIds.Add("EX_RESP.autovoice_bh");
            uniqueIds.Add("EX_RNAV.gating_window");
            uniqueIds.Add("EX_RNAV.scale_factor");
            uniqueIds.Add("EX_RESP.synch");
            uniqueIds.Add("EX_RNAV.resp_comp");
            uniqueIds.Add("EX_CARD.trig_delay");
            var dic2 = new Dictionary<string, IParameterMetaData>();
            foreach (var uniqueId in uniqueIds)
            {
                dic2.Add(uniqueId, Utility.GetEnumTypeParameter(uniqueId));
            }
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.HeartPhaseEnum, 0)).IgnoreArguments().Return("MPUCARD_HPC_ONE");
            GetParameterSessionInfo(2);
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _physiologyParameterGroup.Active = true;

            //Act
            var dto = _physiologyParameterGroup.PopulateGroup();

            //Assert
            Assert.AreEqual(dto.Parameters.Count, uniqueIds.Count);
            foreach (var uniqueId in uniqueIds)
            {
                //Verify whether all the physio parameters are getting added or not.
                Assert.AreEqual(dto.Parameters.ContainsKey(uniqueId), true);
            }
        }

        /// <summary>
        /// Check Physiology InfoParameters are getting filled or not.
        /// </summary>
        [Test]
        public void VerifyPhysiologyInfoParametersAreFilled()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("IF.max_heart_phases", Utility.GetEnumTypeParameter("IF.max_heart_phases"));
            dic2.Add("IF.act_gate_delay", Utility.GetEnumTypeParameter("IF.act_gate_delay"));
            dic2.Add("IF.no_trig_period_trig_del", Utility.GetEnumTypeParameter("IF.no_trig_period_trig_del"));
            dic2.Add("IF.resp_trig_dur", Utility.GetEnumTypeParameter("IF.resp_trig_dur"));
            var dic1 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.trig_delay_enum", Utility.GetEnumTypeParameter("EX_CARD.trig_delay_enum"));
            dic2.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", false));
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                if (tabNameMapping.Value == "Physiology")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic2);
                }
                else
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic1);
                }
            }
            GetParameterSessionInfo(2);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue(EnumNames.HeartPhaseEnum, 0)).IgnoreArguments().Return("MPUCARD_HPC_ONE");
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _physiologyParameterGroup.Active = true;

            //Act
            var dto = _physiologyParameterGroup.PopulateGroup();

            //Assert
            //Verify whether all the physio infoParameters are getting added or not.
            Assert.AreEqual(dto.Parameters.Count, 6);
            Assert.AreEqual(dto.Parameters.ContainsKey("IF.max_heart_phases"), true);
            Assert.AreEqual(dto.Parameters.ContainsKey("IF.act_gate_delay"), true);
            Assert.AreEqual(dto.Parameters.ContainsKey("IF.no_trig_period_trig_del"), true);
            Assert.AreEqual(dto.Parameters.ContainsKey("IF.resp_trig_dur"), true);
            Assert.AreEqual(dto.Parameters.ContainsKey("EX_CARD.trig_delay_enum"), true);
        }

        /// <summary>
        /// Check Physiology invalid Parameters are not getting filled.
        /// </summary>
        [Test]
        public void VerifyPhysiologyInvalidParametersAreNotFilled()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("InvalidParameter", Utility.GetEnumTypeParameter("InvalidParameter"));
            dic2.Add("InvalidInfoParameter", Utility.GetEnumTypeParameter("InvalidInfoParameter"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            GetParameterSessionInfo(2);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue(EnumNames.HeartPhaseEnum, 0)).IgnoreArguments().Return("MPUCARD_HPC_ONE");
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _physiologyParameterGroup.Active = true;

            //Act
            var dto = _physiologyParameterGroup.PopulateGroup();

            //Verify whether all the Invalid Parameters are not getting added.
            //Assert
            Assert.AreEqual(dto.Parameters.Count, 0);
            Assert.AreEqual(dto.Parameters.ContainsKey("InvalidParameter"), false);
            Assert.AreEqual(dto.Parameters.ContainsKey("InvalidInfoParameter"), false);
        }

        /// <summary>
        /// Test whether UpdateHeartPhase Parameters are visible or not.
        /// </summary>
        /// <param name="enumValue"></param>
        /// <param name="expectedHeartPhasesControlResult"></param>
        /// <param name="expectedMaxHeartPhasesResult"></param>
        [Test]
        [TestCaseSource(nameof(TestUpdateHeartPhaseParametersSource))]
        public void VerifyUpdateHeartPhaseParameters(int enumValue, bool expectedHeartPhasesControlResult,
            bool expectedMaxHeartPhasesResult)
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.nr_heart_phases", Utility.GetEnumTypeParameter("EX_CARD.nr_heart_phases"));
            dic2.Add("IF.max_heart_phases", Utility.GetEnumTypeParameter("IF.max_heart_phases"));
            dic2.Add("EX_CARD.heart_phase_control", Utility.GetEnumTypeParameter("EX_CARD.heart_phase_control", expectedHeartPhasesControlResult));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            GetParameterSessionInfo(enumValue);
            //"2":"MPUCARD_HPC_MAXIMUM","0":"MPUCARD_HPC_ONE","1":"MPUCARD_HPC_USER_DEF"
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.HeartPhaseEnum, 0)).Return("MPUCARD_HPC_ONE");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.HeartPhaseEnum, 1)).Return("MPUCARD_HPC_USER_DEF");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.HeartPhaseEnum, 2)).Return("MPUCARD_HPC_MAXIMUM");
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _physiologyParameterGroup.Active = true;

            //Act
            var dto = _physiologyParameterGroup.PopulateGroup();

            //Assert
            //Verify the HeartPhase Parameters are visible or not.
            Assert.AreEqual(dto.Parameters["EX_CARD.nr_heart_phases"].Visible, expectedHeartPhasesControlResult);
            Assert.AreEqual(dto.Parameters["IF.max_heart_phases"].Visible, expectedMaxHeartPhasesResult);
        }



        /// <summary>
        /// VerifyUpdateGateDelayParameters
        /// </summary>
        /// <param name="enumValue"></param>
        /// <param name="expectedExParamVisibility"></param>
        [Test]
        [TestCaseSource(nameof(TestUpdateGateDelayParametersSource))]
        public void VerifyUpdateGateDelayParameters(int enumValue, bool expectedExParamVisibility)
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.gate_delay_ms", Utility.GetEnumTypeParameter("EX_CARD.gate_delay_ms"));
            dic2.Add("IF.act_gate_delay", Utility.GetEnumTypeParameter("IF.act_gate_delay"));
            GetParameterSessionInfo(enumValue);
            dic2.Add("EX_CARD.gate_delay", Utility.GetEnumTypeParameter("EX_CARD.gate_delay"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            //"5":"MGG_TIME_BETWEEN","1":"MGG_TIME_DEFAULT","4":"MGG_TIME_LONGEST","0":"MGG_TIME_MANUAL","2":"MGG_TIME_SHORTEST","3":"MGG_TIME_USER_DEF"
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacGateDelayEnum, 0)).Return("MGG_TIME_MANUAL");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacGateDelayEnum, 1)).Return("MGG_TIME_DEFAULT");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacGateDelayEnum, 2)).Return("MGG_TIME_SHORTEST");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacGateDelayEnum, 3)).Return("MGG_TIME_USER_DEF");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacGateDelayEnum, 4)).Return("MGG_TIME_LONGEST");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacGateDelayEnum, 5)).Return("MGG_TIME_BETWEEN");
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _physiologyParameterGroup.Active = true;

            //Act
            var dto = _physiologyParameterGroup.PopulateGroup();

            //Verify the GateDelay Parameters are visible or not.
            //Assert
            Assert.AreEqual(dto.Parameters["EX_CARD.gate_delay_ms"].Visible, expectedExParamVisibility);
            Assert.AreEqual(dto.Parameters["IF.act_gate_delay"].Visible, !expectedExParamVisibility);
        }

        /// <summary>
        /// Test whether TriggerDelay Parameters are visible or not.
        /// </summary>
        /// <param name="enumValue"></param>
        /// <param name="expectedExParamVisibility">It represents the expected result of Ex Parameter</param>
        [Test]
        [TestCaseSource(nameof(TestUpdateTriggerDelayParametersSource))]
        public void VerifyUpdateTriggerDelayParameters(int enumValue, bool expectedExParamVisibility)
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.trig_delay", Utility.GetEnumTypeParameter("EX_CARD.trig_delay"));
            dic2.Add("IF.no_trig_period_trig_del", Utility.GetEnumTypeParameter("IF.no_trig_period_trig_del"));
            GetParameterSessionInfo(enumValue);
            dic2.Add("EX_CARD.trig_delay_enum", Utility.GetEnumTypeParameter("EX_CARD.trig_delay_enum"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            //"3":"MPUCARD_TRIG_END_DIA","5":"MPUCARD_TRIG_LONGEST","2":"MPUCARD_TRIG_MID_DIA","0":"MPUCARD_TRIG_SHORTEST","1":"MPUCARD_TRIG_USER_DEF","4":"MPUCARD_TRIG_USER_DEF_TABLE"
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacTriggerDelayEnum, 0)).Return("MPUCARD_TRIG_SHORTEST");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacTriggerDelayEnum, 1)).Return("MPUCARD_TRIG_USER_DEF");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacTriggerDelayEnum, 2)).Return("MPUCARD_TRIG_MID_DIA");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacTriggerDelayEnum, 3)).Return("MPUCARD_TRIG_END_DIA");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacTriggerDelayEnum, 4)).Return("MPUCARD_TRIG_USER_DEF_TABLE");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacTriggerDelayEnum, 5)).Return("MPUCARD_TRIG_LONGEST");
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _physiologyParameterGroup.Active = true;

            //Act
            var dto = _physiologyParameterGroup.PopulateGroup();


            //Assert
            //Verify the TriggerDelay Parameters are visible or not.
            Assert.AreEqual(dto.Parameters["EX_CARD.trig_delay"].Visible, expectedExParamVisibility);
            Assert.AreEqual(dto.Parameters["IF.no_trig_period_trig_del"].Visible, !expectedExParamVisibility);
        }

        /// <summary>
        /// Test whether UpdateBreathHoldDurationAttribute.
        /// </summary>
        [Test]
        public void VerifyUpdateBreathHoldDurationAttribute()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);

            GetParameterSessionInfo(2);
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _physiologyParameterGroup.Active = true;

            //Act
            var dto = _physiologyParameterGroup.PopulateGroup();

            //Assert
            Assert.AreEqual(dto.Parameters["EX_RESP.user_def_bh_time_sec"].Visible, true);
            Assert.AreEqual(dto.Parameters["EX_RESP.user_def_bh_time_sec"].Editable, true);
        }

        /// <summary>
        /// Test UserDefinedHeartPhasesControl even if visibility is false it will be shown in disabled format.
        /// </summary>
        [Test]
        public void VerifyUpdateUserDefinedHeartPhasesControl()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.heart_phase_control", Utility.GetEnumTypeParameter("EX_CARD.heart_phase_control"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            GetParameterSessionInfo(2);
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _physiologyParameterGroup.Active = true;

            //Act
            var dto = _physiologyParameterGroup.PopulateGroup();

            //Assert
            //Verify the UserDefinedHeartPhasesControl even if visibility is false it will be shown in disabled format
            Assert.AreEqual(dto.Parameters["EX_CARD.heart_phase_control"].Visible, true);
            Assert.AreEqual(dto.Parameters["EX_CARD.heart_phase_control"].Editable, true);
        }
        /// <summary>
        /// Test PhysiologyParameterGroup index
        /// </summary>
        [Test]
        public void VerifyPhysiologyParameterGroupIndex()
        {
            //Arrrange
            GetParameterSessionInfo(2);

            //Act
            _physiologyParameterGroup = new PhysiologyParameterGroup(_container, _groupInfo, _parameterSessionInfo);

            //Assert
            var groupIndex = -1;
            int.TryParse(
                Utility.GetInstanceField(typeof(ParameterGroup), _physiologyParameterGroup, "_index").ToString(),
                out groupIndex);
            //Verify the groupIndex of PhysiologyParameterGroup.
            Assert.AreEqual(groupIndex, ParameterGroupConstants.TopMostGroupIndex + 2);
        }

        #endregion

        #region Private methods
        private void GetParameterSessionInfo(int enumValue)
        {

            var objIntVector = new IntVector();
            objIntVector.Add(0);
            objIntVector.Add(1);
            objIntVector.Add(2);
            objIntVector.Add(3);
            objIntVector.Add(4);
            objIntVector.Add(5);
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(objIntVector);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");

            var objFloatVector = new FloatVector();
            objFloatVector.Add(0);
            objFloatVector.Add(1);
            objFloatVector.Add(2);

            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");
            objStringVector.Add("String3");

            var kVpNodeMock = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(objIntVector);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(enumValue);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(objFloatVector);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");

            var _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();
            _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);


            _parameterSessionInfo = new ParameterSessionInfo();
            _parameterSessionInfo.ScanProtocol = _scanProtocol;
            _parameterSessionInfo.BaselineProtocol = _scanProtocol;
            _parameterSessionInfo.ScanProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.BaselineProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.IsEditMode = true;
            _parameterSessionInfo.IsInConflict = false;
        }
        #endregion

        #region Test Source
        private static IEnumerable<TestCaseData> TestUpdateHeartPhaseParametersSource
        {
            get
            {
                yield return
                    new TestCaseData(0, false, false);
                yield return
                    new TestCaseData(1, true, false);
                yield return
                    new TestCaseData(2, false, true);
            }
        }

        private static IEnumerable<TestCaseData> TestUpdateGateDelayParametersSource
        {
            get
            {
                yield return
                    new TestCaseData(0, false);
                yield return
                    new TestCaseData(1, false);
                yield return
                    new TestCaseData(2, false);
                yield return
                    new TestCaseData(3, true);
                yield return
                    new TestCaseData(4, false);
                yield return
                    new TestCaseData(5, false);
            }
        }

        private static IEnumerable<TestCaseData> TestUpdateTriggerDelayParametersSource
        {
            get
            {
                yield return
                    new TestCaseData(0, false);
                yield return
                    new TestCaseData(1, true);
                yield return
                    new TestCaseData(2, false);
                yield return
                    new TestCaseData(3, false);
                yield return
                    new TestCaseData(4, false);
                yield return
                    new TestCaseData(5, false);

            }
        }
        #endregion
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History