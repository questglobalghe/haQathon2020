#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: SummaryParameterGroupTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using NUnit.Framework;
using Philips.PmsMR.ParameterEditor.BusinessLayer;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System.Collections.Generic;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Unit Test class for SummaryParameterGroup
    /// </summary>
    public class SummaryParameterGroupTests
    {
        #region Private fields
        private readonly IUnityContainer _container = new UnityContainer();
        private GroupInfo _groupInfo;
        private SummaryParameterGroup _summaryParameterGroup;
        private ParameterSessionInfo _parameterSessionInfo;
        private IScanProtocalWrapper _scanProtocalWrapper;
        #endregion

        #region Setup And TearDown
        
        
        /// <summary>
        ///     Setting up the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            _groupInfo = new GroupInfo { name = "d", id = (int)GroupIds.Summary, parameterCount = 3 };
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());
            XmlParseUtility.InitializeXmlParse();



            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
            }
            _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(1);
        }

        #endregion

        #region Test Source

        private static IEnumerable<TestCaseData> GapModeControlIsNotUserDefinedOrNotSource
        {
            get
            {
                // Test if the Gap mode control is not visible if not user defined
                yield return
                    new TestCaseData(0, false);

                // Test if the Gap mode control is not visible if not user defined
                yield return
                    new TestCaseData(1, false);

                // Test if the Gap mode control is visible if user defined
                yield return
                    new TestCaseData(2, true);


            }
        }


        #endregion
        
        #region Tests
        

        /// <summary>
        /// Test Summary Parameters are filled or not.
        /// </summary>
        [Test]
        public void VerifySummaryParametersAreFilled()
        {
            //Arrange
            var uniqueIds = new List<string>();
            uniqueIds.Add("EX_ACQ.scan_type");
            uniqueIds.Add("EX_GEO.fov");
            uniqueIds.Add("EX_GEO.fov_p");
            uniqueIds.Add("EX_STACKS[1].fov_s");
            uniqueIds.Add("EX_GEO.voxel_size_m");
            uniqueIds.Add("EX_GEO.voxel_size_p");
            uniqueIds.Add("EX_GEO.acq_voxel_size_s");
            uniqueIds.Add("EX_GEO.cur_stack_id");
            uniqueIds.Add("EX_GEO.stacks");
            uniqueIds.Add("EX_STACKS[1].slices");
            uniqueIds.Add("EX_GEO.slice_gap_mode");
            uniqueIds.Add("EX_STACKS[1].slice_gap");
            uniqueIds.Add("EX_SPIR.fat_suppression");
            uniqueIds.Add("EX_ACQ.measurements");
            uniqueIds.Add("EX_COIL.control_SAR_mode");
            var dic2 = new Dictionary<string, IParameterMetaData>();
            foreach (var uniqueId in uniqueIds)
            {
                dic2.Add(uniqueId, Utility.GetStringTypeParameter(uniqueId));
            }
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            GetParameterSessionInfo(1);
            var curParameterMetaData = Utility.GetEnumTypeParameter("EX_GEO.cur_stack_id");
            _parameterSessionInfo.ScanProtocolMetaData.Stub(x => x.GetParameterMetaData("EX_GEO.cur_stack_id")).Return(curParameterMetaData);
            _summaryParameterGroup = new SummaryParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _summaryParameterGroup.Active = true;

            //Act
            var dto = _summaryParameterGroup.PopulateGroup();

            //Assert
            //Verify all the parameters are successfully added
            Assert.AreEqual(dto.Parameters.Count, 15);
            foreach (var uniqueId in uniqueIds)
            {
                Assert.AreEqual(dto.Parameters.ContainsKey(uniqueId), true);
            }
        }


        /// <summary>
        /// Test SummaryParameterGroup Index
        /// </summary>
        [Test]
        public void VerifySummaryParameterGroupIndex()
        {
            //Arrange
            GetParameterSessionInfo(2);

            //Act
            _summaryParameterGroup = new SummaryParameterGroup(_container, _groupInfo, _parameterSessionInfo);

            //Assert
            var groupIndex = -1;
            int.TryParse(Utility.GetInstanceField(typeof(ParameterGroup), _summaryParameterGroup, "_index").ToString(),
                out groupIndex);
            //Verify the groupIndex of SummaryParameterGroup.
            Assert.AreEqual(groupIndex, ParameterGroupConstants.TopMostGroupIndex + 1);
        }

        /// <summary>
        /// Test Summary InfoParameters are Filled or not.
        /// </summary>
        [Test]
        public void VerifySummaryInfoParametersAreFilled()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("IF.act_slice_gap", Utility.GetStringTypeParameter("IF.act_slice_gap"));
            dic2.Add("IF.meas_matrix_size", Utility.GetStringTypeParameter("IF.meas_matrix_size"));
            dic2.Add("IF.sar_lvl_whole_body", Utility.GetStringTypeParameter("IF.sar_lvl_whole_body"));
            var dic1 = new Dictionary<string, IParameterMetaData>();
            dic1.Add("EX_CARD.trig_delay_enum", Utility.GetStringTypeParameter("EX_CARD.trig_delay_enum"));
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                if (tabNameMapping.Value == "Physiology")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic2);
                }
                else
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic1);
                }
            }
            GetParameterSessionInfo(2);
            _summaryParameterGroup = new SummaryParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _summaryParameterGroup.Active = true;

            //Act
            var dto = _summaryParameterGroup.PopulateGroup();

            //Assert
            //Verify all the infoParameters are successfully added
            Assert.AreEqual(dto.Parameters.Count, 3);
            Assert.AreEqual(dto.Parameters.ContainsKey("IF.act_slice_gap"), true);
            Assert.AreEqual(dto.Parameters.ContainsKey("IF.meas_matrix_size"), true);
            Assert.AreEqual(dto.Parameters.ContainsKey("IF.sar_lvl_whole_body"), true);
        }

        /// <summary>
        /// Test Summary InvalidParameters are not filled
        /// </summary>
        [Test]
        public void VerifySummaryInvalidParametersAreNotFilled()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("InvalidParameters", Utility.GetStringTypeParameter("InvalidParameters"));
            dic2.Add("InvalidInfoParameters", Utility.GetStringTypeParameter("InvalidInfoParameters"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            GetParameterSessionInfo(2);
            _summaryParameterGroup = new SummaryParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _summaryParameterGroup.Active = true;

            //Act
            var dto = _summaryParameterGroup.PopulateGroup();

            //Assert
            //Verify all the invalid Parameters are not added
            Assert.AreEqual(dto.Parameters.Count, 0);
            Assert.AreEqual(dto.Parameters.ContainsKey("InvalidParameters"), false);
            Assert.AreEqual(dto.Parameters.ContainsKey("InvalidInfoParameters"), false);
        }

        /// <summary>
        /// Test UpdateGapModeParameters
        /// </summary>
        [Test]
        [TestCaseSource(nameof(GapModeControlIsNotUserDefinedOrNotSource))]
        public void VerifyUpdateGapModeParameters(int enumValue, bool expectedGapModeIFVisibilityParameter)
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_STACKS["+ enumValue + "].slice_gap", Utility.GetStringTypeParameter("EX_STACKS[" + enumValue + "].slice_gap"));
            dic2.Add("IF.act_slice_gap", Utility.GetStringTypeParameter("IF.act_slice_gap"));
            dic2.Add("EX_GEO.slice_gap_mode", Utility.GetEnumTypeParameter("EX_GEO.slice_gap_mode"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            GetParameterSessionInfo(enumValue);
            //"0":"MGG_EXTREM_DEFAULT","3":"MGG_EXTREM_MAXIMUM","1":"MGG_EXTREM_MINIMUM","2":"MGG_EXTREM_USER_DEF"
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.GapModeEnum, 0)).Return("MGG_EXTREM_DEFAULT");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.GapModeEnum, 1)).Return("MGG_EXTREM_MINIMUM");
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.GapModeEnum, 2)).Return("MGG_EXTREM_USER_DEF");
            var curParameterMetaData = Utility.GetEnumTypeParameter("EX_GEO.cur_stack_id");
            _parameterSessionInfo.ScanProtocolMetaData.Stub(x => x.GetParameterMetaData("EX_GEO.cur_stack_id")).Return(curParameterMetaData);
            _summaryParameterGroup = new SummaryParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _summaryParameterGroup.Active = true;

            //Act
            var dto = _summaryParameterGroup.PopulateGroup();

            //Assert
            //Verify GapControl Parameter is visible or not.x
            Assert.AreEqual(expectedGapModeIFVisibilityParameter, dto.Parameters["EX_STACKS[" + enumValue + "].slice_gap"].Visible);
            //Verify SliceGapInfo Parameter is visible or not.
            Assert.AreEqual(!expectedGapModeIFVisibilityParameter, dto.Parameters["IF.act_slice_gap"].Visible);
        }
        /// <summary>
        /// TestInfoParametersAreNonEditable
        /// </summary>
        [Test]
        public void VerifyInfoParametersAreNonEditable()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("IF.act_slice_gap", Utility.GetStringTypeParameter("IF.act_slice_gap"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            GetParameterSessionInfo(2);
            _summaryParameterGroup = new SummaryParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            _summaryParameterGroup.Active = true;

            //Act
            var dto = _summaryParameterGroup.PopulateGroup();

            //Assert
            //Verify all the infoParameter is successfully added
            Assert.AreEqual(dto.Parameters.Count, 1);
            Assert.AreEqual(dto.Parameters.ContainsKey("IF.act_slice_gap"), true);
            Assert.AreEqual(dto.Parameters["IF.act_slice_gap"].Editable, false);
        }

        #endregion

        #region Private methods

        private void GetParameterSessionInfo(int enumValue)
        {

            var objIntVector = new IntVector();
            objIntVector.Add(0);
            objIntVector.Add(1);
            objIntVector.Add(2);
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(objIntVector);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");

            var objFloatVector = new FloatVector();
            objFloatVector.Add(0);
            objFloatVector.Add(1);
            objFloatVector.Add(2);

            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");
            objStringVector.Add("String3");

            var kVpNodeMock = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(objIntVector);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(enumValue);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(objFloatVector);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");

            var _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();
            _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);


            _parameterSessionInfo = new ParameterSessionInfo();
            _parameterSessionInfo.ScanProtocol = _scanProtocol;
            _parameterSessionInfo.BaselineProtocol = _scanProtocol;
            _parameterSessionInfo.ScanProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.BaselineProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.IsEditMode = true;
            _parameterSessionInfo.IsInConflict = false;
        }


        #endregion
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History