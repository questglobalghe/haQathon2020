﻿#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: PdfDataProviderTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using NUnit.Framework;
using Philips.PmsMR.Methods.ParameterData;
using Philips.PmsMR.Methods.PdfInterface;
using Philips.PmsMR.ParameterEditor.BusinessLayer;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Platform.OSInterface;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Unit Test class for PdfDataProvider
    /// </summary>
    public class PdfDataProviderTests
    {
        private readonly IUnityContainer _container = new UnityContainer();
        private IEditorPdf _editorPdf;
        private bool _eventFired;
        private IList<GroupInfo> _groups;
        private PdfDataProvider _pdfDataProvider;
        private IPdfFactory _pdfFactory;
        private IPdfParameter _pdfParameter;
        private SoftwareOptionConfigurationUtil _softwareOptionConfigurationUtil;

        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            _pdfFactory = MockRepository.GenerateMock<IPdfFactory>();
            _container.RegisterInstance(_pdfFactory, new ContainerControlledLifetimeManager());
            _pdfParameter = MockRepository.GenerateMock<IPdfParameter>();
            _container.RegisterInstance(_pdfParameter, new ContainerControlledLifetimeManager());
            _editorPdf = MockRepository.GenerateMock<IEditorPdf>();
            _container.RegisterInstance(_editorPdf, new ContainerControlledLifetimeManager());
            _softwareOptionConfigurationUtil = MockRepository.GenerateMock<SoftwareOptionConfigurationUtil>();
            _container.RegisterInstance(_softwareOptionConfigurationUtil, new ContainerControlledLifetimeManager());
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);
            _groups = PopulateGroupInfos();
        }

        /// <summary>
        /// Test SetParameter method.
        /// </summary>
        [Test]
        public void VerifySetParameter()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMockWithDefaultArrayParameters(_container, "test1",
                true, uniqueId: "enumParameter"));
            parameters.Add(PdfParameterMocks.CreateIntPdfParameterMockWithDefaultArrayParameters(_container, "test2",
                true, uniqueId: "intParameter"));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Expect(x => x.SetParameters(Arg<PdfData>.Is.Anything)).Return(true);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            var success = _pdfDataProvider.SetParameter("enumParameter", new[] { 1 });
            //Verify IEditorPdf Setparameter is getting called or not.
            _editorPdf.VerifyAllExpectations();
            //Verify the result is success or not.
            Assert.IsTrue(success);
        }
        /// <summary>
        /// Test SetParameter with a new Id not present in _pdfParameters
        /// </summary>
        [Test]
        public void VerifySetParameterWithNewId()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMockWithDefaultArrayParameters(_container, "test1",
                true, uniqueId: "enumParameter"));
            parameters.Add(PdfParameterMocks.CreateIntPdfParameterMockWithDefaultArrayParameters(_container, "test2",
                true, uniqueId: "intParameter"));
            infoParameters.Add(PdfParameterMocks.CreateStringPdfParameterMockWithDefaultArrayParameters(_container,
                "test3", true, uniqueId: "stringParameter"));
            infoParameters.Add(PdfParameterMocks.CreateFloatPdfParameterMockWithDefaultArrayParameters(_container,
                "test3", true, uniqueId: "floatParameter"));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            var success = _pdfDataProvider.SetParameter("stringParameter", new[] { 1 });
            //Verify the result is not successfull.
            Assert.IsTrue(!success);
        }

        /// <summary>
        /// Test SetParameter with readOnly Or null Value
        /// </summary>
        [Test]
        public void VerifySetParameterWithReadOnlyOrNullValue()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMockWithDefaultArrayParameters(_container, "test1",
                true, readOnly: true, uniqueId: "enumParameter"));
            parameters.Add(PdfParameterMocks.CreateIntPdfParameterMock(_container, "test2",
                true, new[] { 0, 1 }, internalName: "integer", uniqueId: "intParameter"));


            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SetParameters(Arg<PdfData>.Is.Anything)).Return(true);

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            //Verify Read Only Parameter
            _pdfDataProvider.SetParameter("enumParameter", new[] { 1 });
            _editorPdf.AssertWasNotCalled(x => x.SetParameters(Arg<PdfData>.Is.Anything));

            //Verify Null Value Parameter
            _pdfDataProvider.SetParameter("intParameter", null);
            _editorPdf.AssertWasNotCalled(x => x.SetParameters(Arg<PdfData>.Is.Anything));
        }

        /// <summary>
        /// Verify Adding Initial Group
        /// </summary>
        [Test]
        public void VerifyInitialGroupsWhenSoftwareOptionNotAvaliable()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            _editorPdf.BackToRecord(BackToRecordOptions.All);
            _editorPdf.Replay();

            _softwareOptionConfigurationUtil.BackToRecord(BackToRecordOptions.All);
            _softwareOptionConfigurationUtil.Replay();
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(false);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(_groups.ToArray());

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());


            var enabledSubGroups =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_enabledSubGroups") as IList<GroupInfo>;

            Assert.AreNotEqual(enabledSubGroups, null);
            if (enabledSubGroups != null)
            {
                Assert.AreEqual(enabledSubGroups.Count > 0, true);

                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Initial), true);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Summary), false);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Conflicts), false);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Physio), false);
            }
        }

        /// <summary>
        /// Verify Adding Summary Group
        /// </summary>
        [Test]
        public void VerifyRoutineGroupsWhenSoftwareOptionAvaliable()
        {
            //Add single parameter to enable Physio tab
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMockWithDefaultArrayParameters(_container,"p1",true));
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            _editorPdf.BackToRecord(BackToRecordOptions.All);
            _editorPdf.Replay();

            _softwareOptionConfigurationUtil.BackToRecord(BackToRecordOptions.All);
            _softwareOptionConfigurationUtil.Replay();
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(_groups.ToArray());

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());


            var enabledSubGroups =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_enabledSubGroups") as IList<GroupInfo>;

            Assert.AreNotEqual(enabledSubGroups, null);
            if (enabledSubGroups != null)
            {
                Assert.AreEqual(enabledSubGroups.Count > 0, true);

                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Initial), false);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Summary), true);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Physio), true);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Conflicts), false);
            }
        }

        /// <summary>
        /// Verify Adding Summary Group
        /// </summary>
        [Test]
        public void VerifyRoutineGroupsWithScanTypeIsImagingScan()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            _editorPdf.BackToRecord(BackToRecordOptions.All);
            _editorPdf.Replay();

            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "test1",
                true, uniqueId: "EX_ACQ_scan_type", values: new[] { 0 }, enumNames: new[] { "MGUACQ_SCT_IMAGING", "b" }));

            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(_groups.ToArray());

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());


            var enabledSubGroups =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_enabledSubGroups") as IList<GroupInfo>;

            Assert.AreNotEqual(enabledSubGroups, null);
            if (enabledSubGroups != null)
            {
                Assert.AreEqual(enabledSubGroups.Count > 0, true);

                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Summary), true);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Initial), false);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Physio), true);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Conflicts), false);
            }
        }
        /// <summary>
        /// Verify Adding InitialGroup
        /// </summary>
        [Test]
        public void VerifyInitialGroupWithScanTypeIsSpectroScan()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            _editorPdf.BackToRecord(BackToRecordOptions.All);
            _editorPdf.Replay();

            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "test1",
                true, uniqueId: "EX_ACQ_scan_type", values: new[] { 0 }, enumNames: new[] { "MGUACQ_SCT_SPECTRO", "b" }));

            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(_groups.ToArray());

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());


            var enabledSubGroups =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_enabledSubGroups") as IList<GroupInfo>;

            Assert.AreNotEqual(enabledSubGroups, null);
            if (enabledSubGroups != null)
            {
                Assert.AreEqual(enabledSubGroups.Count > 0, true);
                //Check if Routine group has been skipped
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Summary), false);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Physio), true);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Initial), true);
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Conflicts), false);
            }
        }
        /// <summary>
        /// Verify adding conflict group
        /// </summary>
        [Test]
        public void VerifyConflictGroup()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            _editorPdf.BackToRecord(BackToRecordOptions.All);
            _editorPdf.Replay();

            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "test1",
                true, uniqueId: "EX_ACQ_scan_type", values: new[] { 0, 1 }, enumNames: new[] { "initial", "b" },
                conflict: true));
            _softwareOptionConfigurationUtil.BackToRecord();
            _softwareOptionConfigurationUtil.Replay();
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(_groups.ToArray());

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());


            var enabledSubGroups =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_enabledSubGroups") as IList<GroupInfo>;

            Assert.AreNotEqual(enabledSubGroups, null);
            if (enabledSubGroups != null)
            {
                Assert.AreEqual(enabledSubGroups.Count > 0, true);
                //Check if conflict group has been added
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Conflicts), true);
            }
        }
        /// <summary>
        /// Verify Adding Physio by adding CardiacSynchronizationMode to the parameters.
        /// </summary>
        [TestCaseSource("CardiacSynchronizationModesSource")]
        public void VerifyPhysioGroup(List<IPdfParameter> pdfParameters, bool expectedPhysioTab)
        {
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();

            _editorPdf.Stub(x => x.Parameters).Return(pdfParameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(_groups.ToArray());

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());
            var enabledSubGroups =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_enabledSubGroups") as IList<GroupInfo>;
            Assert.AreNotEqual(enabledSubGroups, null);
            if (enabledSubGroups != null)
            {
                Assert.AreEqual(enabledSubGroups.Count > 0, true);
                //Check if physio group has been skipped
                Assert.AreEqual(enabledSubGroups.Any(x => x.id == (int)GroupIds.Physio), expectedPhysioTab);
            }
        }

        /// <summary>
        /// Test cache Of parameters Is updated On UpdatedEvent
        /// </summary>
        [Test]
        public void VerifyCacheOfParametersIsUpdatedOnUpdatedEvent()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            _editorPdf.BackToRecord(BackToRecordOptions.All);
            _editorPdf.Replay();

            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "testInitial",
                true, uniqueId: "testInitial", values: new[] { 0, 1 }, enumNames: new[] { "initial", "b" }, conflict: true));
            infoParameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "testInfoInitial",
                true, uniqueId: "testInfoInitial", values: new[] { 0, 1 }, enumNames: new[] { "initial", "b" },
                conflict: true));


            _softwareOptionConfigurationUtil.BackToRecord();
            _softwareOptionConfigurationUtil.Replay();
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(_groups.ToArray());

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            //Refreshing Parameters and Info Parameters
            parameters = new List<IPdfParameter>();
            infoParameters = new List<IPdfParameter>();


            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "testFinal",
                true, uniqueId: "testFinal", values: new[] { 0, 1 }, enumNames: new[] { "Final", "b" }, conflict: true));
            infoParameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "testInfoFinal",
                true, uniqueId: "testInfoFinal", values: new[] { 0, 1 }, enumNames: new[] { "Final", "b" }, conflict: true));

            //Here we are only reverting expectations not events because we want to retain the original event subscriptions.
            _editorPdf.BackToRecord(BackToRecordOptions.Expectations);
            _editorPdf.Replay();


            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(_groups.ToArray());

            _editorPdf.Raise(x => x.Updated += (obj, args) => { }, _editorPdf, new EventArgs());


            var pdfParameters =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_pdfParameters") as IDictionary<string, IPdfParameter>;

            Assert.AreNotEqual(pdfParameters, null);
            if (pdfParameters != null)
            {
                //Verify that the _pdfParameters are updated with the new values or not.
                Assert.AreEqual(pdfParameters.Count > 0, true);
                Assert.AreEqual(pdfParameters.ContainsKey("testFinal"), true);
                Assert.AreEqual(pdfParameters.ContainsKey("testInitial"), false);
                Assert.AreEqual(pdfParameters.ContainsKey("testInfoInitial"), false);
            }

            var pdfinfoParameters =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_pdfInfoParameters") as IDictionary<string, IPdfParameter>;

            Assert.AreNotEqual(pdfinfoParameters, null);
            if (pdfinfoParameters != null)
            {
                //Verify that the _pdfInfoParameters are updated with the new values or not.
                Assert.AreEqual(pdfinfoParameters.Count > 0, true);
                Assert.AreEqual(pdfinfoParameters.ContainsKey("testInfoFinal"), true);
            }
        }

        /// <summary>
        /// Test cache Of subGroups is updated On UpdatedEvent
        /// </summary>
        [Test]
        public void VerifyCacheOfSubGroupsIsUpdatedOnUpdatedEvent()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            _editorPdf.BackToRecord(BackToRecordOptions.All);
            _editorPdf.Replay();

            _softwareOptionConfigurationUtil.BackToRecord();
            _softwareOptionConfigurationUtil.Replay();
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);


            IList<GroupInfo> initialGroups = new List<GroupInfo>();
            var customGroup1 = new GroupInfo
            {
                id = 14,
                name = "customGroup1",
                parameterCount = 0
            };
            var customGroup2 = new GroupInfo
            {
                id = 15,
                name = "customGroup2"
            };
            initialGroups.Add(customGroup1);
            initialGroups.Add(customGroup2);



            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(initialGroups.ToArray());

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            //Refreshing groups 

            //Here we are only reverting expectations not events because we want to retain the original event subscriptions.

            IList<GroupInfo> finalGroups = new List<GroupInfo>();
            var customGroup3 = new GroupInfo
            {
                id = 16,
                name = "customGroup3",
                parameterCount = 0
            };
            var customGroup4 = new GroupInfo
            {
                id = 17,
                name = "customGroup4"
            };
            finalGroups.Add(customGroup3);
            finalGroups.Add(customGroup4);

            _editorPdf.BackToRecord(BackToRecordOptions.Expectations);
            _editorPdf.Replay();


            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SubGroups).Return(finalGroups.ToArray());

            _editorPdf.Raise(x => x.Updated += (obj, args) => { }, _editorPdf, new EventArgs());

            var enabledSubGroups =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_enabledSubGroups") as IList<GroupInfo>;

            Assert.AreNotEqual(enabledSubGroups, null);
            if (enabledSubGroups != null)
            {
                //Verify that the _enabledSubGroups is populated with the new values or not.
                Assert.AreEqual(enabledSubGroups.Count > 0, true);
                Assert.AreEqual(enabledSubGroups.Contains(customGroup1), false);
                Assert.AreEqual(enabledSubGroups.Contains(customGroup2), false);
                Assert.AreEqual(enabledSubGroups.Contains(customGroup3), true);
                Assert.AreEqual(enabledSubGroups.Contains(customGroup4), true);
            }
        }

        #region Test cases for Event Firing

        /// <summary>
        /// Test whether PdfSessionUpdated is getting fired or not.
        /// </summary>
        [Test]
        public void VerifyPdfSessionUpdatedIsFired()
        {
            InitialzingStubs();
            _pdfDataProvider = new PdfDataProvider(_container);
            _pdfDataProvider.PdfSessionUpdated += delegate { _eventFired = true; };
            _editorPdf.Raise(x => x.Updated += (obj, args) => { }, _editorPdf, new EventArgs());
            //Verify the event is fired or not.
            Assert.IsTrue(_eventFired);
        }

        /// <summary>
        ///  Test whether PdfSessionStarted is getting fired or not.
        /// </summary>
        [Test]
        public void VerifyPdfSessionStartedIsFired()
        {
            InitialzingStubs();
            _pdfDataProvider = new PdfDataProvider(_container);
            _pdfDataProvider.PdfSessionStarted += delegate { _eventFired = true; };
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());
            //Verify the event is fired or not.
            Assert.IsTrue(_eventFired);

            //Verify the event is fired or not.
        }
        /// <summary>
        ///  Test whether PdfSessionEnded is getting fired or not.
        /// </summary>
        [Test]
        public void VerifyPdfSessionEndedIsFired()
        {
            InitialzingStubs();
            _pdfDataProvider = new PdfDataProvider(_container);
            _pdfDataProvider.PdfSessionEnded += delegate { _eventFired = true; };
            _editorPdf.Raise(x => x.Deactivated += (obj, args) => { }, _editorPdf, new EventArgs());
            //Verify the event is fired or not.
            Assert.IsTrue(_eventFired);
        }

        /// <summary>
        ///  Test whether PdfExceptionOccured is fired on SetActiveGroup or not.
        /// </summary>
        [Test]
        public void VerifyPdfExceptionOccuredIsFiredOnSetActiveGroup()
        {
            int groupId = 45;
            _editorPdf.Stub(x => x.SetSubGroup(Arg<int>.Is.Anything))
                .Throw(new InvalidScanProcedureException("Error introduced"));
            InitialzingStubs();
            _pdfDataProvider = new PdfDataProvider(_container);
            _pdfDataProvider.PdfExceptionOccured += delegate { _eventFired = true; };
            _pdfDataProvider.SetActiveGroup(groupId);
            //Verify the event is fired or not.
            Assert.IsTrue(_eventFired);
        }

        /// <summary>
        ///  Test whether PdfExceptionOccured is fired on SetParameter or not.
        /// </summary>
        [Test]
        public void VerifyPdfExceptionOccuredIsFiredOnSetParameter()
        {
            _eventFired = false;
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMockWithDefaultArrayParameters(_container, "test1",
                true, uniqueId: "enumParameter"));
            infoParameters.Add(PdfParameterMocks.CreateStringPdfParameterMockWithDefaultArrayParameters(_container,
                "test3", true, uniqueId: "stringParameter"));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SetParameters(Arg<PdfData>.Is.Anything))
                .Throw(new InvalidScanProcedureException("Error introduced"));

            _pdfDataProvider = new PdfDataProvider(_container);
            _pdfDataProvider.PdfExceptionOccured += delegate { _eventFired = true; };
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());
            _pdfDataProvider.SetParameter("enumParameter", new[] { 1 });
            //Verify the event is fired or not.
            Assert.IsTrue(_eventFired);


            //Verify with any other exception
            _eventFired = false;
            _editorPdf.BackToRecord(BackToRecordOptions.Expectations);
            _editorPdf.Replay();

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SetParameters(Arg<PdfData>.Is.Anything))
                .Throw(new NullReferenceException("Error introduced"));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);
            _pdfDataProvider = new PdfDataProvider(_container);
            _pdfDataProvider.PdfExceptionOccured += delegate { _eventFired = true; };
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());
            _pdfDataProvider.SetParameter("enumParameter", new[] { 1 });
            //Verify the event is fired or not.
            Assert.IsTrue(_eventFired);
        }
        /// <summary>
        /// Test SetParameter for Enum Type
        /// </summary>
        [Test]
        public void VerifySetParameterForEnumType()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            IEnumPdfParameter enumPdfParameter = PdfParameterMocks.CreateEnumPdfParameterMockWithDefaultArrayParameters(_container,
                "test1", true, uniqueId: "enumParameter") as IEnumPdfParameter;
            parameters.Add(enumPdfParameter);
            infoParameters.Add(PdfParameterMocks.CreateFloatPdfParameterMockWithDefaultArrayParameters(_container,
                "test3", true, uniqueId: "floatParameter"));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SetParameters(Arg<PdfData>.Is.Anything)).Return(true);

            enumPdfParameter.Expect(x => x.FillPdfData(Arg<int[]>.Is.Anything, ref Arg<PdfData>.Ref(Rhino.Mocks.Constraints.Is.Anything(), null).Dummy));
            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            _pdfDataProvider.SetParameter("enumParameter", new[] { 1 });
            var previousValues =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_previousValues") as Array;
            //Verify previousValues should not be null
            Assert.AreNotEqual(previousValues, null);
            if (enumPdfParameter != null)
            {
                //Verify that the old value of the parameter is stored.
                Assert.AreEqual(previousValues, enumPdfParameter.Values);
            }
            //Verify IEditorPdf Setparameter is getting called or not.
            enumPdfParameter.VerifyAllExpectations();

        }
        /// <summary>
        /// Test SetParameter for String Type
        /// </summary>
        [Test]
        public void VerifySetParameterForStringType()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            IStringPdfParameter stringPdfParameter = PdfParameterMocks.CreateStringPdfParameterMockWithDefaultArrayParameters(_container,
                "test1", true, uniqueId: "stringParameter") as IStringPdfParameter;
            parameters.Add(stringPdfParameter);
            infoParameters.Add(PdfParameterMocks.CreateFloatPdfParameterMockWithDefaultArrayParameters(_container,
                "test3", true, uniqueId: "floatParameter"));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SetParameters(Arg<PdfData>.Is.Anything)).Return(true);

            stringPdfParameter.Expect(x => x.FillPdfData(Arg<string[]>.Is.Anything, ref Arg<PdfData>.Ref(Rhino.Mocks.Constraints.Is.Anything(), null).Dummy));
            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            _pdfDataProvider.SetParameter("stringParameter", new[] { "newValue" });
            var previousValues =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_previousValues") as Array;

            //Verify previousValues should not be null
            Assert.AreNotEqual(previousValues, null);
            if (stringPdfParameter != null)
            {
                //Verify that the old value of the parameter is stored.
                Assert.AreEqual(previousValues, stringPdfParameter.Values);
            }
            //Verify IEditorPdf Setparameter is getting called or not.
            stringPdfParameter.VerifyAllExpectations();
        }
        /// <summary>
        /// Test SetParameter for Int Type
        /// </summary>
        [Test]
        public void VerifySetParameterForIntType()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            IIntPdfParameter intPdfParameter = PdfParameterMocks.CreateIntPdfParameterMockWithDefaultArrayParameters(_container,
                "test1", true, uniqueId: "intParameter") as IIntPdfParameter;
            parameters.Add(intPdfParameter);
            infoParameters.Add(PdfParameterMocks.CreateFloatPdfParameterMockWithDefaultArrayParameters(_container,
                "test3", true, uniqueId: "floatParameter"));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SetParameters(Arg<PdfData>.Is.Anything)).Return(true);

            intPdfParameter.Expect(x => x.FillPdfData(Arg<int[]>.Is.Anything, ref Arg<PdfData>.Ref(Rhino.Mocks.Constraints.Is.Anything(), null).Dummy));
            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            _pdfDataProvider.SetParameter("intParameter", new[] { 1, 2 });
            var previousValues =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_previousValues") as Array;

            //Verify previousValues should not be null
            Assert.AreNotEqual(previousValues, null);
            if (intPdfParameter != null)
            {
                //Verify that the old value of the parameter is stored.
                Assert.AreEqual(previousValues, intPdfParameter.Values);
            }
            //Verify IEditorPdf Setparameter is getting called or not.
            intPdfParameter.VerifyAllExpectations();
        }
        /// <summary>
        /// Test SetParameter for Float Type
        /// </summary>
        [Test]
        public void VerifySetParameterForFloatType()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            IFloatPdfParameter floatPdfParameter = PdfParameterMocks.CreateFloatPdfParameterMockWithDefaultArrayParameters(_container,
                "test1", true, uniqueId: "floatParameter") as IFloatPdfParameter;
            parameters.Add(floatPdfParameter);
            infoParameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container,
                "test3", true, uniqueId: "enumParameter"));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SetParameters(Arg<PdfData>.Is.Anything)).Return(true);

            floatPdfParameter.Expect(x => x.FillPdfData(Arg<float[]>.Is.Anything, ref Arg<PdfData>.Ref(Rhino.Mocks.Constraints.Is.Anything(), null).Dummy));
            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            _pdfDataProvider.SetParameter("floatParameter", new float[] { 1 });
            var previousValues =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_previousValues") as Array;

            //Verify previousValues should not be null
            Assert.AreNotEqual(previousValues, null);
            if (floatPdfParameter != null)
            {
                //Verify that the old value of the parameter is stored.
                Assert.AreEqual(previousValues, floatPdfParameter.Values);
            }
            //Verify IEditorPdf Setparameter is getting called or not.
            floatPdfParameter.VerifyAllExpectations();
        }

        /// <summary>
        /// Test HandleParameter if same value is provided
        /// </summary>
        [Test]
        public void VerifyHandleParameterIfSameValueIsProvided()
        {
            IList<IPdfParameter> parameters = new List<IPdfParameter>();
            IList<IPdfParameter> infoParameters = new List<IPdfParameter>();
            IEnumPdfParameter enumPdfParameter = PdfParameterMocks.CreateEnumPdfParameterMock(_container,
                "test1", true, new[] { 0, 1 },
                new[] { 2, 3 },
                new[] { "a", "b" }, new[] { "a", "b" }, new IntRange[2], uniqueId: "Distinct") as IEnumPdfParameter;
            parameters.Add(enumPdfParameter);
            infoParameters.Add(PdfParameterMocks.CreateFloatPdfParameterMockWithDefaultArrayParameters(_container,
                "test3",
                true));

            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);

            _editorPdf.Stub(x => x.Parameters).Return(parameters.ToArray());
            _editorPdf.Stub(x => x.InfoParameters).Return(infoParameters.ToArray());
            _editorPdf.Stub(x => x.SetParameters(Arg<PdfData>.Is.Anything)).Return(true);

            enumPdfParameter.Stub(x => x.FillPdfData(Arg<int[]>.Is.Anything, ref Arg<PdfData>.Ref(Rhino.Mocks.Constraints.Is.Anything(), null).Dummy));
            _pdfDataProvider = new PdfDataProvider(_container);
            _editorPdf.Raise(x => x.Activated += (obj, args) => { }, _editorPdf, new EventArgs());

            _pdfDataProvider.SetParameter("Distinct", new[] { 0, 1 });
            var previousValues =
                Utility.GetInstanceField(typeof(PdfDataProvider), _pdfDataProvider,
                    "_previousValues") as Array;
            //Verify previousValues should null.
            Assert.AreEqual(previousValues, null);
            //Verify IEditorPdf Setparameter is not getting called.
            enumPdfParameter.AssertWasNotCalled(x => x.FillPdfData(Arg<int[]>.Is.Anything, ref Arg<PdfData>.Ref(Rhino.Mocks.Constraints.Is.Anything(), null).Dummy));

        }
        /// <summary>
        /// Initialzing the Stubs
        /// </summary>
        private void InitialzingStubs()
        {
            _eventFired = true;
            _pdfFactory.Stub(x => x.ParameterEditorPdfInstance).Return(_editorPdf);
            _editorPdf.Stub(x => x.Parameters).Return(new IPdfParameter[] { });
            _editorPdf.Stub(x => x.InfoParameters).Return(new IPdfParameter[] { });
        }


        private IEnumerable<TestCaseData> CardiacSynchronizationModesSource
        {
            get
            {
                yield return
                    new TestCaseData(PopulateCardiacSynchronizationParameters(EnumNames.CardSyncNo, EnumNames.CardSyncNo, EnumNames.NavigatorRespOff), false);
                yield return
                    new TestCaseData(PopulateCardiacSynchronizationParameters(EnumNames.CardSyncGate, EnumNames.CardSyncNo, EnumNames.NavigatorRespOff), true);
                yield return
                    new TestCaseData(PopulateCardiacSynchronizationParameters(EnumNames.CardSyncNo, EnumNames.RespCompTrigger, EnumNames.NavigatorRespOff), true);
                yield return
                    new TestCaseData(PopulateCardiacSynchronizationParameters(EnumNames.CardSyncNo, EnumNames.RespCompBreathHold, EnumNames.NavigatorRespOff), true);
                yield return
                    new TestCaseData(PopulateCardiacSynchronizationParameters(EnumNames.CardSyncNo, EnumNames.CardSyncNo, EnumNames.RespCompTrigger), true);
            }
        }

        private List<IPdfParameter> PopulateCardiacSynchronizationParameters(string cardiacSynchronizationMode,
            string respiratoryCompensationMode, string navigatorRespiratoryMode)
        {
            List<IPdfParameter> parameters = new List<IPdfParameter>();
            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "test1", true, uniqueId: "EX_CARD_sync",
                            enumNames: new[] { cardiacSynchronizationMode, "b" }, values: new[] { 0, 1 }));
            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "test1", true, uniqueId: "EX_RESP_synch",
                            enumNames: new[] { respiratoryCompensationMode, "b" }, values: new[] { 0, 1 }));
            parameters.Add(PdfParameterMocks.CreateEnumPdfParameterMock(_container, "test1", true, uniqueId: "EX_RNAV_resp_comp",
                            enumNames: new[] { navigatorRespiratoryMode, "b" }, values: new[] { 0, 1 }));
            return parameters;
        }
        private IList<GroupInfo> PopulateGroupInfos()
        {
            IList<GroupInfo> groups = new List<GroupInfo>();
            var summaryGroup = new GroupInfo
            {
                id = (int)GroupIds.Summary,
                name = "Routine",
                parameterCount = 0
            };
            var physioGroup = new GroupInfo
            {
                id = (int)GroupIds.Physio,
                name = "physio"
            };
            var conflictGroup = new GroupInfo
            {
                id = (int)GroupIds.Conflicts,
                name = "conflict"
            };
            var initalGroup = new GroupInfo
            {
                id = (int)GroupIds.Initial,
                name = "initial"
            };
            var protocolGroup = new GroupInfo
            {
                id = (int)GroupIds.Protocols,
                name = "protocol"
            };
            groups.Add(summaryGroup);
            groups.Add(physioGroup);
            groups.Add(conflictGroup);
            groups.Add(initalGroup);
            groups.Add(protocolGroup);
            return groups;
        }
        #endregion
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)
// 2018-Feb-09  Praveen K
//              Removed VerifySetNewInstanceOfIEditorPdfInstance as the test is no longer valid

#endregion Revision History