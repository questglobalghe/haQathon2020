#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterConverterTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using NUnit.Framework;
using Philips.PmsMR.ParameterEditor.BusinessLayer;
using Rhino.Mocks;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Unit Test class for ParameterConverter
    /// </summary>
    public class ParameterConverterTests
    {
        #region Private Members

        private readonly IUnityContainer _container = new UnityContainer();

        #endregion

        #region Setup

        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            
        }

        #endregion

       
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History