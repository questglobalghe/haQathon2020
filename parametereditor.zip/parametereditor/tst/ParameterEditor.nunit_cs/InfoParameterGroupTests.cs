#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: InfoParameterGroupTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using NUnit.Framework;
using Philips.PmsMR.ParameterEditor.BusinessLayer;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System.Collections.Generic;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerTest
{
    /// <summary>
    ///     Unit Test class for InfoParameterGroup
    /// </summary>
    public class InfoParameterGroupTests
    {
        private IUnityContainer _container;
        private GroupInfo _groupInfo;
        private InfoParameterGroup _infoParameterGroup;
        private ParameterSessionInfo _parameterSessionInfo;
        private IScanProtocalWrapper _scanProtocalWrapper;


        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            _container = new UnityContainer();
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());
            //Setting default id for the setup.
            _groupInfo = new GroupInfo { name = "d", id = (int)GroupIds.InfoParameterGroupId, parameterCount = 3 };

            var objIntVector = new IntVector();
            objIntVector.Add(1);
            objIntVector.Add(2);
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(objIntVector);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");

            var objFloatVector = new FloatVector();
            objFloatVector.Add(1);
            objFloatVector.Add(2);

            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");

            var kVpNodeMock = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(objIntVector);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(objFloatVector);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");

            var _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();

            _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);


            _parameterSessionInfo = new ParameterSessionInfo();
            _parameterSessionInfo.ScanProtocol = _scanProtocol;
            _parameterSessionInfo.BaselineProtocol = _scanProtocol;
            _parameterSessionInfo.ScanProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.BaselineProtocolMetaData = Utility.GetProtocolMetaDataMock();
            _parameterSessionInfo.IsEditMode = true;
            _parameterSessionInfo.IsInConflict = false;


            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
            }
            _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(2);


        }

        /// <summary>
        ///     Test for InfoParameters are NonEditable or not
        /// </summary>
        [Test]
        public void VerifyInfoParametersAreNonEditable()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            dic2.Add("EX_CARD.EnumSync", Utility.GetEnumTypeParameter("EX_CARD.EnumSync"));
            dic2.Add("EX_CARD.FloatSync", Utility.GetFloatTypeParameter("EX_CARD.FloatSync"));
            dic2.Add("EX_CARD.StringSync", Utility.GetStringTypeParameter("EX_CARD.StringSync"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);
            _groupInfo.id = (int)GroupIds.InfoParameterGroupId;


            //Act
            _infoParameterGroup = new InfoParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            var dto = _infoParameterGroup.PopulateGroup();


            //Assert
            Assert.AreEqual(dto.Parameters.Count, 4);
            foreach (var param in dto.Parameters)
            {
                //Check if all parameters are non editable
                Assert.AreEqual(param.Value.Editable, false);
            }
        }

        /// <summary>
        ///     Test Only the Visible Parameters Are Populated in the parameters
        /// </summary>
        [Test]
        public void VerifyOnlyTheVisibleParametersArePopulated()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            dic2.Add("EX_CARD.EnumSync", Utility.GetEnumTypeParameter("EX_CARD.EnumSync"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);


            //Act
            _infoParameterGroup = new InfoParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            var dto = _infoParameterGroup.PopulateGroup();

            //Assert
            Assert.AreEqual(2, dto.Parameters.Count);
            foreach (var param in dto.Parameters)
            {
                //Check if all visible parameters Are populated
                Assert.AreNotEqual(param.Value.Name, "test3");
                Assert.AreNotEqual(param.Value.Name, "test4");
            }
        }

        /// <summary>
        ///     Test Only InfoParameters Are Populated and not Parameters.
        /// </summary>
        [Test]
        public void VerifyOnlyInfoParametersArePopulated()
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments()
                .Return(dic2);

            //Act
            _infoParameterGroup = new InfoParameterGroup(_container, _groupInfo, _parameterSessionInfo);
            var dto = _infoParameterGroup.PopulateGroup();

            //Assert
            //Check if only info parameters are populated
            Assert.AreEqual(1, dto.Parameters.Count);
            Assert.AreEqual(dto.Parameters.ContainsKey("enumParameter"), false);
            Assert.AreEqual(dto.Parameters.ContainsKey("EX_CARD.IntSync"), true);
        }
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History