﻿#region (c) Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterGroupComponentTests.cs
//

#endregion


using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using NUnit.Framework;
using Philips.PmsMR.CTA.Platform.TestTemplate.Attributes;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using GroupInfo = Philips.PmsMR.ParameterEditor.Interfaces.GroupInfo;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer.ComponentTest_csm
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [ComponentTestFixture]
    public class ParameterGroupComponentTests
    {
        #region Private fields

        private IUnityContainer _container;
        private IScanProtocalWrapper _scanProtocalWrapper;
        private ISoftwareOptionConfigurationUtil _softwareOptionConfigurationUtil;

        #endregion

        #region One Time Set up & One Time Tear Down

        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            var currentDirectory = Directory.GetCurrentDirectory();
            var cwd = new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName;
            Directory.SetCurrentDirectory(cwd);
            _container = new UnityContainer();
            _container.LoadConfiguration();
            _softwareOptionConfigurationUtil = MockRepository.GenerateMock<ISoftwareOptionConfigurationUtil>();
            _container.RegisterInstance<ISoftwareOptionConfigurationUtil>(_softwareOptionConfigurationUtil, new ExternallyControlledLifetimeManager());
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());
            Directory.SetCurrentDirectory(currentDirectory);
        }

        /// <summary>
        ///     Shutdown the Scan modification Service
        /// </summary>
        [TearDown]
        public virtual void TearDown()
        {

            _container.Dispose();
        }

        #endregion


        #region Tests

        /// <summary>
        /// Verify PopulateGroup
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanInParameters.Panel.AdvancedParameters")]
        [ComponentTestCase(TestCaseId = "45091", TestCaseName = "VerifyPopulateGroup")]
        [Step(StepIndex = 1,
            Description = "This test is to verify populate group",
            Expected = "Parameter details should be same as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyPopulateGroup()
        {
            //Arrange
            var objIntVector = new IntVector();
            objIntVector.Add(1);
            objIntVector.Add(2);
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(objIntVector);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(1);

            var objFloatVector = new FloatVector();
            objFloatVector.Add(2);
            objFloatVector.Add(3);

            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");

            var kVpNodeMock = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(objIntVector);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(objFloatVector);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");

            var _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();
            _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);
            GroupInfo groupInfo = new GroupInfo() { id = 2, name = "Info", parameterCount = 1 };

            var _protocolMetaDataMock = MockRepository.GenerateMock<Utility.ScanProtocolMetaDataMock>();
            _protocolMetaDataMock.Stub(x => x.GetTabNames()).Return(Utility.tabNameMapping.Keys.ToList());

            var parameterSessionInfo = new ParameterSessionInfo();
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;

            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);
            var parameterGroup = _container.Resolve<ParameterGroup>(new ParameterOverride("groupInfo", groupInfo),
                new ParameterOverride("parameterSessionInfo", parameterSessionInfo));

            var dic2 = new Dictionary<string, IParameterMetaData>();
            var field = Utility.GetIntTypeParameter("EX_CARD.IntSync");
            field.Stub(x => x.GetNameTag()).Return("IntField");
            dic2.Add("EX_CARD.IntSync", field);

            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic2);
            parameterGroup.Active = true;

            //Act
            var parameterGroupDto = parameterGroup.PopulateGroup();

            //Assert
            var singleFloatParam = parameterGroupDto.Parameters.FirstOrDefault(x => x.Value.UniqueId == "EX_CARD.IntSync").Value;
            Assert.AreEqual("EX_CARD.IntSync.help", singleFloatParam.Help,
                $"EX_CARD.IntSync's Help property value should be 'EX_CARD.IntSync.help'. But it is {singleFloatParam.Help}.");

            VerifyActiveParameterGroup();
        }


        private void VerifyActiveParameterGroup()
        {
            //Arrange
            GroupInfo groupInfo = new GroupInfo() { id = 2, name = "Info", parameterCount = 1 };
            var parameterGroup = new ParameterGroup(_container, groupInfo, new ParameterSessionInfo());
            parameterGroup.Active = false;

            //Act
            parameterGroup.SetActiveGroup();

            //Assert
            Assert.IsTrue(parameterGroup.Active, "parameterGroup's Active value should be true");
        }

        #endregion

    }


}
