﻿#region (c) Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: Utility.cs
//

#endregion

using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer.ComponentTest_csm
{
    /// <summary>
    ///     Utility class to combine all the commonly used methods across the project.
    /// </summary>
    public static class Utility
    {
        #region Private Static Fields
        static IKVPNodeMock kvpInitialNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpPhysiologyNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpGeometryNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpSPostprocNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpDefaultNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpALLNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static IKVPNodeMock kvpInfoNode = MockRepository.GenerateMock<IKVPNodeMock>();
        static StringVector Initialvectors = new StringVector { "Initial" };
        static StringVector Physiologyvectors = new StringVector { "Physiology" };
        static StringVector Geometryvectors = new StringVector { "Geometry" };
        static StringVector PostprocVectors = new StringVector { "Postproc" };
        static StringVector Defaultvectors = new StringVector { "Default" };
        static StringVector ALLvectors = new StringVector { "ALL" };
        static StringVector InfoBarvectors = new StringVector { "Info Bar" };
        #endregion

        #region Public Static Fields
        /// <summary>
        /// Tab Name Mapping
        /// </summary>
        public static Dictionary<string, string> tabNameMapping;

        /// <summary>
        /// InfoBar
        /// </summary>
        public static string InfoBar = "Info Bar";
        #endregion

        #region Static Constructor
        static Utility()
        {
            tabNameMapping = new Dictionary<string, string>();


            tabNameMapping.Add("MGG_SOFTKEY_0", "Geometry");
            tabNameMapping.Add("MGG_SOFTKEY_1", "Geo");
            tabNameMapping.Add("MGG_SOFTKEY_ALL", "ALL");
            tabNameMapping.Add("MGG_SOFTKEY_CONFL", "CONFL");
            tabNameMapping.Add("MGG_SOFTKEY_2", "Motion");
            tabNameMapping.Add("MGG_SOFTKEY_3", "Geo3");
            tabNameMapping.Add("MGG_SOFTKEY_4", "Postproc");
            tabNameMapping.Add("MGG_SOFTKEY_5", "Dyn/Ang");
            tabNameMapping.Add("MGG_SOFTKEY_6", "Initial");
            tabNameMapping.Add("MGG_SOFTKEY_ROUTINE", "Summary");
            tabNameMapping.Add("MGG_SOFTKEY_PHYSIO", "Physiology");
            tabNameMapping.Add("MGG_SOFTKEY_INFO", InfoBar);

        }

        #endregion

        #region Public Static Methods

        /// <summary>
        /// GetTabNames
        /// </summary>
        /// <returns></returns>
        public static StringVector GetTabNames()
        {
            StringVector tabNames = new StringVector();
            tabNames.Add("MGG_SOFTKEY_0");
            tabNames.Add("MGG_SOFTKEY_1");
            tabNames.Add("MGG_SOFTKEY_ALL");
            tabNames.Add("MGG_SOFTKEY_CONFL");
            tabNames.Add("MGG_SOFTKEY_2");
            tabNames.Add("MGG_SOFTKEY_3");
            tabNames.Add("MGG_SOFTKEY_4");
            tabNames.Add("MGG_SOFTKEY_5");
            tabNames.Add("MGG_SOFTKEY_6");
            tabNames.Add("MGG_SOFTKEY_ROUTINE");
            tabNames.Add("MGG_SOFTKEY_PHYSIO");
            tabNames.Add("MGG_SOFTKEY_INFO");
            return tabNames;
        }

        /// <summary>
        /// GetTabHierarchy
        /// </summary>
        /// <param name="tabName"></param>
        /// <returns>IKVPNode</returns>
        public static IKVPNode GetTabHierarchyValue(string tabName)
        {
            if (tabName == "Initial")
            {
                kvpInitialNode.Stub(x => x.GetName()).Return(tabName);
                return kvpInitialNode;
            }
            else if (tabName == "Physiology")
            {
                kvpPhysiologyNode.Stub(x => x.GetName()).Return(tabName);
                return kvpPhysiologyNode;
            }
            else if (tabName == "Geometry")
            {
                kvpGeometryNode.Stub(x => x.GetName()).Return(tabName);
                return kvpGeometryNode;
            }
            else if (tabName == "Postproc")
            {
                kvpSPostprocNode.Stub(x => x.GetName()).Return(tabName);
                return kvpSPostprocNode;
            }
            else if (tabName == "ALL")
            {
                kvpALLNode.Stub(x => x.GetName()).Return(tabName);
                return kvpALLNode;
            }
            else if (tabName == InfoBar)
            {
                kvpInfoNode.Stub(x => x.GetName()).Return(tabName);
                return kvpInfoNode;
            }
            else
            {
                kvpDefaultNode.Stub(x => x.GetName()).Return(tabName);
                return kvpDefaultNode;
            }
        }

        /// <summary>
        /// GetParametersPathValue
        /// </summary>
        /// <param name="getTabHierarchyValue"></param>
        /// <returns></returns>
        public static StringVector GetParametersPathValue(IKVPNode getTabHierarchyValue)
        {
            if (getTabHierarchyValue.GetName() == "Initial")
            {
                return Initialvectors;
            }
            else if (getTabHierarchyValue.GetName() == "Physiology")
            {
                return Physiologyvectors;
            }
            else if (getTabHierarchyValue.GetName() == "Geometry")
            {
                return Geometryvectors;
            }
            else if (getTabHierarchyValue.GetName() == "Postproc")
            {
                return PostprocVectors;
            }
            else if (getTabHierarchyValue.GetName() == "ALL")
            {
                return ALLvectors;
            }
            else if (getTabHierarchyValue.GetName() ==InfoBar)
            {
                return InfoBarvectors;
            }
            else
            {
                return Defaultvectors;
            }
        }


        /// <summary>
        /// GetParametersPath
        /// </summary>
        /// <param name="kvpNode"></param>
        /// <returns>StringVector</returns>
        public static StringVector GetParametersPath(IKVPNode kvpNode)
        {

            StringVector vectors = new StringVector();
            foreach (var vector in kvpNode.GetLeaves())
            {
                vectors.Add(vector.Remove(vector.IndexOf("ProtocolBuffer"), "ProtocolBuffer".Length + 1));
            }
            return vectors;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userDefinedHeartPhasesVisible"></param>
        /// <param name="breathholdControlVisible"></param>
        /// <returns></returns>
        internal static Dictionary<string, IParameterMetaData> GetALLFields(bool userDefinedHeartPhasesVisible =true, bool breathholdControlVisible=true)
        {
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_ACQ.partial_matrix", GetFloatTypeParameter("EX_ACQ.partial_matrix"));
            dic.Add("EX_ACQ.scan_type", GetFloatTypeParameter("EX_ACQ.scan_type"));
            dic.Add("EX_CARD.sync", Utility.GetStringTypeParameter("EX_CARD.sync"));
            dic.Add("EX_CARD.heart_phase_control", Utility.GetEnumTypeParameter("EX_CARD.heart_phase_control", userDefinedHeartPhasesVisible));
            dic.Add("EX_CARD.nr_heart1", Utility.GetFloatTypeParameter("EX_CARD.nr_heart1"));
            dic.Add("EX_CARD.nr_heart_phases", Utility.GetFloatTypeParameter("EX_CARD.nr_heart_phases"));
            dic.Add("IF.max_heart_phases", Utility.GetFloatTypeParameter("IF.max_heart_phases"));
            dic.Add("EX_CARD.gate_delay", Utility.GetEnumTypeParameter("EX_CARD.gate_delay"));
            dic.Add("EX_CARD.gate_delay_ms", Utility.GetFloatTypeParameter("EX_CARD.gate_delay_ms"));
            dic.Add("IF.act_gate_delay", Utility.GetFloatTypeParameter("IF.act_gate_delay"));
            dic.Add("EX_CARD.trig_delay_enum", Utility.GetEnumTypeParameter("EX_CARD.trig_delay_enum"));
            dic.Add("EX_CARD.trig_delay", Utility.GetFloatTypeParameter("EX_CARD.trig_delay"));
            dic.Add("IF.no_trig_period_trig_del", Utility.GetFloatTypeParameter("IF.no_trig_period_trig_del"));
            dic.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", breathholdControlVisible));
            dic.Add("EX_GEO.slice_gap_mode", Utility.GetEnumTypeParameter("EX_GEO.slice_gap_mode"));
            dic.Add("EX_STACKS[1].slice_gap", Utility.GetFloatTypeParameter("EX_STACKS[1].slice_gap"));
            dic.Add("IF.act_slice_gap", Utility.GetFloatTypeParameter("IF.act_slice_gap"));
            dic.Add("EX_ACQ.accelerationMethod", Utility.GetEnumTypeParameter("EX_ACQ.accelerationMethod"));
            dic.Add("EX_GEO.sense_s_red_factor", Utility.GetIntTypeParameter("EX_GEO.sense_s_red_factor"));
            dic.Add("EX_GEO.sense_p_red_factor", Utility.GetIntTypeParameter("EX_GEO.sense_p_red_factor"));
            dic.Add("EX_ACQ.cs_factor", Utility.GetIntTypeParameter("EX_ACQ.cs_factor"));
            return dic;
        }

        internal static Dictionary<string, IParameterMetaData> GetCommonParameterMetaDatas()
        {
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_PROC.image_types", Utility.GetEnumTypeParameter("EX_PROC.image_types"));
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            dic.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));
            return dic;
        }
        internal static Dictionary<string, IParameterMetaData> GetInfoBarFields()
        {
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("IF.act_slice_gap", GetFloatTypeParameter("IF.act_slice_gap"));
            dic.Add("IF.resp_trig_dur", GetFloatTypeParameter("IF.resp_trig_dur"));
            return dic;
        }

        /// <summary>
        /// GetParameterMetaDataMock
        /// </summary>
        /// <param name="isVisible"></param>
        /// <param name="range"></param>
        /// <param name="type"></param>
        /// <param name="nameTag"></param>
        /// <param name="helpTag"></param>
        /// <param name="isConflict"></param>
        /// <param name="enumDataType"></param>
        /// <param name="adjustValue"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetParameterMetaDataMock(bool isVisible, string range, TypeInfo type, string nameTag, string helpTag,
            bool isConflict, string enumDataType, double adjustValue = 1.0f)
        {
            var parametaData = MockRepository.GenerateMock<ParameterMetaDataMock>();
            parametaData.Stub(x => x.GetVisible()).Return(isVisible);
            parametaData.Stub(x => x.GetRange()).Return(range);
            parametaData.Stub(x => x.GetDataType()).Return(type);
            parametaData.Stub(x => x.GetNameTag()).Return(nameTag);
            parametaData.Stub(x => x.GetHelpTag()).Return(helpTag);
            parametaData.Stub(x => x.GetConflict()).Return(isConflict);
            parametaData.Stub(x => x.GetEnumDataType()).Return(enumDataType);
            parametaData.Stub(x => x.GetAdjustValue()).Return(adjustValue);
            return parametaData;
        }

        /// <summary>
        /// GetEnumTypeParameter
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="isVisible"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetEnumTypeParameter(string fieldName,bool isVisible = true)
        {
            return GetParameterMetaDataMock(isVisible, "1-1,2-2", TypeInfo.TypeEnum, fieldName, fieldName + ".help",
                false, "string");
        }

        /// <summary>
        /// GetFloatTypeParameter
        /// </summary>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetFloatTypeParameter(string fieldName)
        {
            return GetParameterMetaDataMock(true, "5.0-5.0,560.0-560.0", TypeInfo.TypeFloat, fieldName, fieldName + ".help",
                false, "string", 34.0f);
        }

        /// <summary>
        /// GetStringTypeParameter
        /// </summary>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetStringTypeParameter(string fieldName)
        {
            return GetParameterMetaDataMock(true, "5.0-5.0,560.0-560.0", TypeInfo.TypeString, "", fieldName + ".help",
                false, "string");
        }

        /// <summary>
        /// GetIntTypeParameter
        /// </summary>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static ParameterMetaDataMock GetIntTypeParameter(string fieldName)
        {
            return GetParameterMetaDataMock(true, "1-1,2-2,3-3", TypeInfo.TypeInteger, fieldName, fieldName + ".help",
                false, "int", 3);
        }
        #endregion

        #region Mocked Entities

        /// <summary>
        /// IKVPNodeMock
        /// </summary>
        public class IKVPNodeMock : IKVPNode
        {
            /// <summary>
            /// IKVPNodeMock
            /// </summary>
            public IKVPNodeMock() : base(IntPtr.Zero, false)
            {

            }

            //  override Getva
        }

        /// <summary>
        /// ScanProtocolMock
        /// </summary>
        [Serializable]
        public class ScanProtocolMock : IScanProtocol
        {
            /// <summary>
            /// ScanProtocolMock
            /// </summary>
            public ScanProtocolMock() : base(IntPtr.Zero, false)
            {

            }
        }

        /// <summary>
        ///     ScanProtocolMetaDataMock
        /// </summary>
        [Serializable]
        public class ScanProtocolMetaDataMock : IScanProtocolMetaData
        {
            /// <summary>
            /// ScanProtocolMetaDataMock
            /// </summary>
            public ScanProtocolMetaDataMock() : base(IntPtr.Zero, false)
            {

            }
        }

        /// <summary>
        /// ConflictGuidanceSuggestionsMock
        /// </summary>
        public class ConflictGuidanceSuggestionsMock : ConflictGuidanceSuggestions , IEnumerable<SuggestionStruct>
        {
            /// <summary>
            /// ConflictGuidanceSuggestionsMock
            /// </summary>
            public ConflictGuidanceSuggestionsMock() : base(0)
            {


            }

            /// <summary>
            /// ConflictGuidanceSuggestionsMock
            /// </summary>
            /// <param name="t"></param>
            public ConflictGuidanceSuggestionsMock(List<SuggestionStruct> t) : base(0)
            {
            }




            /// <summary>
            /// 
            /// </summary>
            /// <param name="item"></param>
            /// <returns></returns>
            public bool Contains(SuggestionStruct item)
            {
              return true;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="item"></param>
            /// <returns></returns>
            public bool Remove(SuggestionStruct item)
            {
              return true;

            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="item"></param>
            /// <returns></returns>
            public int IndexOf(SuggestionStruct item)
            {
               return 0;
            }
        }

        /// <summary>
        ///     Component Test class for ParameterEditor
        /// </summary>
        [Serializable]
        public class ParameterMetaDataMock : IParameterMetaData
        {
            /// <summary>
            /// 
            /// </summary>
            public ParameterMetaDataMock() : base(IntPtr.Zero, false)
            {

            }

            /// <summary>
            /// ParameterPath
            /// </summary>
            public string ParameterPath { get; internal set; }
        }


        /// <summary>
        /// 
        /// </summary>
        public class ICoilSelectionMock : ICoilSelection
        {
            /// <summary>
            /// 
            /// </summary>
            public ICoilSelectionMock() : base(IntPtr.Zero, false)
            {


            }
        }
        

        /// <summary>
        /// 
        /// </summary>
        public class ICoilLogicMock : ICoilLogic
        {
            /// <summary>
            /// 
            /// </summary>  
            public ICoilLogicMock() : base(IntPtr.Zero, false)
            {
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public class ICoilPropertiesMock : ICoilProperties
        {
            /// <summary>
            /// 
            /// </summary>  
            public ICoilPropertiesMock() : base(IntPtr.Zero, false)
            {
            }
        }
        
        #endregion
    }
}
#region Revision History

// 2019-11-15  Ramanjaneyulu SBV
//              Initial version
#endregion