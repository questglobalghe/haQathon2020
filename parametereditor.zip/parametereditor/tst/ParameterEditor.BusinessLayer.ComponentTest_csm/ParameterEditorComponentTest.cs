﻿#region (c) Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterEditorTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using NUnit.Framework;
using Philips.DI.Interfaces.Services.Messaging;
using Philips.DI.Interfaces.Services.UserMessaging;
using Philips.DI.Interfaces.Services.UserMessaging.Model;
using Philips.PmsMR.CTA.Platform.TestTemplate.Attributes;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using TypeInfo = Philips.PmsMR.Scanning.IMethods.TypeInfo;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer.ComponentTest_csm
{
    /// <summary>
    ///  ParameterEditorComponentTest - Component Test class for ParameterEditor which implemented IParameterEditor
    /// </summary>
    [Serializable]
    [ComponentTestFixture]
    public class ParameterEditorComponentTest
    {
        #region Private fields

        private int _waitTime = 200;
        private int _five = 5;
        private int _nine = 9;
        private IUnityContainer _container;
        private IParameterEditor _parameterEditor;
        private IPlanEditor _planEditor;
        private ParameterEditorDto _parameterEditorDto;
        private ParameterSessionInfo _parameterSessionInfo;
        private IScanProtocolMetaData _protocolMetaDataMock; // Need to check
        private IScanProtocol _scanProtocol; // Need to check
        private IScanProtocalWrapper _scanProtocalWrapper;
        private const string DefaultSuggestion = "String.ScanDashboardUI.ConflictGuidanceView.DefaultSuggestion";
        private ISoftwareOptionConfigurationUtil _softwareOptionConfigurationUtil;
        private bool _allGroupsNotLoaded = false;
        private IUserMessaging _userMessaging;
        #endregion

        #region One Time Set up & One Time Tear Down

        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            var currentDirectory = Directory.GetCurrentDirectory();
            var cwd = new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName;
            Directory.SetCurrentDirectory(cwd);
            _container = new UnityContainer();
            _container.LoadConfiguration();
            _userMessaging = MockRepository.GenerateMock<IUserMessaging>();
            _container.RegisterInstance<IUserMessaging>(_userMessaging, new ExternallyControlledLifetimeManager());
            var messagingServiceMock = MockRepository.GenerateMock<IMessagingService>();
            var mqService = MockRepository.GenerateMock<IMQService>();
            var broker = MockRepository.GenerateMock<IBroker>();
            mqService.Stub(x => x.ConvertTo<IBroker>()).Return(broker);
            messagingServiceMock.Stub(x => x.Proxy("ParameterEditorBroker")).IgnoreArguments().Return(mqService);
            _container.RegisterInstance(messagingServiceMock, new ContainerControlledLifetimeManager());
            _softwareOptionConfigurationUtil = MockRepository.GenerateMock<ISoftwareOptionConfigurationUtil>();
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(true);
            _container.RegisterInstance<ISoftwareOptionConfigurationUtil>(_softwareOptionConfigurationUtil, new ExternallyControlledLifetimeManager());
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());
            _planEditor = _container.Resolve<IPlanEditor>();
            _container.RegisterInstance<IPlanEditor>(_planEditor, new ExternallyControlledLifetimeManager());
            //Todo: Create Parameter editor and register as IPlanEditor and IParameterEditor
            _container.RegisterInstance<IParameterEditor>((_planEditor as IParameterEditor), new ExternallyControlledLifetimeManager());
            _parameterEditor = _container.Resolve<IParameterEditor>();
            _parameterEditor.ParameterEditorUpdated += ParameterEditorUpdated;
            _planEditor.ScanProtocolChanged += OnScanProtocolChanged;
            Directory.SetCurrentDirectory(currentDirectory);
        }

        /// <summary>
        ///     Shutdown the Scan modification Service
        /// </summary>
        [TearDown]
        public virtual void TearDown()
        {
            _parameterEditor.ParameterEditorUpdated -= ParameterEditorUpdated;
            _planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
            (_parameterEditor as IDisposable)?.Dispose();
            (_planEditor as IDisposable)?.Dispose();
            _container.Dispose();
        }

        #endregion

        #region Tests

        /// <summary>
        /// Verify SetParameter API
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanInParameters.Controls")]
        [ComponentTestCase(TestCaseId = "45087", TestCaseName = "VerifySetParameter")]
        [Step(StepIndex = 1,
            Description = "This test is to verify set parameter",
            Expected = "ScanProtocol's parameter field value should change to as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifySetParameter()
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            dic.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));
            GetProtocolMetaDataMock();
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic);
            var parameterSessionInfo = GetParameterSessionInfo();
            _planEditor.StartSession(parameterSessionInfo);


            ////Test SetParameter for float field EX_ACQ.patient_weight with multiple values
            //Act
            _parameterEditor.SetParameter("EX_ACQ.patient_weight", new[] { 2.0f, 3.0f });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_ACQ.patient_weight"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_ACQ.patient_weight"));

            ////Test SetParameter for float field EX_ACQ.patient_weight with single values
            //Act
            _parameterEditor.SetParameter("EX_ACQ.patient_weight", new[] { 2.0f });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_ACQ.patient_weight"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_ACQ.patient_weight"));

            ////Test SetParameter for int field EX_CARD.sync with multple values
            //Act
            _parameterEditor.SetParameter("EX_CARD.sync", new[] { 2, 4 });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.sync"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.sync"));

            ////Test SetParameter for int field EX_CARD.sync with single values
            //Act
            _parameterEditor.SetParameter("EX_CARD.sync", new[] { 2 });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.sync"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.sync"));

            ////Test SetParameter for string field EX_CARD.str with multilple values
            //Act
            _parameterEditor.SetParameter("EX_CARD.str", new[] { "", "" });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.str"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.str"));

            ////Test SetParameter for string field EX_CARD.str with single values
            //Act
            _parameterEditor.SetParameter("EX_CARD.str", new[] { "" });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.str"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.str"));

            ////Test SetParameter for custom field EX_CARD.str with single values
            //Act
            _parameterEditor.SetParameter("EX_CARD.str", new[] { new object() });

            //Assert
            _scanProtocol.AssertWasCalled(x => x.GetChildByPath("EX_CARD.str"));
            _scanProtocol.AssertWasCalled(x => x.SetCurrentParameter("EX_CARD.str"));
        }

        /// <summary>
        /// Verify SetActiveGroup API
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanInParameters.Controls.ActiveGroup")]
        [ComponentTestCase(TestCaseId = "45085", TestCaseName = "VerifySetActiveGroup")]
        [Step(StepIndex = 1,
            Description = "This test is to verify set active group",
            Expected = "ParameterEditorUpdated event should fired and actvie group should be changed as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifySetActiveGroup()
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            dic.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));
            GetProtocolMetaDataMock();
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic);
            var parameterSessionInfo = GetParameterSessionInfo();
            _allGroupsNotLoaded = true;
            _planEditor.StartSession(parameterSessionInfo);
            WaitUntilAllGroupLoaded();

            //Act
            _parameterEditor.SetActiveGroup(2);

            //Assert
            _allGroupsNotLoaded = true;
            _planEditor.RefreshSession(parameterSessionInfo);
            WaitUntilAllGroupLoaded();
            Assert.AreEqual(2, _parameterEditorDto.ActiveGroupId, $"Actvie group should be changed to 2, but it is  {_parameterEditorDto.ActiveGroupId}");

            //Act
            _parameterEditor.SetActiveGroup(4);

            //Assert
            _allGroupsNotLoaded = true;
            _planEditor.RefreshSession(parameterSessionInfo);
            WaitUntilAllGroupLoaded();
            Assert.AreEqual(4, _parameterEditorDto.ActiveGroupId, $"Actvie group should be changed to 4, but it is  {_parameterEditorDto.ActiveGroupId}");
        }

        /// <summary>
        /// Verify ResolveConflict API
        /// </summary>
        [TestCaseSource(nameof(ResolveConflictTestSource))]
        [Category("SWCMP.UW.ScanInParameters.Panel.Conflict")]
        [ComponentTestCase(TestCaseId = "45084", TestCaseName = "VerifyResolveConflict")]
        [Step(StepIndex = 1,
            Description = "This test is to verify resolve conflict",
            Expected = "ScanProtocolChanged event shoould fired and parameter's conflict should be fixed",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyResolveConflict(string str, string suggestionKey, int scenarioType)
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            dic.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));
            var dic1 = new Dictionary<string, IParameterMetaData>();
            dic1.Add("EX_CARD.sync", Utility.GetStringTypeParameter("EX_CARD.sync"));
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));

            GetProtocolMetaDataMock();

            var parameterSessionInfo = GetParameterSessionInfo(false);

            var singleKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            singleKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeFloat);
            singleKVPNode.Stub(x => x.GetFloatArrayValue()).Return(new FloatVector() { _five, _nine });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_GEO.fov")).Return(singleKVPNode);

            var stringKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            stringKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeString);
            singleKVPNode.Stub(x => x.GetStringArrayValue()).Return(new StringVector() { @"String1", "String2" });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_CARD.sync")).Return(stringKVPNode);

            var int32KVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            if (scenarioType != 2)
            {
                int32KVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeInteger);
                singleKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() {1, 2});
                _scanProtocol.Stub(x => x.GetChildByPath("EX_CARD.IntSync")).Return(int32KVPNode);
            }

            var customKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            customKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeComposite);
            _scanProtocol.Stub(x => x.GetChildByPath("CustomId")).Return(customKVPNode);

            var enumKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            enumKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
            enumKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { 1, 2 });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_RESP.user_def_bh_time_sec")).Return(enumKVPNode);

            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic);

            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;

            _scanProtocol.Stub(x => x.CloneToKVPDocument()).Return(new IKVPDocument(IntPtr.Zero, false));

            //Act
            _planEditor.StartSession(parameterSessionInfo);

            //Assert
            var parameterGroup = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial");
            Assert.AreEqual(false, parameterGroup.ConflictPresent, "As protocal state is not in conflict state, parameterGroup's ConflictPresent should be false.");

            //Arrange
            var scanProtocol = parameterSessionInfo.ScanProtocol;
            _protocolMetaDataMock.Stub(x => x.GetConflictParameters()).Return(new StringVector { "EX_PROC.image_types" });

            parameterSessionInfo.ScanProtocol = scanProtocol;
            parameterSessionInfo.BaselineProtocol = scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = true;

            _scanProtocalWrapper.Stub(x => x.GetConflictKey(null)).IgnoreArguments().Return("EX_PROC.image_types");
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments().Return(
                new List<SuggestionStruct>()
                {
                    new SuggestionStruct(IntPtr.Zero, false),
                    new SuggestionStruct(IntPtr.Zero, false)
                });
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(2);
            var singleParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var intParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var stringParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var enumParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var defaultParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceParameterStructs(null)).IgnoreArguments().Return(
                new List<ParameterStruct>()
                {
                    singleParameterStruct,
                    intParameterStruct,
                    stringParameterStruct,
                    enumParameterStruct,
                    defaultParameterStruct
                });

            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(singleParameterStruct)).Return("System.Single");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(singleParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(singleParameterStruct)).Return(2.0f);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(singleParameterStruct)).Return("EX_GEO.fov");

            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(intParameterStruct)).Return("System.Int32");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(intParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(intParameterStruct)).Return(4);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(intParameterStruct)).Return("EX_CARD.IntSync");

            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(stringParameterStruct)).Return("System.String");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(stringParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(stringParameterStruct)).Return(3);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(stringParameterStruct)).Return("EX_CARD.sync");

            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(enumParameterStruct)).Return("System.Enum");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(enumParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(enumParameterStruct)).Return(4);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(enumParameterStruct)).Return("EX_RESP.user_def_bh_time_sec");

            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(defaultParameterStruct)).Return("System.Custom");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(defaultParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(defaultParameterStruct)).Return(3);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(defaultParameterStruct)).Return("CustomId");

            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("key").Repeat.Once();

            var c = new Utility.ConflictGuidanceSuggestionsMock();
            parameterSessionInfo.ConflictGuidanceInfo = new ParameterConflictGuidanceInfo(IntPtr.Zero, false);
            parameterSessionInfo.ConflictGuidanceInfo.conflictKey = "EX_PROC.image_types";
            parameterSessionInfo.ConflictGuidanceInfo.suggestionInfo = new List<SuggestionStruct>();
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments().Return(new List<SuggestionStruct>()
            {
                new SuggestionStruct(IntPtr.Zero, false),
                new SuggestionStruct(IntPtr.Zero, false)
            });

            if (scenarioType == 1)
            {
                _scanProtocol.Stub(x => x.ApplyDelta((IKVPDocument)null)).IgnoreArguments().Throw(new Exception());
                //Act -- Assert
                _parameterEditor.ResolveConflict("EX_PROC.image_types", suggestionKey);

                _userMessaging.AssertWasCalled(x => x.Send(Arg<TextUserMessage>.Is.Anything));
            }
            else if (scenarioType == 2)
            {
                _parameterEditor.ResolveConflict("EX_PROC.image_types", suggestionKey);
                _userMessaging.AssertWasCalled(x => x.Send(Arg<TextUserMessage>.Is.Anything));
            }
            else
            {
                //Act
                _parameterEditor.ResolveConflict("EX_PROC.image_types", suggestionKey);

                //Assert
                if (suggestionKey == DefaultSuggestion)
                {
                    _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
                }
                else
                {
                    _scanProtocol.AssertWasNotCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
                }

                _userMessaging.AssertWasNotCalled(x => x.Send(Arg<TextUserMessage>.Is.Anything));
            }

        }

        /// <summary>
        /// Verify SetStackCoilSelection API
        /// </summary>
        [Test]
        [TestCaseSource(nameof(SetStackCoilSelectionTestSource))]
        [Category("SWCMP.UW.ScanInParameters.Panel.CoilSelection")]
        [ComponentTestCase(TestCaseId = "45089", TestCaseName = "VerifySetStackCoilSelection")]
        [Step(StepIndex = 1,
            Description = "This test is to verify set stack coil selection",
            Expected = "ScanProtocol's SetCoilSelectionStack should call and fire OnScanProtocolChanged event",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifySetStackCoilSelection(bool throwException)
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            GetProtocolMetaDataMock();
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);

            var parameterSessionInfo = GetParameterSessionInfo();
            var coilLogicMock = MockRepository.GenerateMock<Utility.ICoilLogicMock>();
            var coilPropertries = MockRepository.GenerateMock<Utility.ICoilPropertiesMock>();
            coilPropertries.Stub(x => x.GetManualSelectable()).Return(true);
            coilLogicMock.Stub(x => x.GetCoilProperties("")).IgnoreArguments().Return(coilPropertries);
            _scanProtocalWrapper.Stub(x => x.GetCoilLogic(null)).IgnoreArguments().Return(coilLogicMock);
            var coilSelection = MockRepository.GenerateMock<Utility.ICoilSelectionMock>();
            coilSelection.Stub(x => x.GetSelectedCoilElements()).Return(new List<CoilSelectionElement>()
            {
                new CoilSelectionElement("c", "s", 23),
                new CoilSelectionElement("c", "s", 24)
            });
            _scanProtocalWrapper.Stub(x => x.GetCoils(null, null)).IgnoreArguments().Return(new List<Coil>() {
                new Coil("coilName1","coilStocket1"), new Coil("coilName2","coilStocket2")});
            _scanProtocol.Stub(x => x.GetCoilSelectionStack(0, null)).IgnoreArguments().Return(coilSelection);
            _scanProtocol.Stub(x => x.GetNrStacks()).Return(2);
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.CloneToKVPDocument()).Return(new IKVPDocument(IntPtr.Zero, false));

            _planEditor.StartSession(parameterSessionInfo);
            if (throwException)
            {
                _scanProtocol.Stub(x => x.SetCoilSelectionStack(0, null, null)).IgnoreArguments()
                    .Throw(new Exception());
            }
            var stackDetailsDto = new StackDetailsDto();
            stackDetailsDto.CoilStackDetailsCollection = new ObservableCollection<CoilDetailsDto>()
            {
                new CoilDetailsDto() {IsCoilSelected = true, CoilName = "CoilName"}
            };

            if (throwException)
            {
                //Act -- Assert
                Assert.Throws<Exception>(() => _parameterEditor.SetStackCoilSelection(1, stackDetailsDto));
            }
            else
            {
                _parameterSessionInfo = null;
                _planEditor.ScanProtocolChanged += OnScanProtocolChanged;

                //Act
                _parameterEditor.SetStackCoilSelection(1, stackDetailsDto);

                //Assert
                parameterSessionInfo.ScanProtocol.AssertWasCalled(x => x.GetCoilSelectionStack(0, null),
                    op => op.IgnoreArguments());
                parameterSessionInfo.ScanProtocol.AssertWasCalled(x => x.SetCoilSelectionStack(0, null, null),
                op => op.IgnoreArguments());
                Assert.IsNotNull(_parameterSessionInfo.ScanProtocol, "As ScanProtocolChanged event is fired, _parameterSessionInfo's ScanProtocol property should be filled.");
            }
        }



        /// <summary>
        /// Verify SetCoilSmartSelection API
        /// </summary>
        [Test]
        [TestCaseSource(nameof(SetCoilSmartSelectionTestSource))]
        [Category("SWCMP.UW.ScanInParameters.Panel.CoilSelection")]
        [ComponentTestCase(TestCaseId = "45086", TestCaseName = "VerifySetCoilSmartSelection")]
        [Step(StepIndex = 1,
            Description = "This test is to verify set coil smart selection",
            Expected = "ScanProtocol's SetAutoCoilSelect should call and fire OnScanProtocolChanged event",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifySetCoilSmartSelection(bool throwException)
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            GetProtocolMetaDataMock(1);
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            var parameterSessionInfo = GetParameterSessionInfo();
            var coilSelection = MockRepository.GenerateMock<Utility.ICoilSelectionMock>();
            coilSelection.Stub(x => x.GetSelectedCoilElements()).Return(new List<CoilSelectionElement>()
            {
                new CoilSelectionElement("c", "s", 23),
                new CoilSelectionElement("c", "s", 24)
            });
            _scanProtocol.Stub(x => x.GetCoilSelectionStack(0, null)).IgnoreArguments().Return(coilSelection);
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.CloneToKVPDocument()).Return(new IKVPDocument(IntPtr.Zero, false));
            if (throwException)
            {
                parameterSessionInfo.ScanProtocol.Stub(x => x.SetAutoCoilSelect(true)).IgnoreArguments().Throw(new Exception());
            }
            _planEditor.StartSession(parameterSessionInfo);


            var stackDetailsDto = new StackDetailsDto();
            stackDetailsDto.CoilStackDetailsCollection = new ObservableCollection<CoilDetailsDto>();
            if (throwException)
            {
                //Act -- Assert
                Assert.Throws<Exception>(() => _parameterEditor.SetSmartSelect(true));
            }
            else
            {
                _parameterSessionInfo = null;
                _planEditor.ScanProtocolChanged += OnScanProtocolChanged;
                //Act
                _parameterEditor.SetSmartSelect(true);

                //Assert
                parameterSessionInfo.ScanProtocol.AssertWasCalled(x => x.SetAutoCoilSelect(true),
                    op => op.IgnoreArguments());
                Assert.IsNotNull(_parameterSessionInfo.ScanProtocol, "As ScanProtocolChanged event is fired, _parameterSessionInfo's ScanProtocol property should be filled.");
                _planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
            }
        }


        /// <summary>
        /// Verify ResetAll API
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanInParameters.Controls.Reset")]
        [ComponentTestCase(TestCaseId = "45083", TestCaseName = "VerifyResetAll")]
        [Step(StepIndex = 1,
            Description = "This test is to verify reset parameter after doing the few changes",
            Expected = "ScanProtocol's ApplyDelta mocked method should call and fire OnScanProtocolChanged event",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyResetAll()
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            GetProtocolMetaDataMock();
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);

            var parameterSessionInfo = GetParameterSessionInfo();
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.Clone()).Return(new IScanProtocol(IntPtr.Zero, false));
            _planEditor.StartSession(parameterSessionInfo);
            _planEditor.RefreshSession(parameterSessionInfo);


            //Test UndoParameter
            //Act
            _parameterEditor.UndoParameter();

            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());

            //Test RedoParameter
            //Act
            _parameterEditor.RedoParameter();

            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());

            //Test ResetAll
            //Act
            _parameterEditor.ResetAll();

            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());

            //Act
            _parameterEditor.SetParameter("EX_GEO.fov", new[] { 2 });
            _parameterEditor.SetParameter("EX_GEO.fov", new[] { 3 });
            _parameterEditor.SetParameter("EX_GEO.fov", new[] { 1 });

            //Test RedoParameter
            //Act
            _parameterEditor.UndoParameter();

            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());


            //Test ResetAll
            //Act
            _parameterEditor.ResetAll();

            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
            Assert.IsNotNull(_parameterSessionInfo.ScanProtocol, "As ScanProtocolChanged event is fired, _parameterSessionInfo's ScanProtocol property should be filled.");
        }

        /// <summary> 
        /// Verify UndoParameter API
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanInParameters.Controls")]
        [Category("SWCMP.UW.ScanInParameters.Controls.Undo")]
        [ComponentTestCase(TestCaseId = "45090", TestCaseName = "VerifyUndoParameter")]
        [Step(StepIndex = 1,
            Description = "This test is to verify undo parameter after starting the session",
            Expected = "ScanProtocol's ApplyDelta mocked method should call and fire OnScanProtocolChanged event",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyUndoParameter()
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            GetProtocolMetaDataMock();
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);
            var parameterSessionInfo = GetParameterSessionInfo();
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.Clone()).Return(new IScanProtocol(IntPtr.Zero, false));
            _allGroupsNotLoaded = true;
            _planEditor.StartSession(parameterSessionInfo);
            WaitUntilAllGroupLoaded();
            _allGroupsNotLoaded = true;
            _planEditor.RefreshSession(parameterSessionInfo);
            WaitUntilAllGroupLoaded();
            _parameterSessionInfo = null;

            //Test UndoParameter
            //Act
            _parameterEditor.UndoParameter();


            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
            Assert.IsNotNull(_parameterSessionInfo.ScanProtocol, "As ScanProtocolChanged event is fired, _parameterSessionInfo's ScanProtocol property should be filled.");
        }

        private void WaitUntilAllGroupLoaded()
        {
            while (_allGroupsNotLoaded)
            {
                Thread.Sleep(_waitTime);
            }
        }

        /// <summary>
        /// Test RedoParameter API
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanInParameters.Controls")]
        [Category("SWCMP.UW.ScanInParameters.Controls.Redo")]
        [ComponentTestCase(TestCaseId = "45030", TestCaseName = "VerifyRedoParameter")]
        [Step(StepIndex = 1,
            Description = "This test is to verify redo parameter after starting the session",
            Expected = "ScanProtocol's ApplyDelta mocked method should call and fire OnScanProtocolChanged event",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyRedoParameter()
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            GetProtocolMetaDataMock();

            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);

            var parameterSessionInfo = GetParameterSessionInfo();
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.Clone()).Return(new IScanProtocol(IntPtr.Zero, false));
            _planEditor.StartSession(parameterSessionInfo);
            _planEditor.RefreshSession(parameterSessionInfo);

            //Test UndoParameter
            //Act
            _parameterEditor.UndoParameter();

            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());

            //Test RedoParameter
            _parameterSessionInfo = null;

            //Act
            _parameterEditor.RedoParameter();

            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
            Assert.IsNotNull(_parameterSessionInfo.ScanProtocol, "As ScanProtocolChanged event is fired, _parameterSessionInfo's ScanProtocol property should be filled.");
        }

        /// <summary>
        /// Test RedoParameter API
        /// </summary>
        [Test]
        [TestCaseSource(nameof(SetStackSelectTestSource))]
        [Category("SWCMP.UW.ScanInParameters.Controls")]
        [ComponentTestCase(TestCaseId = "45919", TestCaseName = "VerifySetStackSelect")]
        [Step(StepIndex = 1,
            Description = "This test is to verify set stack select after starting the session",
            Expected = "ScanProtocol's SetAutoCoilSelect mocked method should call",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifySetStackSelect(bool isStackSelect, bool isThrowException)
        {
            var dic = Utility.GetCommonParameterMetaDatas();
            GetProtocolMetaDataMock();

            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic);

            var parameterSessionInfo = GetParameterSessionInfo();
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.CloneToKVPDocument()).Return(new IKVPDocument(IntPtr.Zero, false));
            _planEditor.StartSession(parameterSessionInfo);

            _parameterEditor.SetStackSelect(isStackSelect);
            if (isThrowException)
            {
                _scanProtocol.Stub(x => x.SetAutoCoilSelect(false)).IgnoreArguments().Throw(new Exception());
                //Act -- Assert
                Assert.Throws<Exception>(() => _parameterEditor.SetStackSelect(isStackSelect));
            }
            else
            {
                if (isStackSelect)
                {
                    _scanProtocol.AssertWasCalled(x => x.SetAutoCoilSelect(false));
                    _scanProtocol.AssertWasCalled(x => x.EnableStackSelect());
                    _scanProtocol.AssertWasNotCalled(x => x.DisableStackSelect());
                }
                else
                {
                    _scanProtocol.AssertWasCalled(x => x.DisableStackSelect());
                    _scanProtocol.AssertWasNotCalled(x => x.SetAutoCoilSelect(false));
                    _scanProtocol.AssertWasNotCalled(x => x.EnableStackSelect());
                }
            }
        }

        #endregion

        #region Private methods

        private ParameterSessionInfo GetParameterSessionInfo(bool resolveFields = true)
        {
            var objIntVector = new IntVector();
            objIntVector.Add(1);
            objIntVector.Add(2);
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(objIntVector);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");

            var objFloatVector = new FloatVector();
            objFloatVector.Add(_five);
            objFloatVector.Add(_nine);

            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");

            var kVpNodeMock = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(objIntVector);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(objFloatVector);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");

            _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();
            if (resolveFields)
            {
                _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);
            }

            var parameterSessionInfo = new ParameterSessionInfo();
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            return parameterSessionInfo;
        }

        private void GetProtocolMetaDataMock(uint currentNodeValueSize = 2)
        {
            _protocolMetaDataMock = MockRepository.GenerateMock<Utility.ScanProtocolMetaDataMock>();
            _protocolMetaDataMock.Stub(x => x.GetTabNames()).Return(Utility.tabNameMapping.Keys.ToList());
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _protocolMetaDataMock.Stub(x => x.GetTabHierarchy(tabNameMapping.Key))
                    .Return(Utility.GetTabHierarchyValue(tabNameMapping.Value));
            }

            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _protocolMetaDataMock.Stub(x =>
                        x.GetParametersPath(Utility.GetTabHierarchyValue(tabNameMapping.Value)))
                    .Return(Utility.GetParametersPathValue(
                        Utility.GetTabHierarchyValue(tabNameMapping.Value)));
            }

            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(new StringVector())).IgnoreArguments()
                .Return(null);

            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
            }
            _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(currentNodeValueSize);
        }

        private void ParameterEditorUpdated(object sender, ParameterEditorUpdateArgs e)
        {
            if (e.InitialMode)
            {
                if (_parameterEditorDto == null)
                {
                    _parameterEditorDto = new ParameterEditorDto();
                }
                _parameterEditorDto.CopyProperties(e.EditorDto);
                _parameterEditor.SetAdvanceParameterState(true);
            }
            else
            {

                for (int index = 0; e.EditorDto.ParameterGroups.Count - 1 > index; index++)
                {
                    var item = _parameterEditorDto.ParameterGroups.FirstOrDefault(x =>
                        x.GroupId == e.EditorDto.ParameterGroups[index].GroupId);
                    if (item != null)
                    {
                        _parameterEditorDto.ParameterGroups.Remove(item);
                    }
                    _parameterEditorDto.ParameterGroups.Add(e.EditorDto.ParameterGroups[index]);
                }

                _parameterEditorDto.ActiveGroupId = e.EditorDto.ActiveGroupId;
                _allGroupsNotLoaded = false;
            }
        }

        /// <summary>
        /// Called whenever there is any change in scanprotocol from UI.
        /// </summary>
        /// <param name="sender">sender of this event</param>
        /// <param name="modifiedScanProtocol">Holds the modified scanprotocol</param>
        private void OnScanProtocolChanged(object sender, IScanProtocol modifiedScanProtocol)
        {
            _parameterSessionInfo = new ParameterSessionInfo
            {
                ScanProtocol = modifiedScanProtocol
            };
        }

        #endregion

        #region Test Source


        internal static IEnumerable ResolveConflictTestSource
        {
            get
            {
                yield return new TestCaseData("DefaultSuggestion selection", DefaultSuggestion, 0); // 0 : DefaultSuggestion selection
                yield return new TestCaseData("DefaultSuggestion selection ; ApplyDelta API throws exceptipn", DefaultSuggestion, 1); // 1 : Code throw exception  : ApplyDelta API throws exceptipn
                yield return new TestCaseData("Parameter key selection", "Key", 0); // Parameter key selection
                yield return new TestCaseData("Parameter unavailable ; GetChildByPath API throws exception", "Key", 2); // 2 : Parameter unavailable : GetChildByPath API throws exception
            }
        }



        internal static IEnumerable SetStackCoilSelectionTestSource
        {
            get
            {
                yield return new TestCaseData(false);
                yield return new TestCaseData(true);
            }
        }

        internal static IEnumerable SetCoilSmartSelectionTestSource
        {
            get
            {
                yield return new TestCaseData(false);
                yield return new TestCaseData(true);
            }
        }

        internal static IEnumerable SetStackSelectTestSource
        {
            get
            {
                yield return new TestCaseData(false, false);
                yield return new TestCaseData(true, false);
                yield return new TestCaseData(true, true);
            }
        }


        #endregion
    }
}
#region Revision History

// 2019-11-15  Ramanjaneyulu SBV
//              Initial version
#endregion
