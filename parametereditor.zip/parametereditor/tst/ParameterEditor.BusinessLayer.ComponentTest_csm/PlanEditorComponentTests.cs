﻿#region (c) Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: PlanEditorComponentTests.cs
//

#endregion

using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using NUnit.Framework;
using Philips.DI.Interfaces.Services.Messaging;
using Philips.DI.Interfaces.Services.UserMessaging;
using Philips.PmsMR.CTA.Platform.TestTemplate.Attributes;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using Rhino.Mocks;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using TypeInfo = Philips.PmsMR.Scanning.IMethods.TypeInfo;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer.ComponentTest_csm
{

    /// <summary>
    ///  PlanEditorComponentTests - Component Test class for ParameterEditor which implemented IPlanEditor
    /// </summary>
    [Serializable]
    [ComponentTestFixture]
    public class PlanEditorComponentTests
    {
        #region Private fields

        private int _waitTime = 200;
        private int _five = 5;
        private int _nine = 9;
        private IUnityContainer _container;
        private IParameterEditor _parameterEditor;
        private IPlanEditor _planEditor;
        private ParameterEditorDto _parameterEditorDto;
        private ParameterSessionInfo _parameterSessionInfo;
        private IScanProtocolMetaData _protocolMetaDataMock;
        private IScanProtocol _scanProtocol;
        private IScanProtocol _baseLineScanProtocol;
        private IScanProtocalWrapper _scanProtocalWrapper;
        private ISoftwareOptionConfigurationUtil _softwareOptionConfigurationUtil;
        private IUserMessaging _userMessaging;
        private bool _allGroupsNotLoaded = false;
        private bool _isParameterEditorEnabled;
        #endregion

        #region One Time Set up & One Time Tear Down

        /// <summary>
        ///     Setup the test environment
        /// </summary>
        [SetUp]
        public void Setup()
        {
            var currentDirectory = Directory.GetCurrentDirectory();
            var cwd = new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName;
            Directory.SetCurrentDirectory(cwd);
            _container = new UnityContainer();
            _container.LoadConfiguration();
            _userMessaging = MockRepository.GenerateMock<IUserMessaging>();
            _container.RegisterInstance<IUserMessaging>(_userMessaging, new ExternallyControlledLifetimeManager());
            var messagingServiceMock = MockRepository.GenerateMock<IMessagingService>();
            var mqService = MockRepository.GenerateMock<IMQService>();
            var broker = MockRepository.GenerateMock<IBroker>();
            mqService.Stub(x => x.ConvertTo<IBroker>()).Return(broker);
            messagingServiceMock.Stub(x => x.Proxy("ParameterEditorBroker")).IgnoreArguments().Return(mqService);
            _container.RegisterInstance(messagingServiceMock, new ContainerControlledLifetimeManager());
            _softwareOptionConfigurationUtil = MockRepository.GenerateMock<ISoftwareOptionConfigurationUtil>();
            _container.RegisterInstance<ISoftwareOptionConfigurationUtil>(_softwareOptionConfigurationUtil, new ExternallyControlledLifetimeManager());
            _scanProtocalWrapper = MockRepository.GenerateMock<IScanProtocalWrapper>();
            _container.RegisterInstance<IScanProtocalWrapper>(_scanProtocalWrapper, new ExternallyControlledLifetimeManager());
            _planEditor = _container.Resolve<IPlanEditor>();
            _container.RegisterInstance<IPlanEditor>(_planEditor, new ExternallyControlledLifetimeManager());
            //Todo: Create Parameter editor and register as IPlanEditor and IParameterEditor
            _container.RegisterInstance<IParameterEditor>((_planEditor as IParameterEditor), new ExternallyControlledLifetimeManager());
            _parameterEditor = _container.Resolve<IParameterEditor>();
            _parameterEditor.ParameterEditorUpdated += ParameterEditorUpdated;
            _parameterEditor.ParameterEditorEnabled += OnParameterEditorEnabled;
            _planEditor.ScanProtocolChanged += OnScanProtocolChanged;
            Directory.SetCurrentDirectory(currentDirectory);
        }



        /// <summary>
        ///     Shutdown the Scan modification Service
        /// </summary>
        [TearDown]
        public virtual void TearDown()
        {
            _parameterEditor.ParameterEditorUpdated -= ParameterEditorUpdated;
            _parameterEditor.ParameterEditorEnabled -= OnParameterEditorEnabled;
            _planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
            (_parameterEditor as IDisposable)?.Dispose();
            (_planEditor as IDisposable)?.Dispose();
            _container.Dispose();
        }

        #endregion

        #region Tests



        #region StartSession
        /// <summary>
        /// Verify StartSession API
        /// </summary>
        [Test]
        [TestCaseSource(nameof(StartSessionTestSource))]
        [Category("SWCMP.UW.ScanInParameters.Panel.AdvancedParameters")]
        [Category("SWCMP.UW.ScanParameters.Info")]
        [ComponentTestCase(TestCaseId = "45097", TestCaseName = "VerifyStartSession")]
        [Step(StepIndex = 1,
            Description = "This test is to verify start session with advanced parameters",
            Expected = "Parameter groups and parameter details should be same as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyStartSession(string str, uint currentNodeValueSize, int defaultTab, bool isExpandableFields)
        {

            ParameterSessionInfo parameterSessionInfo = null;
            //Arrange
            if (isExpandableFields)
            {
                var dic1 = new Dictionary<string, IParameterMetaData>();
                dic1.Add(InformationModel.ExDynScanBeginTimesStr, Utility.GetStringTypeParameter(InformationModel.ExDynScanBeginTimesStr));
                dic1.Add(InformationModel.ExDynContrastPhaseNrDyns, Utility.GetIntTypeParameter(InformationModel.ExDynContrastPhaseNrDyns));
                dic1.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));

                _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(null, null)).IgnoreArguments().Return(dic1);

                _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(IntField);
                _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("enumValues");
                _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();
                _baseLineScanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();



                var stringKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
                stringKVPNode.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(new StringVector() { @"String1", "String2", });
                stringKVPNode.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");
                stringKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeString);
                _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExDynScanBeginTimesStr)).Return(stringKVPNode);
                _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(stringKVPNode)).Return(2);

                var stringBaseKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
                stringBaseKVPNode.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(new StringVector() { @"String1", "String2", "_", "_", "_" });
                stringBaseKVPNode.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");
                stringBaseKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeString);
                _baseLineScanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExDynScanBeginTimesStr)).Return(stringBaseKVPNode);
                _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(stringBaseKVPNode)).Return(5);

                var int32KVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
                int32KVPNode.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(new IntVector() { 1, 2, });
                int32KVPNode.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
                int32KVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeInteger);
                _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExDynContrastPhaseNrDyns)).Return(int32KVPNode);
                _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(int32KVPNode)).Return(2);


                var int32BaseKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
                int32BaseKVPNode.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(new IntVector() { 1, 2, 0, 0, 0, 0 });
                int32BaseKVPNode.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
                int32BaseKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeInteger);
                _baseLineScanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExDynContrastPhaseNrDyns)).Return(int32BaseKVPNode);
                _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(int32BaseKVPNode)).Return(6);

                var enumKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
                enumKVPNode.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(new IntVector() { 1, 2 });
                enumKVPNode.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
                enumKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
                _scanProtocol.Stub(x => x.GetChildByPath("EX_RESP.user_def_bh_time_sec")).Return(enumKVPNode);
                _baseLineScanProtocol.Stub(x => x.GetChildByPath("EX_RESP.user_def_bh_time_sec")).Return(enumKVPNode);
                _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(enumKVPNode)).Return(2);


                _protocolMetaDataMock = MockRepository.GenerateMock<Utility.ScanProtocolMetaDataMock>();
                _protocolMetaDataMock.Stub(x => x.GetTabNames()).Return(Utility.tabNameMapping.Keys.ToList());
                foreach (var tabNameMapping in Utility.tabNameMapping)
                {
                    _protocolMetaDataMock.Stub(x => x.GetTabHierarchy(tabNameMapping.Key))
                        .Return(Utility.GetTabHierarchyValue(tabNameMapping.Value));
                }
                foreach (var tabNameMapping in Utility.tabNameMapping)
                {
                    _protocolMetaDataMock.Stub(x =>
                            x.GetParametersPath(Utility.GetTabHierarchyValue(tabNameMapping.Value)))
                        .Return(Utility.GetParametersPathValue(
                            Utility.GetTabHierarchyValue(tabNameMapping.Value)));
                }
                _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(new StringVector())).IgnoreArguments()
                    .Return(null);
                foreach (var tabNameMapping in Utility.tabNameMapping)
                {
                    _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
                }
                _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");



                parameterSessionInfo = new ParameterSessionInfo();
                parameterSessionInfo.ScanProtocol = _scanProtocol;
                parameterSessionInfo.BaselineProtocol = _baseLineScanProtocol;
                parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
                parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
                parameterSessionInfo.IsEditMode = true;
                parameterSessionInfo.IsInConflict = false;



            }
            else
            {
                #region Regular

                var dic = Utility.GetCommonParameterMetaDatas();
                var inVisibleParameter = Utility.GetParameterMetaDataMock(false, "5.0-5.0,560.0-560.0",
                    TypeInfo.TypeFloat, "", ".help",
                    false, "string", 34.0f);
                dic.Add("EX_GEO.InVisible", inVisibleParameter);
                var dic1 = new Dictionary<string, IParameterMetaData>();
                dic1.Add("EX_CARD.sync", Utility.GetStringTypeParameter("EX_CARD.sync"));
                var dic2 = new Dictionary<string, IParameterMetaData>();
                dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
                var dic3 = new Dictionary<string, IParameterMetaData>();
                dic3.Add("EX_ACQ.patient_weight", Utility.GetIntTypeParameter("EX_ACQ.patient_weight"));

                if (defaultTab == 0)
                {
                    if (!Utility.tabNameMapping.ContainsKey("MGG_SOFTKEY_0"))
                    {
                        Utility.tabNameMapping.Add("MGG_SOFTKEY_0", "Geometry");
                    }
                }
                else
                {
                    Utility.tabNameMapping.Remove("MGG_SOFTKEY_0");
                }

                if (defaultTab == 4 && !Utility.tabNameMapping.ContainsKey("MGG_SOFTKEY_4"))
                {
                    if (!Utility.tabNameMapping.ContainsKey("MGG_SOFTKEY_4"))
                    {
                        Utility.tabNameMapping.Add("MGG_SOFTKEY_4", "Postproc");
                    }
                }
                else
                {
                    Utility.tabNameMapping.Remove("MGG_SOFTKEY_4");
                }

                GetProtocolMetaDataMock(currentNodeValueSize);

                _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(null, 0)).IgnoreArguments().Return("");
                foreach (var tabNameMapping in Utility.tabNameMapping)
                {
                    if (tabNameMapping.Value == "Initial")
                    {
                        _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                            Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                            null)).Return(dic);
                    }
                    else if (tabNameMapping.Value == "Geometry")
                    {
                        _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                            Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                            null)).Return(dic3);
                    }
                    else if (tabNameMapping.Value == "ALL")
                    {
                        _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                            Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                            null)).Return(Utility.GetALLFields());
                    }
                    else if (tabNameMapping.Value == Utility.InfoBar)
                    {
                        _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                            Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                            null)).Return(Utility.GetInfoBarFields());
                    }
                    else
                    {
                        _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                            Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                            null)).Return(dic2);
                    }

                }


                #endregion


                parameterSessionInfo = GetParameterSessionInfo();
            }


            //Act

            _allGroupsNotLoaded = true;
            _planEditor.StartSession(parameterSessionInfo);

            WaitUntilAllGroupsLoaded();

            if (isExpandableFields)
            {
                StringParameterDto stringParameterDto = (StringParameterDto)_parameterEditorDto.ParameterGroups
                    .FirstOrDefault(x => x.Name == "Initial").Parameters
                    .FirstOrDefault(y => y.Key.Contains(InformationModel.ExDynScanBeginTimesStr)).Value;

                //Assert
                Assert.AreEqual("String1", stringParameterDto.Values[0]);

                Int32ParameterDto intParameterDto = (Int32ParameterDto)_parameterEditorDto.ParameterGroups
                    .FirstOrDefault(x => x.Name == "Initial").Parameters
                    .FirstOrDefault(y => y.Key.Contains(InformationModel.ExDynContrastPhaseNrDyns)).Value;

                Assert.AreEqual(1, intParameterDto.Values[0]);
            }
            else
            {


                //Assert for Tab names
                foreach (var groupName in Utility.tabNameMapping.Values)
                {
                    if (groupName == Utility.InfoBar)
                    {
                        Assert.IsNotNull(_parameterEditorDto.InfoParameterGroupDto, "");
                    }
                    else
                    {
                        Assert.AreEqual(groupName,
                            _parameterEditorDto.ParameterGroups.FirstOrDefault(t => t.Name == groupName)?.Name,
                            $"Parameter groups should have one of the group name as {groupName}");
                    }
                }

                //Assert for Initial field count
                Assert.AreEqual(3,
                    _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial")?.Parameters.Count,
                    "Parameter Group 'Initial' should have parameters count as 2");

                // Test Enum Parameters for Group Initial
                var intScanProtocolValue = IntField.AsEnumerable().ToList();
                EnumParameterDto enumParameterDto = (EnumParameterDto)_parameterEditorDto.ParameterGroups
                    .FirstOrDefault(x => x.Name == "Initial").Parameters
                    .FirstOrDefault(y => y.Key.Contains("EX_PROC.image_types")).Value;
                var enumParameterList = enumParameterDto.Values.ToList();

                //Assert
                Assert.AreEqual(currentNodeValueSize > 1 ? intScanProtocolValue : new List<int>() { 2 },
                    enumParameterList);
                Assert.AreEqual("EX_PROC.image_types.help", enumParameterDto.Help,
                    $"EX_PROC.image_types parameter's Help property value should be 'EX_PROC.image_types.help'. But it is {enumParameterDto.Help}.");
                Assert.AreEqual("1-1", enumParameterDto.Ranges[0].ToString(),
                    $"EX_PROC.image_types parameter's Ranges property value should be '1-1'. But it is {enumParameterDto.Ranges[0].ToString()}.");

                // Test Float Parameters for Group Initial
                var fltScanProtocolValue = FloatField;
                SingleParameterDto singleParameterDto = (SingleParameterDto)_parameterEditorDto.ParameterGroups
                    .FirstOrDefault(x => x.Name == "Initial").Parameters
                    .FirstOrDefault(y => y.Key.Contains("EX_GEO.fov")).Value;
                var singleParameterList = singleParameterDto.Values[0];

                //Assert
                Assert.AreEqual(currentNodeValueSize > 1 ? fltScanProtocolValue[0] : 2.0, singleParameterList);
                Assert.AreEqual("EX_GEO.fov.help", singleParameterDto.Help,
                    $"EX_GEO.fov parameter's Help property value should be 'EX_GEO.fov.help'. But it is {singleParameterDto.Help}.");
                Assert.AreEqual(5.0, singleParameterDto.Ranges[0].lower,
                    $"EX_GEO.fov parameter's Ranges[0] lower value should be '5.0'. But it is {singleParameterDto.Ranges[0].lower}.");
                Assert.AreEqual(5.0, singleParameterDto.Ranges[0].upper,
                    $"EX_GEO.fov parameter's Ranges[0] upper value should be '5.0'. But it is {singleParameterDto.Ranges[0].upper}.");
                Assert.AreEqual(560.0, singleParameterDto.Ranges[1].lower,
                    $"EX_GEO.fov parameter's Ranges[1] lower value should be '560.0'. But it is {singleParameterDto.Ranges[1].lower}.");
                Assert.AreEqual(560.0, singleParameterDto.Ranges[1].upper,
                    $"EX_GEO.fov parameter's Ranges[1] upper value should be '560.0'. But it is {singleParameterDto.Ranges[1].upper}.");
                Assert.AreEqual(34.0f, singleParameterDto.StepValue,
                    $"EX_GEO.fov parameter's StepValue value should be '34.0f'. But it is {singleParameterDto.StepValue}.");

                // Test string Parameters for Group Physiology
                StringParameterDto geoStringParameterDto = (StringParameterDto)_parameterEditorDto.ParameterGroups
                    .FirstOrDefault(x => x.Name == "Physiology").Parameters
                    .FirstOrDefault(y => y.Key.Contains("EX_CARD.sync")).Value;

                //Assert
                Assert.AreEqual(currentNodeValueSize > 1 ? "String1" : "String3", geoStringParameterDto.Values[0]);
                Assert.AreEqual("EX_CARD.sync.help", geoStringParameterDto.Help,
                    $"EX_CARD.sync parameter's Help property value should be 'EX_CARD.sync.help'. But it is {geoStringParameterDto.Help}.");

                // Test Int Parameters for Group Geometry
                if (defaultTab == 0)
                {
                    Int32ParameterDto geoIntParameterDto = (Int32ParameterDto)_parameterEditorDto.ParameterGroups
                        .FirstOrDefault(x => x.Name == "Geometry").Parameters
                        .FirstOrDefault(y => y.Key.Contains("EX_ACQ.patient_weight")).Value;

                    //Assert
                    Assert.AreEqual(currentNodeValueSize > 1 ? IntField[0] : IntField[1], geoIntParameterDto.Values[0]);
                    Assert.AreEqual(3.0, geoIntParameterDto.StepValue,
                        $"EX_ACQ.patient_weight parameter's StepValue value should be '3.0'. But it is {geoIntParameterDto.StepValue}.");
                    Assert.AreEqual("EX_ACQ.patient_weight.help", geoIntParameterDto.Help,
                        $"EX_ACQ.patient_weight parameter's Help property value should be 'EX_ACQ.patient_weight.help'. But it is {geoIntParameterDto.Help}.");
                    Assert.AreEqual(1.0, geoIntParameterDto.Ranges[0].lower,
                        $"EX_ACQ.patient_weight parameter's Ranges[0].lower value should be '1.0'. But it is {geoIntParameterDto.Ranges[0].lower}.");
                    Assert.AreEqual(3, geoIntParameterDto.Ranges[0].upper,
                        $"EX_ACQ.patient_weight parameter's Ranges[0].upper value should be '3.0'. But it is {geoIntParameterDto.Ranges[0].upper}.");
                }

                //Assert
                Assert.AreEqual(defaultTab, _parameterEditorDto.ActiveGroupId,
                    $"As provided ActiveGroupId should be {defaultTab}, but it is {_parameterEditorDto.ActiveGroupId}");
            }
        }

        private void WaitUntilAllGroupsLoaded()
        {
            while (_allGroupsNotLoaded)
            {
                Thread.Sleep(_waitTime);
            }
        }

        /// <summary>
        /// Verify Parameters Types On StartSession
        /// </summary>
        [Test]
        [TestCaseSource(nameof(ParametersTypesOnStartSessionTestSource))]
        [Category("SWCMP.UW.ScanInParameters.Panel.AdvancedParameters")]
        [Category("SWCMP.UW.ScanParameters.Info.AdditionalParameters")]
        [Category("SWCMP.UW.ScanParameters.Info.ScanSuration")]
        [ComponentTestCase(TestCaseId = "45094", TestCaseName = "VerifyParametersTypesOnStartSession")]
        [Step(StepIndex = 1,
            Description = "This test is to verify start session with provided parameters",
            Expected = "Parameter details should be same as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyParametersTypesOnStartSession(string str, TypeInfo typeInfo)
        {
            //Arrange
            var dic = new Dictionary<string, IParameterMetaData>();
            var parameter = Utility.GetParameterMetaDataMock(true, "5.0-5.0,560.0-560.0", typeInfo, "EX_PROC.image_types", "EX_PROC.image_types.help",
                false, "string");
            dic.Add("EX_PROC.image_types", parameter);
            dic.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));
            GetProtocolMetaDataMock();
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic);
            var parameterSessionInfo = GetParameterSessionInfo();


            if (typeInfo == TypeInfo.TypeUnknown || typeInfo == TypeInfo.TypeComposite)
            {
                //Act
                _planEditor.StartSession(parameterSessionInfo);

                // Test Enum Parameters for Group Geometry
                var intScanProtocolValue = IntField.AsEnumerable().ToList();
                EnumParameterDto enumParameterDto = (EnumParameterDto)_parameterEditorDto.ParameterGroups
                    .FirstOrDefault(x => x.Name == "Initial").Parameters
                    .FirstOrDefault(y => y.Key.Contains("EX_RESP.user_def_bh_time_sec")).Value;

                //Assert
                _scanProtocalWrapper.AssertWasCalled(x => x.GetCurrentNodeValueSize(null),
                    op => op.IgnoreArguments());

            }
            else
            {
                //Act - Assert
                Assert.Throws<System.ArgumentOutOfRangeException>(() => _planEditor.StartSession(parameterSessionInfo));
            }

        }

        /// <summary>
        /// Test Postproc Tab
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanParameters.Info.AdditionalParameters")]
        [ComponentTestCase(TestCaseId = "45092", TestCaseName = "VerifyDelayedReconTab")]
        [Step(StepIndex = 1,
            Description = "This test is to verify start session with delayed recon tab",
            Expected = "ParameterEditorDto's ParameterGroups should contain tab with 'Delayed Recon' and parameters value should be same as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyDelayedReconTab()
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            dic2.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));

            if (!Utility.tabNameMapping.ContainsKey("MGG_SOFTKEY_4"))
            {
                Utility.tabNameMapping.Add("MGG_SOFTKEY_4", "Postproc");
            }

            GetProtocolMetaDataMock();

            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                if (tabNameMapping.Value == "Postproc")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic);
                }
                else
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic2);
                }
            }

            var parameterSessionInfo = GetParameterSessionInfo();

            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;

            //Act
            _planEditor.StartSession(parameterSessionInfo);

            //Assert
            Assert.AreEqual("Postproc", _parameterEditorDto.ParameterGroups.FirstOrDefault(t => t.Name == "Postproc").Name,
                $"Parameter groups should have one of the group name as 'Postproc'");



            // Test Parameters with different types for Group Postproc
            var intScanProtocolValue = IntField.AsEnumerable().ToList();
            EnumParameterDto enumParameterDto = (EnumParameterDto)_parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Postproc").Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_PROC.image_types")).Value;
            var enumParameterList = enumParameterDto.Values.ToList();

            //Assert
            Assert.AreEqual(intScanProtocolValue, enumParameterList);
            Assert.AreEqual("EX_PROC.image_types.help", enumParameterDto.Help,
               $"EX_PROC.image_types parameter's Help property value should be 'EX_PROC.image_types.help'. But it is {enumParameterDto.Help}.");
            Assert.AreEqual("1-1", enumParameterDto.Ranges[0].ToString(),
                $"EX_PROC.image_types parameter's Ranges[0] property value should be '1-1'. But it is {enumParameterDto.Ranges[0].ToString()}.");


            var fltScanProtocolValue = FloatField;
            SingleParameterDto singleParameterDto = (SingleParameterDto)_parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Postproc").Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_GEO.fov")).Value;
            var singleParameterList = singleParameterDto.Values[0];

            //Assert
            Assert.AreEqual(fltScanProtocolValue[0], singleParameterList);
            Assert.AreEqual("EX_GEO.fov.help", singleParameterDto.Help,
                $"EX_GEO.fov parameter's Help property value should be 'EX_GEO.fov.help'. But it is {singleParameterDto.Help}.");
            Assert.AreEqual(5.0, singleParameterDto.Ranges[0].lower,
                $"EX_GEO.fov parameter's Ranges[0] lower value should be '5.0'. But it is {singleParameterDto.Ranges[0].lower}.");
            Assert.AreEqual(5.0, singleParameterDto.Ranges[0].upper,
                $"EX_GEO.fov parameter's Ranges[0] upper value should be '5.0'. But it is {singleParameterDto.Ranges[0].upper}.");
            Assert.AreEqual(560.0, singleParameterDto.Ranges[1].lower,
                $"EX_GEO.fov parameter's Ranges[1] lower value should be '560.0'. But it is {singleParameterDto.Ranges[1].lower}.");
            Assert.AreEqual(560.0, singleParameterDto.Ranges[1].upper,
                $"EX_GEO.fov parameter's Ranges[1] upper value should be '560.0'. But it is {singleParameterDto.Ranges[1].upper}.");
            Assert.AreEqual(34.0f, singleParameterDto.StepValue,
                $"EX_GEO.fov parameter's StepValue value should be '34.0f'. But it is {singleParameterDto.StepValue}.");
        }

        /// <summary>
        /// Test Postproc Tab
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanParameters.Info.AdditionalParameters")]
        [ComponentTestCase(TestCaseId = "45920", TestCaseName = "VerifyDelayedReconScanInfoTab")]
        [Step(StepIndex = 1,
            Description = "This test is to verify scan info details with delayed recon tab",
            Expected = "ParameterEditorDto's ParameterGroups should contain tab with 'Delayed Recon' and parameters value should be same as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyDelayedReconScanInfoTab()
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            dic2.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));

            if (!Utility.tabNameMapping.ContainsKey("MGG_SOFTKEY_4"))
            {
                Utility.tabNameMapping.Add("MGG_SOFTKEY_4", "Postproc");
            }

            Utility.tabNameMapping.Remove("MGG_SOFTKEY_INFO");

            GetProtocolMetaDataMock();

            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                if (tabNameMapping.Value == "Postproc")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic);
                }
                else
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic2);
                }
            }

            var parameterSessionInfo = GetParameterSessionInfo();

            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;

            //Act
            _planEditor.StartSession(parameterSessionInfo);

            //Assert
            Assert.AreEqual("Postproc", _parameterEditorDto.ParameterGroups.FirstOrDefault(t => t.Name == "Postproc").Name,
                $"Parameter groups should have one of the group name as 'Postproc'");



            // Test Parameters with different types for Group Postproc
            var intScanProtocolValue = IntField.AsEnumerable().ToList();
            EnumParameterDto enumParameterDto = (EnumParameterDto)_parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Postproc").Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_PROC.image_types")).Value;
            var enumParameterList = enumParameterDto.Values.ToList();

            //Assert
            Assert.AreEqual(intScanProtocolValue, enumParameterList);
            Assert.AreEqual("EX_PROC.image_types.help", enumParameterDto.Help,
               $"EX_PROC.image_types parameter's Help property value should be 'EX_PROC.image_types.help'. But it is {enumParameterDto.Help}.");
            Assert.AreEqual("1-1", enumParameterDto.Ranges[0].ToString(),
                $"EX_PROC.image_types parameter's Ranges[0] property value should be '1-1'. But it is {enumParameterDto.Ranges[0].ToString()}.");


            var fltScanProtocolValue = FloatField;
            SingleParameterDto singleParameterDto = (SingleParameterDto)_parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Postproc").Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_GEO.fov")).Value;
            var singleParameterList = singleParameterDto.Values[0];

            //Assert
            Assert.AreEqual(fltScanProtocolValue[0], singleParameterList);
            Assert.AreEqual("EX_GEO.fov.help", singleParameterDto.Help,
                $"EX_GEO.fov parameter's Help property value should be 'EX_GEO.fov.help'. But it is {singleParameterDto.Help}.");
            Assert.AreEqual(5.0, singleParameterDto.Ranges[0].lower,
                $"EX_GEO.fov parameter's Ranges[0] lower value should be '5.0'. But it is {singleParameterDto.Ranges[0].lower}.");
            Assert.AreEqual(5.0, singleParameterDto.Ranges[0].upper,
                $"EX_GEO.fov parameter's Ranges[0] upper value should be '5.0'. But it is {singleParameterDto.Ranges[0].upper}.");

            Assert.AreEqual(560.0, singleParameterDto.Ranges[1].lower,
                $"EX_GEO.fov parameter's Ranges[1] lower value should be '560.0'. But it is {singleParameterDto.Ranges[1].lower}.");
            Assert.AreEqual(560.0, singleParameterDto.Ranges[1].upper,
                $"EX_GEO.fov parameter's Ranges[1] upper value should be '560.0'. But it is {singleParameterDto.Ranges[1].upper}.");
            Assert.AreEqual(34.0f, singleParameterDto.StepValue,
                $"EX_GEO.fov parameter's StepValue value should be '34.0f'. But it is {singleParameterDto.StepValue}.");
        }

        /// <summary>
        /// Verify StartSession
        /// </summary>
        [Test]
        [TestCaseSource(nameof(PhysiologyParameterTestSource))]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.HeartPhase.UserDefined")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.HeartPhase.Maximum")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.HeartPhase.Others")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.HeartPhase.Display")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.GateDelay.UserDefined")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.GateDelay.Others")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.TrigDelay.UserDefined")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.TrigDelay.Others")]
        [Category("SWCMP.UW.ScanParameters.Info.Physiology.BreathHold")]
        [ComponentTestCase(TestCaseId = "45098", TestCaseName = "VerifyStartSessionWithPhysiologyParameter")]
        [Step(StepIndex = 1,
            Description = "This test is to verify start session with physiology tab parameters",
            Expected = "1. Physiology tab parameters should be same as provided. 2. Fields should be visible or hidden as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyStartSessionWithPhysiologyParameter(string userDefinedHeartPhasesEnumName, bool userDefinedHeartPhasesVisible, string CardiacGateDelayModeEnumName,
            string CardiacTriggerDelayModeEnumName, bool breathholdControlVisible, bool isRoutineUi)
        {
            //Arrange
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));

            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(isRoutineUi);
            GetProtocolMetaDataMock(2);
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.HeartPhaseEnum, 2))
                .Return(userDefinedHeartPhasesEnumName);
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacGateDelayEnum, 2))
                .Return(CardiacGateDelayModeEnumName);
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.CardiacTriggerDelayEnum, 2))
                .Return(CardiacTriggerDelayModeEnumName);
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                if (tabNameMapping.Value == "ALL")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(Utility.GetALLFields(userDefinedHeartPhasesVisible, breathholdControlVisible));
                }

                else if (tabNameMapping.Value == Utility.InfoBar)
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(Utility.GetInfoBarFields());
                }
                else
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic2);
                }
            }
            var parameterSessionInfo = GetParameterSessionInfo();


            //Act
            _planEditor.StartSession(parameterSessionInfo);

            //Assert
            //Verify nr_heart_phases Parameter is visible or not
            BaseParameterDto nr_heart_phasesDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_CARD.nr_heart_phases")).Value;
            //Verify max_heart_phases Parameter is visible or not.
            BaseParameterDto max_heart_phasesDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key.Contains("IF.max_heart_phases")).Value;
            if (isRoutineUi)
            {
                if (userDefinedHeartPhasesEnumName == EnumNames.HeartPhaseUserDefined)
                {
                    Assert.IsTrue(nr_heart_phasesDto.Visible, "As HeartPhasesEnumName is UserDefined, EX_CARD.nr_heart_phases field visibility should set to true");
                    Assert.IsFalse(max_heart_phasesDto.Visible, "As HeartPhasesEnumName is not Maximum, IF.max_heart_phases field visibility should set to false");
                }
                else if (userDefinedHeartPhasesEnumName == EnumNames.HeartPhaseMaximum)
                {
                    Assert.IsFalse(nr_heart_phasesDto.Visible, "As HeartPhasesEnumName is Maximum, EX_CARD.nr_heart_phases field visibility should set to false");
                    Assert.IsTrue(max_heart_phasesDto.Visible, "As HeartPhasesEnumName is Maximum, IF.max_heart_phases field visibility should set to true");
                }
                else if (string.IsNullOrEmpty(userDefinedHeartPhasesEnumName))
                {
                    Assert.IsFalse(nr_heart_phasesDto.Visible, "As HeartPhasesEnumName is not UserDefined, EX_CARD.nr_heart_phases field visibility should set to false");
                    Assert.IsFalse(max_heart_phasesDto.Visible, "As HeartPhasesEnumName is not Maximum, IF.max_heart_phases field visibility should set to false");
                }

            }
            else
            {
                Assert.IsFalse(nr_heart_phasesDto.Visible, "As RoutineUi is false, EX_CARD.nr_heart_phases field visibility should set to false");
                Assert.IsFalse(max_heart_phasesDto.Visible, "As RoutineUi is false, IF.max_heart_phases field visibility should set to false");

            }

            BaseParameterDto heart_phase_control = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_CARD.heart_phase_control")).Value;
            if (isRoutineUi)
            {
                if (userDefinedHeartPhasesVisible)
                {
                    Assert.IsTrue(heart_phase_control.Visible);
                    Assert.IsTrue(heart_phase_control.Editable);
                }
                else
                {
                    Assert.IsTrue(heart_phase_control.Visible,
                        "Even though, EX_CARD.heart_phase_control visibility is false, System should display the field");
                    Assert.IsFalse(heart_phase_control.Editable,
                        "Even though, EX_CARD.heart_phase_control visibility is false, System should display the field in readonly mode");
                }
            }
            else
            {
                Assert.IsTrue(heart_phase_control.Visible);
                Assert.IsFalse(heart_phase_control.Editable);
            }

            //verify act_gate_delay parameter is visible or not
            BaseParameterDto act_gate_delayDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key.Contains("IF.act_gate_delay")).Value;
            //Verify gate_delay_ms Parameter is visible or not.
            BaseParameterDto gate_delay_msDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_CARD.gate_delay_ms")).Value;
            //Verify gate_delay Parameter is visible or not.
            BaseParameterDto gate_delayDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_CARD.gate_delay")).Value;
            if (isRoutineUi)
            {
                if (string.IsNullOrEmpty(CardiacGateDelayModeEnumName))
                {
                    Assert.IsFalse(gate_delay_msDto.Visible,
                        "As CardiacGateDelayMode is not UserDefined, EX_CARD.gate_delay_ms field visibility should set to false");
                    Assert.IsTrue(act_gate_delayDto.Visible,
                        "As CardiacGateDelayMode is not UserDefined, IF.act_gate_delay field visibility should set to true");
                }
                else
                {
                    Assert.IsFalse(act_gate_delayDto.Visible,
                        "As CardiacGateDelayMode is UserDefined, IF.act_gate_delay field visibility should set to false");
                    Assert.IsTrue(gate_delay_msDto.Visible,
                        "As CardiacGateDelayMode is UserDefined, EX_CARD.gate_delay_ms field visibility should set to true");
                }
            }
            else
            {
                Assert.IsTrue(gate_delay_msDto.Visible,
                    "As RoutineUi is false, EX_CARD.gate_delay_ms field visibility should set to true");
                Assert.IsFalse(act_gate_delayDto.Visible,
                    "As RoutineUi is false, IF.act_gate_delay field visibility should set to false");
            }

            //Verify trig_delay Parameter is visible or not.
            BaseParameterDto trig_delayDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key == "EX_CARD.trig_delay").Value;
            //Verify no_trig_period_trig_del Parameter is visible or not.
            BaseParameterDto no_trig_period_trig_delDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key.Contains("IF.no_trig_period_trig_del")).Value;

            if (isRoutineUi)
            {
                if (string.IsNullOrEmpty(CardiacTriggerDelayModeEnumName))
                {
                    Assert.IsTrue(no_trig_period_trig_delDto.Visible,
                        "As CardiacTriggerDelayMode is not UserDefined, IF.no_trig_period_trig_del field visibility should set to true");
                    Assert.IsFalse(trig_delayDto.Visible,
                        "As CardiacTriggerDelayMode is not UserDefined, EX_CARD.trig_delay field visibility should set to false");
                }
                else
                {
                    Assert.IsTrue(trig_delayDto.Visible,
                        "As CardiacTriggerDelayMode is UserDefined, EX_CARD.trig_delay field visibility should set to true");
                    Assert.IsFalse(no_trig_period_trig_delDto.Visible,
                        "As RoutineUi is false, IF.no_trig_period_trig_del field visibility should set to false");
                }
            }
            else
            {
                Assert.IsTrue(no_trig_period_trig_delDto.Visible,
                    "As RoutineUi is false, IF.no_trig_period_trig_del field visibility should set to true");
                Assert.IsFalse(trig_delayDto.Visible,
                    "As RoutineUi is false, EX_CARD.trig_delay field visibility should set to false");
            }

            //Verify user_def_bh_time_sec Parameter is visible or not.
            BaseParameterDto user_def_bh_time_secDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 10).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_RESP.user_def_bh_time_sec")).Value;
            if (isRoutineUi)
            {
                if (breathholdControlVisible)
                {
                    Assert.IsTrue(user_def_bh_time_secDto.Visible,
                        "As EX_RESP.user_def_bh_time_sec visibility value is false, system should display the field");
                }
                else
                {
                    Assert.IsTrue(user_def_bh_time_secDto.Visible,
                        "Even though EX_RESP.user_def_bh_time_sec visibility value is false, system should display the field");
                }
            }
            else
            {
                if (breathholdControlVisible)
                {
                    Assert.IsTrue(user_def_bh_time_secDto.Visible,
                        "As EX_RESP.user_def_bh_time_sec visibility value is false, system should display the field");
                }
                else
                {
                    Assert.IsFalse(user_def_bh_time_secDto.Visible,
                        "Even though EX_RESP.user_def_bh_time_sec visibility value is false, system should not display the field");
                }
            }
        }

        /// <summary>
        /// Verify StartSession
        /// </summary>
        [Test]
        [TestCaseSource(nameof(SummaryParameterTestSource))]
        [Category("SWCMP.UW.ScanInParameters.Panel.Info")]
        [Category("SWCMP.UW.ScanInParameters.Panel.Info.SliceGap")]
        [ComponentTestCase(TestCaseId = "45100", TestCaseName = "VerifyStartSessionWithSummaryParameter")]
        [Step(StepIndex = 1,
            Description = "This test is to verify start session with summary tab parameters",
            Expected = "1. Summary tab parameters should be same as provided. 2. field EX_STACKS[0].slice_gap should be visible or hidden as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyStartSessionWithSummaryParameter(string gapModeEnumName, string acqAccelEnumName, bool isRoutineUi)
        {
            //Arrange
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(isRoutineUi);
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            GetProtocolMetaDataMock(2);
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.GapModeEnum, 2))
                .Return(gapModeEnumName);
            _scanProtocalWrapper.Stub(x => x.GetEnumNameFromValue(EnumNames.MpuAcqAccelEnum, 2))
                .Return(acqAccelEnumName);
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                if (tabNameMapping.Value == "ALL")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(Utility.GetALLFields());
                }

                else if (tabNameMapping.Value == Utility.InfoBar)
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(Utility.GetInfoBarFields());
                }
                else
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic2);
                }
            }

            var curParameterMetaData = Utility.GetEnumTypeParameter("EX_GEO.cur_stack_id");
            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData("EX_GEO.cur_stack_id")).Return(curParameterMetaData);

            var parameterSessionInfo = GetParameterSessionInfo();

            //Act
            _planEditor.StartSession(parameterSessionInfo);


            //Assert
            //Verify GapControl Parameter is visible or not
            BaseParameterDto cur_stack_slice_gapDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 9).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_STACKS[1].slice_gap")).Value;
            //Verify SliceGapInfo Parameter is visible or not.
            BaseParameterDto act_slice_gapDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 9).Parameters
                .FirstOrDefault(y => y.Key.Contains("IF.act_slice_gap")).Value;
            if (isRoutineUi)
            {
                if (string.IsNullOrEmpty(gapModeEnumName))
                {
                    Assert.IsFalse(cur_stack_slice_gapDto.Visible,
                        "As GapModeEnum is not UserDefined, EX_STACKS[1].slice_gap field visibility should set to false");
                    Assert.IsTrue(act_slice_gapDto.Visible,
                        "As GapModeEnum is not UserDefined, IF.act_slice_gap field visibility should set to true");
                }
                else
                {
                    Assert.IsTrue(cur_stack_slice_gapDto.Visible,
                        "As GapModeEnum is UserDefined, EX_STACKS[1].slice_gap field visibility should set to true");
                    Assert.IsFalse(act_slice_gapDto.Visible,
                        "As GapModeEnum is UserDefined, IF.act_slice_gap field visibility should set to false");
                }
            }
            else
            {
                Assert.IsTrue(cur_stack_slice_gapDto.Visible,
                    "As GapModeEnum is UserDefined, EX_STACKS[1].slice_gap field visibility should set to true");
                Assert.IsFalse(act_slice_gapDto.Visible,
                    "As RoutineUi is false, IF.act_slice_gap field visibility should set to false");
            }


            //Verify GapControl Parameter is visible or not
            BaseParameterDto sensePRedFactorDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 9).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_GEO.sense_p_red_factor")).Value;
            //Verify SliceGapInfo Parameter is visible or not.
            BaseParameterDto senseSRedFactorDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 9).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_GEO.sense_s_red_factor")).Value;
            BaseParameterDto csFactorDto = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == 9).Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_ACQ.cs_factor")).Value;

            //Verify Acceleration Method parameter dependent fields status based on accelerationMethod enum selection.
            if (string.IsNullOrEmpty(acqAccelEnumName))
            {
                Assert.IsFalse(sensePRedFactorDto.Visible, "As accelerationMethod enum selected value is empty, EX_GEO.sense_p_red_factor parameter's visibility should set to false.");
                Assert.IsFalse(senseSRedFactorDto.Visible, "As accelerationMethod enum selected value is empty, EX_GEO.sense_s_red_factor parameter's visibility should set to false.");
                Assert.IsFalse(csFactorDto.Visible, "As accelerationMethod enum selected value is empty, EX_ACQ.cs_factor parameter's visibility should set to false.");
            }
            else if (acqAccelEnumName == EnumNames.MpuAcqAccelSense)
            {
                Assert.IsTrue(sensePRedFactorDto.Visible, $"As accelerationMethod enum selected value is {acqAccelEnumName}, EX_GEO.sense_p_red_factor parameter's visibility should set to true.");
                Assert.IsTrue(senseSRedFactorDto.Visible, $"As accelerationMethod enum selected value is {acqAccelEnumName}, EX_GEO.sense_s_red_factor parameter's visibility should set to true.");
                Assert.IsFalse(csFactorDto.Visible, $"As accelerationMethod enum value is selected is {acqAccelEnumName}, EX_ACQ.cs_factor parameter's visibility should set to false.");
            }
            else if (acqAccelEnumName == EnumNames.MpuAcqAccelCsSense || acqAccelEnumName == EnumNames.MpuAcqAccelCsSenseAi)
            {
                Assert.IsFalse(sensePRedFactorDto.Visible, $"As accelerationMethod enum selected value is {acqAccelEnumName}, EX_GEO.sense_p_red_factor parameter's visibility should set to false.");
                Assert.IsFalse(senseSRedFactorDto.Visible, $"As accelerationMethod enum selected value is {acqAccelEnumName}, EX_GEO.sense_s_red_factor parameter's visibility should set to false.");
                Assert.IsTrue(csFactorDto.Visible, $"As accelerationMethod enum selected value is {acqAccelEnumName}, EX_ACQ.cs_factor parameter's visibility should set to true.");
            }

        }


        #endregion

        #region Refresh Session

        /// <summary>
        /// Verify RefreshSession
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanInParameters.Panel.AdvancedParameters")]
        [Category("SWCMP.UW.ScanParameters.Info")]
        [ComponentTestCase(TestCaseId = "45095", TestCaseName = "VerifyRefreshSession")]
        [Step(StepIndex = 1,
            Description = "This test is to verify refresh session with advanced parameters",
            Expected = "Parameter tabs and parameter details should be same as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyRefreshSession()
        {
            //Act
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add("EX_GEO.fov", Utility.GetFloatTypeParameter("EX_GEO.fov"));
            dic.Add("EX_RESP.user_def_bh_time_sec", Utility.GetEnumTypeParameter("EX_RESP.user_def_bh_time_sec", true));
            var dic1 = new Dictionary<string, IParameterMetaData>();
            dic1.Add("EX_CARD.sync", Utility.GetStringTypeParameter("EX_CARD.sync"));
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            var dic3 = new Dictionary<string, IParameterMetaData>();
            dic3.Add("EX_ACQ.patient_weight", Utility.GetIntTypeParameter("EX_ACQ.patient_weight"));
            GetProtocolMetaDataMock();
            var parameterSessionInfo = GetParameterSessionInfo(false);
            var singleKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            singleKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeFloat);
            singleKVPNode.Stub(x => x.GetFloatArrayValue()).Return(new FloatVector() { _five, _nine });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_GEO.fov")).Return(singleKVPNode);
            var stringKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            stringKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeString);
            singleKVPNode.Stub(x => x.GetStringArrayValue()).Return(new StringVector() { @"String1", "String2" });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_CARD.sync")).Return(stringKVPNode);
            var int32KVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            int32KVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeInteger);
            singleKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { 1, 2 });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_CARD.IntSync")).Return(int32KVPNode);
            var customKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            customKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeComposite);
            _scanProtocol.Stub(x => x.GetChildByPath("CustomId")).Return(customKVPNode);
            var enumKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            enumKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
            enumKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { 3, 4 });
            _scanProtocol.Stub(x => x.GetChildByPath("EX_RESP.user_def_bh_time_sec")).Return(enumKVPNode);
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic);
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.Clone()).Return(new IScanProtocol(IntPtr.Zero, false));

            //Act
            _planEditor.StartSession(parameterSessionInfo);

            //Assert

            var parameterGroup = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial");
            Assert.AreEqual(false, parameterGroup.ConflictPresent, "As provided parameterSessionInfo's IsInConflict is false,Initial parameterGroup's ConflictPresent should be false");

            //Test Enum field in Group Initial is in conflict state or not
            var intScanProtocolValue = new IntVector() { 3, 4 };
            EnumParameterDto enumParameterDto = (EnumParameterDto)_parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial").Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_RESP.user_def_bh_time_sec")).Value;
            var enumParameterList = enumParameterDto.Values.ToList();

            //Asset
            Assert.AreEqual(intScanProtocolValue, enumParameterList);
            Assert.AreEqual("EX_RESP.user_def_bh_time_sec.help", enumParameterDto.Help,
                $"EX_RESP.user_def_bh_time_sec's Help property value should be 'EX_RESP.user_def_bh_time_sec.help'. But it is {enumParameterDto.Help}.");
            Assert.AreEqual("1-1", enumParameterDto.Ranges[0].ToString(),
            $"EX_PROC.image_types's Ranges[0] value should be '1-1'. But it is {enumParameterDto.Ranges[0].ToString()}.");
            Assert.AreEqual(false, enumParameterDto.InConflict,
                "As no conflict provided for field EX_RESP.user_def_bh_time_sec, EX_RESP.user_def_bh_time_sec's InConflict property should be false");
            Assert.AreEqual(false, _parameterEditorDto.ConflictPresent,
                "As no conflict provided for parametersessioninfo, _parameterEditorDto's ConflictPresent property should be false");

            //Arrange
            var scanProtocol = parameterSessionInfo.ScanProtocol;
            _protocolMetaDataMock.Stub(x => x.GetConflictParameters()).Return(new StringVector { "EX_RESP.user_def_bh_time_sec" });
            parameterSessionInfo.ScanProtocol = scanProtocol;
            parameterSessionInfo.BaselineProtocol = scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = true;
            _scanProtocalWrapper.Stub(x => x.GetConflictKey(null)).IgnoreArguments().Return("EX_RESP.user_def_bh_time_sec");
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments().Return(
                new List<SuggestionStruct>()
                {
                    new SuggestionStruct(IntPtr.Zero, false),
                    new SuggestionStruct(IntPtr.Zero, false)
                });
            var t = new List<SuggestionStruct>()
            {
                new SuggestionStruct(IntPtr.Zero, false),
                new SuggestionStruct(IntPtr.Zero, false)
            };
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceSuggestions(null)).IgnoreArguments()
                .Return(new Utility.ConflictGuidanceSuggestionsMock(t));
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(2);
            var singleParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var intParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var stringParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var enumParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            var defaultParameterStruct = new ParameterStruct(IntPtr.Zero, false);
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceParameterStructs(null)).IgnoreArguments().Return(
                new List<ParameterStruct>()
                {
                    singleParameterStruct,
                    intParameterStruct,
                    stringParameterStruct,
                    enumParameterStruct,
                    defaultParameterStruct
                }
            );

            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(singleParameterStruct)).Return("System.Single");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(singleParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(singleParameterStruct)).Return(2.0f);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(singleParameterStruct)).Return("EX_GEO.fov");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(intParameterStruct)).Return("System.Int32");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(intParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(intParameterStruct)).Return(4);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(intParameterStruct)).Return("EX_CARD.IntSync");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(stringParameterStruct)).Return("System.String");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(stringParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(stringParameterStruct)).Return(3);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(stringParameterStruct)).Return("EX_CARD.sync");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(enumParameterStruct)).Return("System.Enum");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(enumParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(enumParameterStruct)).Return(4);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(enumParameterStruct)).Return("EX_RESP.user_def_bh_time_sec");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(defaultParameterStruct)).Return("System.Custom");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(defaultParameterStruct)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(defaultParameterStruct)).Return(3);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(defaultParameterStruct)).Return("CustomId");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("key");

            var c = new Utility.ConflictGuidanceSuggestionsMock();
            parameterSessionInfo.ConflictGuidanceInfo = new ParameterConflictGuidanceInfo(IntPtr.Zero, false);
            parameterSessionInfo.ConflictGuidanceInfo.conflictKey = "EX_RESP.user_def_bh_time_sec";
            parameterSessionInfo.ConflictGuidanceInfo.suggestionInfo = new List<SuggestionStruct>();

            //Act
            _planEditor.RefreshSession(parameterSessionInfo);

            //Assert
            Assert.AreEqual(true, _parameterEditorDto.ConflictPresent,
                $"As provided parameterSessionInfo's IsInConflict is true. _parameterEditorDto's ConflictPresent value should be true.");

            //Test Enum field in Group Initial is in conflict state or not
            intScanProtocolValue = new IntVector() { 3, 4 };
            enumParameterDto = (EnumParameterDto)_parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial").Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_RESP.user_def_bh_time_sec")).Value;
            enumParameterList = enumParameterDto.Values.ToList();
            Assert.AreEqual(intScanProtocolValue, enumParameterList);
            Assert.AreEqual("EX_RESP.user_def_bh_time_sec.help", enumParameterDto.Help,
                $"EX_RESP.user_def_bh_time_sec parameter's Help property value should be 'EX_RESP.user_def_bh_time_sec.help'. But it is {enumParameterDto.Help}.");
            Assert.AreEqual("1-1", enumParameterDto.Ranges[0].ToString(),
                $"EX_RESP.user_def_bh_time_sec parameter's Ranges property value should be '1-1'. But it is {enumParameterDto.Ranges[0].ToString()}.");
            Assert.AreEqual(false, enumParameterDto.InConflict,
                "As no conflict present for provide field, enumParameterDto's InConflict property value should be false");

            //Act
            _planEditor.RefreshSession(parameterSessionInfo);
            _parameterEditor.SetParameter("EX_GEO.fov", new[] { 2 });
            _parameterEditor.SetParameter("EX_GEO.fov", new[] { 3 });
            _parameterEditor.SetParameter("EX_GEO.fov", new[] { 1 });
            _parameterEditor.UndoParameter();
            _planEditor.RefreshSession(parameterSessionInfo);
            _planEditor.RefreshSession(parameterSessionInfo);

            //Assert
            _scanProtocol.AssertWasCalled(x => x.ApplyDelta((IKVPDocument)null), op => op.IgnoreArguments());
        }

        /// <summary>
        /// Verify Precision
        /// </summary>
        [Test]
        [Category("SWCMP.ScanDashboard.Panels.ConflictCase.AssistancePanel")]
        [ComponentTestCase(TestCaseId = "49203", TestCaseName = "VerifyPrecision")]
        [Step(StepIndex = 1,
            Description = "This test is to verify conflict suggestions for float type parameters",
            Expected = "Conflict suggestion shall have float value of precision 2",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyPrecision()
        {
            //Act
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add(InformationModel.ExGeofov, Utility.GetFloatTypeParameter(InformationModel.ExGeofov));
            dic.Add(InformationModel.ExRespUserDefBhTimeSec, Utility.GetEnumTypeParameter(InformationModel.ExRespUserDefBhTimeSec, true));
            dic.Add(InformationModel.IfRelativeSnr, Utility.GetFloatTypeParameter(InformationModel.IfRelativeSnr));
            dic.Add(InformationModel.IfAbsoluteSnr, Utility.GetFloatTypeParameter(InformationModel.IfAbsoluteSnr));

            GetProtocolMetaDataMock();
            var parameterSessionInfo = GetParameterSessionInfo(false);
            var singleKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            singleKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeFloat);
            singleKVPNode.Stub(x => x.GetFloatArrayValue()).Return(new FloatVector() { _five, _nine });
            singleKVPNode.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(_five);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExGeoCurStackId)).Return(singleKVPNode);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExGeofov)).Return(singleKVPNode);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.IfRelativeSnr)).Return(singleKVPNode);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.IfAbsoluteSnr)).Return(singleKVPNode);

            var enumKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            enumKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
            enumKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { 3, 4 });
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExRespUserDefBhTimeSec)).Return(enumKVPNode);
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic);
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.Clone()).Return(new IScanProtocol(IntPtr.Zero, false));

            //Act
            _planEditor.StartSession(parameterSessionInfo);

            //Assert

            var parameterGroup = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial");
            Assert.AreEqual(false, parameterGroup.ConflictPresent, "As provided parameterSessionInfo's IsInConflict is false,Initial parameterGroup's ConflictPresent should be false");

            //Arrange
            var scanProtocol = parameterSessionInfo.ScanProtocol;
            var ParameterMockData = Utility.GetParameterMetaDataMock(false, "5.0-5.0,560.0-560.0",
                TypeInfo.TypeFloat, "", ".help",
                false, "string", 34.0f);
            _protocolMetaDataMock.Stub(x => x.GetConflictParameters()).Return(new StringVector { InformationModel.ExGeofov });
            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(Arg<String>.Is.Anything)).IgnoreArguments().Return(ParameterMockData);
            parameterSessionInfo.ScanProtocol = scanProtocol;
            parameterSessionInfo.BaselineProtocol = scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = true;
            _scanProtocalWrapper.Stub(x => x.GetConflictKey(null)).IgnoreArguments().Return(InformationModel.ExGeofov);
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments().Return(
                new List<SuggestionStruct>()
                {
                    new SuggestionStruct(IntPtr.Zero, false),
                    new SuggestionStruct(IntPtr.Zero, false)
                });


            var conflictParameters = new ParameterStruct("EX.conflict_suggestion", true, 2.11f);
            var conflictParametersCollection = new List<ParameterStruct>() { conflictParameters };
            var suggestionStructsCollection = new List<SuggestionStruct>()
            {
                new SuggestionStruct(true,"xmugeo000",conflictParametersCollection)
            };
            var conflictGuidanceSuggestions = new ConflictGuidanceSuggestions((ICollection)suggestionStructsCollection);
            var conflictGuidanceParameters = new ConflictGuidanceParameters((ICollection)conflictParametersCollection);


            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceSuggestions(Arg<ParameterConflictGuidanceInfo>.Is.Anything)).IgnoreArguments()
                .Return(conflictGuidanceSuggestions);
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(2);

            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(Arg<ParameterStruct>.Is.Anything)).Return(typeof(ParameterStruct).ToString());
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(Arg<ParameterStruct>.Is.Anything)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(Arg<ParameterStruct>.Is.Anything)).Return(1.5634322f);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(Arg<ParameterStruct>.Is.Anything)).Return(InformationModel.ExGeofov);
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceParameters(null)).IgnoreArguments().Return(conflictGuidanceParameters);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("xmugeo000");

            parameterSessionInfo.ConflictGuidanceInfo = new ParameterConflictGuidanceInfo(IntPtr.Zero, false);
            parameterSessionInfo.ConflictGuidanceInfo.conflictKey = "EX_GEO.fov";
            parameterSessionInfo.ConflictGuidanceInfo.suggestionInfo = new List<SuggestionStruct>();
            _parameterEditor.SetParameter("EX_GEO.fov", new[] { 2.371211393f });

            //Act
            _planEditor.RefreshSession(parameterSessionInfo);
            var suggestionText = _parameterEditorDto.ConflictInfoData?.SuggestionInfoCollection?.Count == 2
                ? _parameterEditorDto.ConflictInfoData.SuggestionInfoCollection[0].SuggestionText
                : null;
            var suggestionTextSplit = suggestionText?.Split();
            var suggestedValue = suggestionTextSplit?[suggestionTextSplit.Length - 1]?.TrimEnd('.');

            //Assert
            Assert.AreEqual(true, _parameterEditorDto.ConflictPresent,
                $"As provided parameterSessionInfo's IsInConflict is true. _parameterEditorDto's ConflictPresent value should be true.");
            _scanProtocalWrapper.AssertWasCalled(x => x.GetConflictGuidanceParameters(null), op => op.IgnoreArguments());
            _scanProtocalWrapper.AssertWasCalled(x => x.GetParameterStructType(Arg<ParameterStruct>.Is.Anything),
                op => op.IgnoreArguments());
            _scanProtocalWrapper.AssertWasCalled(x => x.ParameterStructToBeDisplayed(Arg<ParameterStruct>.Is.Anything), op => op.IgnoreArguments());
            _scanProtocalWrapper.AssertWasCalled(x => x.GetParameterStructSuggestedValue(Arg<ParameterStruct>.Is.Anything), op => op.IgnoreArguments());
            Assert.IsNotNull(_parameterEditorDto.ConflictInfoData, "parameterEditorDto should have conflictInfoDto");
            Assert.AreEqual(2, _parameterEditorDto?.ConflictInfoData?.SuggestionInfoCollection?.Count, "Suggestions count is expected to be 2");
            Assert.AreEqual("1.56", suggestedValue, "Suggested value shall be rounded off to 2 decimal places");
        }


        /// <summary>
        /// Verify TE Suggestion
        /// </summary>
        [Test]
        [Category("SWCMP.ScanDashboard.Panels.ConflictCase.AssistancePanel")]
        [ComponentTestCase(TestCaseId = "49204", TestCaseName = "VerifyTeSuggestion")]
        [Step(StepIndex = 1,
            Description = "This test is to verify conflict suggestions for enum parameters",
            Expected = "Confict Suggestion shall display Enum key instead of Enum values ",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyTeSuggestion()
        {
            //Act
            var dic = new Dictionary<string, IParameterMetaData>();
            dic.Add(InformationModel.ExRespUserDefBhTimeSec, Utility.GetEnumTypeParameter(InformationModel.ExRespUserDefBhTimeSec, true));
            dic.Add(InformationModel.IfRelativeSnr, Utility.GetFloatTypeParameter(InformationModel.IfRelativeSnr));
            dic.Add(InformationModel.IfAbsoluteSnr, Utility.GetFloatTypeParameter(InformationModel.IfAbsoluteSnr));
            dic.Add(InformationModel.ExDynContrastPhaseBeginTimes, Utility.GetEnumTypeParameter(InformationModel.ExDynContrastPhaseBeginTimes, true));
            dic.Add(InformationModel.ExDynContrastPhaseNrDyns, Utility.GetEnumTypeParameter(InformationModel.ExDynContrastPhaseNrDyns, true));
            dic.Add(InformationModel.ExDiffBFactors, Utility.GetIntTypeParameter(InformationModel.ExDiffBFactors));
            dic.Add(InformationModel.ExDiffNrWeighting, Utility.GetIntTypeParameter(InformationModel.ExDiffNrWeighting));
            dic.Add(InformationModel.ExSpyPhaseCycles, Utility.GetIntTypeParameter(InformationModel.ExSpyPhaseCycles));
            dic.Add(InformationModel.ExAcqFirstEchoTimeEnum, Utility.GetEnumTypeParameter(InformationModel.ExAcqFirstEchoTimeEnum, true));

            GetProtocolMetaDataMock();
            var parameterSessionInfo = GetParameterSessionInfo(false);
            var singleKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            singleKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
            singleKVPNode.Stub(x => x.GetFloatArrayValue()).Return(new FloatVector() { _five, _nine });
            singleKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { _five, _nine });
            singleKVPNode.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(_five);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExGeoCurStackId)).Return(singleKVPNode);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExDynContrastPhaseBeginTimes)).Return(singleKVPNode);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExDynContrastPhaseNrDyns)).Return(singleKVPNode);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExAcqFirstEchoTimeEnum)).Return(singleKVPNode);


            //fill rel. SNR value
            var singleKVPNodeRelSnr = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            singleKVPNodeRelSnr.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeFloat);
            singleKVPNodeRelSnr.Stub(x => x.GetFloatArrayValue()).Return(new FloatVector() { float.PositiveInfinity });
            singleKVPNodeRelSnr.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { 0 });
            singleKVPNodeRelSnr.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(float.PositiveInfinity);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.IfRelativeSnr)).Return(singleKVPNodeRelSnr);
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.IfAbsoluteSnr)).Return(singleKVPNodeRelSnr);

            var int32KVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            int32KVPNode.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(new IntVector() { 1, 2, });
            int32KVPNode.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            int32KVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeInteger);
            _scanProtocol.Stub(x => x.GetChildByPath(Arg<string>.Matches(c => c.Contains(InformationModel.ExDynContrastPhaseNrDyns) || c.Contains(InformationModel.ExSpyPhaseCycles) || c.Contains(InformationModel.ExDiffBFactors) || c.Contains(InformationModel.ExDiffNrWeighting)))).Return(int32KVPNode);

            var enumKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            enumKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
            enumKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { 3, 4 });
            _scanProtocol.Stub(x => x.GetChildByPath(InformationModel.ExRespUserDefBhTimeSec)).Return(enumKVPNode);
            _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                Utility.GetParametersPathValue(Utility.GetTabHierarchyValue("")),
                null)).IgnoreArguments().Return(dic);
            var ParameterMockData = Utility.GetParameterMetaDataMock(false, "1-1,2-2,3-3,4-4,5-5",
                TypeInfo.TypeEnum, "", ".help",
                false, "string", 34.0f);
            var parameterMockDataInt = Utility.GetParameterMetaDataMock(false, "5-5,560-560",
                TypeInfo.TypeInteger, "", ".help",
                false, "string", 34.0f);
            _protocolMetaDataMock.Stub(x => x.GetConflictParameters()).Return(new StringVector { InformationModel.ExAcqFirstEchoTimeEnum });
            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(Arg<String>.Matches(c => c.Equals(InformationModel.ExGeoCurStackId) || c.Equals(InformationModel.ExAcqFirstEchoTimeEnum) ||
                                                                                            c.Equals(InformationModel.ExRespUserDefBhTimeSec) || c.Equals("EX.conflict_suggestion") || c.Equals(InformationModel.ExDynContrastPhaseBeginTimes) || c.Equals(InformationModel.ExDynContrastPhaseNrDyns)))).Return(ParameterMockData);
            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(Arg<String>.Matches(c => c.Equals(InformationModel.ExDiffNrWeighting) || c.Equals(InformationModel.ExSpyPhaseCycles) || c.Equals(InformationModel.ExDiffBFactors)))).Return(parameterMockDataInt);
            _protocolMetaDataMock.Stub(x => x.GetTabNames()).Return(Utility.GetTabNames());
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.Clone()).Return(new IScanProtocol(IntPtr.Zero, false));

            //Act
            _parameterEditor.GetInitialModel();
            _planEditor.StartSession(parameterSessionInfo);

            //Assert

            var parameterGroup = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial");
            Assert.AreEqual(false, parameterGroup.ConflictPresent, "As provided parameterSessionInfo's IsInConflict is false,Initial parameterGroup's ConflictPresent should be false");

            //Arrange
            dic.Remove(InformationModel.IfAbsoluteSnr);
            var scanProtocol = parameterSessionInfo.ScanProtocol;


            var parameterMockDataFloat = Utility.GetParameterMetaDataMock(false, "5.0-5.0,560.0-560.0",
                TypeInfo.TypeFloat, "", ".help",
                false, "string", 34.0f);
            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(Arg<String>.Matches(c => c.Equals(InformationModel.IfRelativeSnr) || c.Equals(InformationModel.IfAbsoluteSnr)))).Return(parameterMockDataFloat);

            parameterSessionInfo.ScanProtocol = scanProtocol;
            parameterSessionInfo.BaselineProtocol = GetBaselineProtocol();
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = true;
            _scanProtocalWrapper.Stub(x => x.GetConflictKey(null)).IgnoreArguments().Return(InformationModel.ExAcqFirstEchoTimeEnum);
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments().Return(
                new List<SuggestionStruct>()
                {
                    new SuggestionStruct(IntPtr.Zero, false),
                    new SuggestionStruct(IntPtr.Zero, false)
                });


            var conflictParameters = new ParameterStruct("EX.conflict_suggestion", true, 1.0f);
            var conflictParametersCollection = new List<ParameterStruct>() { conflictParameters };
            var suggestionStructsCollection = new List<SuggestionStruct>()
            {
                new SuggestionStruct(true,"xnirfe063",conflictParametersCollection)
            };
            var conflictGuidanceSuggestions = new ConflictGuidanceSuggestions((ICollection)suggestionStructsCollection);
            var conflictGuidanceParameters = new ConflictGuidanceParameters((ICollection)conflictParametersCollection);


            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceSuggestions(Arg<ParameterConflictGuidanceInfo>.Is.Anything)).IgnoreArguments()
                .Return(conflictGuidanceSuggestions);
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(2);

            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(Arg<ParameterStruct>.Is.Anything)).Return(typeof(ParameterStruct).ToString());
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(Arg<ParameterStruct>.Is.Anything)).Return(true);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestedValue(Arg<ParameterStruct>.Is.Anything)).Return(1);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructParameterId(Arg<ParameterStruct>.Is.Anything)).Return(InformationModel.ExAcqFirstEchoTimeEnum);
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceParameters(null)).IgnoreArguments().Return(conflictGuidanceParameters);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("xnirfe063");

            parameterSessionInfo.ConflictGuidanceInfo = new ParameterConflictGuidanceInfo(IntPtr.Zero, false);
            parameterSessionInfo.ConflictGuidanceInfo.conflictKey = InformationModel.ExAcqFirstEchoTimeEnum;
            parameterSessionInfo.ConflictGuidanceInfo.suggestionInfo = new List<SuggestionStruct>();
            _parameterEditor.SetParameter(InformationModel.ExAcqFirstEchoTimeEnum, new[] { 2 });
            _softwareOptionConfigurationUtil.Stub(x => x.CheckOptionAvailable()).Return(false);

            //Act
            _planEditor.RefreshSession(parameterSessionInfo);
            var suggestionText = _parameterEditorDto.ConflictInfoData?.SuggestionInfoCollection?.Count == 2
                ? _parameterEditorDto.ConflictInfoData.SuggestionInfoCollection[0].SuggestionText
                : null;
            var suggestionTextSplit = suggestionText?.Split();
            var suggestedValue = suggestionTextSplit?[suggestionTextSplit.Length - 1]?.TrimEnd('.');

            //Assert
            Assert.AreEqual(true, _parameterEditorDto.ConflictPresent,
                $"As provided parameterSessionInfo's IsInConflict is true. _parameterEditorDto's ConflictPresent value should be true.");
            _scanProtocalWrapper.AssertWasCalled(x => x.GetConflictGuidanceParameters(null), op => op.IgnoreArguments());
            _scanProtocalWrapper.AssertWasCalled(x => x.GetParameterStructType(Arg<ParameterStruct>.Is.Anything),
                op => op.IgnoreArguments());
            _scanProtocalWrapper.AssertWasCalled(x => x.ParameterStructToBeDisplayed(Arg<ParameterStruct>.Is.Anything), op => op.IgnoreArguments());
            _scanProtocalWrapper.AssertWasCalled(x => x.GetParameterStructSuggestedValue(Arg<ParameterStruct>.Is.Anything), op => op.IgnoreArguments());
            Assert.IsNotNull(_parameterEditorDto.ConflictInfoData, "parameterEditorDto should have conflictInfoDto");
            Assert.AreEqual(2, _parameterEditorDto?.ConflictInfoData?.SuggestionInfoCollection?.Count, "Suggestions count is expected to be 2");
            Assert.AreEqual("shortest", suggestedValue, "Suggeted values shall display shortest instead of its enum value");

            //Fill SNR value
            IScanProtocol baselineProtocol = parameterSessionInfo.BaselineProtocol;
            baselineProtocol.AssertWasCalled(x => x.GetChildByPath(Arg<string>.Matches(c => c.Equals(InformationModel.IfRelativeSnr) || c.Equals(InformationModel.IfAbsoluteSnr))));


            // clear session
            _planEditor.ClearSession();
        }

        /// <summary>
        /// Test Conflict
        /// </summary>
        [Test]
        [Category("SWCMP.UW.ScanInParameters.Panel.AdvancedParameters")]
        [Category("SWCMP.UW.ScanInParameters.Panel.Conflict")]
        [ComponentTestCase(TestCaseId = "45096", TestCaseName = "VerifyRefreshSessionWithResolveConflict")]
        [Step(StepIndex = 1,
            Description = "This test is to verify refresh session with resolve conflicts",
            Expected = "Parameters conflicts should be resolved and parameters values should be as provided",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyRefreshSessionWithResolveConflict()
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            var dic1 = new Dictionary<string, IParameterMetaData>();
            dic1.Add("EX_CARD.sync", Utility.GetFloatTypeParameter("EX_CARD.sync"));
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            var dic3 = new Dictionary<string, IParameterMetaData>();
            dic3.Add("EX_ACQ.patient_weight", Utility.GetIntTypeParameter("EX_ACQ.patient_weight"));
            GetProtocolMetaDataMock();
            var parameterSessionInfo = GetParameterSessionInfo();
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                if (tabNameMapping.Value == "Initial")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic);
                }
                else if (tabNameMapping.Value == "ALL")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(Utility.GetALLFields());
                }

                else if (tabNameMapping.Value == Utility.InfoBar)
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(Utility.GetInfoBarFields());
                }
                else if (tabNameMapping.Value == "Geometry")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic3);
                }
                else
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic2);
                }
            }
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            _scanProtocol.Stub(x => x.CloneToKVPDocument()).Return(new IKVPDocument(IntPtr.Zero, false));

            //Act
            _planEditor.StartSession(parameterSessionInfo);
            var parameterGroup = _parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial");

            //Test Enum
            var intScanProtocolValue = IntField.AsEnumerable().ToList();
            EnumParameterDto enumParameterDto = (EnumParameterDto)_parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial").Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_PROC.image_types")).Value;
            var enumParameterList = enumParameterDto.Values.ToList();

            //Assert
            Assert.AreEqual(intScanProtocolValue, enumParameterList);
            Assert.AreEqual("EX_PROC.image_types.help", enumParameterDto.Help,
                $"EX_PROC.image_types parameter's Help property value should be 'EX_PROC.image_types.help'. But it is {enumParameterDto.Help}.");
            Assert.AreEqual("1-1", enumParameterDto.Ranges[0].ToString(),
                $"EX_PROC.image_types parameter's Ranges property value should be '1-1'. But it is {enumParameterDto.Ranges[0].ToString()}.");
            Assert.AreEqual(false, enumParameterDto.InConflict,
                "As no conflict present for provide field, enumParameterDto's InConflict property value should be false");
            Assert.AreEqual(false, _parameterEditorDto.ConflictPresent,
                "As provided parameterSessionInfo's IsInConflict property value is false,_parameterEditorDto's  ConflictPresent property value should be false");

            //Arrange
            var scanProtocol = parameterSessionInfo.ScanProtocol;
            _protocolMetaDataMock.Stub(x => x.GetConflictParameters()).Return(new StringVector { "EX_PROC.image_types" });
            parameterSessionInfo.ScanProtocol = scanProtocol;
            parameterSessionInfo.BaselineProtocol = scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = true;

            //Act
            _planEditor.RefreshSession(parameterSessionInfo);

            //Assert
            Assert.AreEqual(true, _parameterEditorDto.ConflictPresent,
                "As provided parameterSessionInfo's IsInConflict property value is true,_parameterEditorDto's  ConflictPresent property value should be true");

            //Test Enum field value in Group Initial
            intScanProtocolValue = IntField.AsEnumerable().ToList();
            enumParameterDto = (EnumParameterDto)_parameterEditorDto.ParameterGroups.FirstOrDefault(x => x.Name == "Initial").Parameters
                .FirstOrDefault(y => y.Key.Contains("EX_PROC.image_types")).Value;
            enumParameterList = enumParameterDto.Values.ToList();

            //Assert
            Assert.AreEqual(intScanProtocolValue, enumParameterList);
            Assert.AreEqual(enumParameterDto.Help, "EX_PROC.image_types.help",
                $"EX_PROC.image_types parameter's Help property value should be 'EX_PROC.image_types.help'. But it is {enumParameterDto.Help}.");
            Assert.AreEqual("1-1", enumParameterDto.Ranges[0].ToString(),
                $"EX_PROC.image_types parameter's Ranges property value should be '1-1'. But it is {enumParameterDto.Ranges[0].ToString()}.");
            Assert.AreEqual(false, enumParameterDto.InConflict, "As no conflict present for provide field, enumParameterDto's InConflict property value should be false");
        }

        #endregion

        /// <summary>
        /// Verify EndSession 
        /// </summary>
        [Test]
        [TestCaseSource(nameof(TestEndSessionSource))]
        [Category("SWCMP.UW.ScanInParameters.Panel.AdvancedParameters")]
        [ComponentTestCase(TestCaseId = "45093", TestCaseName = "VerifyEndSession")]
        [Step(StepIndex = 1,
            Description = "This test is to verify end session",
            Expected = "ParameterEditorDto field should filled with provided information",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyEndSession(bool isEventErrorOccuredBinded)
        {
            //Arrange
            var dic = Utility.GetCommonParameterMetaDatas();
            var inVisibleParameter = Utility.GetParameterMetaDataMock(false, "5.0-5.0,560.0-560.0", TypeInfo.TypeFloat, "", ".help",
                false, "string", 34.0f);
            dic.Add("EX_GEO.InVisible", inVisibleParameter);
            var dic1 = new Dictionary<string, IParameterMetaData>();
            dic1.Add("EX_CARD.sync", Utility.GetStringTypeParameter("EX_CARD.sync"));
            var dic2 = new Dictionary<string, IParameterMetaData>();
            dic2.Add("EX_CARD.IntSync", Utility.GetIntTypeParameter("EX_CARD.IntSync"));
            var dic3 = new Dictionary<string, IParameterMetaData>();
            dic3.Add("EX_ACQ.patient_weight", Utility.GetIntTypeParameter("EX_ACQ.patient_weight"));
            GetProtocolMetaDataMock(2);
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                if (tabNameMapping.Value == "Initial")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic);
                }
                else if (tabNameMapping.Value == "ALL")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(Utility.GetALLFields());
                }
                else if (tabNameMapping.Value == Utility.InfoBar)
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(Utility.GetInfoBarFields());
                }
                else if (tabNameMapping.Value == "Geometry")
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic3);
                }
                else
                {
                    _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                        Utility.GetParametersPathValue(Utility.GetTabHierarchyValue(tabNameMapping.Value)),
                        null)).Return(dic2);
                }
            }
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceParameterStructs(null)).IgnoreArguments()
                .Return(new List<ParameterStruct>() { new ParameterStruct(IntPtr.Zero, false) });
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(3);
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments()
                .Return(new List<SuggestionStruct>() { new SuggestionStruct(IntPtr.Zero, false) });
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("DummySuggestionKey");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(null)).IgnoreArguments().Return("System.Int32");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(null)).IgnoreArguments().Return(true);
            _scanProtocalWrapper.Stub(x => x.GetCoils(null, null)).IgnoreArguments().Return(new List<Coil>() {
                new Coil("coilName1","coilStocket1"), new Coil("coilName2","coilStocket2")});
            _scanProtocalWrapper.Stub(x => x.GetSuggestionInfoCount(null)).IgnoreArguments().Return(3);
            _scanProtocalWrapper.Stub(x => x.GetSuggestions(null)).IgnoreArguments()
                .Return(new List<SuggestionStruct>() { new SuggestionStruct(IntPtr.Zero, false) });
            _scanProtocalWrapper.Stub(x => x.GetConflictGuidanceSuggestions(null)).IgnoreArguments()
                .Return(null);
            _scanProtocalWrapper.Stub(x => x.GetParameterStructSuggestionKey(null)).IgnoreArguments().Return("DummySuggestionKey");
            _scanProtocalWrapper.Stub(x => x.GetParameterStructType(null)).IgnoreArguments().Return("System.Int32");
            _scanProtocalWrapper.Stub(x => x.ParameterStructToBeDisplayed(null)).IgnoreArguments().Return(true);
            var coilLogicMock = MockRepository.GenerateMock<Utility.ICoilLogicMock>();
            var coilPropertries = MockRepository.GenerateMock<Utility.ICoilPropertiesMock>();
            coilPropertries.Stub(x => x.GetManualSelectable()).Return(true);
            coilLogicMock.Stub(x => x.GetCoilProperties("")).IgnoreArguments().Return(coilPropertries);
            _scanProtocalWrapper.Stub(x => x.GetCoilLogic(null)).IgnoreArguments().Return(coilLogicMock);
            var parameterSessionInfo = GetParameterSessionInfo();
            parameterSessionInfo.ScanProtocol.Stub(x => x.GetNrStacks()).Return(2);
            var coilSelection = MockRepository.GenerateMock<Utility.ICoilSelectionMock>();
            coilSelection.Stub(x => x.GetSelectedCoilElements()).Return(new List<CoilSelectionElement>()
            {
                new CoilSelectionElement("c", "s", 23),
                new CoilSelectionElement("c", "s", 24)
            });
            parameterSessionInfo.ScanProtocol.Stub(x => x.GetCoilSelectionStack(0, null)).IgnoreArguments().Return(coilSelection);
            parameterSessionInfo.ConflictGuidanceInfo = new ParameterConflictGuidanceInfo(IntPtr.Zero, false);
            parameterSessionInfo.ConflictGuidanceInfo.conflictKey = "EX_PROC.image_types";
            parameterSessionInfo.ConflictGuidanceInfo.suggestionInfo = new List<SuggestionStruct>();
            _planEditor.StartSession(parameterSessionInfo);
            _planEditor.ConflictInfoUpdated -= PlanEditorOnConflictInfoUpdated;
            _planEditor.ErrorOccured -= PlanEditor_ErrorOccured;
            _parameterEditor.ParameterEditorUpdated -= ParameterEditorUpdated;
            if (isEventErrorOccuredBinded)
            {
                _planEditor.ErrorOccured += PlanEditor_ErrorOccured;
                _planEditor.ConflictInfoUpdated += PlanEditorOnConflictInfoUpdated;
                _parameterEditor.ParameterEditorUpdated += ParameterEditorUpdated;
            }

            conflictInfoUpdated = false;
            errorOccurred = false;
            _parameterEditorDto = null;

            //Act
            _planEditor.EndSession();

            //Assert
            if (isEventErrorOccuredBinded)
            {
                Assert.IsTrue(conflictInfoUpdated, "As ConflictInfoUpdated event available, conflictInfoUpdated field should be filled.");
                Assert.IsTrue(errorOccurred, "As ErrorOccured event available, errorOccurred field should be filled.");
                Assert.IsNotNull(_parameterEditorDto, "As ParameterEditorUpdated event available, _parameterEditorDto field should be filled.");
            }
            else
            {
                Assert.IsFalse(conflictInfoUpdated, "As ConflictInfoUpdated event not available, conflictInfoUpdated field should be not filled.");
                Assert.IsFalse(errorOccurred, "As ErrorOccured event not available, errorOccurred field should be not filled.");
                Assert.IsNull(_parameterEditorDto, "As ParameterEditorUpdated event not available, _parameterEditorDto field should be not filled.");
            }

            _planEditor.ErrorOccured -= PlanEditor_ErrorOccured;
            _planEditor.ConflictInfoUpdated -= PlanEditorOnConflictInfoUpdated;
            _parameterEditor.ParameterEditorUpdated -= ParameterEditorUpdated;
        }

        /// <summary>
        /// Verify UpdateScanProtocol
        /// </summary>
        [Test]
        [TestCaseSource(nameof(TestUpdateScanProtocol))]
        [Category("SWCMP.UW.ScanInParameters.Panel.AdvancedParameters")]
        [ComponentTestCase(TestCaseId = "45099", TestCaseName = "VerifyUpdateScanProtocol")]
        [Step(StepIndex = 1,
            Description = "This test is to verify update scan protocol",
            Expected = "ParameterSessionInfo should be filled with provided information",
            SuccessMessage = "test pass",
            FailureMessage = "test fail",
            AssertStep = true)]
        public void VerifyUpdateScanProtocol(bool parameterSessionInfoAvailable, bool isEventErrorOccuredBinded)
        {
            //Arrange
            if (parameterSessionInfoAvailable)
            {
                var dic = Utility.GetCommonParameterMetaDatas();
                GetProtocolMetaDataMock(1);
                _scanProtocalWrapper.Stub(x => x.ConvertStringVectorToDictionary(
                    null, null)).IgnoreArguments().Return(dic);
                var parameterSessionInfo = GetParameterSessionInfo();
                _planEditor.StartSession(parameterSessionInfo);
            }
            _planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
            if (isEventErrorOccuredBinded)
            {
                _planEditor.ScanProtocolChanged += OnScanProtocolChanged;
            }
            _parameterSessionInfo = null;

            //Act
            _planEditor.UpdateScanProtocol();

            //Assert
            if (isEventErrorOccuredBinded && parameterSessionInfoAvailable)
            {
                Assert.IsNotNull(_parameterSessionInfo, "As ScanProtocolChanged event available, _parameterSessionInfo field should be filled.");
            }
            else if (isEventErrorOccuredBinded)
            {
                Assert.IsNull(_parameterSessionInfo.ScanProtocol,
                    "Even though, ScanProtocolChanged event is binded; As parameterSessionInfoAvailable not available, _parameterSessionInfo's ScanProtocol property should be not filled.");
            }
            else
            {
                Assert.IsNull(_parameterSessionInfo, "As ScanProtocolChanged event not available, _parameterSessionInfo field should be not filled.");
            }
            _planEditor.ScanProtocolChanged -= OnScanProtocolChanged;
        }


        #endregion

        #region Private methods

        private IntVector IntField
        {
            get
            {
                var objIntVector = new IntVector();
                objIntVector.Add(1);
                objIntVector.Add(2);
                return objIntVector;
            }
        }

        private FloatVector FloatField
        {
            get
            {
                var objFloatVector = new FloatVector();
                objFloatVector.Add(_five);
                objFloatVector.Add(_nine);
                return objFloatVector;
            }
        }

        private ParameterSessionInfo GetParameterSessionInfo(bool resolveFields = true)
        {
            _scanProtocalWrapper.Stub(x => x.GetRangeForEnum("")).IgnoreArguments().Return(IntField);
            _scanProtocalWrapper.Stub(x => x.GetUINameForEnumValue("", 0)).IgnoreArguments().Return("shortest");
            var objStringVector = new StringVector();
            objStringVector.Add("String1");
            objStringVector.Add("String2");
            var kVpNodeMock = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            kVpNodeMock.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(IntField);
            kVpNodeMock.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetFloatArrayValue()).IgnoreArguments().Return(FloatField);
            kVpNodeMock.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(2);
            kVpNodeMock.Stub(x => x.GetStringArrayValue()).IgnoreArguments().Return(objStringVector);
            kVpNodeMock.Stub(x => x.GetStringValue()).IgnoreArguments().Return("String3");
            _scanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();
            if (resolveFields)
            {
                _scanProtocol.Stub(x => x.GetChildByPath("")).IgnoreArguments().Return(kVpNodeMock);
            }
            var parameterSessionInfo = new ParameterSessionInfo();
            parameterSessionInfo.ScanProtocol = _scanProtocol;
            parameterSessionInfo.BaselineProtocol = _scanProtocol;
            parameterSessionInfo.ScanProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.BaselineProtocolMetaData = _protocolMetaDataMock;
            parameterSessionInfo.IsEditMode = true;
            parameterSessionInfo.IsInConflict = false;
            return parameterSessionInfo;
        }

        private IScanProtocol GetBaselineProtocol()
        {
            var baselineScanProtocol = MockRepository.GenerateMock<Utility.ScanProtocolMock>();
            var singleKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            singleKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
            singleKVPNode.Stub(x => x.GetFloatArrayValue()).Return(new FloatVector() { _five, _nine });
            singleKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { _five, _nine });
            singleKVPNode.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(_five);
            baselineScanProtocol.Stub(x => x.GetChildByPath("EX_GEO.cur_stack_id")).Return(singleKVPNode);
            baselineScanProtocol.Stub(x => x.GetChildByPath("EX_ACQ.first_echo_time_enum")).Return(singleKVPNode);
            baselineScanProtocol.Stub(x => x.GetChildByPath("EX_DYN.contrastPhaseBeginTimes")).Return(singleKVPNode);
            baselineScanProtocol.Stub(x => x.GetChildByPath("EX_DYN.contrastPhaseNrDyns")).Return(singleKVPNode);

            //fill rel. SNR value
            var singleKVPNodeRelSnr = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            singleKVPNodeRelSnr.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeFloat);
            singleKVPNodeRelSnr.Stub(x => x.GetFloatArrayValue()).Return(new FloatVector() { _five, _nine });
            singleKVPNodeRelSnr.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { _five });
            singleKVPNodeRelSnr.Stub(x => x.GetFloatValue()).IgnoreArguments().Return(_five);
            baselineScanProtocol.Stub(x => x.GetChildByPath("IF.relative_SNR")).Return(singleKVPNodeRelSnr);
            baselineScanProtocol.Stub(x => x.GetChildByPath("IF.absolute_SNR")).Return(singleKVPNodeRelSnr);

            var enumKVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            enumKVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeEnum);
            enumKVPNode.Stub(x => x.GetIntegerArrayValue()).Return(new IntVector() { 3, 4 });
            baselineScanProtocol.Stub(x => x.GetChildByPath("EX_RESP.user_def_bh_time_sec")).Return(enumKVPNode);

            var int32KVPNode = MockRepository.GenerateMock<Utility.IKVPNodeMock>();
            int32KVPNode.Stub(x => x.GetIntegerArrayValue()).IgnoreArguments().Return(new IntVector() { 1, 2, });
            int32KVPNode.Stub(x => x.GetIntegerValue()).IgnoreArguments().Return(2);
            int32KVPNode.Stub(x => x.GetDataTypeInfo()).Return(TypeInfo.TypeInteger);
            baselineScanProtocol.Stub(x => x.GetChildByPath(Arg<string>.Matches(c => c.Contains("EX_DYN.contrastPhaseNrDyns") || c.Contains("EX_SPY.phase_cycles") || c.Contains("EX_DIFF.b_factors") || c.Contains("EX_DIFF.nr_weightings")))).Return(int32KVPNode);


            baselineScanProtocol.Stub(x => x.Clone()).Return(new IScanProtocol(IntPtr.Zero, false));
            return baselineScanProtocol;

        }

        private void GetProtocolMetaDataMock(uint currentNodeValueSize = 2)
        {
            _protocolMetaDataMock = MockRepository.GenerateMock<Utility.ScanProtocolMetaDataMock>();
            _protocolMetaDataMock.Stub(x => x.GetTabNames()).Return(Utility.tabNameMapping.Keys.ToList());
            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _protocolMetaDataMock.Stub(x => x.GetTabHierarchy(tabNameMapping.Key))
                    .Return(Utility.GetTabHierarchyValue(tabNameMapping.Value));
            }

            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _protocolMetaDataMock.Stub(x =>
                        x.GetParametersPath(Utility.GetTabHierarchyValue(tabNameMapping.Value)))
                    .Return(Utility.GetParametersPathValue(
                        Utility.GetTabHierarchyValue(tabNameMapping.Value)));
            }

            _protocolMetaDataMock.Stub(x => x.GetParameterMetaData(new StringVector())).IgnoreArguments()
                .Return(null);

            foreach (var tabNameMapping in Utility.tabNameMapping)
            {
                _scanProtocalWrapper.Stub(x => x.GetUINameForTabName(tabNameMapping.Key)).Return(tabNameMapping.Value);
            }
            _scanProtocalWrapper.Stub(x => x.GetUINameForParameterName("")).IgnoreArguments().Return("ParameterName");
            _scanProtocalWrapper.Stub(x => x.GetCurrentNodeValueSize(null)).IgnoreArguments().Return(currentNodeValueSize);
        }



        private void ParameterEditorUpdated(object sender, ParameterEditorUpdateArgs e)
        {
            if (e.InitialMode)
            {
                if (_parameterEditorDto == null)
                {
                    _parameterEditorDto = new ParameterEditorDto();
                }
                _parameterEditorDto.CopyProperties(e.EditorDto);
                _parameterEditor.SetAdvanceParameterState(true);
            }
            else
            {

                for (int index = 0; e.EditorDto.ParameterGroups.Count - 1 > index; index++)
                {
                    var item = _parameterEditorDto.ParameterGroups.FirstOrDefault(x =>
                         x.GroupId == e.EditorDto.ParameterGroups[index].GroupId);
                    if (item != null)
                    {
                        _parameterEditorDto.ParameterGroups.Remove(item);
                    }
                    _parameterEditorDto.ParameterGroups.Add(e.EditorDto.ParameterGroups[index]);
                }

                _parameterEditorDto.ActiveGroupId = e.EditorDto.ActiveGroupId;
                _allGroupsNotLoaded = false;
            }
        }

        private void OnParameterEditorEnabled(object sender, bool parameterEditorState)
        {
            _isParameterEditorEnabled = parameterEditorState;
        }

        /// <summary>
        /// Called whenever there is any change in scanprotocol from UI.
        /// </summary>
        /// <param name="sender">sender of this event</param>
        /// <param name="modifiedScanProtocol">Holds the modified scanprotocol</param>
        private void OnScanProtocolChanged(object sender, IScanProtocol modifiedScanProtocol)
        {
            _parameterSessionInfo = new ParameterSessionInfo
            {
                ScanProtocol = modifiedScanProtocol
            };
        }


        private bool conflictInfoUpdated = false;
        private void PlanEditorOnConflictInfoUpdated(bool obj)
        {
            conflictInfoUpdated = true;
        }

        private bool errorOccurred = false;
        private void PlanEditor_ErrorOccured(object sender, EventArgs e)
        {
            errorOccurred = true;
        }

        #endregion

        #region Test Source

        /// <summary>
        ///     StartSessionTestSource - test date source for verifying Start Session API
        /// </summary>
        internal static IEnumerable StartSessionTestSource
        {
            get
            {
                yield return new TestCaseData("", Convert.ToUInt32(1), GroupIds.Geometry, false);
                yield return new TestCaseData("", Convert.ToUInt32(2), GroupIds.Postproc, false);
                yield return new TestCaseData("", Convert.ToUInt32(2), GroupIds.Initial, false);
                yield return new TestCaseData("", Convert.ToUInt32(2), GroupIds.Initial, true);
            }
        }

        /// <summary>
        ///     SummaryParameterTestSource - test date source for verify Summary Parameter
        /// </summary>
        internal static IEnumerable SummaryParameterTestSource
        {
            get
            {
                yield return new TestCaseData(EnumNames.GapModeUserDefined, "", true);
                yield return new TestCaseData("","", true);
                yield return new TestCaseData(EnumNames.GapModeUserDefined, "", false);
                yield return new TestCaseData(EnumNames.GapModeUserDefined, EnumNames.MpuAcqAccelSense, false);
                yield return new TestCaseData(EnumNames.GapModeUserDefined, EnumNames.MpuAcqAccelCsSense, false);
                yield return new TestCaseData(EnumNames.GapModeUserDefined, EnumNames.MpuAcqAccelCsSenseAi, false);
            }
        }

        /// <summary>
        ///     PhysiologyParameterTestSource - test date source for verify Physiology Parameter
        /// </summary>
        internal static IEnumerable PhysiologyParameterTestSource
        {
            get
            {
                yield return new TestCaseData(EnumNames.HeartPhaseUserDefined, true, EnumNames.CardiacGateDelayUserDefined, EnumNames.CardiacTriggerDelayUserDefined, true, true);
                yield return new TestCaseData(EnumNames.HeartPhaseMaximum, false, "", EnumNames.CardiacTriggerDelayUserDefined, false, true);
                yield return new TestCaseData("", true, EnumNames.CardiacGateDelayUserDefined, "", true, true);
                yield return new TestCaseData("", true, EnumNames.CardiacGateDelayUserDefined, "", true, false);
            }
        }

        /// <summary>
        ///     ParametersTypesOnStartSessionTestSource - test date source for verify all parameter types while start session API called
        /// </summary>
        internal static IEnumerable ParametersTypesOnStartSessionTestSource
        {
            get
            {
                yield return new TestCaseData("", TypeInfo.TypeUnknown);
                yield return new TestCaseData("", TypeInfo.TypeComposite);
                yield return new TestCaseData("", TypeInfo.TypeInt64);
                yield return new TestCaseData("", TypeInfo.TypeDouble);
                yield return new TestCaseData("", TypeInfo.TypeBool);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private static IEnumerable<TestCaseData> TestEndSessionSource
        {
            get
            {
                yield return
                    new TestCaseData(false);
                yield return
                    new TestCaseData(true);

            }
        }


        /// <summary>
        /// 
        /// </summary>
        private static IEnumerable<TestCaseData> TestUpdateScanProtocol
        {
            get
            {
                yield return
                    new TestCaseData(true, false);
                yield return
                    new TestCaseData(false, true);
                yield return
                    new TestCaseData(true, true);

            }
        }

        #endregion
    }
}
#region Revision History

// 2019-11-15  Ramanjaneyulu SBV
//             Initial version
// 2020-05-19  Ramanjaneyulu SBV
//             Replaced DELAYED_RECON with GroupIds.Postproc
#endregion