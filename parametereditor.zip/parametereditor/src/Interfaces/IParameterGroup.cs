﻿#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: IParameterGroup.cs
//

#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Interface to represent and populates parameters of Parameter Group.
    /// </summary>
    public interface IParameterGroup
    {
        /// <summary>
        /// Id of the parameter group
        /// </summary>
        int Id { get; }

        /// <summary>
        /// bool to indicate if parameter group is active
        /// </summary>
        bool Active { get; set; }

        /// <summary>
        /// bool to indicate if conflict is present
        /// </summary>
        bool ConflictPresent { get; }
        /// <summary>
        /// Name represents the group name
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Tab Name
        /// </summary>
        string TabName { get; set; }

        /// <summary>
        /// Populate ParameterGroupDto
        /// </summary>
        /// <returns></returns>
        ParameterGroupDto PopulateGroup();

        /// <summary>
        /// To set curretn group as active parameter group in PDF
        /// </summary>
        void SetActiveGroup();
    }
}
