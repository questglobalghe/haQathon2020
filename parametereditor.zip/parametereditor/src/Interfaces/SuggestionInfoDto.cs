﻿#region (c) Koninklijke Philips Electronics N.V. 2019
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: SuggestionInfoDto.cs
//
#endregion

#region namespace
using System;
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    #region SuggestionInfoDto class
    /// <summary>
    /// Class for showing suggestion information in UI elements of Conflict guidance
    /// </summary>
    [Serializable]
    public class SuggestionInfoDto : DtoBase
    {
        #region private fields
        /// <summary>
        /// Suggestion Key variable
        /// </summary>
        private string _suggestionKey;

        /// <summary>
        /// Suggestion text for a suggestion text
        /// </summary>
        private string _suggestionText;
        #endregion

        #region Public Properties
        /// <summary>
        ///  Suggestion Key property
        /// </summary>
        public string SuggestionKey
        {
            get
            {
                return _suggestionKey;
            }
            set
            {
                _suggestionKey = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Suggestion Text property
        /// </summary>
        public string SuggestionText
        {
            get
            {
                return _suggestionText;
            }
            set
            {
                _suggestionText = value;
                RaisePropertyChanged();
            }
        }
        #endregion
    }
    #endregion

}

#region Revision History
// 2019-May-05  Anu jothis
//              Initial version stroy point 32400
// 2019-Aug-27  Anu jothis
//              Added SuggestionCode member to the class.
// 2019-Sep-02  Anu jothis
//              Renamed one property and variable.
#endregion
