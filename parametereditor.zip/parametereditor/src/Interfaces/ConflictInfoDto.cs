﻿#region (c) Koninklijke Philips Electronics N.V. 2019
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: ConflictInfoDto.cs
//
#endregion

#region namespaces
using System;
using System.Collections.ObjectModel;
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    #region ConflictInfoDto
    /// <summary>
    /// Class for showing UI elements of Conflict
    /// </summary>
    [Serializable]
    public class ConflictInfoDto : DtoBase
    {
        #region private fields
        /// <summary>
        /// private conflict key declaration
        /// </summary>
        private string _conflictKey;

        /// <summary>
        /// Suggestions info collection declaration
        /// </summary>
        private ObservableCollection<SuggestionInfoDto> _suggestions = new ObservableCollection<SuggestionInfoDto>();
        #endregion

        #region Public Properties
        /// <summary>
        /// Conflict key Property
        /// </summary>
        public string ConflictKey
        {
            get
            {
                return _conflictKey;
            }
            set
            {
                _conflictKey = value;
                RaisePropertyChanged();
            }
        }


        /// <summary>
        /// Suggestions collection
        /// </summary>
        public ObservableCollection<SuggestionInfoDto> SuggestionInfoCollection
        {
            get { return _suggestions; }
            set
            {
                _suggestions = value;
                RaisePropertyChanged();
            }
        }

        #endregion
    }
    #endregion
}

#region Revision History
// 2019-May-07  Anu Jothis
//              Initial version story point 39048
#endregion
