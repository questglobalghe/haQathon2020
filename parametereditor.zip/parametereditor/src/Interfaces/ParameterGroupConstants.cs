#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: ParameterGroupConstants.cs
//
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
 /// <summary>
    /// Constants for ParameterGroup Index
    /// </summary>
    public static class ParameterGroupConstants
    {
        /// <summary>
        /// Top Most Index of parameter group (Index of parameter group which is Top most)
        /// </summary>
        public const int TopMostGroupIndex = -99;

        /// <summary>
        /// Bottom most index of parameter group (Index of parameter group which is Bottom most)
        /// </summary>
        public const int BottomMostGroupIndex = 99;
    }
}

#region Revision History
// 24-Sep-2013  Chandralatha
//              Intial Version
//2013-Oct-24  Subin Varghese
//             MR00133256 : Breathhold controls are not displayed in Physio Tab in Greek and Russian Language
//             Added EnumNames class
// 2013-Nov-11  Chandralatha
//              Switched to EnumNames rather than UGIIText as the UGGI translated value and methods parametervalue 
//              where not matching in some Languages
// 2014-Nov-03  Sahana
//              Changes for feedback comments of Image Orientation.
// 2017-Oct-05  Vivek Saurav
//              Added ParameterUiConstants class
//2017-Oct-06   Ankita Kumari
//              Added constant strings to ParameterUiConstants class
//2017-Oct-06   Vivek Saurav
//              Removed constant ScanInfoFallbackValue 
// 2017-Nov-24  Vivek Saurav
//              Added ParameterGroupConstants (Story ID- 23086)
#endregion Revision History