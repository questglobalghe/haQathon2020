﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: EnumNames.cs
//
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{

    /// <summary>
    /// Enum Names for EnumParameters
    /// </summary>
    public static class EnumNames
    {
        /// <summary>
        ///  Enum Name for Transverse Slice Orientation
        /// </summary>
        public static readonly string SliceOrientationTransverse = "MGG_ORIENT_TRANSVERSAL";

        /// <summary>
        ///  Enum Name for Sagittal Slice Orientation
        /// </summary>
        public static readonly string SliceOrientationSagittal = "MGG_ORIENT_SAGITTAL";

        /// <summary>
        ///  Enum Name for Coronal Slice Orientation
        /// </summary>
        public static readonly string SliceOrientationCoronal = "MGG_ORIENT_CORONAL";

        /// <summary>
        ///  Enum Name for Transverse Series Orientation
        /// </summary>
        public static readonly string SeriesOrientationTransverse = "AWGEOM_AX_FH";

        /// <summary>
        ///  Enum Name for Sagittal Series Orientation
        /// </summary>
        public static readonly string SeriesOrientationSagittal = "AWGEOM_AX_RL";

        /// <summary>
        ///  Enum Name for Coronal Series Orientation
        /// </summary>
        public static readonly string SeriesOrientationCoronal = "AWGEOM_AX_AP";

        /// <summary>
        /// Enum Name for Navigator Respiratory OFF
        /// </summary>
        public static readonly string NavigatorRespOff = "MPURNAV_RESPC_OFF";

        /// <summary>
        /// Enum Name for Scan Mode 2D
        /// </summary>
        public static readonly string ScanMode2D = "MGUACQ_SCM_2D";

        /// <summary>
        /// Enum Name for  Scan Mode 3D
        /// </summary>
        public static readonly string ScanMode3D = "MGUACQ_SCM_3D";

        /// <summary>
        /// Enum Name for Cardiac Synchronozation - No 
        /// </summary>
        public static readonly string CardSyncNo = "MGG_CARD_NO";

        /// <summary>
        /// Enum Name for Cardiac Synchronozation - Trigger 
        /// </summary>
        public static readonly string CardSyncTrigger = "MGG_CARD_TRIG";

        /// <summary>
        ///  Enum Name for Cardiac Synchronozation - Gate 
        /// </summary>
        public static readonly string CardSyncGate = "MGG_CARD_GATE";

        /// <summary>
        ///  Enum Name for Cardiac Synchronozation - Retro 
        /// </summary>
        public static readonly string CardSyncRetrospective = "MGG_CARD_RETRO";

        /// <summary>
        /// Enum Name for Respiratory Compensation - Trigger  
        /// </summary>
        public static readonly string RespCompTrigger = "MGG_RESP_TRIG";

        /// <summary>
        /// Enum Name for Respiratory Compensation - Breathhold
        /// </summary>
        public static readonly string RespCompBreathHold = "MGG_RESP_HOLD";


        
        /// <summary>
        /// Enum Name for Cardiac Trigger Delay Enum 
        /// </summary>
        public static readonly string CardiacTriggerDelayEnum = "MPUCARD_TRIG_ENUM";


        /// <summary>
        /// Enum Name for Cardiac Trigger Delay - User Defined
        /// </summary>
        public static readonly string CardiacTriggerDelayUserDefined = "MPUCARD_TRIG_USER_DEF";


        /// <summary>
        /// Enum Name for Cardiac Gate Delay Enum
        /// </summary>
        public static readonly string CardiacGateDelayEnum = "MGG_TIME_ENUM";

        
        /// <summary>
        /// Enum Name for Cardiac Gate Delay - User Defined
        /// </summary>
        public static readonly string CardiacGateDelayUserDefined = "MGG_TIME_USER_DEF";

        /// <summary>
        /// Enum Name for Gap Mode Enum
        /// </summary>
        public static readonly string GapModeEnum = "MGG_EXTREM_ENUM";

        /// <summary>
        /// Enum Name for Gap Mode - User Defined
        /// </summary>
        public static readonly string GapModeUserDefined = "MGG_EXTREM_USER_DEF";

        /// <summary>
        /// Enum Name for Gap Mode - Default
        /// </summary>
        public static readonly string GapModeDefault = "MGG_EXTREM_DEFAULT";


        
        /// <summary>
        /// Enum Name for Heart Phase Enum
        /// </summary>
        public static readonly string HeartPhaseEnum = "MPUCARD_HPC_ENUM";


        /// <summary>
        /// Enum Name for Heart Phase - User Defined
        /// </summary>
        public static readonly string HeartPhaseUserDefined = "MPUCARD_HPC_USER_DEF";

        /// <summary>
        /// Enum Name for Heart Phase - Single Phase
        /// </summary>
        public static readonly string HeartPhaseSinglePhase = "MPUCARD_HPC_ONE";

        /// <summary>
        /// Enum Name for Heart Phase - Maximum
        /// </summary>
        public static readonly string HeartPhaseMaximum = "MPUCARD_HPC_MAXIMUM";

        /// <summary>
        /// Enum Name for Low SAR
        /// </summary>
        public static readonly string SarLow = "MPUCOIL_SAR_MODE_LOW";

        /// <summary>
        /// Enum Name for Moderate SAR
        /// </summary>
        public static readonly string SarModerate = "MPUCOIL_SAR_MODE_MODERATE";

        /// <summary>
        /// Enum Name for UltraLow SAR
        /// </summary>
        public static readonly string SarUltraLow = "MPUCOIL_SAR_MODE_ULTRA_LOW";

        /// <summary>
        /// Enum Name for imaging type scan
        /// </summary>
        public static readonly string ImagingTypeScan = "MGUACQ_SCT_IMAGING";

        /// <summary>
        /// Enum Name for Spectro type scan
        /// </summary>
        public static readonly string SpectroTypeScan = "MGUACQ_SCT_SPECTRO";

        /// <summary>
        /// 
        /// </summary>
        public static readonly string YesEnumKey = "YES";

        /// <summary>
        /// 
        /// </summary>
        public static readonly string NoEnumKey = "NO";

        /// <summary>
        /// Enum Name for Acceleration Method Enum
        /// </summary>
        public static readonly string MpuAcqAccelEnum = "MPUACQ_ACCEL_ENUM";


        /// <summary>
        /// Enum key for Sense
        /// </summary>
        public static readonly string MpuAcqAccelSense = "MPUACQ_ACCEL_SENSE";

        /// <summary>
        /// Enum key for Cs Sense
        /// </summary>
        public static readonly string MpuAcqAccelCsSense = "MPUACQ_ACCEL_CS_SENSE";

        /// <summary>
        /// Enum key for Cs Sense AI
        /// </summary>
        public static readonly string MpuAcqAccelCsSenseAi = "MPUACQ_ACCEL_CS_SENSE_AI";

    }

}
