﻿#region (c) Koninklijke Philips Electronics N.V. 2019
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: CoilDetailsDto.cs
//
#endregion

#region namespaces
using System;
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    #region CoilDetailsDto
    /// <summary>
    /// Class for showing coil details for coil selection
    /// </summary>
    [Serializable]
    public class CoilDetailsDto : DtoBase
    {
        #region private fields
        /// <summary>
        /// private coil name declaration
        /// </summary>
        private string _coilName;

        /// <summary>
        /// private connector name declaration
        /// </summary>
        private string _connectorName;

        /// <summary>
        /// private if coil selected declaration
        /// </summary>
        private bool _isCoilSelected;

        /// <summary>
        /// private if coil selectable declaration
        /// </summary>
        private bool _isCoilSelectable;

        /// <summary>
        ///  private stack index declaration
        /// </summary>
        private uint _stackIndex;
        /// <summary>
        ///  private coil ui name declaration
        /// </summary>
        private string _coilUIName;

        #endregion

        #region Public Properties
        /// <summary>
        /// Coil name Property
        /// </summary>
        public string CoilName
        {
            get
            {
                return _coilName;
            }
            set
            {
                _coilName = value;
                RaisePropertyChanged();
            }
        }
        /// <summary>
        /// Coil UI name Property
        /// </summary>
        public string CoilUIName
        {
            get
            {
                return _coilUIName;
            }
            set
            {
                _coilUIName = value;
                RaisePropertyChanged();
            }
        }
        /// <summary>
        /// Stack index Property
        /// </summary>
        public uint StackIndex
        {
            get
            {
                return _stackIndex;
            }
            set
            {
                _stackIndex = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Connector name Property
        /// </summary>
        public string ConnectorName
        {
            get
            {
                return _connectorName;
            }
            set
            {
                _connectorName = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Is coil selected Property
        /// </summary>
        public bool IsCoilSelected
        {
            get
            {
                return _isCoilSelected;
            }
            set
            {
                _isCoilSelected = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Is coil selectable Property
        /// </summary>
        public bool IsCoilSelectable
        {
            get
            {
                return _isCoilSelectable;
            }
            set
            {
                _isCoilSelectable = value;
                RaisePropertyChanged();
            }
        }

        #endregion
    }
    #endregion
}

#region Revision History
// 2019-Jul-19  Anu Jothis
//              Initial version story point 33332

#endregion
