﻿#region (c) Koninklijke Philips Electronics N.V. 2019
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: CoilSelectionDto.cs
//
#endregion

#region namespaces
using System;
using System.Collections.ObjectModel;
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    #region CoilSelectionDto
    /// <summary>
    /// Class for showing UI elements of Coil Selection
    /// </summary>
    [Serializable]
    public class CoilSelectionDto : DtoBase
    {
        #region private fields
        /// <summary>
        /// private number of stacks declaration
        /// </summary>
        private int _stackCount;

        /// <summary>
        /// private if smart select declaration
        /// </summary>
        private bool _isSmartSelect;


        /// <summary>
        /// private if stack select declaration
        /// </summary>
        private bool _isStackSelect;

        /// <summary>
        /// Stack details collection declaration
        /// </summary>
        private ObservableCollection<StackDetailsDto> _stackDetailsCollection = new ObservableCollection<StackDetailsDto>();
        #endregion

        #region Public Properties
        /// <summary>
        /// Stack count Property
        /// </summary>
        public int StackCount
        {
            get
            {
                return _stackCount;
            }
            set
            {
                _stackCount = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// IsSmartSelect Property
        /// </summary>
        public bool IsSmartSelect
        {
            get
            {
                return _isSmartSelect;
            }
            set
            {
                _isSmartSelect = value;
                RaisePropertyChanged();
            }
        }


        /// <summary>
        /// IsStackSelect Property
        /// </summary>
        public bool IsStackSelect
        {
            get
            {
                return _isStackSelect;
            }
            set
            {
                _isStackSelect = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Coil stack details collection
        /// </summary>
        public ObservableCollection<StackDetailsDto> StackCollection
        {
            get { return _stackDetailsCollection; }
            set
            {
                _stackDetailsCollection = value;
                RaisePropertyChanged();
            }
        }

        #endregion
    }
    #endregion
}

#region Revision History
// 2019-Jul-19  Anu Jothis
//              Initial version story point 33332
// 2019-Sep-03  Anu Jothis
//              Introduced IsStackSelect property
#endregion
