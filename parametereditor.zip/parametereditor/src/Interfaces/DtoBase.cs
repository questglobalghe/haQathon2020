﻿#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: DtoBase.cs
//

#endregion

using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Base class for all classes which raises property changed notification
    /// </summary>
    [Serializable]
    public class DtoBase : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged Members
        /// <summary>
        /// Property changed event to be notified to the UI
        /// </summary>
        [field: NonSerializedAttribute()]
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        /// <summary>
        /// Notifies that the property has changed
        /// </summary>        
        /// <param name="property">Property</param>
        protected void RaisePropertyChanged([CallerMemberName]string property = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }

}
