#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: ParameterEditorDto.cs
//
#endregion
using System;
using System.Collections.ObjectModel;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Top level DTO which represents ParameterEditor
    /// </summary>
    [Serializable]
    public class ParameterEditorDto : DtoBase
    {
        #region private

        private ObservableCollection<ParameterGroupDto> _parameterGroups = new ObservableCollection<ParameterGroupDto>();

        /// <summary>
        /// Conflict Info Dto declaration
        /// </summary>
        private ConflictInfoDto _conflictInfoDto = new ConflictInfoDto();

        /// <summary>
        /// Coil selection dto declaration
        /// </summary>
        private CoilSelectionDto _coilSelectionDto = new CoilSelectionDto();

        private ParameterGroupDto _scanInfobarDto;

        private ParameterGroupDto _infoParameterGroupDto;

        private int _activeGroupId;

        private bool _conflictPresent;

        private bool _conflictSaved;

        private bool _canUndo;

        private bool _canRedo;

        private bool _canReset;

        #endregion

        /// <summary>
        /// Id of the active group (This maps to the tab which will be active on ParameterEditorUI)
        /// </summary>
        public int ActiveGroupId
        {
            get { return _activeGroupId; }
            set
            {
                _activeGroupId = value;
                RaisePropertyChanged("ActiveGroupId");
            }
        }

        /// <summary>
        /// Parameter groups
        /// </summary>
        public ObservableCollection<ParameterGroupDto> ParameterGroups
        {
            get { return _parameterGroups; }
            set { _parameterGroups = value; }
        }

        /// <summary>
        /// Dto which holds coil selection info data
        /// </summary>
        public CoilSelectionDto CoilSelectionInfoDto
        {
            get { return _coilSelectionDto; }
            set
            {
                _coilSelectionDto = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Dto which holds conflict info data
        /// </summary>
        public ConflictInfoDto ConflictInfoData
        {
            get { return _conflictInfoDto; }
            set
            {
                _conflictInfoDto = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Dto which holds the parameters which are shown in ScanInfoBar
        /// </summary>
        public ParameterGroupDto ScanInfoBarDto {
            get { return _scanInfobarDto; }
            set
            {
                _scanInfobarDto = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Dto which holds the parameters which are shown in ScanInfoBar
        /// </summary>
        public ParameterGroupDto InfoParameterGroupDto
        {
            get { return _infoParameterGroupDto; }
            set
            {
                _infoParameterGroupDto = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Conflict at parameterEditor level
        /// </summary>
        public bool ConflictPresent
        {
            get { return _conflictPresent; }
            set
            {
                _conflictPresent = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Conflict at parameterEditor level
        /// </summary>
        public bool ConflictSaved
        {
            get { return _conflictSaved; }
            set
            {
                _conflictSaved = value;
                RaisePropertyChanged();
            }
        }
        /// <summary>
        /// CanUndo at parameterEditor level
        /// </summary>
        public bool CanUndo
        {
            get { return _canUndo; }
            set
            {
                _canUndo = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// CanRedo at parameterEditor level
        /// </summary>
        public bool CanRedo
        {
            get { return _canRedo; }
            set
            {
                _canRedo = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// CanReset at parameterEditor level
        /// </summary>
        public bool CanReset
        {
            get { return _canReset; }
            set
            {
                _canReset = value;
                RaisePropertyChanged();
            }
        }
    }


 }

#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2017-Nov-22  M Kranthi Kumar
//              Added ConflictPresent property
// 2019-May-07 Anu Jothis
//             Added ConflictInfoData property  story point 32400
// 2019-Jul-19  Anu Jothis
//              Initial version Coil selection feature. Story point 33332
#endregion