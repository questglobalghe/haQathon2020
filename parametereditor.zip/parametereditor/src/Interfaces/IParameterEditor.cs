#region (c) Koninklijke Philips Electronics N.V. 2019
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: IParameterEditor.cs
//
#endregion

using System;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// This interface is used by ParameterEditor UI to fetch ParmaterEditor Dto.
    /// This also provides interface to Edit Parameter or switch groups.
    /// </summary>
    public interface IParameterEditor
    {
        /// <summary>
        /// Update the parameter change to PDF
        /// </summary>
        /// <param name="paramId">Modified parameter id</param>
        /// <param name="newValues">New values for Parameter</param>
        void SetParameter(string paramId, Array newValues);

        /// <summary>
        /// Update the current active group when user switched to new tab on UI to 
        /// populate new group
        /// </summary>
        /// <param name="groupId"></param>
        void SetActiveGroup(int groupId);

        /// <summary>
        /// Resolve the selected conflict from list
        /// </summary>
        /// <param name="conflictKey">Conflict key</param>
        /// <param name="suggestionKey">Suggestion key for selected option</param>
        void ResolveConflict(string conflictKey, string suggestionKey);

        /// <summary>
        /// Set the stack and coil details to scan protocol
        /// </summary>
        /// <param name="stackIndex">Stack index of modified coil</param>
        /// <param name="stackDetails">Stack details for the selected stack index</param>
        void SetStackCoilSelection(uint stackIndex, StackDetailsDto stackDetails);

        /// <summary>
        /// Set the smart select to true or false
        /// </summary>
        /// <param name="isSmartSelect">Boolean for smart select</param>
        void SetSmartSelect(bool isSmartSelect);

        /// <summary>
        /// Set the stack select to true or false
        /// </summary>
        /// <param name="isStackSelect">Boolean for stack select</param>
        void SetStackSelect(bool isStackSelect);

        /// <summary>
        /// Reset all Parameters 
        /// </summary>
        void ResetAll();

        /// <summary>
        /// Undo Parameter
        /// </summary>
        void UndoParameter();

        /// <summary>
        /// Redo Parameter
        /// </summary>
        void RedoParameter();

        /// <summary>
        /// Get Initial Model
        /// </summary>
        void GetInitialModel();

        /// <summary>
        /// Event to enable or disable parameter editor
        /// </summary>
        event EventHandler<bool> ParameterEditorEnabled;

        /// <summary>
        /// Event to communicate new ParameterEditorDto
        /// </summary>
        event EventHandler<ParameterEditorUpdateArgs> ParameterEditorUpdated;

        /// <summary>
        /// Update the current advance parameter state (either open/close) when user click on advance parameter button on UI to 
        /// either to open or close
        /// </summary>
        /// <param name="advanceParameterOpenState"></param>
        void SetAdvanceParameterState(bool advanceParameterOpenState);
    }

}

#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2019-May-14  Anu Jothis
//              Created code for ResolveConflict story Id - 32400
//2019-Jul-26  Anu Jothis
//              Created code for SetCoilSelectionDto story Id - 54058
//2019-July-31  Anu Jothis
//              Refactored coil selection set and created two separate APIs - SetCoilStack and SetCoilSmartSelect. Story Id - 54058
//2019-Oct-22  Anu Jothis
//              Renamed smart selection api to SetSmartSelect. Added one more API for Stack select. SetStackSelect.
#endregion