﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: ParameterValueLevelConstants.cs
//
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// This class has contants which are used by UI to identify Low, High or Medium indicator for Parameter
    /// </summary>
    public static class ParameterValueLevelConstants
    {
        /// <summary>
        /// Sar level is marked as low if value is below 1
        /// </summary>
        public const int SarLevelLow = 1;

        /// <summary>
        /// Sar level is marked as Mid if value is below 2 and greater than 1
        /// Above 2 it will be marked as High
        /// </summary>
        public const int SarLevelMid = 2;

        /// <summary>
        /// Pns level is marked as low if value is below 40
        /// </summary>
        public const int PnsLevelLow = 40;

        /// <summary>
        /// Pns level is marked as Mid if value is below 80 and greater than 40
        /// Above 80 it will be marked as High
        /// </summary>
        public const int PnsLevelMid = 80;
    }

}
