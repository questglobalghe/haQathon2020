#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: SingleParameterDto.cs
//
#endregion
using System;
using System.Collections.ObjectModel;
using Philips.PmsMR.Platform.OSInterface;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Represents a float parameter
    /// </summary>
    [Serializable]
    public class SingleParameterDto : BaseParameterDto
    {
        #region private fields

        private int _precision = 2;
        private float _stepValue;
        private ObservableCollection<FloatRange> _ranges;
        private ObservableCollection<float> _defaultValues;
        private ObservableCollection<float> _values;

        #endregion

        #region Public Properties


        /// <summary>
        /// Gets or sets the default values for the current object.
        /// </summary>
        public ObservableCollection<float> DefaultValues
        {
            get
            {
                return _defaultValues;
            }
            set
            {
                _defaultValues = value ?? new ObservableCollection<float>();
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating the floating-point precision.
        /// </summary>
        /// <value>
        /// The number of digits behind the comma-separator.
        /// </value>
        public int Precision
        {
            get { return _precision; }

            set
            {
                _precision = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets one or more ranges for the current object.
        /// </summary>
        /// <value>
        /// One or more <see cref="FloatRange"/> objects.
        /// </value>
        public ObservableCollection<FloatRange> Ranges
        {
            get { return _ranges; }

            set
            {
                _ranges = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets a step value of the parameter
        /// </summary>
        /// <value>
        /// The new step value
        /// </value>
        public float StepValue
        {
            get { return _stepValue; }

            set
            {
                if(FloatComparison.Compare(_stepValue, value) != 0 || FloatComparison.Compare(_stepValue, 0) == 0)
                {
                    // if trying to set too small value, derive the stepValue 
                    // from the range of the possible values
                    double accuracy = Math.Pow(10, -_precision);
                    if ((Math.Abs(value) < accuracy) && _ranges.Count>0)
                    {
                        _stepValue = (float) Math.Pow(10, (int) Math.Log10(
                                                              Ranges[0].upper - Ranges[0].lower) - 2);
                    }
                    else
                    {
                        _stepValue = value;
                    }
                    // if the set value is smaller than accuracy, set the 
                    // step value to accuracy
                    if (Math.Abs(_stepValue) < accuracy)
                    {
                        _stepValue = (float) accuracy;
                    }
                    RaisePropertyChanged();
                }
            }
        }


        /// <summary>
        /// Gets or sets one or more values for the current object.
        /// </summary>
        public ObservableCollection<float> Values
        {
            get { return _values; }
            set
            {
                _values = value;
                RaisePropertyChanged();
            }
        }


        #endregion

        #region Constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public SingleParameterDto()
        {
            _values = new ObservableCollection<float>();
            _defaultValues = new ObservableCollection<float>();
            _ranges = new ObservableCollection<FloatRange>() {};
        }

        #endregion

        /// <summary>
        ///     Helper class to compare float / double parameters
        /// </summary>
        public static class FloatComparison
        {
            /// <summary>
            ///     Compare float parameters
            /// </summary>
            /// <param name="x1"></param>
            /// <param name="x2"></param>
            /// <returns></returns>
            public static int Compare(float x1, float x2)
            {
                float absX1 = Math.Abs(x1);
                float absX2 = Math.Abs(x2);

                if ((absX1 - absX2) <= float.Epsilon ||
                    (absX2 - absX1) <= float.Epsilon)
                {
                    return 0;
                }

                if ((absX1 - absX2) > float.Epsilon)
                {
                    return 1;
                }

                if ((absX2 - absX1) > float.Epsilon)
                {
                    return -1;
                }

                return -1;
            }
        }
    }
}

#region Revision History

// 2017-Aug-04  Ankit Singh Bhakuni
//              Initial version
// 2017-Aug-07  Shailendra
//              Adapted for additional properties and constructor.
// 2017-Nov-07  Shailendra Nalwaya
//              Fixed the issues related to difference of JSON Serialization(Component Test) compare
//              to Binary Serialization(Messaging Framework).
//              Moved logic/initializations present in Parameter Level Dto to respective Dto converter code.
#endregion Revision History