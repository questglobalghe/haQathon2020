#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: StringParameterDto.cs
//
#endregion
using System;
using System.Collections.ObjectModel;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Represents a string parameter
    /// </summary>
    [Serializable]
    public class StringParameterDto : BaseParameterDto
    {
        #region private 
        private ObservableCollection<string> _values;

        private ObservableCollection<string> _defaultValues;

        #endregion

        #region Public Properties
        /// <summary>
        /// Gets or sets the default values for the current object.
        /// </summary>
        public ObservableCollection<string> DefaultValues
        {
            get
            {
                return _defaultValues;
            }
            set
            {
                _defaultValues = value ?? new ObservableCollection<string>();
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Values of current parameter
        /// </summary>
        public ObservableCollection<string> Values
        {
            get { return _values; }
            set
            {
                _values = value;
                RaisePropertyChanged();
            }
        }

        #endregion

        #region Constructor
        
        /// <summary>
        /// Default constructor
        /// </summary>
        public StringParameterDto()
        {
            _values = new ObservableCollection<string>();
            _defaultValues = new ObservableCollection<string>();
        }
        #endregion
    }
}

#region Revision History

// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2017-Nov-07  Shailendra Nalwaya
//              Fixed the issues related to difference of JSON Serialization(Component Test) compare
//              to Binary Serialization(Messaging Framework).
//              Moved logic/initializations present in Parameter Level Dto to respective Dto converter code.
#endregion Revision History
