#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: ParameterGroupDto.cs
//
#endregion
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Class for showing UI elements of Parameter Group
    /// </summary>
    [Serializable]
    public class ParameterGroupDto : DtoBase
    {
        #region private fields
        private int _groupId;

        private string _name;

        private string _code;

        private int _index;

        private bool _visible;

        private bool _conflictPresent;

        private SerializableDictionary<string, BaseParameterDto> _parameters = new SerializableDictionary<string, BaseParameterDto>();

        /// <summary>
        /// Observable Collection of BaseParameterDto, Used to bind for advanced tabs.
        /// It will be initialized when SerializableDictionary of BaseParameterDto is filled.
        /// </summary>
        private List<BaseParameterDto> _parameterDtoCollection = new List<BaseParameterDto>();
        #endregion

        #region Public Properties
        /// <summary>
        /// Parameter Group Id
        /// </summary>
        public int GroupId {
            get
            {   
                return _groupId;
            }
            set
            {
                _groupId = value;
                RaisePropertyChanged();
            } 
        }

        /// <summary>
        /// Parameter Group Name
        /// </summary>
        public string Name {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Parameter Group Code
        /// </summary>
        public string Code
        {
            get
            {
                return _code;
            }
            set
            {
                _code = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Index of Parameter group (Order of display)
        /// </summary>
        public int Index {
            get
            {
                return _index;
            }
            set
            {
                _index = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Indicates if Parameter group is visible or not
        /// </summary>
        public bool Visible {
            get
            {
                return _visible;
            }
            set
            {
                _visible = value;
                RaisePropertyChanged();
            }
        }

 
        /// <summary>
        /// Parameters for current group
        /// </summary>
        public SerializableDictionary<string, BaseParameterDto> Parameters
        {
            get { return _parameters; }
            set
            {
                _parameters = value;
                
                RaisePropertyChanged();
                //Clear the existing ParameterDtoCollection
                ParameterDtoCollection = _parameters.Values.ToList();
            }
        }


        /// <summary>
        /// Conflict at PDF level
        /// </summary>
        public bool ConflictPresent
        {
            get { return _conflictPresent; }
            set
            {
                _conflictPresent = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public List<BaseParameterDto> ParameterDtoCollection
        {
            get { return _parameterDtoCollection; }
            set
            {
                _parameterDtoCollection = value;
                RaisePropertyChanged();
            }
        }
        #endregion
    }
}

#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2020-May-19  Ramanjaneyulu SBV
//              Added new property for parameter group code
#endregion