#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part,in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// FILENAME: UiConstants.cs
//

#endregion (c) Koninklijke Philips Electronics N.V. 2017

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Class holding the constants for Parameter Editor UI and converters.
    /// </summary>
    public static class UiConstants
    {
        /// <summary>
        /// String constant for coronal on routineUI
        /// </summary>
        public static readonly string Coronal = "routineui.coronal";

        /// <summary>
        /// String constant for transverse on routineUI
        /// </summary>
        public static readonly string Transverse = "routineui.transverse";

        /// <summary>
        /// String constant for sagittal on routineUI
        /// </summary>
        public static readonly string Sagittal = "routineui.sagittal";

        /// <summary>
        /// String constant for notavailable on routineUI
        /// </summary>
        public static readonly string InfoNotAvailable = "routineui.notavailable";

        /// <summary>
        /// String constant for sliceorientation on routineUI
        /// </summary>
        public static readonly string SliceOrientation = "routineui.sliceorientation";

        /// <summary>
        /// Voxel parameter in X-Direction
        /// </summary>
        public static readonly string VoxelX = "VoxelX";

        /// <summary>
        /// Voxel parameter in Y-Direction
        /// </summary>
        public static readonly string VoxelY = "VoxelY";

        /// <summary>
        /// Voxel parameter in Z-Direction
        /// </summary>
        public static readonly string VoxelZ = "VoxelZ";

        /// <summary>
        /// Voxel Scale constant
        /// </summary>
        public static readonly string VoxelScaleX = "VoxelScaleX";

        /// <summary>
        /// Voxel Scale constant
        /// </summary>
        public static readonly string VoxelScaleY = "VoxelScaleY";

        /// <summary>
        /// Voxel Scale constant
        /// </summary>
        public static readonly string VoxelScaleZ = "VoxelScaleZ";

        /// <summary>
        /// Minimum Float value for UI control.
        /// </summary>
        public static readonly double SingleParamMin = float.MinValue;

        /// <summary>
        /// Maximum float value for UI control.
        /// </summary>
        public static readonly double SingleParamMax = float.MaxValue;

        /// <summary>
        /// Minimum int value for UI control.
        /// </summary>
        public static readonly double Int32ParamMin = int.MinValue;

        /// <summary>
        /// Maximum int value for UI control.
        /// </summary>
        public static readonly double Int32ParamMax = int.MaxValue;
    }
 
}

#region Revision History

// 05-Sep-2017  Vivek Saurav
//              Initial Version (Story -17347)
// 06-Sep-2017  Ankit Singh Bhakuni
//              added constants for UI control max-min.
#endregion