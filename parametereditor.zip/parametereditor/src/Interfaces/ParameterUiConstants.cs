﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: ParameterUiConstants.cs
//
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Constants for ParameterEditorUi
    /// </summary>
    public static class ParameterUiConstants
    {
        /// <summary>
        /// "string.p_peui.editorbank.otheritems"
        /// </summary>
        public static readonly string OtherItemsToolTipIndication = "(Other items left out for brevity)";

        /// <summary>
        /// "routineui.slicesperbreathholdparameter"
        /// </summary>
        public static readonly string SlicesControl = "Slices/breathhold";

        /// <summary>
        /// "routineui.breathholdmodeparameter"
        /// </summary>
        public static readonly string BreathholdModeControl = "Breathhold Mode";

        /// <summary>
        /// "routineui.userdefinedbreathhold"
        /// </summary>
        public static readonly string BreathholdEnumControl = "User Defined Breathhold Mode";

        /// <summary>
        /// "routineui.gatingleveldriftparameter"
        /// </summary>
        public static readonly string GatingLevelDriftControl = "Gating Level Drift";

        /// <summary>
        /// "routineui.gatedelaymode"
        /// </summary>
        public static readonly string CardiacGateDelayMode = "Cardiac Gate  Delay Mode";

        /// <summary>
        /// "routineui.arythmiarejectionparameter"
        /// </summary>
        public static readonly string ArythmiaRejectionControl = "Arrhythmia Rejection";

        /// <summary>
        /// "routineui.cardiacdeviceparameter"
        /// </summary>
        public static readonly string CardiacDeviceControl = "Cardiac Device";

        /// <summary>
        /// "routineui.cardiactriggerdelay"
        /// </summary>
        public static readonly string CardiacSynchronizationMode = "Trigger delay";

        /// <summary>
        /// "routineui.heartphasesmode"
        /// </summary>
        public static readonly string UserDefinedHeartPhasesControl = "Heart Phases Definition Mode";

        /// <summary>
        /// "routineui.triggerdelayparameter"
        /// </summary>
        public static readonly string CardiacTriggerDelayControl = "Cardiac Trigger Delay";

        /// <summary>
        /// "routineui.triggerdelaymode"
        /// </summary>
        public static readonly string CardiacTriggerDelayMode = "Cardiac Trigger Delay Mode";

        /// <summary>
        /// "routineui.heartphasesparameter"
        /// </summary>
        public static readonly string HeartPhasesControl = "Heart Phases";

        /// <summary>
        /// "routineui.respiratorytriggerdelayparameter"
        /// </summary>
        public static readonly string RespiratoryTriggerControl = "Respiratory Trigger Delay";

        /// <summary>
        /// "routineui.rrwindowparameter"
        /// </summary>
        public static readonly string RRWindowControl = "R-R Window Interval";

        /// <summary>
        /// "routineui.gatingwindowparameter"
        /// </summary>
        public static readonly string GatingWindowControl = "Gating window";

        /// <summary>
        /// "routineui.scalefactorparameter"
        /// </summary>
        public static readonly string ScaleFactor = "Scale Factor";

        /// <summary>
        /// "routineui.gatedelayparameter"
        /// </summary>
        public static readonly string CardiacGateDelayControl = "Gate delay";

        /// <summary>
        /// "routineui.breathholddurationparameter"
        /// </summary>
        public static readonly string BreathholdControl = "Breathhold Duration";

        /// <summary>
        /// "routineui."
        /// </summary>
        public static readonly string AutovoiceBreathholdInstrControl = "Voice Instruction";

        /// <summary>
        /// "routineui."
        /// </summary>
        public static readonly string AutovoiceBreathholdMode = "Breathhold Guidance";
    }

}
