#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: EnumParameterDto.cs
//
#endregion

using System;
using System.Collections.ObjectModel;
using System.Linq;
using Philips.PmsMR.Platform.OSInterface;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Represents a parameter containing an array of an enumeration type.
    /// </summary>
    /// <remarks>
    /// It defines the possible string representations of the enumeration type
    /// (represented by an <see cref="Enumerator"/>) and it contains one or 
    /// more instances of this type. 
    /// </remarks>
    [Serializable]
    public class EnumParameterDto : BaseParameterDto
    {
        #region Private Fields

        private bool _extendable;
        private bool _sorted;
        private ObservableCollection<Enumerator> _enumList;
        private ObservableCollection<IntRange> _ranges;
        private ObservableCollection<int> _values;
        private ObservableCollection<int> _defaultValues;

        #endregion

        /// <summary>
        /// Gets or sets one or more values for the current object.
        /// </summary>
        public ObservableCollection<int> Values
        {
            get
            {
                return _values;
            }
            set
            {
                _values = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets an array of enumerators for the enumeration 
        /// type, replacing the original representations.
        /// </summary>
        public ObservableCollection<Enumerator> Enumerators
        {
            get { return _enumList; }
            set
            {
                _enumList.Clear();
                _enumList = _sorted ? new ObservableCollection<Enumerator>(value.OrderByDescending(x => x.Key)) : value;
            }
        }

        /// <summary>
        /// Gets a copy of the culture-sensitive names of the enumerators.
        /// </summary>
        public ObservableCollection<string> Names
        {
            get
            {
                ObservableCollection<string> names = new ObservableCollection<string>();
                for (int i = 0; i < _enumList.Count; ++i)
                {
                    names.Add(_enumList[i].DisplayName);
                }

                return names;
            }
        }

        /// <summary>
        /// Gets or sets one or more ranges for the current object.
        /// </summary>
        /// <value>
        /// One or more <see cref="IntRange"/> objects.
        /// </value>
        public ObservableCollection<IntRange> Ranges
        {
            get { return _ranges; }

            set
            {
                _ranges = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the enumerator list should
        /// be sorted.
        /// </summary>
        /// <value>
        /// <b>true</b> if list must be sorted, or <b>false</b> otherwise.
        /// </value>
        public bool Sorted
        {
            get { return _sorted; }
            set
            {
                _sorted = value;
                if (_sorted)
                {
                    _enumList = new ObservableCollection<Enumerator>(_enumList.OrderByDescending(x => x.Key));
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this enumeration type can
        /// be extended.
        /// </summary>
        /// <value>
        /// <b>true</b> if it is possible to add, remove, or rename enumList
        /// using <see />, <see />, or 
        /// <see />.
        /// </value>
        public bool Extendable
        {
            get { return _extendable; }
            set
            {
                _extendable = value;
                RaisePropertyChanged();
            }
        }



        /// <summary>
        /// Gets or sets the default values for the current object.
        /// </summary>
        public ObservableCollection<int> DefaultValues
        {
            get
            {
                return _defaultValues;
            }
            set
            {
                if (value != null)
                {
                    _defaultValues = value;
                }
                else
                {
                    _defaultValues = new ObservableCollection<int>();
                }
                RaisePropertyChanged();
            }
        }
        /// <summary>
        /// EnumParameterDto Constructor
        /// </summary>
        public EnumParameterDto()
        {
            _values = new ObservableCollection<int>();
            _defaultValues = new ObservableCollection<int>();
            _enumList = new ObservableCollection<Enumerator>();
            _ranges = new ObservableCollection<IntRange>();
        }
    }


}

#region Revision History

// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2017-Nov-07  Shailendra Nalwaya
//              Fixed the issues related to difference of JSON Serialization(Component Test) compare
//              to Binary Serialization(Messaging Framework).
//              Moved logic/initializations present in Parameter Level Dto to respective Dto converter code.
#endregion Revision History