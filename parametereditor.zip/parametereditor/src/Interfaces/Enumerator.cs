﻿#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: Enumerator.cs
//
#endregion

using System;
using System.Collections.ObjectModel;
using System.Linq;
using Philips.PmsMR.Platform.OSInterface;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Represents an enumerator in the list of enumList contained by 
    /// <see cref="EnumParameterDto"/>.
    /// </summary>
    [Serializable]
    public class Enumerator : IComparable
    {
        private string _key;
        private string _displayname;

        /// <summary>
        /// Initializes an instance of this structure.
        /// </summary>
        /// <param name="key">
        /// The unique culture-insensitive identifier of this object.
        /// </param>
        /// <param name="name">
        /// The translated representation of this object.
        /// </param>
        public Enumerator(string key, string name)
        {
            _key = key;
            _displayname = name;
        }

        /// <summary>
        /// Gets or sets a value indicating the key that identifies this 
        /// enumerator.
        /// </summary>
        /// <value>
        /// An culture-insensitive string that uniquely identifies this 
        /// enumerator.
        /// </value>
        public string Key
        {
            get { return _key; }
            set { _key = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating the string representation of this
        /// enumerator.
        /// </summary>
        /// <value>
        /// Typically holds the translated (culture-sensitive) representation
        /// of this enumerator.
        /// </value>
        public string DisplayName
        {
            get { return _displayname; }
            set { _displayname = value; }
        }

        /// <summary>
        /// See <see cref="Object.Equals(object)"/>.
        /// </summary>
        public override bool Equals(object obj)
        {
            bool equal = false;
            if (obj.GetType() == GetType())
            {
                equal = (_key.ToLower() == ((Enumerator)obj).Key.ToLower());
            }
            return equal;
        }

        /// <summary>
        /// See <see cref="Object.GetHashCode"/>.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return _key.GetHashCode();
        }

        /// <summary>
        /// See <see cref="Object.ToString"/>.
        /// </summary>
        public override string ToString()
        {
            return _displayname;
        }

        /// <summary>
        /// Compares two objects for equality by key.
        /// </summary>
        public static bool operator ==(Enumerator o1, Enumerator o2)
        {
            bool equal = false;
            if (Equals(o1, null) && Equals(o2, null))
            {
                // consider the two objects as equal when both of them are null
                // references 
                // note that object.Equals(object, object) is used instead of
                // == operator. The latter would cause recursive calls to this 
                // overload and therefore StackOverflowException wil be raised
                equal = true;
            }
            else if (Equals(o1, null) || Equals(o2, null))
            {
                // so not both of the objects are null. Then if either one of 
                // them is null return false
            }
            else
            {
                // none of the objects is null, so go for checking equality of 
                // the keys
                equal = (o1._key.ToLower() == o2._key.ToLower());
            }
            return equal;
        }

        /// <summary>
        /// Compares two objects by unequality by key.
        /// </summary>
        public static bool operator !=(Enumerator o1, Enumerator o2)
        {
            return (!(o1 == o2));
        }

        /// <summary>
        /// Compares two objects for less than by key.
        /// </summary>
        /// <param name="o1"></param>
        /// <param name="o2"></param>
        /// <returns></returns>
        public static bool operator <(Enumerator o1, Enumerator o2)
        {
            return (Compare(o1, o2) < 0);
        }

        /// <summary>
        /// Compares two objects for greater than by key.
        /// </summary>
        /// <param name="o1"></param>
        /// <param name="o2"></param>
        /// <returns></returns>
        public static bool operator >(Enumerator o1, Enumerator o2)
        {
            return (Compare(o1, o2) > 0);
        }

        /// <summary>
        /// Compares two objects for less than equal than by key.
        /// </summary>
        /// <param name="o1"></param>
        /// <param name="o2"></param>
        /// <returns></returns>
        public static bool operator <=(Enumerator o1, Enumerator o2)
        {

            return (Compare(o1, o2) <= 0);

        }

        /// <summary>
        /// Compares two objects for greater than equal than by key.
        /// </summary>
        /// <param name="o1"></param>
        /// <param name="o2"></param>
        /// <returns></returns>
        public static bool operator >=(Enumerator o1, Enumerator o2)
        {

            return (Compare(o1, o2) >= 0);

        }

        /// <summary>
        /// Compares two objects by key.
        /// </summary>
        /// <param name="o1"></param>
        /// <param name="o2"></param>
        /// <returns></returns>
        public static int Compare(Enumerator o1, Enumerator o2)
        {
            if (object.ReferenceEquals(o1, o2))
            {
                return 0;
            }
            if (object.ReferenceEquals(o1, null))
            {
                return -1;
            }
            return o1.CompareTo(o2);
        }

        /// <summary>
        /// See <see cref="IComparable.CompareTo"/>
        /// </summary>
        public int CompareTo(object obj)
        {
            return String.Compare(DisplayName, ((Enumerator)obj).DisplayName, StringComparison.Ordinal);
        }
    }
}
