﻿#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: ParameterEditorUpdateArgs.cs
//
#endregion
using System;
using System.Collections.ObjectModel;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// EventArgs for Parameter Editor Dto update
    /// </summary>
    [Serializable]
    public class ParameterEditorUpdateArgs : EventArgs
    {
        /// <summary>
        /// _editorDto
        /// </summary>
        private ParameterEditorDto _editorDto;

        /// <summary>
        /// initialMode
        /// </summary>
        private bool _initialMode;

        /// <summary>
        /// Event Args to updated ParameterEditorDto on UI
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="initialMode"></param>
        public ParameterEditorUpdateArgs(ParameterEditorDto dto, bool initialMode)
        {
            _editorDto = dto;
            _initialMode = initialMode;
        }

        /// <summary>
        /// ParameterEditorDto mode - either initial or not
        /// </summary>
        public bool InitialMode => _initialMode;

        /// <summary>
        ///  ParameterEditorDto to be populated on UI
        /// </summary>
        public ParameterEditorDto EditorDto => _editorDto;
    }
}
