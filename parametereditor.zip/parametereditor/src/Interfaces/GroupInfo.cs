﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: GroupInfo.cs
//
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Represents a group of parameters in the native parameter hives.
    /// </summary>
    public struct GroupInfo
    {
        /// <summary>Identifier for the parameter group.</summary>
        public int id;
        /// <summary>
        /// Group code for the parameter group.
        /// </summary>
        public string Code;
        /// <summary>
        /// Count of the number of parameters in the group represented by this
        /// structure.
        /// </summary>
        public int parameterCount;
        /// <summary>Name of the parameter group.</summary>
        public string name;
    }

}
