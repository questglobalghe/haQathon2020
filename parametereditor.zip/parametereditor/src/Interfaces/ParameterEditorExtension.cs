#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterEditorExtension.cs
//

#endregion

using System;
using System.Collections.ObjectModel;
using System.Linq;
using Philips.PmsMR.Platform.Logging;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// This class contains extension methods for ParameterEditorDto and ParameterGroupDto
    /// </summary>
    public static class ParameterEditorExtension
    {
        /// <summary>
        /// <see cref="SystemMessage"/> object for logging messages.
        /// </summary>
        private static readonly SystemMessage Log =
            new SystemMessage("ParameterEditor", "ParameterEditorExtension");

        /// <summary>
        /// This method copies the all the information from the passed ParameterEditorDto without creating a new instance of it. 
        /// </summary>
        /// <param name="oldParameterEditorDto"></param>
        /// <param name="newParameterEditorDto"></param>
        public static void CopyProperties(this ParameterEditorDto oldParameterEditorDto, ParameterEditorDto newParameterEditorDto)
        {
            PerformanceLoggingUtil.Enter("OPEN_PROTOCOL", "CopyProperties");
            if (newParameterEditorDto != null)
            {
                oldParameterEditorDto.ScanInfoBarDto = newParameterEditorDto.ScanInfoBarDto;
                oldParameterEditorDto.InfoParameterGroupDto = newParameterEditorDto.InfoParameterGroupDto;
                oldParameterEditorDto.ConflictInfoData = newParameterEditorDto.ConflictInfoData;
                oldParameterEditorDto.CoilSelectionInfoDto = newParameterEditorDto.CoilSelectionInfoDto;
                var newlyAddedGroups = NewlyAddedGroups(oldParameterEditorDto, newParameterEditorDto);
                var toBeRemovedGroups = RemovedGroups(oldParameterEditorDto, newParameterEditorDto);
                var commonGroups = CommonGroups(oldParameterEditorDto, newParameterEditorDto);


                // 1. Remove obsolete/toBeRemoved groups
                foreach (var toRemoveGroup in toBeRemovedGroups)
                {
                    oldParameterEditorDto.ParameterGroups.Remove(toRemoveGroup);
                }
                // 2. Add new groups
                foreach (var newlyAddedGroup in newlyAddedGroups)
                {
                    int currentnewParameterIndex = newParameterEditorDto.ParameterGroups.IndexOf(newlyAddedGroup);
                    if (currentnewParameterIndex <= oldParameterEditorDto.ParameterGroups.Count)
                    {
                        // preferably add at correct index
                        oldParameterEditorDto.ParameterGroups.Insert(currentnewParameterIndex, newlyAddedGroup);
                    }
                    else
                    {
                        // else add at the end
                        oldParameterEditorDto.ParameterGroups.Add(newlyAddedGroup);
                    }
                }
                // 3. Update existing common groups
                foreach (var commonGroup in commonGroups)
                {
                    var newData = newParameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == commonGroup.GroupId);
                    if (newData != null)
                    {
                        commonGroup.CopyProperties(newData);
                    }
                }

                // Set ActiveGroupId AFTER synching Collections so that correct selectedindex can be evaluated
                //oldParameterEditorDto.ActiveGroupId = newParameterEditorDto.ActiveGroupId
                oldParameterEditorDto.ConflictPresent = newParameterEditorDto.ConflictPresent;
                oldParameterEditorDto.CanUndo = newParameterEditorDto.CanUndo;
                oldParameterEditorDto.CanRedo = newParameterEditorDto.CanRedo;
            }
            else
            {
                Log.Info("NewParameterEditorDto is null");
            }
            PerformanceLoggingUtil.Exit();
        }

        private static ObservableCollection<ParameterGroupDto> CommonGroups(ParameterEditorDto oldParameterEditorDto,
            ParameterEditorDto newParameterEditorDto)
        {
            // 3. Identify Common Groups for [Update]
            var commonGroups = new ObservableCollection<ParameterGroupDto>();
            foreach (var oldGroup in oldParameterEditorDto.ParameterGroups)
            {
                // if also present in new list
                if (newParameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == oldGroup.GroupId) != null)
                {
                    // then add to common list
                    commonGroups.Add(oldGroup);
                }
            }

            return commonGroups;
        }

        private static ObservableCollection<ParameterGroupDto> RemovedGroups(ParameterEditorDto oldParameterEditorDto,
            ParameterEditorDto newParameterEditorDto)
        {
            // 2. Identify To Be Removed Groups for [Removal]
            var toBeRemovedGroups = new ObservableCollection<ParameterGroupDto>();
            foreach (var oldGroup in oldParameterEditorDto.ParameterGroups)
            {
                // if not present in new list
                if (newParameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == oldGroup.GroupId) == null)
                {
                    // then add toBe removed list
                    toBeRemovedGroups.Add(oldGroup);
                }
            }

            return toBeRemovedGroups;
        }

        private static ObservableCollection<ParameterGroupDto> NewlyAddedGroups(ParameterEditorDto oldParameterEditorDto,
            ParameterEditorDto newParameterEditorDto)
        {
            // 1. Identify Newly Added Groups for [Addition]
            var newlyAddedGroups = new ObservableCollection<ParameterGroupDto>();
            foreach (var newGroup in newParameterEditorDto.ParameterGroups)
            {
                // if not present in old list
                if (oldParameterEditorDto.ParameterGroups.FirstOrDefault(x => x.GroupId == newGroup.GroupId) == null)
                {
                    // then add to newly added list
                    newlyAddedGroups.Add(newGroup);
                }
            }

            return newlyAddedGroups;
        }

        /// <summary>
        /// This method copies the all the information from the passed ParameterGroupDto without creating a new instance of it. 
        /// </summary>
        /// <param name="oldGroupDto"></param>
        /// <param name="newGroupDto"></param>
        public static void CopyProperties(this ParameterGroupDto oldGroupDto, ParameterGroupDto newGroupDto)
        {
            oldGroupDto.GroupId = newGroupDto.GroupId;
            oldGroupDto.ConflictPresent = newGroupDto.ConflictPresent;
            oldGroupDto.Index = newGroupDto.Index;
            oldGroupDto.Name = newGroupDto.Name;
            oldGroupDto.Parameters = newGroupDto.Parameters;
            oldGroupDto.Visible = newGroupDto.Visible;
        }

        /// <summary>
        /// Get Enum Key for current value of EnumParameterDto
        /// </summary>
        public static string GetCurrentValueEnumKey(this EnumParameterDto dto)
        {
            string enumValue = string.Empty;
            if (dto != null && dto.Values.Count > 0)
            {
                int selectedIndex = dto.Values[0];
                if (selectedIndex < dto.Enumerators.Count)
                {
                    enumValue = dto.Enumerators[selectedIndex].Key;
                }
            }
            return enumValue;
        }
        
    }
}

#region Revision History

// 2017-Sep-21  Vivek Saurav
//              Initial version
// 2017-Sep-21  Shailendra Nalwaya
//              Added extension method to fetch enum key for current value of EnumParameterDto
// 2017-Nov-22  M Kranthi Kumar
//              Added assignment of ConflictPresent property of the NewParameterDto to the OldParameterDto
//2019-May-24   Anu Jothis
//             Added ConflictInfoData to fill data from the NewParameterDto to the OldParameterDto story id - 32400

// 2019-Jun-20  B Ravikumar
//              Added assignment of CanUndo & CanRedo property of the NewParameterDto to the OldParameterDto
// 2019-Aug-1  Anu Jothis
//             Added CoilSelectionInfoDto to fill data from the NewParameterDto to the OldParameterDto  Story ID - 54058. Coil Selection backend implementation
#endregion Revision History