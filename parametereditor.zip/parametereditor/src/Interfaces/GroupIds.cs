﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: GroupIds.cs
//
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Enum to represent group Ids
    /// </summary>
    public enum GroupIds
    {
        /// <summary>
        /// Geometry
        /// </summary>
        Geometry = 0,

        /// <summary>
        /// Contrast
        /// </summary>
        Contrast = 1,

        /// <summary>
        /// Motion
        /// </summary>
        Motion = 2,

        /// <summary>
        /// Group Id for DynAng tab
        /// </summary>        
        DynAng = 3,

        /// <summary>
        /// Group Id for PostProc tab
        /// </summary>
        Postproc = 4,

        /// <summary>
        /// Group Id for PostProc tab
        /// </summary>
        OffcAng = 5,

        /// <summary>
        /// Initial
        /// </summary>
        Initial = 6,

        /// <summary>
        /// Protocols
        /// </summary>
        Protocols = 7,

        /// <summary>
        /// Conflicts
        /// </summary>
        Conflicts = 8,

        /// <summary>
        /// Summary
        /// </summary>
        Summary = 9,

        /// <summary>
        /// Physio
        /// </summary>
        Physio = 10,

        /// <summary>
        /// Other   
        /// </summary>
        Other = 13,

        /// <summary>
        /// ScanInfoParameterGroupId
        /// </summary>
        ScanInfoParameterGroupId = 998,

        /// <summary>
        /// InfoParameterGroupId
        /// </summary>
        InfoParameterGroupId = 999,

        /// <summary>
        /// None - other than regular tab group
        /// </summary>
        None = -1
    };

}
