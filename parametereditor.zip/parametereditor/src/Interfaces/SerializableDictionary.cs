#region Copyright Koninklijke Philips Electronics N.V. 2008
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: SerializableDictionary.cs
//
#endregion

#region System namespaces
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Xml.Serialization;
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Represents an XML Serializable verison of the Generic Dictionary
    /// </summary>
    [XmlRoot("dictionary")]
    [Serializable]
    public class SerializableDictionary<TKey, TValue> : Dictionary<TKey, TValue>, IXmlSerializable
    {
        #region Constructor
        /// <summary>
        /// Default Constructor needs to be explicitly specified for XML Serialization
        /// </summary>
        public SerializableDictionary() : base()
        {            
        }


        /// <summary>
        /// Required for Remoting Serialization of the SerializableDictionary instance
        /// </summary>
        private SerializableDictionary(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
        #endregion

        #region IXmlSerializable Members
        /// <summary>
        /// Returns the expected XML Schema for given serializations
        /// </summary>
        /// <returns>
        /// <b>null</b> since we don`t impose any Schema Validation restrictions
        /// </returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Implements the logic for reading and deserializing the XmlReader contents 
        /// into a SerializableDictionary instance
        /// </summary>
        /// <param name="reader">
        /// XmlReader instance that refers to the actual file contents to read from
        /// </param>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            XmlSerializer keySerializer = new XmlSerializer(typeof(TKey));
            XmlSerializer valueSerializer = new XmlSerializer(typeof(TValue));

            bool wasEmpty = reader.IsEmptyElement;
            reader.Read();

            if (!wasEmpty)
            {
                while (reader.NodeType != System.Xml.XmlNodeType.EndElement)
                {
                    reader.ReadStartElement("item");
                    reader.ReadStartElement("key");
                    TKey key = (TKey)keySerializer.Deserialize(reader);
                    reader.ReadEndElement();
                    reader.ReadStartElement("value");
                    TValue value = (TValue)valueSerializer.Deserialize(reader);
                    reader.ReadEndElement();
                    Add(key, value);
                    reader.ReadEndElement();
                    reader.MoveToContent();
                }

                reader.ReadEndElement();
            }
        }

        /// <summary>
        /// Contains logic to serialize and write the contents 
        /// of a SerializableDictionary instance
        /// </summary>
        /// <param name="writer">
        /// XmlWriter instance that refers to the actual file contents to write to
        /// </param>
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            XmlSerializer keySerializer = new XmlSerializer(typeof(TKey));
            XmlSerializer valueSerializer = new XmlSerializer(typeof(TValue));

            foreach (TKey key in Keys)
            {
                writer.WriteStartElement("item");
                writer.WriteStartElement("key");
                keySerializer.Serialize(writer, key);
                writer.WriteEndElement();

                writer.WriteStartElement("value");
                TValue value = this[key];
                valueSerializer.Serialize(writer, value);
                writer.WriteEndElement();
                writer.WriteEndElement();
            }

        }
        #endregion       
    }
}

#region Revision History
// 18-Apr-2008  Darshan
//              Initial Version
#endregion Revision History