#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: ParameterEditorDtoSerializer.cs
//
#endregion
using System;
using System.IO;
using System.Runtime.Serialization.Formatters;
using Newtonsoft.Json;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// ParameterEditor Dto Serializer/Deserializer
    /// </summary>
   
    public static class ParameterEditorDtoSerializer
    {
        /// <summary>
        /// Deserialize ParameterEditor Dto from Json serialized content
        /// </summary>
        /// <param name="fileName">File path of Json Serialized ParameterEditor Dto</param>
        /// <returns></returns>
        public static ParameterEditorDto Deserialize(string fileName)
        {

            ParameterEditorDto newDto = new ParameterEditorDto();

            newDto = JsonConvert.DeserializeObject<ParameterEditorDto>(File.ReadAllText(fileName),
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects,
                    TypeNameHandling = TypeNameHandling.Objects
                });
            return newDto;

        }

        /// <summary>
        /// Serialize parameterEditor Dto to Json Format and dump it in file.
        /// </summary>
        /// <param name="dto"> ParameterEditorDto to be serialized</param>
        public static void Dump(ParameterEditorDto dto)
        {
            string fileName = "ParameterEditorDto" + DateTime.Now.Ticks + ".Json";

            //Json Serialization
            var content = JsonConvert.SerializeObject(dto, Formatting.Indented,
                         new JsonSerializerSettings
                         {
                             ReferenceLoopHandling = ReferenceLoopHandling.Serialize,
                             PreserveReferencesHandling = PreserveReferencesHandling.Objects,
                             TypeNameHandling = TypeNameHandling.Objects,
                             TypeNameAssemblyFormatHandling = (TypeNameAssemblyFormatHandling)FormatterAssemblyStyle.Simple
                         });
            File.WriteAllText(fileName, content);
        }
    }
}

#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
#endregion