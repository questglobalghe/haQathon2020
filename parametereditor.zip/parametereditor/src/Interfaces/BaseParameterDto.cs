#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: BaseParameterDto.cs
//

#endregion

using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Represents the base type for all parameters.
    /// </summary>
    [Serializable]
    public abstract class BaseParameterDto : DtoBase
    {
        #region Private Fields

        private string _name;
        private string _uniqueId;
        private bool _inConflict;
        private string _help;
        private bool _visible;
        private bool _editable;
        private int _visibleCount;
        private int _valueElementCount;
        private int _actualDimension;

        #endregion

        /// <summary>
        /// BaseParameterDto Constructor
        /// </summary>
        protected BaseParameterDto() { }

        #region Public properties

        /// <summary>
        /// Gets or sets the culture-sensitive name of the parameter.
        /// </summary>
        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets the unique name (or ID) of the parameter.
        /// </summary>
        public string UniqueId
        {
            get { return _uniqueId; }
            set
            {
                _uniqueId = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets the help text for this parameter.
        /// </summary>
        public string Help
        {
            get { return _help; }
            set
            {
                _help = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this parameter is in
        /// conflict with another.
        /// </summary>
        /// <remarks>
        /// <b>true</b> if it is in conflict, or <b>false</b> otherwise.
        /// </remarks>
        public bool InConflict
        {
            get { return _inConflict; }
            set
            {
                if (_inConflict != value)
                {
                    _inConflict = value;
                    RaisePropertyChanged();
                }
            }
        }


        /// <summary>
        /// Gets or sets a value indicating whether this parameter should be
        /// made visible from a UI (and is enabled).
        /// </summary>
        /// <value>
        /// <b>true</b> if should be visible, or <b>false</b> if not.
        /// </value>
        public bool Visible
        {
            get { return _visible; }
            set
            {
                _visible = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether it is allowed to change this
        /// parameter
        /// </summary>
        /// <value>
        /// <b>true</b> if changing is allowed, or <b>false</b> if not.
        /// </value>
        public bool Editable
        {
            get { return _editable; }
            set
            {
                _editable = value;
                RaisePropertyChanged();
            }
        }


        /// <summary>
        /// Get/Set the Visible Count. This is the number of values that 
        /// should be shown by the UI.
        /// </summary>
        public int VisibleCount
        {
            get { return _visibleCount; }
            set
            {
                _visibleCount = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets the length of the value array of the parameter.
        /// </summary>
        public int ValueElementCount
        {
            get { return _valueElementCount; }
            set { _valueElementCount = value; RaisePropertyChanged(); }
        }


        /// <summary>
        /// Gets the length of the value array of the parameter.
        /// </summary>
        public int ActualDimension
        {
            get { return _actualDimension; }
            set
            {
                _actualDimension = value;
                RaisePropertyChanged();
            }
        }

        #endregion
    }
}

#region Revision History

// 2017-Jul-03  Shailendra Nalwaya
//              Initial version

#endregion Revision History