﻿#region (c) Koninklijke Philips Electronics N.V. 2019
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: StackDetailsDto.cs
//
#endregion

#region namespaces
using System;
using System.Collections.ObjectModel;
#endregion

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    #region StackDetailsDto
    /// <summary>
    /// Class for showing stack details of Coil Selection
    /// </summary>
    [Serializable]
    public class StackDetailsDto : DtoBase
    {
        #region private fields
        /// <summary>
        /// private stack name declaration
        /// </summary>
        private string _stackName;

        /// <summary>
        /// private stack index declaration
        /// </summary>
        private uint _stackIndex;

        /// <summary>
        /// Coil stack details collection declaration
        /// </summary>
        private ObservableCollection<CoilDetailsDto> _coilStackDetails = new ObservableCollection<CoilDetailsDto>();
        #endregion

        #region Public Properties
        /// <summary>
        /// Stack name Property
        /// </summary>
        public string StackName
        {
            get
            {
                return _stackName;
            }
            set
            {
                _stackName = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Stack name Property
        /// </summary>
        public uint StackIndex
        {
            get
            {
                return _stackIndex;
            }
            set
            {
                _stackIndex = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Coil stack details collection
        /// </summary>
        public ObservableCollection<CoilDetailsDto> CoilStackDetailsCollection
        {
            get { return _coilStackDetails; }
            set
            {
                _coilStackDetails = value;
                RaisePropertyChanged();
            }
        }

        #endregion
    }
    #endregion
}

#region Revision History
// 2019-Jul-19  Anu Jothis
//              Initial version story point 33332
#endregion
