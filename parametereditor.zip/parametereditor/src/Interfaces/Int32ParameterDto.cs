#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: Int32ParameterDto.cs
//
#endregion

using System;
using System.Collections.ObjectModel;
using Philips.PmsMR.Platform.OSInterface;

namespace Philips.PmsMR.ParameterEditor.Interfaces
{
    /// <summary>
    /// Represents a parameter containing an array of <see cref="int"/> 
    /// values.
    /// </summary>
    [Serializable]
    public class Int32ParameterDto : BaseParameterDto
    {
        /// <summary>
        /// 
        /// </summary>
        private ObservableCollection<IntRange> _ranges;

        /// <summary>
        /// 
        /// </summary>
        private int _stepValue = 1;

        /// <summary>
        /// 
        /// </summary>
        private ObservableCollection<int> _values;


        private ObservableCollection<int> _defaultValues;

        /// <summary>
        /// Gets or sets one or more ranges for the current object.
        /// </summary>
        /// <value>
        /// One or more <see cref="IntRange"/> objects.
        /// </value>
        public ObservableCollection<IntRange> Ranges
        {
            get { return _ranges; }

            set
            {
                _ranges = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Gets or sets one or more values for the current object.
        /// </summary>
        /// <remarks>
        /// Getting returns a copy of the internal list, and setting stores
        /// a copy of the provided data.
        /// </remarks>        
        public ObservableCollection<int> Values
        {
            get
            {
                return _values;
            }
            set
            {
                _values = value;
                RaisePropertyChanged();
            }
        }


        /// <summary>
        /// Gets or sets a unit step of the parameter
        /// </summary>
        /// <value>
        /// The new step value
        /// </value>
        /// <remarks>Set this value after the ranges to make sure that if the
        /// value is less than accuracy needed it will be correctly recalculated
        /// </remarks>
        public int StepValue
        {
            get { return _stepValue; }
            set
            {
                if (_stepValue != value)
                {
                    // if trying to set 0, derive the stepValue from the range
                    // of the possible values
                    if (value == 0)
                    {
                        _stepValue = (int) Math.Pow(10, (int) Math.Log10(
                                                            Ranges[0].upper - Ranges[0].lower) - 2);
                    }
                    else
                    {
                        _stepValue = value;
                    }
                    // if still zero, make it 1
                    if (_stepValue == 0)
                    {
                        _stepValue = 1;
                    }
                }
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public ObservableCollection<int> DefaultValues
        {
            get { return _defaultValues; }
            set
            {
                _defaultValues = value ?? new ObservableCollection<int>();
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public Int32ParameterDto()
        {
            _values = new ObservableCollection<int>();
            _defaultValues = new ObservableCollection<int>();
            _ranges = new ObservableCollection<IntRange>();
        }
    }
}

#region Revision History

// 2017-Aug-04  Ankit Singh Bhakuni
//              Initial version
// 2017-Aug-10  Shailendra Nalwaya
//              Adapted to use ObservableCollection and enable JSON Serialization/Deserialization.
// 2017-Nov-07  Shailendra Nalwaya
//              Fixed the issues related to difference of JSON Serialization(Component Test) compare
//              to Binary Serialization(Messaging Framework).
//              Moved logic/initializations present in Parameter Level Dto to respective Dto converter code.
#endregion Revision History