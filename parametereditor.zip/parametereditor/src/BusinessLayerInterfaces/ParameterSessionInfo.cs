﻿#region Copyright Koninklijke Philips Electronics N.V. 2019
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// FILENAME: ParameterSessionInfo.cs
//
#endregion
using Newtonsoft.Json;
using Philips.PmsMR.Platform.OSInterface;
using Philips.PmsMR.Scanning.IMethods;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces
{
    /// <summary>
    /// Holds the ScanProtocol,ScanInfo and their MetaData info.
    /// </summary>
    public class ParameterSessionInfo
    {
        private IScanProtocol _scanProtocol;

        string tmpDir = Logical.Translate("GYRO_TEMP");

        /// <summary>
        /// Holds ScanProtocol
        /// </summary>
        public IScanProtocol ScanProtocol
        {
            get { return _scanProtocol; }
            set { _scanProtocol = value; }
        }
        private IScanProtocolMetaData _scanProtocolMetaData;
        /// <summary>
        /// Holds ScanProtocolMetaData
        /// </summary>
        public IScanProtocolMetaData ScanProtocolMetaData
        {
            get { return _scanProtocolMetaData; }
            set { _scanProtocolMetaData = value; }
        }
        private IScanProtocol _baselineProtocol;
        /// <summary>
        /// Holds BaselineScanProtocol
        /// </summary>
        public IScanProtocol BaselineProtocol
        {
            get { return _baselineProtocol; }
            set { _baselineProtocol = value; }
        }

        private IScanProtocolMetaData _baselineProtocolMetaData;
        /// <summary>
        /// Holds BaselineScanProtocolMetaData
        /// </summary>
        public IScanProtocolMetaData BaselineProtocolMetaData
        {
            get { return _baselineProtocolMetaData; }
            set { _baselineProtocolMetaData = value; }
        }
        private bool _isInConflict;
        /// <summary>
        /// Holds whether the scan is in conflict state
        /// </summary>
        public bool IsInConflict
        {
            get { return _isInConflict; }
            set { _isInConflict = value; }
        }

        private bool _isEditMode;
        /// <summary>
        /// Holds whether the scan is in edit mode
        /// </summary>
        public bool IsEditMode
        {
            get
            { return _isEditMode; }
            set
            { _isEditMode = value; }
        }
        private ParameterConflictGuidanceInfo conflictGuidanceInfo;
        /// <summary>
        /// Holds the parameter conflict guidance info.
        /// </summary>
        public ParameterConflictGuidanceInfo ConflictGuidanceInfo
        {
            get
            {
                return conflictGuidanceInfo;
            }
            set
            {
                conflictGuidanceInfo = value;
            }
        }
        private bool _isContextUpdate;
        /// <summary>
        /// Specifies whether the validation context is updated or not
        /// </summary>
        public bool IsContextUpdate
        {
            get
            { return _isContextUpdate; }
            set
            { _isContextUpdate = value; }
        }


        /// <summary>
        /// Serialize ParameterSessionInfo object to json format and dump it into file in given path
        /// </summary>
        /// <param name="suggestionKey"></param>
        public void DumpParameterSessionInfo(string suggestionKey)
        {
            string fileName = "ResolveConflict" + DateTime.Now.Ticks + ".Json";
            var content = JsonConvert.SerializeObject(this, Formatting.Indented,
                new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Serialize,
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects,
                    TypeNameHandling = TypeNameHandling.Objects,
                    TypeNameAssemblyFormatHandling = (TypeNameAssemblyFormatHandling)FormatterAssemblyStyle.Simple
                });
            content += "Selected suggestionKey: " + suggestionKey + ". ";
            File.WriteAllText(Path.Combine(tmpDir, fileName), content);
        }

        /// <summary>
        /// Serialize scan protocol and scan protocol meta data objects to json format and dump it into files.
        /// </summary>
        public void DumpScanProtocol()
        {
            string scanProtocolFileName;
            string scanProtocolMetaDataFileName;


            //Json Serialization
            if (this.IsEditMode)
            {
                scanProtocolFileName = "ScanProtocolEdit" + DateTime.Now.Ticks + ".Json";
                scanProtocolMetaDataFileName = "ScanProtocolMetaDataEdit" + DateTime.Now.Ticks + ".Json";
            }
            else
            {
                scanProtocolFileName = "ScanProtocol" + DateTime.Now.Ticks + ".Json";
                scanProtocolMetaDataFileName = "ScanProtocolMetaData" + DateTime.Now.Ticks + ".Json";
            }

            File.WriteAllText(Path.Combine(tmpDir, scanProtocolFileName), JsonConvert.SerializeObject(
                JsonConvert.DeserializeObject(
                    SerializeToJSON.SerializeKVPDocumentToJSON(this.ScanProtocol)
                ),
                Formatting.Indented));

            File.WriteAllText(Path.Combine(tmpDir, scanProtocolMetaDataFileName), JsonConvert.SerializeObject(
                JsonConvert.DeserializeObject(
                    SerializeToJSON.SerializeKVPDocumentToJSON(
                        this.ScanProtocolMetaData.ConvertToKVPDocument())
                ),
                Formatting.Indented));
        }
    }
}

#region Revision History
// 2019-Jan-14  Naresh Jadapalli
//              Initial Version - Introduced as part of migration to Stateless Validation.
// 2019-Mar-15 Indira RamaKrishnan
//              ValidationResult Model renamed to ParameterSessionInfo, Additional properties added
// 2019-Mar-25 Indira RamaKrishnan
//              IsResultOfGraphicalPlanning, IsResultOfValidationContextUpdate Properties removed
#endregion Revision History