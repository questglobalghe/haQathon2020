#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: IPlanEditor.cs
//
#endregion
using System;
using Philips.PmsMR.Scanning.IMethods;

namespace Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces
{
    /// <summary>
    /// This interface is used by Planning Component to interact or listen to the events of Parameter Editor.
    /// </summary>
    public interface IPlanEditor : IDisposable
    {
        /// <summary>
        /// Notify about error during current parameter editing
        /// </summary>
        event EventHandler ErrorOccured;

        /// <summary>
        /// Notify about conflict occured/resolved
        /// </summary>
        event Action<bool> ConflictInfoUpdated;

        /// <summary>
        /// Notify PatientEngine that ScanProtocol is updated in edit session.
        /// </summary>
        event EventHandler<IScanProtocol> ScanProtocolChanged;
        /// <summary>
        /// Based on the isEditMode bool ParameterEditor will decide to show the parameters in view/edit mode.
        /// </summary>
        /// <param name="sessionInfo">Holds all the information to be communicated to ScanModification during scan�s plan/view session</param>
        void StartSession(ParameterSessionInfo sessionInfo);
        /// <summary>
        /// Sets the modified scanProtocolMetaData corresponding to updated scanProtocol or change in Validation Context so that ParameterEditor can refresh the UI.
        /// </summary>
        /// <param name="sessionInfo">Holds all the information to be communicated to ScanModification during scan�s plan/view session</param>
        void RefreshSession(ParameterSessionInfo sessionInfo);
        /// <summary>
        /// //View or Edit session is ended.
        /// </summary>
        void EndSession();
        /// <summary>
        ///Update the ScanProtocol with modified values
        /// </summary>
        void UpdateScanProtocol();

        /// <summary>
        /// Clear session 
        /// </summary>
        void ClearSession();

        /// <summary>
        /// Reset session
        /// </summary>
        void ResetSession();


        /// <summary>
        /// SetActive - Set parameter editor activate/deactivate for modifications
        /// </summary>
        /// <param name="isActive">true/false</param>
        void SetActive(bool isActive);



    }
}

#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2019-Jan-14  Naresh Jadapalli
//              Added StartSession,RefreshSession,EndSession, ScanProtocolChanged and UpdateScanProtocol.
// 2019-Mar-15  Indira RamaKrishnan
//              ValidationResult Model changed to ParameterSessionInfo
#endregion Revision History