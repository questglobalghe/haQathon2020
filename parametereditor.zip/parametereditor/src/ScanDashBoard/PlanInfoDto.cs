﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: PlanInfoDto.cs
//
#endregion

#region System Namespaces
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// This class represents the Dto for plan controls
    /// </summary>
    [Serializable]
    public class PlanInfoDto : INotifyPropertyChanged
    {
        #region Private Variable
        /// <summary>
        /// Plan control status dto
        /// </summary>
        private PlanControlStatusDto _planControlStatusDto = new PlanControlStatusDto();
        /// <summary>
        /// Accept control status dto
        /// </summary>
        private PlanControlStatusDto _acceptControlStatusDto = new PlanControlStatusDto();
        /// <summary>
        /// Close control status dto
        /// </summary>
        private PlanControlStatusDto _closeControlStatusDto = new PlanControlStatusDto();
        #endregion

        #region Events
        /// <summary>
        /// Property changed event.
        /// </summary>
        [field: NonSerializedAttribute()]
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Public Properties
        /// <summary>
        /// Property for Plan control status
        /// </summary>
        public PlanControlStatusDto PlanControlStatusDto
        {
            get { return _planControlStatusDto; }
            set
            {
                if (!_planControlStatusDto.Equals(value))
                {
                    _planControlStatusDto = value;
                    RaisePropertyChanged("PlanControlStatusDto");
                }
            }
        }
        /// <summary>
        /// Property for Accept control status
        /// </summary>
        public PlanControlStatusDto AcceptControlStatusDto
        {
            get { return _acceptControlStatusDto; }
            set
            {
                if (!_acceptControlStatusDto.Equals(value))
                {
                    _acceptControlStatusDto = value;
                    RaisePropertyChanged("AcceptControlStatusDto");
                }
            }
        }
        /// <summary>
        /// Property for Close control status
        /// </summary>
        public PlanControlStatusDto CloseControlStatusDto
        {
            get { return _closeControlStatusDto; }
            set
            {
                if (!_closeControlStatusDto.Equals(value))
                {
                    _closeControlStatusDto = value;
                    RaisePropertyChanged("CloseControlStatusDto");
                }
            }
        }
        #endregion

        #region Protected Methods
        /// <summary>
        /// Notifies the property has changed
        /// </summary>
        /// <param name="property">Property</param>
        protected void RaisePropertyChanged(string property)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
        #endregion
    }
}