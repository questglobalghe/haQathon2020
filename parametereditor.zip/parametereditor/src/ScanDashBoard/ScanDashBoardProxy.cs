﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ScanDashBoardProxy.cs
//
#endregion

#region System Namespaces
using System;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;
#endregion

#region Philips Namespaces
using Philips.DI.Interfaces.Services.Messaging;
using Philips.PmsMR.Platform.Mip;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// This class represents the Proxy class for ScanDashBoard service communication.
    /// </summary>
    public class ScanDashBoardProxy : IScanDashBoardProxy, IDisposable
    {
        #region Private Variables
        /// <summary>
        /// Specifies whether the class is disposed or not.
        /// </summary>
        private bool _disposed;
        /// <summary>
        /// Dealer instance for zero-mq communication.
        /// </summary>
        private IDealer _scanDashBoardDealer;
        #endregion

        #region Public Events
        /// <summary>
        /// Event for notifying scan information change
        /// </summary>
        public event EventHandler<ScanInfoDto> ScanInfoDtoChanged;
        /// <summary>
        /// Event for notifying plan control status change.
        /// </summary>
        public event EventHandler<PlanInfoDto> PlanInfoDtoChanged;
        #endregion
        #region Properties

        /// <summary>
        /// Property for getting ScanInfo dto.
        /// </summary>
        public ScanInfoDto ScanInfoDto
        {
            get
            {
                var request = new GetScanInfoDtoRequest();
                var response = _scanDashBoardDealer.SendSync<
                                GetScanInfoDtoRequest,GetScanInfoDtoResponse>(request);
                return response.ScanInfoDto;
            }
        }

        /// <summary>
        /// Property for getting PlanInfo dto.
        /// </summary>
        public PlanInfoDto PlanInfoDto
        {
            get
            {
                var request = new GetPlanInfoDtoRequest();
                var response = _scanDashBoardDealer.SendSync<
                               GetPlanInfoDtoRequest, GetPlanInfoDtoResponse>(request);
                return response.PlanInfoDto;
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="container"></param>
        public ScanDashBoardProxy(IUnityContainer container)
        {
            var msgService = container.Resolve<IMessagingService>();
            _scanDashBoardDealer = msgService.
                                   Proxy("ScanDashBoardDealer").ConvertTo<IDealer>();
            _scanDashBoardDealer.SynchronizeInvoker = StaticInvoke.Instance;
            _scanDashBoardDealer.Start();
            RegisterPushMessages();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Send StartPlan Message to service
        /// </summary>
        public async Task<bool> SendStartPlanMessage()
        {
            var startPlanMessage = new StartPlanMessage();
            var response = await _scanDashBoardDealer.SendAsync<StartPlanMessage,
                                 BoolResultResponse>(startPlanMessage);
            return response.Result;
        }
        /// <summary>
        /// Send CommitPlan message to service
        /// </summary>
        public async Task<bool> SendCommitPlanMessage()
        {
            var commitPlanMessage = new CommitPlanMessage();
            var response = await _scanDashBoardDealer.SendAsync<CommitPlanMessage,
                                 BoolResultResponse>(commitPlanMessage);
            return response.Result;
        }
        /// <summary>
        /// Send CancelPlan message to service
        /// </summary>
        public async Task<bool> SendCancelPlanMessage()
        {
            var cancelPlanMessage = new CancelPlanMessage();
            var response = await _scanDashBoardDealer.SendAsync<CancelPlanMessage,
                                 BoolResultResponse>(cancelPlanMessage);
            return response.Result;
        }
        /// <summary>
        /// Send ResetToSmartPlan message to service
        /// </summary>
        public async Task<bool> SendResetToSmartPlanMessage()
        {
            var resetToSmartPlanMessage = new ResetToSmartPlanMessage();
            var response = await _scanDashBoardDealer.SendAsync<ResetToSmartPlanMessage,
                                 BoolResultResponse>(resetToSmartPlanMessage);
            return response.Result;
        }
        /// <summary>
        /// Send ShowScanInfo message to service
        /// </summary>
        public async Task<bool> SendShowScanInfoMessage()
        {
            var showScanInfoMessage = new ShowScanInfoMessage();
            var response = await _scanDashBoardDealer.SendAsync<ShowScanInfoMessage, BoolResultResponse>(showScanInfoMessage);
            return response.Result;
        }
        /// <summary>
        /// Send StackPlanningView Message to service
        /// </summary>
        public async Task<bool> SendStackPlanningViewMessage()
        {
            var showStackPlanningViewMessage = new ShowStackPlanningViewMessage();
            var response = await _scanDashBoardDealer.SendAsync<ShowStackPlanningViewMessage,
                BoolResultResponse>(showStackPlanningViewMessage);
            return response.Result;
        }
        /// <summary>
        /// Dispose Method
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region Protected Methods
        /// <summary>
        /// Dispose method, which stops the dealer.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (!_disposed)
                {
                    if (_scanDashBoardDealer != null)
                    {
                        _scanDashBoardDealer.Stop();
                        _scanDashBoardDealer.Dispose();
                        _scanDashBoardDealer = null;
                    }
                    _disposed = true;
                }
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Registers for push messages and raised a event for dto update.
        /// </summary>
        private void RegisterPushMessages()
        {
            _scanDashBoardDealer.RegisterAction<PushScanInfoDtoMessage>(
                (pushScanInfoDtoMessage) =>
                {
                    ScanInfoDtoChanged?.Invoke(null,
                                        pushScanInfoDtoMessage.ScanInfoDto);
                });

            _scanDashBoardDealer.RegisterAction<PushPlanInfoDtoMessage>(
                (pushPlanInfoDtoMessage) =>
                {
                    PlanInfoDtoChanged?.Invoke(null,
                                        pushPlanInfoDtoMessage.PlanInfoDto);
                });
        }
        #endregion
    }
}