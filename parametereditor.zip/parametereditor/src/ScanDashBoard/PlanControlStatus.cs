﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: PlanControlStatus.cs
//
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// Represents the status for planning related controls.
    /// </summary>
    public class PlanControlStatus
    {
        #region Public Properties
        /// <summary>
        /// Specifies the caption of the control.
        /// </summary>
        public string Caption { get; set; }
        /// <summary>
        /// Specifies whether control is visible or not,
        /// </summary>
        public bool Visible { get; set; }
        /// <summary>
        /// Specifies whether control is enabled or not,
        /// </summary>
        public bool Enabled { get; set; }
        /// <summary>
        /// Specifies whether control is highlighted or not,
        /// </summary>
        public bool HighLighted { get; set; }
        /// <summary>
        /// Specifies cancel button tooltip text.
        /// </summary>
        public string TooltipText { get; set; }
        #endregion
    }
}