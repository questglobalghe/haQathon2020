﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: IScanDashBoardService.cs
//
#endregion

#region System Namespaces
using System;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// Interface for ScanDashBoardService
    /// </summary>
    public interface IScanDashBoardService : IDisposable
    {
        #region Events
        /// <summary>
        /// Event for notifying the change in scan information
        /// </summary>
        event EventHandler ScanInfoDtoChanged;
        /// <summary>
        /// Event for notifying the change in planning control status
        /// </summary>
        event EventHandler PlanInfoDtoChanged;
        #endregion

        #region Properties
        /// <summary>
        /// Property for getting ScanInfo dto.
        /// </summary>
        ScanInfoDto ScanInfoDto { get; }
        /// <summary>
        /// Property for getting PlanInfo dto.
        /// </summary>
        PlanInfoDto PlanInfoDto { get; }
        #endregion

        #region Methods
        /// <summary>
        /// Method for notifying StartPlan requested from proxy.
        /// </summary>
        void NotifyStartPlanRequested();
        /// <summary>
        /// Method for notifying CommitPlan requested from proxy.
        /// </summary>
        void NotifyCommitPlanRequested();
        /// <summary>
        /// Method for notifying CancelPlan requested from proxy.
        /// </summary>
        void NotifyCancelPlanRequested();
        /// <summary>
        /// Method for notifying ResetToSmartPlan requested from proxy.
        /// </summary>
        void NotifyResetToSmartPlanRequested();
        /// <summary>
        /// Method for notifying ShowScanInfo requested from proxy.
        /// </summary>
        void NotifyShowScanInfoRequested();
        /// <summary>
        /// Method for notifying Show StackPlanningView requested from proxy.
        /// </summary>
        void NotifyShowStackPlanningViewRequested();
        #endregion
    }
}