﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: PlanControlStatusDto.cs
//
#endregion

#region System Namespaces
using System;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// This class represents the status of the control.
    /// </summary>
    [Serializable]
    public class PlanControlStatusDto
    {
        #region Public Properties
        /// <summary>
        /// Specifies the caption of the control.
        /// </summary>
        public string Caption { get; set; }
        /// <summary>
        /// Specifies control is visible or not.
        /// </summary>
        public bool Visible { get; set; }
        /// <summary>
        /// Specifies control is enabled or not.
        /// </summary>
        public bool Enabled { get; set; }
        /// <summary>
        /// Specifies control is highlighted or not.
        /// </summary>
        public bool HighLighted { get; set; }
        /// <summary>
        /// Specifies cancel button tooltip text.
        /// </summary>
        public string TooltipText { get; set; }
        #endregion

        #region Protected Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        protected bool Equals(PlanControlStatusDto obj)
        {
            return string.Equals(Caption, obj.Caption) &&
                                    Visible == obj.Visible &&
                                    Enabled == obj.Enabled &&
                                    HighLighted == obj.HighLighted;
        }
        #endregion
    }
}