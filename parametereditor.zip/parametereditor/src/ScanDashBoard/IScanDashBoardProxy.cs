﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: IScanDashBoardProxy.cs
//
#endregion

#region System Namespaces
using System;
using System.Threading.Tasks;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// Interface for ScanDashBoardProxy.
    /// </summary>
    public interface IScanDashBoardProxy : IDisposable
    {
        #region Public Events
        /// <summary>
        /// Event for notifying the change in scan information
        /// </summary>
        event EventHandler<ScanInfoDto> ScanInfoDtoChanged;
        /// <summary>
        /// Event for notifying the change in Plan control status.
        /// </summary>
        event EventHandler<PlanInfoDto> PlanInfoDtoChanged;
        #endregion

        #region Properties
        /// <summary>
        /// Property for getting ScanInfo dto.
        /// </summary>
        ScanInfoDto ScanInfoDto { get; }
        /// <summary>
        /// Property for getting PlanInfo dto.
        /// </summary>
        PlanInfoDto PlanInfoDto { get; }
        #endregion

        #region Methods
        /// <summary>
        /// Send the StartPlan message to service
        /// </summary>
        Task<bool> SendStartPlanMessage();
        /// <summary>
        /// Send the CommitPlan message to service
        /// </summary>
        Task<bool> SendCommitPlanMessage();
        /// <summary>
        /// Send CancelPlan message to service.
        /// </summary>
        Task<bool> SendCancelPlanMessage();
        /// <summary>
        /// Send ResetToSmartPlan message to service.
        /// </summary>
        /// <returns></returns>
        Task<bool> SendResetToSmartPlanMessage();
        /// <summary>
        /// Send ResetToSmartPlan message to service.
        /// </summary>
        /// <returns></returns>
        Task<bool> SendShowScanInfoMessage();
        /// <summary>
        /// Send the StackPlanningView message to service
        /// </summary>
        Task<bool> SendStackPlanningViewMessage();
        #endregion
    }
}