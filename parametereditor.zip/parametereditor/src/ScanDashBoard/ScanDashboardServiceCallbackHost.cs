﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ScanDashboardServiceCallbackHost.cs
//
#endregion

#region System Namespaces
using Microsoft.Practices.Unity;
#endregion

#region Philips Namespaces
using Philips.DI.Interfaces.Services.Messaging;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// ScanDashBoard Service call back host which exposes the Service request handler
    /// Required as part of IMdBroker Socket implementation for per session socket.
    /// </summary>
    public class ScanDashboardServiceCallbackHost : IBrokerCallback
    {
        #region Private Variables
        /// <summary>
        /// Unity container for dependency injection
        /// </summary>
        private readonly IUnityContainer _container;
        /// <summary>
        /// communication handler for Scan Dashboard service class
        /// </summary>
        private ScanDashBoardService _scanDashBoardService;

        /// <summary>
        /// Lock for restricting one instance for service class
        /// </summary>
        private static readonly object ServiceLock = new object();
        #endregion

        #region Constructor
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="container">unity container for injecting the dependencies</param>
        public ScanDashboardServiceCallbackHost(IUnityContainer container)
        {
            _container = container;
            _scanDashBoardService = _container.Resolve<ScanDashBoardService>();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Gets the server side message handler for Scan Dashboard service
        /// </summary>
        /// <returns>Communicating handler</returns>
        BaseBrokerCallbackService IBrokerCallback.GetService()
        {
            if (_scanDashBoardService == null)
            {
                lock (ServiceLock)
                {
                    if (_scanDashBoardService == null)
                    {
                        _scanDashBoardService = _container.Resolve<ScanDashBoardService>();
                    }
                }
            }
            return _scanDashBoardService;
        }
        #endregion
    }
}
