﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ScanDashBoardService.cs
//
#endregion

#region System Namespaces
using System;
using Microsoft.Practices.Unity;
#endregion

#region Philips Namepaces
using Philips.DI.Interfaces.Services.Messaging;
using Philips.DI.Interfaces.Services.Messaging.Model;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// This class represents the Service class for ScanDashBoard service communication.
    /// </summary>
    public class ScanDashBoardService : BaseBrokerCallbackService
    {
        #region Private Variables
        /// <summary>
        /// Instance for ScanDashBoard based on IScanDashBoardService interface
        /// </summary>
        private readonly IScanDashBoardService _scanDashBoardService;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="container"></param>
        public ScanDashBoardService(IUnityContainer container)
        {
            _scanDashBoardService = container.Resolve<IScanDashBoardService>();
            _scanDashBoardService.ScanInfoDtoChanged += OnScanInfoDtoChanged;
            _scanDashBoardService.PlanInfoDtoChanged += OnPlanInfoDtoChanged;
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Initialize the message endpoints
        /// </summary>
        /// <param name="worker"></param>
        public override void InitializeWorker(IWorker worker)
        {
            worker.RegisterHandler<StartPlanMessage,
                                   BoolResultResponse>(OnStartPlanMessage);
            worker.RegisterHandler<CommitPlanMessage,
                                   BoolResultResponse>(OnCommitPlanMessage);
            worker.RegisterHandler<CancelPlanMessage,
                                   BoolResultResponse>(OnCancelPlanMessage);
            worker.RegisterHandler<ResetToSmartPlanMessage,
                                   BoolResultResponse>(OnResetToSmartPlanMessage);
            worker.RegisterHandler<GetPlanInfoDtoRequest,
                                   GetPlanInfoDtoResponse>(OnGetPlanInfoDto);
            worker.RegisterHandler<GetScanInfoDtoRequest,
                                   GetScanInfoDtoResponse>(OnGetScanInfoDto);
            worker.RegisterHandler<ShowScanInfoMessage,
                                   BoolResultResponse>(OnShowScanInfoMessage);
            worker.RegisterHandler<ShowStackPlanningViewMessage,
                                   BoolResultResponse>(OnShowStackPlanningViewMessage);
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Update StartPlan to ScanDashBoard back-end class
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private BoolResultResponse OnStartPlanMessage(StartPlanMessage message)
        {
            var responseObj = new BoolResultResponse();
            try
            {
                _scanDashBoardService.NotifyStartPlanRequested();
                responseObj.Result = true;
            }
            catch (InvalidOperationException ex)
            {
                HandleException(responseObj, ex);
                responseObj.Result = false;
            }
            return responseObj;
        }

        /// <summary>
        /// Update CommitPlan to ScanDashBoard back-end class
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private BoolResultResponse OnCommitPlanMessage(CommitPlanMessage message)
        {
            var responseObj = new BoolResultResponse();
            try
            {
                _scanDashBoardService.NotifyCommitPlanRequested();
                responseObj.Result = true;
            }
            catch (InvalidOperationException ex)
            {
                HandleException(responseObj, ex);
                responseObj.Result = false;
            }
            return responseObj;
        }

        /// <summary>
        /// Update CancelPlan to ScanDashBoard back-end class
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private BoolResultResponse OnCancelPlanMessage(CancelPlanMessage message)
        {
            var responseObj = new BoolResultResponse();
            try
            {
                _scanDashBoardService.NotifyCancelPlanRequested();
                responseObj.Result = true;
            }
            catch (InvalidOperationException ex)
            {
                HandleException(responseObj, ex);
                responseObj.Result = false;
            }
            return responseObj;
        }

        /// <summary>
        /// Update ResetToSmartPlan to ScanDashBoard back-end class
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private BoolResultResponse OnResetToSmartPlanMessage(
                                   ResetToSmartPlanMessage message)
        {
            var responseObj = new BoolResultResponse();
            try
            {
                _scanDashBoardService.NotifyResetToSmartPlanRequested();
                responseObj.Result = true;
            }
            catch (InvalidOperationException ex)
            {
                HandleException(responseObj, ex);
                responseObj.Result = false;
            }
            return responseObj;
        }

        /// <summary>
        /// Update ShowScanInfo to ScanDashBoard back-end class
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private BoolResultResponse OnShowScanInfoMessage(
                                   ShowScanInfoMessage message)
        {
            var responseObj = new BoolResultResponse();
            try
            {
                _scanDashBoardService.NotifyShowScanInfoRequested();
                responseObj.Result = true;
            }
            catch (InvalidOperationException ex)
            {
                HandleException(responseObj, ex);
                responseObj.Result = false;
            }
            return responseObj;
        }
        /// <summary>
        /// Update StackPlanningViewMessage to ScanDashBoard back-end class
        /// </summary>
        private BoolResultResponse OnShowStackPlanningViewMessage(ShowStackPlanningViewMessage message)
        {
            var responseObj = new BoolResultResponse();
            try
            {
                _scanDashBoardService.NotifyShowStackPlanningViewRequested();
                responseObj.Result = true;
            }
            catch (InvalidOperationException ex)
            {
                HandleException(responseObj, ex);
                responseObj.Result = false;
            }
            return responseObj;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnScanInfoDtoChanged(object sender, EventArgs args)
        {
            var pushDtoMessage = new PushScanInfoDtoMessage
            { ScanInfoDto = _scanDashBoardService.ScanInfoDto };
            Send(pushDtoMessage);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnPlanInfoDtoChanged(object sender, EventArgs args)
        {
            var pushDtoMessage = new PushPlanInfoDtoMessage
            { PlanInfoDto = _scanDashBoardService.PlanInfoDto };
            Send(pushDtoMessage);
        }
        private GetPlanInfoDtoResponse OnGetPlanInfoDto(GetPlanInfoDtoRequest request)
        {
            var responseObj = new GetPlanInfoDtoResponse
            {
                PlanInfoDto = _scanDashBoardService.PlanInfoDto
            };
            return responseObj;
        }

        private GetScanInfoDtoResponse OnGetScanInfoDto(GetScanInfoDtoRequest request)
        {
            var responseObj = new GetScanInfoDtoResponse
            {
                ScanInfoDto = _scanDashBoardService.ScanInfoDto
            };
            return responseObj;
        }

        /// <summary>
        /// Handles any exception.
        /// </summary>
        /// <param name="responseObj"></param>
        /// <param name="ex"></param>
        private void HandleException(Message responseObj, Exception ex)
        {
            responseObj.IsError = true;
            var error = new ErrorMessage
            {
                Message = ex.Message,
                InnerException = ex.InnerException,
                StackTrace = ex.StackTrace
            };
            responseObj.Error = error;
        }
        #endregion
    }
}