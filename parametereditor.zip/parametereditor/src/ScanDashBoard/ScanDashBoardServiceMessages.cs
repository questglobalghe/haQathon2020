﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ScanDashBoardServiceMessages.cs
//
#endregion

#region System Namespaces
using System;
#endregion

#region Philips Namespaces
using Philips.DI.Interfaces.Services.Messaging.Model;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    //TICS -7@107: Ignore tics warning -"Limit the contents of a source code file to one type" 
    #region ScanDashBoardServiceMessages
    /// This class is for Ignore tics warning: "Name the source file to the main class"
    /// <summary>
    /// ScanDashBoardServiceMessages class
    /// </summary>
    internal class ScanDashBoardServiceMessages 
    {
    }
    #endregion ScanDashBoardServiceMessages

    #region StartPlanMessage
    /// <summary>
    /// Message for sending StartPlan information
    /// </summary>
    [Serializable]
    public class StartPlanMessage : Message
    {
    }
    #endregion

    #region StackPlanningView dialog
    /// <summary>
    /// Message for showing StackPlanningView dialog
    /// </summary>
    [Serializable]
    public class ShowStackPlanningViewMessage : Message
    {
    }
    #endregion

    #region CommitPlanMessage
    /// <summary>
    /// Message for sending CommitPlan information
    /// </summary>
    [Serializable]
    public class CommitPlanMessage : Message
    {
    }
    #endregion

    #region CancelPlanMessage
    /// <summary>
    /// Message for sending CancelPlan information
    /// </summary>
    [Serializable]
    public class CancelPlanMessage : Message
    {
    }
    #endregion

    #region ResetToSmartPlanMessage
    /// <summary>
    /// Message for sending ResetToSmartPlan information
    /// </summary>
    [Serializable]
    public class ResetToSmartPlanMessage : Message
    {
    }
    #endregion

    #region ShowScanInfoMessage
    /// <summary>
    /// Message for sending ShowScanInfo information
    /// </summary>
    [Serializable]
    public class ShowScanInfoMessage : Message
    {
    }
    #endregion

    #region BoolResultResponse
    /// <summary>
    /// Response providing whether the operation was successful or not
    /// </summary>
    [Serializable]
    public class BoolResultResponse : Message
    {
        /// <summary>
        /// Indicating the result of the operation
        /// </summary>
        public bool Result;
    }
    #endregion

    #region PushScanInfoDtoMessage
    /// <summary>
    /// Message for sending ScanInfo dto update
    /// </summary>
    [Serializable]
    public class PushScanInfoDtoMessage : Message
    {
        /// <summary>
        /// ScanInfo Dto
        /// </summary>
        public ScanInfoDto ScanInfoDto;
    }
    #endregion

    #region PushPlanInfoDtoMessage
    /// <summary>
    /// Message for PlanInfo dto update
    /// </summary>
    [Serializable]
    public class PushPlanInfoDtoMessage : Message
    {
        /// <summary>
        /// PlanInfo Dto
        /// </summary>
        public PlanInfoDto PlanInfoDto;
    }
    #endregion

    #region GetPlanInfoDtoRequest
    /// <summary>
    /// Request for fetching the command state dto
    /// </summary>
    [Serializable]
    public class GetPlanInfoDtoRequest : Message
    {
    }
    #endregion

    #region GetScanInfoDtoRequest
    /// <summary>
    /// Request for fetching the command state dto
    /// </summary>
    [Serializable]
    public class GetScanInfoDtoRequest : Message
    {
    }
    #endregion

    #region GetPlanInfoDtoResponse
    /// <summary>
    /// Response providing with the command state dto
    /// </summary>
    [Serializable]
    internal class GetPlanInfoDtoResponse : Message
    {
        /// <summary>
        /// specify the PlanInfoDto
        /// </summary>
        public PlanInfoDto PlanInfoDto;
    }
    #endregion

    #region GetScanInfoDtoResponse
    /// <summary>
    /// Response providing with the command state dto
    /// </summary>
    [Serializable]
    internal class GetScanInfoDtoResponse : Message
    {
        /// <summary>
        /// specify the ScanInfoDto
        /// </summary>
        public ScanInfoDto ScanInfoDto;
    }
    #endregion
    //TICS +7@107:
}