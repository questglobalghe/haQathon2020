﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ScanDashBoard.cs
//
#endregion

#region System Namespaces
using System;
using Microsoft.Practices.Unity;
#endregion

#region Philips Namespaces
using Philips.DI.Interfaces.Services.Messaging;
using Philips.PmsMR.Platform.Mip;
using Philips.PmsMR.Platform.Logging;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// This class is for implementing the back-end logic for ScanDashBoard
    /// </summary>
    public class ScanDashBoard : IScanDashBoard, IScanDashBoardService, IDisposable
    {
        #region Private Variables
        /// <summary>
        /// Instance for unity container.
        /// </summary>
        private readonly IUnityContainer _container;

        /// <summary>
        /// <see cref="SystemMessage"/> object for logging messages.
        /// </summary>
        private readonly SystemMessage _log =
            new SystemMessage("PMED", "ScanDashBoard");

        /// <summary>
        /// Broker instance for zero-mq communication
        /// </summary>
        private IBroker _scanDashboardBroker;
        /// <summary>
        /// Specifies the class is disposed or not.
        /// </summary>
        private bool _disposed;
        #endregion

        #region Public Properties
        /// <summary>
        /// Dto for scan information
        /// </summary>
        public ScanInfoDto ScanInfoDto { get; }
        /// <summary>
        /// Dto for plan control status.
        /// </summary>
        public PlanInfoDto PlanInfoDto { get; }
        #endregion

        #region Events
        /// <summary>
        /// Event for notifying StartPlan requested
        /// </summary>
        public event EventHandler StartPlanRequested;
        /// <summary>
        /// Event for notifying CommitPlan requested
        /// </summary>
        public event EventHandler CommitPlanRequested;
        /// <summary>
        /// Event for notifying CancelPlan requested
        /// </summary>
        public event EventHandler CancelPlanRequested;
        /// <summary>
        /// Event for resetting the geo to planned by smart.
        /// </summary>
        public event EventHandler ResetToSmartPlanRequested;
        /// <summary>
        /// Event for notifying scan information change.
        /// </summary>
        public event EventHandler ScanInfoDtoChanged;
        /// <summary>
        /// Event for notifying plan control status change.
        /// </summary>
        public event EventHandler PlanInfoDtoChanged;
        /// <summary>
        /// Event for notifying show scan info status change.
        /// </summary>
        public event EventHandler ShowScanInfoRequested;
        /// <summary>
        /// Event for notifying show StackPlanningView.
        /// </summary>
        public event EventHandler ShowStackPlanningViewRequested;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor.
        /// </summary>
        public ScanDashBoard(IUnityContainer container)
        {
            _container = container;
            var scanDashBoardService = this as IScanDashBoardService;
            ScanInfoDto = new ScanInfoDto();
            PlanInfoDto = new PlanInfoDto();
            container.RegisterInstance(scanDashBoardService,
                                       new ExternallyControlledLifetimeManager());
            InitializeService();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Update the 'Plan' control status
        /// </summary>
        /// <param name="planControlStatus"></param>
        public void UpdateStartPlan(PlanControlStatus planControlStatus)
        {
            var planControlStatusDto = GetPlanControlStatusDto(planControlStatus);
            if (!PlanInfoDto.PlanControlStatusDto.Equals(planControlStatusDto))
            {
                PlanInfoDto.PlanControlStatusDto = planControlStatusDto;
                _log.Info($"Raise PlanInfoDtoChanged event with Plan state {planControlStatusDto.Enabled}");
                PlanInfoDtoChanged?.Invoke(null, EventArgs.Empty);
            }
        }
        /// <summary>
        /// Update 'Accept' and 'Close' control's status
        /// </summary>
        /// <param name="acceptControlStatus"></param>
        /// <param name="closeControlStatus"></param>
        public void UpdatePlanningControls(PlanControlStatus acceptControlStatus,
                                           PlanControlStatus closeControlStatus)
        {
            var acceptControlStatusDto = GetPlanControlStatusDto(acceptControlStatus);
            var closeControlStatusDto = GetPlanControlStatusDto(closeControlStatus);
            if (!PlanInfoDto.AcceptControlStatusDto.Equals(acceptControlStatusDto) ||
                !PlanInfoDto.CloseControlStatusDto.Equals(closeControlStatusDto))
            {
                PlanInfoDto.AcceptControlStatusDto = acceptControlStatusDto;
                PlanInfoDto.CloseControlStatusDto = closeControlStatusDto;
                _log.Info($"Raise PlanInfoDtoChanged event with Accept state :{acceptControlStatusDto.Enabled} and Close state :{closeControlStatusDto.Enabled}");
                PlanInfoDtoChanged?.Invoke(null, EventArgs.Empty);
            }
        }

        /// <summary>
        /// Update scan information
        /// </summary>
        /// <param name="scanName"></param>
        /// <param name="geoName"></param>
        public void UpdateScanInfo(string scanName, string geoName)
        {
            if (!string.Equals(ScanInfoDto.Name, scanName) ||
                !string.Equals(ScanInfoDto.GeoName, geoName))
            {
                ScanInfoDto.Name = scanName;
                ScanInfoDto.GeoName = geoName;
                ScanInfoDtoChanged?.Invoke(null, EventArgs.Empty);
            }
        }
        /// <summary>
        /// Update the key for smart geometry icon
        /// </summary>
        /// <param name="iconKey"></param>
        public void UpdateSmartGeometryIcon(string iconKey)
        {
            if (!string.Equals(ScanInfoDto.SmartGeoIcon, iconKey))
            {
                ScanInfoDto.SmartGeoIcon = iconKey;
                ScanInfoDtoChanged?.Invoke(null, EventArgs.Empty);
            }
        }
        /// <summary>
        /// Update the stack definition for a geometry
        /// </summary>
        /// <param name="definition"></param>
        public void UpdateStackDefinition(string definition)
        {
            if (!string.Equals(ScanInfoDto.StackDefinition, definition))
            {
                ScanInfoDto.StackDefinition = definition;
                ScanInfoDtoChanged?.Invoke(null, EventArgs.Empty);
            }
        }
        /// <summary>
        /// Update the status for ResetToSmartPlan
        /// </summary>
        /// <param name="resetToSmartPlan"></param>
        /// <returns></returns>
        public void UpdateResetSmartGeoEnable(bool resetToSmartPlan)
        {
            if (ScanInfoDto.ResetToSmartPlan != resetToSmartPlan)
            {
                ScanInfoDto.ResetToSmartPlan = resetToSmartPlan;
                ScanInfoDtoChanged?.Invoke(null, EventArgs.Empty);
            }
        }
        /// <summary>
        /// Notifying the StartPlan requested to component
        /// </summary>
        public void NotifyStartPlanRequested()
        {
            StartPlanRequested?.Invoke(null, EventArgs.Empty);
        }
        /// <summary>
        /// Notifying the CommitPlan requested to component
        /// </summary>
        public void NotifyCommitPlanRequested()
        {
            CommitPlanRequested?.Invoke(null, EventArgs.Empty);
        }
        /// <summary>
        /// Notifying the CancelPlan requested to component
        /// </summary>
        public void NotifyCancelPlanRequested()
        {
            CancelPlanRequested?.Invoke(null, EventArgs.Empty);
        }
        /// <summary>
        /// Notifying for resetting the geo to planned by smart.
        /// </summary>
        public void NotifyResetToSmartPlanRequested()
        {
            ResetToSmartPlanRequested?.Invoke(null, EventArgs.Empty);
        }
        /// <summary>
        /// Notifying for resetting the geo to planned by smart.
        /// </summary>
        public void NotifyShowScanInfoRequested()
        {
            ShowScanInfoRequested?.Invoke(null, EventArgs.Empty);
        }
        /// <summary>
        /// Notifying for showing StackPlanningView.
        /// </summary>
        public void NotifyShowStackPlanningViewRequested()
        {
            ShowStackPlanningViewRequested?.Invoke(null, EventArgs.Empty);
        }
        /// <summary>
        /// Dispose Method
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region Protected Method
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (_scanDashboardBroker != null)
                    {
                        _scanDashboardBroker.Stop();
                        _scanDashboardBroker.Dispose();
                        _scanDashboardBroker = null;
                    }
                }
                _disposed = true;
            }
        }
        #endregion

        #region Private Methods
        private void InitializeService()
        {
            var scanDashboardCallBack = _container.Resolve<ScanDashboardServiceCallbackHost>();
            var messagingService = _container.Resolve<IMessagingService>();
            _scanDashboardBroker = messagingService.Proxy("ScanDashBoardBroker")
                                                   .ConvertTo<IBroker>();
            _scanDashboardBroker.BrokerCallback = scanDashboardCallBack;
            _scanDashboardBroker.Start();
        }

        private PlanControlStatusDto GetPlanControlStatusDto(
                                     PlanControlStatus planControlStatus)
        {
            var planControlStatusDto = new PlanControlStatusDto();
            planControlStatusDto.Caption = planControlStatus.Caption;
            planControlStatusDto.Enabled = planControlStatus.Enabled;
            planControlStatusDto.Visible = planControlStatus.Visible;
            planControlStatusDto.HighLighted = planControlStatus.HighLighted;
            planControlStatusDto.TooltipText = planControlStatus.TooltipText;
            return planControlStatusDto;
        }
        #endregion
    }
}