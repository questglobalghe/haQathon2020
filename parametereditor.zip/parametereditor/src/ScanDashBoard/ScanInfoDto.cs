﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ScanInfoDto.cs
//
#endregion

#region System Namespaces
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// Represents the Scan Information.
    /// </summary>
    [Serializable]
    public class ScanInfoDto : INotifyPropertyChanged
    {
        #region Private Variable
        /// <summary>
        /// Specifies the scan name
        /// </summary>
        private string _name;
        /// <summary>
        /// Specifies the geometry name
        /// </summary>
        private string _geoName;
        /// <summary>
        /// Specifies the smart icon key.
        /// </summary>
        private string _smartGeoIcon;
        /// <summary>
        /// Specifies the stack definition of the geometry.
        /// </summary>
        private string _stackDefinition;
        /// <summary>
        /// Specifies the ResetToSmartPlan is enable or not.
        /// </summary>
        private bool _resetToSmartPlan;
        #endregion

        #region Events
        /// <summary>
        /// Property changed event.
        /// </summary>
        [field: NonSerializedAttribute()]
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Public Properties
        /// <summary>
        /// Property for Scan Name
        /// </summary>
        public string Name
        {
            get { return _name; }
            set
            {
                if (value != _name)
                {
                    _name = value;
                    RaisePropertyChanged("Name");
                }
            }
        }
        /// <summary>
        /// Property for Geometry name
        /// </summary>
        public string GeoName
        {
            get{ return _geoName; }
            set
            {
                if (value != _geoName)
                {
                    _geoName = value;
                    RaisePropertyChanged("GeoName");
                }
            }
        }
        /// <summary>
        /// Property for smart icon key.
        /// </summary>
        public string SmartGeoIcon
        {
            get { return _smartGeoIcon; }
            set
            {
                if (value != _smartGeoIcon)
                {
                    _smartGeoIcon = value;
                    RaisePropertyChanged("SmartGeoIcon");
                }
            }
        }
        /// <summary>
        /// Property for stack definition for a geometry.
        /// </summary>
        public string StackDefinition
        {
            get { return _stackDefinition; }
            set
            {
                if (value != _stackDefinition)
                {
                    _stackDefinition = value;
                    RaisePropertyChanged("StackDefinition");
                }
            }
        }
        /// <summary>
        /// Property for ResetToSmartPlan enable or not.
        /// </summary>
        public bool ResetToSmartPlan
        {
            get { return _resetToSmartPlan; }
            set
            {
                if (value != _resetToSmartPlan)
                {
                    _resetToSmartPlan = value;
                    RaisePropertyChanged("ResetToSmartPlan");
                }
            }
        }
        #endregion

        #region Protected Methods
        /// <summary>
        /// Notifies the property has changed
        /// </summary>
        /// <param name="property">Property</param>
        protected void RaisePropertyChanged(string property)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
        #endregion
    }
}