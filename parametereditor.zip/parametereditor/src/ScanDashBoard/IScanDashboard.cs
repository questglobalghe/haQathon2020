﻿#region Copyright Koninklijke Philips N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: IScanDashBoard.cs
//
#endregion

#region System Namespaces
using System;
#endregion

namespace Philips.PmsMR.UW.ScanApp.ScanDashboard
{
    /// <summary>
    /// Represents the external interface for ScanDashBoard.
    /// </summary>
    public interface IScanDashBoard : IDisposable
    {
        #region Public Events
        /// <summary>
        /// Event for notifying StartPlan requested.
        /// </summary>
        event EventHandler StartPlanRequested;
        /// <summary>
        /// Event for notifying CommitPlan requested.
        /// </summary>
        event EventHandler CommitPlanRequested;
        /// <summary>
        /// Event for notifying CancelPlan requested.
        /// </summary>
        event EventHandler CancelPlanRequested;
        /// <summary>
        /// Event for resetting the geo to planned by smart.
        /// </summary>
        event EventHandler ResetToSmartPlanRequested;
        /// <summary>
        /// Event for Show scan Info.
        /// </summary>
        event EventHandler ShowScanInfoRequested;
        /// <summary>
        /// Event for showing stackplanningview
        /// </summary>
        event EventHandler ShowStackPlanningViewRequested;
        #endregion

        #region Methods
        /// <summary>
        /// Update the status of Plan control
        /// </summary>
        void UpdateStartPlan(PlanControlStatus planControlStatus);
        /// <summary>
        /// Update the status of Accept and Close control.
        /// </summary>
        /// <param name="acceptControlStatus"></param>
        /// <param name="closeControlStatus"></param>
        void UpdatePlanningControls(PlanControlStatus acceptControlStatus,
                                    PlanControlStatus closeControlStatus);
        /// <summary>
        /// Update the information about the scan.
        /// </summary>
        /// <param name="scanName"></param>
        /// <param name="geoName"></param>
        void UpdateScanInfo(string scanName, string geoName);
        /// <summary>
        /// Update icon key for smart geometry.
        /// </summary>
        /// <param name="iconKey"></param>
        void UpdateSmartGeometryIcon(string iconKey);
        /// <summary>
        /// Update stack definition for the geometry.
        /// </summary>
        /// <param name="definition"></param>
        void UpdateStackDefinition(string definition);
        /// <summary>
        /// Update the status for ResetSmartGeo.
        /// </summary>
        /// <param name="resetSmartGeoEnable"></param>
        /// <returns></returns>
        void UpdateResetSmartGeoEnable(bool resetSmartGeoEnable);
        #endregion
    }
}