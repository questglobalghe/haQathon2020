﻿#region Copyright Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: SetParameterRequest.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2017

using System;
using Philips.DI.Interfaces.Services.Messaging.Model;
using Philips.PmsMR.ParameterEditor.Interfaces;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{

    /// <summary>
    ///     Response providing with string data
    /// </summary>
    [Serializable]
    public class SetActiveGroupResponse : Message
    {
    }
}

#region Revision History

// 2019-Jul-09  Ravikumar B
//              Initial version

#endregion Revision History
