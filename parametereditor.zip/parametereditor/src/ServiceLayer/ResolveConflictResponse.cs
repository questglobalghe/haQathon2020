﻿#region Copyright Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ResolveConflictResponse.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2019

using System;
using Philips.DI.Interfaces.Services.Messaging.Model;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{
    /// <summary>
    ///     Response on resolve conflict
    /// </summary>
    [Serializable]
    public class ResolveConflictResponse : Message
    {
    }
}

#region Revision History

// 2019-Jul-16  Anu Jothis
//              Initial version
#endregion Revision History
