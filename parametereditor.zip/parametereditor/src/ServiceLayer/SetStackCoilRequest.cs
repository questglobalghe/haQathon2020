﻿#region Copyright Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: SetStackCoilRequest.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2019

#region namespaces
using System;
using Philips.DI.Interfaces.Services.Messaging.Model;
using Philips.PmsMR.ParameterEditor.Interfaces;
#endregion

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{
    #region class

    /// <summary>
    ///     Request to set coil selection 
    /// </summary>
    [Serializable]
    public class SetStackCoilRequest : Message
    {
       /// <summary>
        /// Stack index
        /// </summary>
        public uint StackIndex { get; set; }

        /// <summary>
        /// Stack details corresponding to the selected stack index
        /// </summary>
        public StackDetailsDto StackDetails { get; set; }
    }
    #endregion
}

#region Revision History
// 2019-Jul-31  Anu Jothis
//              Initial version
//              Story ID - 54058. Coil Selection backend implementation

#endregion Revision History
