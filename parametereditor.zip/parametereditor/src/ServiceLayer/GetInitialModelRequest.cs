﻿#region Copyright Koninklijke Philips Electronics N.V. 2020

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: GetInitialModelRequest.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2020

using System;
using Philips.DI.Interfaces.Services.Messaging.Model;
using Philips.PmsMR.ParameterEditor.Interfaces;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{

    /// <summary>
    ///  Request for GetInitialModelRequest
    /// </summary>
    [Serializable]
    public class GetInitialModelRequest : Message
    {
    }
}

#region Revision History

// 2020-May-13  Duraichi Veerakumar
//              Initial version

#endregion Revision History
