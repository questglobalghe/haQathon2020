#region Copyright Koninklijke Philips Electronics N.V. 2020

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: SetAdvanceParameterRequest.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2020

using System;
using Philips.DI.Interfaces.Services.Messaging.Model;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{

    /// <summary>
    ///     Request for setting advance parameter state to parameter editor back end
    /// </summary>
    [Serializable]
    public class SetAdvanceParameterRequest : Message
    {
        /// <summary>
        /// AdvanceParameterOpenState
        /// </summary>
        public bool AdvanceParameterOpenState;
    }
}

#region Revision History

// 2020-Sept-21  Ramanjaneyulu SBV
//              Initial version

#endregion Revision History
