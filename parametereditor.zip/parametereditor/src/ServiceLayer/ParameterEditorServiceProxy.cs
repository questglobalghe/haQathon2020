#region Copyright Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ParameterEditorServiceProxy.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2019

using Microsoft.Practices.Unity;
using Philips.DI.Interfaces.Services.Messaging;
using Philips.DI.Interfaces.Services.Messaging.Model;
using Philips.PmsMR.CommonProxy_cs;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Platform.Logging;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{
    /// <summary>
    /// The proxy class to Parameter Editor Service. This class implements IParameterEditor
    /// and exposes the defined functionality to whoever used it.
    /// </summary>
    public class ParameterEditorServiceProxy : BaseProxy, IParameterEditor, IDisposable
    {
        #region Private Fields

        /// <summary>
        ///     logging accessors
        /// </summary>
        private static readonly SystemMessage Log =
            new SystemMessage("ParameterEditor", "ParameterEditorServiceProxy");

        /// <summary>
        ///     Tracing accessor
        /// </summary>
        private static readonly TraceMessage Trace =
            new TraceMessage("ParameterEditor", "ParameterEditorServiceProxy");

        /// <summary>
        ///     Holds the information if the object is disposed or not.
        /// </summary>
        private bool _disposed;

        /// <summary>
        ///     PatientOrchestrator service  dealer socket
        /// </summary>
        private IDealer _parameterEditorDealer;

        /// <summary>
        ///     List of events handled by PatientScheduler proxy.
        /// </summary>
        private EventHandlerList _events = new EventHandlerList();

        /// <summary>
        /// Event key for Parameter Editor Updated.
        /// </summary>
        private static readonly object ParameterEditorUpdatedEventKey = new object();

        
        /// <summary>
        /// Event key for Parameter Editor Enabled.
        /// </summary>
        private static readonly object ParameterEditorEnabledEventKey = new object();


        /// <summary>
        ///     Holds the information of the object status disposing while disposing taking place.
        /// </summary>
        private bool _disposing;

        #endregion

        #region Constructor and Dispose

        /// <summary>
        /// Constructor
        /// </summary>
        public ParameterEditorServiceProxy(IUnityContainer container)
        {

            _parameterEditorDealer = container.Resolve<IMessagingService>().Proxy("ParameterEditorDealer").ConvertTo<IDealer>();

            //Registering for push messages
            RegisterPushMessages();
        }


        /// <summary>
        ///     Dispose method
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        ///     Dispose method
        /// </summary>
        /// <param name="disposing">
        ///     Indicates if the dispose is done internally or by garbage collector
        /// </param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                _disposing = true;
                if (disposing)
                {
                    if (_events != null)
                    {
                        _events.Dispose();
                        _events = null;
                    }

                    if (_parameterEditorDealer != null)
                    {
                        _parameterEditorDealer.Stop();
                        _parameterEditorDealer.Dispose();
                        _parameterEditorDealer = null;
                    }
                    _disposed = true;
                }
                _disposing = false;
            }
        }

        #endregion Constructor and Dispose

        #region  IParameterEditor Implementations

        /// <summary>
        /// Method to  update the parameter change to PDF
        /// </summary>
        /// <param name="paramId"></param>
        /// <param name="newValues"></param>
        public async void SetParameter(string paramId, Array newValues)
        {
            Trace.Info("Entering SetParameter");
            var request = new SetParameterRequest() { ParamId = paramId, NewValues = newValues };

            var response = await GetResponse<SetParameterResponse>(request);
            Trace.Info("SetParameter response: {0}", response != null);
            Trace.Info("Exit SetParameter");
        }



        /// <summary>
        /// Method to update advance parameter state from UI 
        /// </summary>
        /// <param name="isOpenState"></param>
        public async void SetAdvanceParameterState(bool isOpenState)
        {
            Trace.Info($"Entering SetAdvanceParameterState with state: {isOpenState}");
            if (isOpenState) // When advanced parameter dialog is closed state (isOpenState value is false), then no need to send the request, in current implementation. 
            {
                var request = new SetAdvanceParameterRequest() {AdvanceParameterOpenState = isOpenState};
                var response = await GetResponse<SetAdvanceParameterResponse>(request);

                Trace.Info("SetAdvanceParameterState response: {0}", response != null);
            }
            Trace.Info("Exit SetAdvanceParameterState");
        }

        /// <summary>
        /// Method to update the current active group when user switched to new tab on UI to 
        /// populate new group
        /// </summary>
        /// <param name="groupId"></param>
        public async void SetActiveGroup(int groupId)
        {
            Trace.Info("Entering SetActiveGroup");
            var request = new SetActiveGroupRequest() { GroupId = groupId };

            var response = await GetResponse<SetActiveGroupResponse>(request);

            Trace.Info("SetActiveGroup response: {0}", response != null);
            Trace.Info("Exit SetActiveGroup");
        }

        /// <summary>
        /// Parameter Editor Updated event handler.
        /// </summary>
        public event EventHandler<ParameterEditorUpdateArgs> ParameterEditorUpdated
        {
            add { _events?.AddHandler(ParameterEditorUpdatedEventKey, value); }
            remove { _events?.RemoveHandler(ParameterEditorUpdatedEventKey, value); }
        }

        /// <summary>
        /// Parameter Editor Enabled event handler.
        /// </summary>
        public event EventHandler<bool> ParameterEditorEnabled
        {
            add { _events?.AddHandler(ParameterEditorEnabledEventKey, value); }
            remove { _events?.RemoveHandler(ParameterEditorEnabledEventKey, value); }
        }

        /// <summary>
        /// Method to Resolve conflict from parameter editor
        /// </summary>
        /// <param name="confictKey">Conflict key for conflict</param>
        /// <param name="suggestionKey">Suggestion key for suggestion selected</param>
        public async void ResolveConflict(string confictKey, string suggestionKey)
        {
            Trace.Info("Entering ResolveConflict");
            var request = new ResolveConflictRequest() { ConflictKey = confictKey, SuggestionKey = suggestionKey };

            var response =
               await GetResponse<ResolveConflictResponse>(request);
            Trace.Info("Resolve Conflict response: {0}", response != null);
            Trace.Info("Exit ResolveConflict");
        }


        /// <summary>
        /// Method to set smart select
        /// </summary>
        /// <param name="isSmartSelect">Boolean isSmartSelect</param>
        public async void SetSmartSelect(bool isSmartSelect)
        {
            Trace.Info("Entering SetCoilSmartSelection");
            var request = new SetSmartSelectRequest() { IsSmartSelect = isSmartSelect };

            var response = await GetResponse<SetSmartSelectResponse>(request);

            Trace.Info("SetSmartSelect response: {0}", response != null);
            Trace.Info("Exit SetSmartSelect");
        }


        /// <summary>
        /// Method to set stack select
        /// </summary>
        /// <param name="isStackSelect">Boolean isStackSelect</param>
        public async void SetStackSelect(bool isStackSelect)
        {
            Trace.Info("Entering SetStackSelect");
            var request = new SetStackSelectRequest() { IsStackSelect = isStackSelect };

            var response = await GetResponse<SetStackSelectResponse>(request);
            Trace.Info("SetStackSelect response: {0}", response != null);
            Trace.Info("Exit SetStackSelect");
        }
        /// <summary>
        /// Method to set stack coils
        /// </summary>
        /// <param name="stackIndex">stack index</param>
        /// <param name="stackDetails">Stack details of selected stack index</param>
        public async void SetStackCoilSelection(uint stackIndex, StackDetailsDto stackDetails)
        {
            Trace.Info("Entering SetStackCoilSelection");
            var request = new SetStackCoilRequest() { StackIndex = stackIndex, StackDetails = stackDetails };

            var response = await GetResponse<SetStackCoilResponse>(request);
            Trace.Info("SetStackCoilSelection response: {0}", response != null);
            Trace.Info("Exit SetStackCoilSelection");
        }
        /// <summary>
        /// Method to Reset the Parameters to the last view session
        /// </summary>
        public async void ResetAll()
        {
            Trace.Info("Entering ResetAll");
            var request = new ResetParameterRequest() { };

            var response = await GetResponse<ResetParameterRespose>(request);
            Trace.Info("ResetAll response: {0}", response != null);
            Trace.Info("Exit ResetAll");
        }

        /// <summary>
        /// Method to Undo the Parameter to the previous session
        /// </summary>
        public async void UndoParameter()
        {
            Trace.Info("Entering UndoParameter");
            var request = new UndoParameterRequest() { };

            var response = await GetResponse<UndoParameterRespose>(request);
            Trace.Info("UndoParameter response: {0}", response != null);
            Trace.Info("Exit UndoParameter");
        }

        /// <summary>
        /// Method to Redo the Parameter to the next session
        /// </summary>
        public async void RedoParameter()
        {
            Trace.Info("Entering RedoParameter");
            var request = new RedoParameterRequest() { };

            var response = await GetResponse<RedoParameterRespose>(request);
            Trace.Info("RedoParameter response: {0}", response != null);
            Trace.Info("Exit RedoParameter");
        }

        /// <summary>
        /// Method to GetInitialModel to the next session
        /// </summary>
        public async void GetInitialModel()
        {
            Trace.Info("Entering GetInitialModel");
            var request = new GetInitialModelRequest() { };

            var response = await GetResponse<GetInitialModelResponse>(request);

            Trace.Info("GetInitialModel response: {0}", response != null);
            Trace.Info("Exit GetInitialModel");
        }
        #endregion IParameterEditor Implementations

        #region Private Methods

        /// <summary>
        ///     Registers for push messages and raised a event for dto model updated notification
        /// </summary>
        private void RegisterPushMessages()
        {
            // Registering for PushPatientInfo
            //Added the null check as dispatcher is being accessed after ParameterEditor is disposed
            RegisterParameterEditorUpdated();
            //Register parameter editor enabled response
            RegisterParameterEditorEnabled();
        }

        private void RegisterParameterEditorUpdated()
        {
            _parameterEditorDealer.RegisterAction<ParameterEditorUpdatedResponse>(
                pushDtoModelMessage =>
                {
                    Trace.Info("Enter ParameterEditorUpdatedResponse Handler -->");
                    if (_events != null)
                    {
                        var patientInfoDelegate =
                            (EventHandler<ParameterEditorUpdateArgs>)_events[ParameterEditorUpdatedEventKey];
                        if ((patientInfoDelegate != null)
                            && (pushDtoModelMessage != null)
                            && pushDtoModelMessage.Result != null)
                        {
                            patientInfoDelegate?.Invoke(
                                this, new ParameterEditorUpdateArgs(pushDtoModelMessage.Result.EditorDto,
                                    pushDtoModelMessage.Result.InitialMode));
                        }
                        else
                        {
                            if (pushDtoModelMessage == null)
                            {
                                Log.Info("PushDtoModelMessage is null");
                            }
                            else if (pushDtoModelMessage.Result == null)
                            {
                                Log.Info("PushDtoModelMessage.Result is null");
                            }
                            else
                            {
                                Log.Info("Delegate to handle ParameterEditorUpdatedResponse is null");
                            }
                        }
                    }
                    else
                    {
                        Log.Info("_events are set to Null");
                    }

                    Trace.Info(" <--Exit ParameterEditorUpdatedResponse Handler.");
                });
        }

        private void RegisterParameterEditorEnabled()
        {
            _parameterEditorDealer.RegisterAction<ParameterEditorEnabledResponse>(
                parameterEditorEnabledResponseMessage =>
                {
                    Trace.Info("Enter ParameterEditorEnabledResponse Handler -->");
                    if (_events != null)
                    {
                        var parameterEditorEnabledDelegate =
                            (EventHandler<bool>)_events[ParameterEditorEnabledEventKey];
                        if ((parameterEditorEnabledDelegate != null)
                            && (parameterEditorEnabledResponseMessage != null))
                        {
                            parameterEditorEnabledDelegate?.Invoke(this, parameterEditorEnabledResponseMessage.IsEnable);
                        }
                        else
                        {
                            if (parameterEditorEnabledResponseMessage == null)
                            {
                                Log.Info("ParameterEditorEnabledResponseMessage is null");
                            }
                            else
                            {
                                Log.Info("Delegate to handle ParameterEditorEnabledResponse is null");
                            }
                        }
                    }
                    else
                    {
                        Log.Info("_events are set to Null");
                    }

                    Trace.Info(" <--Exit ParameterEditorEnabledResponse Handler.");
                });
        }

        /// <summary>
        ///     Gets the response for given request.
        /// </summary>
        /// <typeparam name="T">desired type in which response should be</typeparam>
        /// <param name="request">The request.</param>
        /// <param name="caller">The request.</param>
        /// <returns></returns>
        public async Task<T> GetResponse<T>(Message request, [CallerMemberName] string caller = "")
            where T : Message
        {
            string errmsg = $"Error during {caller} on ParameterEditor";
            if (IsDisposingOrDisposed())
            {
                return default(T);
            }

            Trace?.Info("Begin of GetResponse");
            T operationResult = null;
            try
            {
                operationResult = await ExecuteGetRespose<T>(request, errmsg);
            }
            catch (NullReferenceException e)
            {
                Log?.Info($"End of GetResponse with exception {e.StackTrace}");
                operationResult = null;
            }
            catch (TaskCanceledException exception)
            {
                Log?.Info($"Exception while running the task for request {request} with exception : {exception}");
                operationResult = null;
            }
            catch (AggregateException exception)
            {
                Log?.Error($"Aggregate Exception caught while running the task for request {request} with exception : {exception}");
                foreach (var ex in exception.InnerExceptions)
                {
                    if (!(ex is TaskCanceledException))
                    {
                        throw;
                    }
                }
                operationResult = null;
            }

            Trace?.Info($"{caller}  response: {operationResult != null}");
            return await Task.FromResult<T>(operationResult);
        }

        private async Task<T> ExecuteGetRespose<T>(Message request, string errmsg) where T : Message
        {
            Task<T> operationResult;
            var result = _parameterEditorDealer.SendAsync<Message, T>(request);
            var response = await result;

            var output = IsResponsePresent(response, errmsg);
            if (output)
            {
                operationResult = result;
            }

            return response;
        }

        private bool IsDisposingOrDisposed()
        {
            return _disposing || _disposed;
        }

        #endregion

        /// <summary>
        /// Destructor
        /// </summary>
        ~ParameterEditorServiceProxy()
        {
            Dispose(false);
        }
    }
}

#region Revision History

// 2017-Aug-11  Ankit Singh Bhakuni
//              Initial version
// 2017-Aug-23  Vivek Saurav
//              Service layer on Parameter editor needs to be bootstrapped (Story-17303)
// 2017-Nov-13  Lokesh N
//              Added null check for events in RegisterPush Messages
// 2019-May-14  Anu Jothis
//              Added ResolveConflict  method to support resolving conflicts (Story-39048)
// 2019-Jul-26  Anu Jothis
//              Added method for SetCoilSelectionDto. Story Id - 54058
// 2019-Oct-25 Anu Jothis
//              Added method for SetStackSelect. SetCoilSmartSelect renamed to SetSmartSelect. Story Id - 73850
#endregion Revision History
