#region Copyright Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ParameterEditorService.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2019

using System;
using Microsoft.Practices.Unity;
using Philips.DI.Interfaces.Services.Messaging;
using Philips.DI.Interfaces.Services.Messaging.Model;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Platform.Logging;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{
    //TICS -5@113: Ignore tics warning -"Does not implement IDisposable although it has a method 'protected override void Dispose" 
    /// <summary>
    ///     ParameterEditor Service handler
    /// </summary>
    public class ParameterEditorService : BaseBrokerCallbackService
    {
        #region Private Fields

        /// <summary>
        ///     Trace accessor
        /// </summary>
        private static readonly TraceMessage Trace =
            new TraceMessage("ParameterEditor", "ParameterEditorService");

        /// <summary>
        ///     logging accessor
        /// </summary>
        private static readonly SystemMessage Log =
            new SystemMessage("ParameterEditor", "ParameterEditorService");

        /// <summary>
        /// Unity container for dependency injection
        /// </summary>
        private IUnityContainer _container;

        /// <summary>
        /// Handler for worklist
        /// </summary>
        private IParameterEditor _parameterEditorServiceHandler;

        /// <summary>
        /// To check if already disposed by another class
        /// </summary>
        private bool _disposed;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="unitycontainer"></param>.ass
        public ParameterEditorService(IUnityContainer unitycontainer)
        {
            Trace.Info("ParameterEditorService Ctor Enter");

            _container = unitycontainer;

            //Parameter Editor handler
            _parameterEditorServiceHandler = _container.Resolve<IParameterEditor>();

            _parameterEditorServiceHandler.ParameterEditorUpdated += OnParameterEditorUpdated;
            _parameterEditorServiceHandler.ParameterEditorEnabled += OnParameterEditorEnabled;

            Trace.Info("ParameterEditorService Ctor Exit");
        }




        #region IDisposable
        /// <summary>
        ///Dispose Method
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (_parameterEditorServiceHandler != null)
                    {
                        _parameterEditorServiceHandler.ParameterEditorUpdated -= OnParameterEditorUpdated;
                        _parameterEditorServiceHandler.ParameterEditorEnabled -= OnParameterEditorEnabled;
                        var parameterEditorServiceHandlerDisposable = ConvertValue<IDisposable>(_parameterEditorServiceHandler);
                        parameterEditorServiceHandlerDisposable?.Dispose();
                        _parameterEditorServiceHandler = null;
                    }
                    base.Dispose(true);
                    _container = null;
                    _disposed = true;

                }
            }
        }
        /// <summary>
        /// Initializes the worker.
        /// </summary>
        /// <param name="worker">The worker.</param>
        public override void InitializeWorker(IWorker worker)
        {
            Trace.Info("Initialize Enter");
            worker.RegisterHandler<SetParameterRequest, SetParameterResponse>(SetParameter);
            worker.RegisterHandler<SetActiveGroupRequest, SetActiveGroupResponse>(SetActiveGroup);
            worker.RegisterHandler<SetAdvanceParameterRequest, SetAdvanceParameterResponse>(SetAdvanceParameter);
            worker.RegisterHandler<ResolveConflictRequest, ResolveConflictResponse>(ResolveConflict);
            worker.RegisterHandler<ResetParameterRequest, ResetParameterRespose>(ResetAll);
            worker.RegisterHandler<UndoParameterRequest, UndoParameterRespose>(UndoParameter);
            worker.RegisterHandler<RedoParameterRequest, RedoParameterRespose>(RedoParameter);
            worker.RegisterHandler<SetSmartSelectRequest, SetSmartSelectResponse>(SetSmartSelect);
            worker.RegisterHandler<SetStackSelectRequest, SetStackSelectResponse>(SetStackSelect);
            worker.RegisterHandler<SetStackCoilRequest, SetStackCoilResponse>(SetStackCoilSelection);
            worker.RegisterHandler<GetInitialModelRequest, GetInitialModelResponse>(GetInitialModel);
            Trace.Info("Initialize Exit");
        }

        #endregion

        /// <summary>
        /// Handles Typecasting
        /// </summary>
        /// <param name="convertValue">ConvertValue argument</param>
        protected T ConvertValue<T>(object convertValue)
        {
            return convertValue is T ? (T)convertValue : default(T);
        }

        /// <summary>
        ///     SetParameter Request Handler
        /// </summary>
        /// <param name="setParameterRequest"></param>
        /// <returns></returns>
        private SetParameterResponse SetParameter(SetParameterRequest setParameterRequest)
        {
            Trace.Info("Entering SetParameterRequest");
            var response = new SetParameterResponse();

            try
            {
                _parameterEditorServiceHandler.SetParameter(setParameterRequest.ParamId, setParameterRequest.NewValues);
            }
            catch (ArgumentNullException ex)
            {
                Trace.Info("Error in Setting Parameter with exception {0}", ex.ToString());
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        ///     Set ActiveGroup Handler
        /// </summary>
        /// <returns></returns>
        private SetActiveGroupResponse SetActiveGroup(SetActiveGroupRequest setActiveGroupRequest)
        {
            Trace.Info("Entering SetActiveGroup");
            var response = new SetActiveGroupResponse();

            try
            {
                _parameterEditorServiceHandler.SetActiveGroup(setActiveGroupRequest.GroupId);
            }
            catch (ArgumentNullException ex)
            {
                Trace.Info("Error in Setting Active Group with message {0}", ex.Message);
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        ///     Set ActiveGroup Handler
        /// </summary>
        /// <returns></returns>
        private SetAdvanceParameterResponse SetAdvanceParameter(SetAdvanceParameterRequest setAdvanceParameterRequest)
        {
            Trace.Info("Entering SetAdvanceParameter");
            var response = new SetAdvanceParameterResponse();
            try
            {
                _parameterEditorServiceHandler.SetAdvanceParameterState(setAdvanceParameterRequest.AdvanceParameterOpenState);
            }
            catch (ArgumentNullException ex)
            {
                Trace.Info("Error in Setting Advance parameter state with message {0}", ex.Message);
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        ///     called on OnParameterEditorUpdated
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="parameterEditorUpdateArgs"></param>
        private void OnParameterEditorUpdated(object sender, ParameterEditorUpdateArgs parameterEditorUpdateArgs)
        {
            if (parameterEditorUpdateArgs != null)
            {
                var parameterEditorUpdatedResponseMessage = new ParameterEditorUpdatedResponse { Result = parameterEditorUpdateArgs };
                //Push message notification to the client registered with the end point
                Send(parameterEditorUpdatedResponseMessage);
            }
        }

        /// <summary>
        ///  Event menthod  will be  called on ParameterEditorEnabled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="isEnabled"></param>
        private void OnParameterEditorEnabled(object sender, bool isEnabled)
        {
            var parameterEditorEnabledResponseMessage = new ParameterEditorEnabledResponse { IsEnable = isEnabled };
            //Push message notification to the client registered with the end point
            Send(parameterEditorEnabledResponseMessage);
        }


        /// <summary>
        ///  ResolveConflict request handler
        /// </summary>
        /// <param name="resolveConflictRequest">ResolveConflictRequest object </param>
        /// <returns>Returns ResolveConflictResponse object</returns>
        private ResolveConflictResponse ResolveConflict(ResolveConflictRequest resolveConflictRequest)
        {
            Trace.Info("Entering ResolveConflict");
            var response = new ResolveConflictResponse();

            try
            {
                _parameterEditorServiceHandler.ResolveConflict(resolveConflictRequest.ConflictKey, resolveConflictRequest.SuggestionKey);
            }
            catch (ArgumentNullException ex)
            {
                Log.Error($"Error in resolving conflict with message {ex.Message}");
                HandleException(response, ex);
            }

            return response;
        }


        /// <summary>
        /// Method to set smart select
        /// </summary>
        /// <param name="smartSelectRequest">SetSmartSelectRequest object</param>
        /// <returns>SetSmartSelectResponse</returns>
        private SetSmartSelectResponse SetSmartSelect(SetSmartSelectRequest smartSelectRequest)
        {
            Trace.Info("Entering SetSmartSelect");
            var response = new SetSmartSelectResponse();

            try
            {
                _parameterEditorServiceHandler.SetSmartSelect(smartSelectRequest.IsSmartSelect);
            }
            catch (ArgumentNullException ex)
            {
                Log.Error($"Error in SetSmartSelect with message {ex.Message}");
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        /// Method to set stack select
        /// </summary>
        /// <param name="stackSelectRequest">SetStackSelectRequest object</param>
        /// <returns>SetStackSelectResponse</returns>
        private SetStackSelectResponse SetStackSelect(SetStackSelectRequest stackSelectRequest)
        {
            Trace.Info("Entering SetStackSelect");
            var response = new SetStackSelectResponse();

            try
            {
                _parameterEditorServiceHandler.SetStackSelect(stackSelectRequest.IsStackSelect);
            }
            catch (ArgumentNullException ex)
            {
                Log.Error($"Error in SetStackSelect with message {ex.Message}");
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        /// Method to set stack coils
        /// </summary>
        /// <param name="coilStackRequest">SetStackCoilRequest object</param>
        /// <returns>SetStackCoilResponse object</returns>
        private SetStackCoilResponse SetStackCoilSelection(SetStackCoilRequest coilStackRequest)
        {
            Trace.Info("Entering SetStackCoilSelection");
            var response = new SetStackCoilResponse();

            try
            {
                _parameterEditorServiceHandler.SetStackCoilSelection(coilStackRequest.StackIndex, coilStackRequest.StackDetails);
            }
            catch (ArgumentNullException ex)
            {
                Log.Error($"Error in SetStackCoilSelection with message {ex.Message}");
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        ///     ResetAll Request Handler
        /// </summary>
        /// <param name="resetParameterRequest"></param>
        /// <returns></returns>
        private ResetParameterRespose ResetAll(ResetParameterRequest resetParameterRequest)
        {
            Trace.Info("Entering ResetAll");
            var response = new ResetParameterRespose();

            try
            {
                _parameterEditorServiceHandler.ResetAll();
            }
            catch (ArgumentNullException ex)
            {
                Trace.Info("Error in Setting Parameter with exception {0}", ex.ToString());
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        ///     UndoParameter Request Handler
        /// </summary>
        /// <param name="undoParameterRequest"></param>
        /// <returns></returns>
        private UndoParameterRespose UndoParameter(UndoParameterRequest undoParameterRequest)
        {
            Trace.Info("Entering UndoParameter");
            var response = new UndoParameterRespose();

            try
            {
                _parameterEditorServiceHandler.UndoParameter();
            }
            catch (ArgumentNullException ex)
            {
                Trace.Info("Error in Undo Parameter with exception {0}", ex.ToString());
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        ///     RedoParameter Request Handler
        /// </summary>
        /// <param name="redoParameterRequest"></param>
        /// <returns></returns>
        private RedoParameterRespose RedoParameter(RedoParameterRequest redoParameterRequest)
        {
            Trace.Info("Entering RedoParameter");
            var response = new RedoParameterRespose();

            try
            {
                _parameterEditorServiceHandler.RedoParameter();
            }
            catch (ArgumentNullException ex)
            {
                Trace.Info("Error in Undo Parameter with exception {0}", ex.ToString());
                HandleException(response, ex);
            }

            return response;
        }

        /// <summary>
        ///  getInitialModel Request Handler
        /// </summary>
        /// <param name="getInitialModelRequest"></param>
        /// <returns></returns>
        private GetInitialModelResponse GetInitialModel(GetInitialModelRequest getInitialModelRequest)
        {
            Trace.Info("Entering GetInitialModel");
            var response = new GetInitialModelResponse();

            try
            {
                _parameterEditorServiceHandler.GetInitialModel();
            }
            catch (ArgumentNullException ex)
            {
                Trace.Info("Error in GetInitialModel Parameter with exception {0}", ex.ToString());
                HandleException(response, ex);
            }

            return response;
        }
        /// <summary>
        /// Handles the exceptions and updates the reposnse object accordingle
        /// </summary>
        /// <param name="responseObj">
        /// Reponse that would be recived by the client
        /// </param>
        /// <param name="ex">
        /// Exception details
        /// </param>
        private static void HandleException(Message responseObj, Exception ex)
        {
            responseObj.IsError = true;
            var error = new ErrorMessage { Message = ex.Message, StackTrace = ex.StackTrace, InnerException = ex };
            responseObj.Error = error;
            Trace.Info($"{ex.Message} with Stack trace {ex.StackTrace}");
        }
    }
    //TICS +5@113:
}

#region Revision History

// 2017-Aug-11  Ankit Singh Bhakuni
//              Initial version
// 2017-Aug-23  Vivek Saurav
//              Corrected Namespace (Story-17303)
// 2018-May-02  Vivek Saurav
//              Implemented Dispose for ParameterEditor ServiceHandler.
// 2019-May-14  Anu Jothis
//              Added method for  ResolveConflict story point 39048
// 2019-Jul-26  Anu Jothis
//              Added method for  SetCoilSelectionDto. Story Id - 54058
// 2019-Oct-25 Anu Jothis
//              Added method for SetStackSelect. SetCoilSmartSelect renamed to SetSmartSelect. Story Id - 73850
#endregion Revision History
