﻿#region Copyright Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: SetStackSelectRequest.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2019

#region namespaces
using System;
using Philips.DI.Interfaces.Services.Messaging.Model;
using Philips.PmsMR.ParameterEditor.Interfaces;
#endregion

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{
    #region class
    /// <summary>
    ///     Request to set stack select for a coil stack 
    /// </summary>
    [Serializable]
    public class SetStackSelectRequest : Message
    {
        /// <summary>
        /// Boolean is stack select property
        /// </summary>
        public bool IsStackSelect { get; set; }
    }
    #endregion
}

#region Revision History

// 2019-Oct-18  Anu Jothis
//              Initial version
//             Story ID - 54058. Coil Selection backend implementation
// 2019-Sep-17  Anu Jothis
//              Updated according to review
// 2019-Oct-25 Anu Jothis
//             Updated code for new API for stack select. Story Id - 73850
#endregion Revision History
