﻿#region Copyright Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: SetSmartSelectResponse.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2019

#region namespaces
using System;
using Philips.DI.Interfaces.Services.Messaging.Model;
#endregion

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{
    #region class
    /// <summary>
    ///     Response to set stack smart select
    /// </summary>
    [Serializable]
    public class SetSmartSelectResponse : Message
    {
    }
    #endregion
}

#region Revision History

// 2019-Jul-31  Anu Jothis
//              Initial version
//             Story ID - 54058. Coil Selection backend implementation
// 2019-Nov-13  Anu Jothis
//              Initial version
//             Story ID - 54058. Renamed class.
#endregion Revision History
