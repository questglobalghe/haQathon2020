﻿#region Copyright Koninklijke Philips Electronics N.V. 2020

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: SetAdvanceParameterResponse.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2020

using System;
using Philips.DI.Interfaces.Services.Messaging.Model;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{

    /// <summary>
    ///     Response providing with string data
    /// </summary>
    [Serializable]
    public class SetAdvanceParameterResponse : Message
    {
    }
}

#region Revision History

// 2020-Sept-25  Ramanjaneyulu SBV
//              Initial version

#endregion Revision History
