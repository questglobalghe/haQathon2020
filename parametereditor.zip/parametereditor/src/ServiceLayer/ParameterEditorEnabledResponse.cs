﻿#region Copyright Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ParameterEditorEnabledResponse.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2017

using Philips.DI.Interfaces.Services.Messaging.Model;
using System;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{

    /// <summary>
    /// Response  - Parameter editor enabled 
    /// </summary>
    [Serializable]
    public class ParameterEditorEnabledResponse : Message
    {
        /// <summary>
        /// IsEnable
        /// </summary>
        public bool IsEnable;
    }
}
#region Revision History

// 2019-Jul-09  Ravikumar B
//              Initial version

#endregion Revision History
