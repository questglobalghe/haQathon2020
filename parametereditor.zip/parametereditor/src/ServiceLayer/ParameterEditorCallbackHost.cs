#region Copyright Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ParameterEditorCallbackHost.cs
//

#endregion Copyright Koninklijke Philips Electronics N.V. 2017

using System;
using Microsoft.Practices.Unity;
using Philips.DI.Interfaces.Services.Messaging;
using Philips.DI.Interfaces.Services.Messaging.Model;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Platform.Logging;

namespace Philips.PmsMR.ParameterEditor.ServiceLayer
{

    /// <summary>
    /// ParameterEditor service call back host which exposes the Service request handler
    /// Required as part of IMdBroker Socket implementation for per session socket.
    /// </summary>
    public class ParameterEditorCallbackHost : IBrokerCallback
    {
        /// <summary>
        ///     Logging accessor
        /// </summary>
        private static readonly SystemMessage Log =
            new SystemMessage("ParameterEditor", "ParameterEditorCallbackHost");
        /// <summary>
        /// Singleton instance of ParameterEditor Service
        /// </summary>
        private ParameterEditorService _service;
        /// <summary>
        /// Unity container for dependency injection
        /// </summary>
        private readonly IUnityContainer _container;
        /// <summary>
        /// Lock for restricting one instance for service class
        /// </summary>
        private static readonly object ServiceLock = new object();

        /// <summary>
        /// Default constructor.
        /// This constructor is called one time at start of Router
        /// </summary>
        /// <param name="container"></param>
        public ParameterEditorCallbackHost(IUnityContainer container)
        {
            _container = container;
        }

        /// <summary>
        /// Gets the server side message handler for review service.
        /// </summary>
        /// <returns></returns>
        BaseBrokerCallbackService IBrokerCallback.GetService()
        {
            if (_service == null)
            {
                lock (ServiceLock)
                {
                    if (_service == null)
                    {
                        Log.Info("New instance of type {0} created by ParameterEditorService.",
                            typeof(ParameterEditorService));
                        _service = _container.Resolve<ParameterEditorService>();
                    }
                }
            }
            return _service;
        }
    }

}

#region Revision History

// 2017-Aug-11  Ankit Singh Bhakuni
//              Initial version
// 2017-Aug-23  Vivek Saurav
//              Corrected Namespace (Story-17303)
// 2018-May-02  Vivek Saurav
//              Implemented Dispose for ParameterEditor ServiceHandler.

#endregion Revision History
