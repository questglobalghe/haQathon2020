#region (c) Koninklijke Philips Electronics N.V. 2007
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: IParameterSource.cs
//
#endregion
using System;
using Philips.PmsMR.Scanning.IMethods;

namespace Philips.PmsMR.Methods.ParameterEditor
{
    /// <summary>
    /// Interface used to get the parameters that are to be displayed
    /// </summary>
    public interface IParameterSource : IDisposable
    {
        /// <summary>
        /// Gets the parameters for a source
        /// </summary>
        /// <returns>
        /// Parameters
        /// </returns>
        IKVPDocument GetArchiveParameters(string grpName);
        /// <summary>
        /// Set new values for the parameters in PDF
        /// </summary>
        /// <param name="modifiedParams"></param>
        /// <param name="grpName"></param>
        /// <returns></returns>
        bool SetParameters(IMutableKVPDocument modifiedParams, string grpName);
    }

    /// <summary>
    /// Class that gives the coil parameters
    /// </summary>
    public class CoilParameterSource : IParameterSource
    {
        /// <summary>
        /// ParameterArchive instance
        /// </summary>
        private static IParameterArchives parameterArchive = null;

        /// <summary>
        /// Editor pdf instance
        /// </summary>
        public static IParameterArchives ParameterArchivesInstance
        {
            get
            {
                if (parameterArchive == null)
                {
                    parameterArchive = ParameterArchives.GetParameterArchives();
                    parameterArchive.ReadFromShared();
                }
                return parameterArchive;
            }
        }
        /// <summary>
        /// true if disposed
        /// </summary>
        private bool disposed = false;
        /// <summary>
        /// Gets an instance of pdf
        /// </summary>
        public CoilParameterSource()
        {
            disposed = false;
            parameterArchive = ParameterArchives.GetParameterArchives();
            parameterArchive.ReadFromShared();
        }
        /// <summary>
        /// Gets the coil parameters
        /// </summary>
        /// <returns>
        /// Coil parameters
        /// </returns>
        public IKVPDocument GetArchiveParameters(string grpName)
        {
            return parameterArchive.GetCoils();
        }
        /// <summary>
        /// Set new values for the parameters in PDF
        /// </summary>
        /// <param name="modifiedParams"></param>
        /// <param name="grpName"></param>
        /// <returns></returns>
        public bool SetParameters(IMutableKVPDocument modifiedParams, string grpName)
        {
            return parameterArchive.ApplyCoilValues(modifiedParams);
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        /// <summary>
        /// Dispose method.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!disposed)
            {
                // If disposing equals true, dispose all managed 
                // and unmanaged resources.
                if (disposing)
                {
                    // Dispose managed resources.                    
                    if (parameterArchive != null)
                    {
                        parameterArchive = null;
                    }
                }
                disposed = true;
            }
        }
        /// <summary>
        /// Destructor
        /// </summary>
        ~CoilParameterSource()
        {
            Dispose(false);
        }

    }


    /// <summary>
    /// Class that gives the archive parameters
    /// </summary>   
    public class ArchiveParameterSource : IParameterSource
    {
        /// <summary>
        /// Editor pdf instance
        /// </summary>
        private IParameterArchives parameterArchive = null;
        /// <summary>
        /// true if disposed
        /// </summary>
        private bool disposed;
        /// <summary>
        /// Gets an instance of pdf
        /// </summary>
        public ArchiveParameterSource()
        {
            disposed = false;
            parameterArchive = ParameterArchives.GetParameterArchives();
        }

        /// <summary>
        /// Gets the coil parameters
        /// </summary>
        /// <returns>
        /// Coil parameters
        /// </returns>
        public IKVPDocument GetArchiveParameters(string grpName)
        {
            return parameterArchive.GetArchiveGroupParameters(grpName);
        }


        private string GetGroupName(string grpName)
        {
            string parameterGrpName = string.Empty;
            switch (grpName)
            {
                case "General":
                    parameterGrpName = "CGEN_pars";
                    break;
                case "Preparation":
                    parameterGrpName = "CPR_pars";
                    break;
                case "Reconstruction":
                    parameterGrpName = "CRC_pars";
                    break;
                case "Scan":
                default:
                    parameterGrpName = "CSC_pars";
                    break;
            }
            return parameterGrpName;
        }
        /// <summary>
        /// Set new values for the parameters in PDF
        /// </summary>
        /// <param name="modifiedParams"></param>
        /// <param name="grpName"></param>
        /// <returns></returns>
        public bool SetParameters(IMutableKVPDocument modifiedParams, string grpName)
        {
            return parameterArchive.ApplyArchiveParameterValues(grpName, modifiedParams);
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }



        /// <summary>
        /// Dispose method.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!disposed)
            {
                // If disposing equals true, dispose all managed 
                // and unmanaged resources.
                if (disposing)
                {
                    // Dispose managed resources.                    
                    if(parameterArchive != null)
                    {
                        parameterArchive = null;
                    }
                }
                disposed = true;
            }
        }
        /// <summary>
        /// Destructor
        /// </summary>
        ~ArchiveParameterSource()
        {
            Dispose(false);
        }
    }
}
#region Revision History
// 2007-Jan-11  Somanna CG
//              Initial version
// 2010-Mar-17 Chandru
//             MR00080372:Identical connected coils get switched after selection. 
//             Related to IEditorPdf.SetParameters
// 2018-Mar-16  Rohit Goynar
//              Coding standards for Tics Violations 
// 2019-Aug-08  Jitendra Dash
//              Code updated according to parameterArchives dll(Methods 2.0).
#endregion