#region (c) Koninklijke Philips Electronics N.V. 2006
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: CoilGridParameterEditor.cs
//
#endregion
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using Philips.PmsMR.Platform.NonAswglo;
using Philips.PmsMR.Platform.ParameterEditorUI;
using Philips.PmsMR.Platform.Logging;
using Philips.PmsMR.Platform.VTUserInterface;
using Philips.PmsMR.Platform.OSInterface;
using System.Collections.Generic;
using Philips.PmsMR.Scanning.IMethods;


namespace Philips.PmsMR.Methods.ParameterEditor
{
    /// <summary>
    /// Class to be used by the control parameter editor to diplay the control parameters
    /// </summary>
    public class CoilGridParameterEditor : GridParameterEditor
    {
        /// <summary>
        /// logging member
        /// </summary>
        private SystemMessage sysMsg = new SystemMessage("PMED", "CoilGridParameterEditor");

        /// <summary>
        /// Constructor of CoilParameterGrid
        /// </summary>
        /// <param name="archives"></param>
        public CoilGridParameterEditor(IParameterArchives archives) : base(archives)
        {
            IsForCoil = true;
        }

        /// <summary>
        /// Creates the integer float/single/double parameters
        /// </summary>
        /// <param name="name"></param>
        /// <param name="metadata"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        protected override BaseParameter MakeNewUISingleParameter(string name, IParameterMetaData metadata, IKVPValueType val)
        {
            SingleParameter uiSingleParameter = null;
            try
            {
                List<float> floatValues = new List<float>();
                FloatRange[] floatRanges = GetDoubleRange(metadata);
                if (val.GetValueSize() > 1)
                {
                    DoubleVector floatVec = val.GetDoubleArrayValue();
                    for (int i = 0; i < floatVec.Count; i++)
                    {
                        floatValues.Add((float)floatVec[i]);
                    }
                }
                else
                {
                    floatValues.Add((float)val.GetDoubleValue());
                }
                uiSingleParameter = new SingleParameter(name, floatValues.ToArray())
                {
                    Ranges = floatRanges,
                    // set the BaseLine Values of the pdf parameter in the 
                    // Default Values
                    Values = floatValues.ToArray(),
                    DefaultValues = floatValues,
                    Precision = metadata.GetAccuracy(),
                    StepValue = (float)(metadata.GetAdjustValue()),
                    // Set VisibleCount to 1 more than ActualDimension with a maximum
                    // of the maximum dimension.
                    VisibleCount = Math.Min(
                    metadata.GetActualDimension() + 1, floatValues.Count)
                };
            }
            catch (Exception ex)
            {
                sysMsg.Error("GridParameterEditor: ExtractValues()" + ex.Message);
            }
            return uiSingleParameter;
        }

        /// <summary>
        /// Gets the range for double parameters
        /// </summary>
        /// <param name="metadata"></param>
        /// <returns></returns>
        private FloatRange[] GetDoubleRange(IParameterMetaData metadata)
        {
            DoublePairVector doubleRangeValues = metadata.GetDoubleRange();
            FloatRange[] floatRanges = new FloatRange[doubleRangeValues.Count];
            if (doubleRangeValues.Count > 0)
            {
                for (int i = 0; i < doubleRangeValues.Count; i++)
                {
                    DoublePair pair = doubleRangeValues[i];

                    float lower = Convert.ToSingle(pair.first);
                    float upper = Convert.ToSingle(pair.second);
                    FloatRange floatRange = new FloatRange(lower, upper);
                    floatRanges[i] = floatRange;
                }
            }
            return floatRanges;
        }

        /// <summary>
        /// Gets the range for the integer parameters
        /// </summary>
        /// <param name="parentNode"></param>
        /// <returns></returns>
        protected override List<IKVPNode> GetNodes(IKVPDocument parentNode)
        {
            IKVPNode child = parentNode.GetChildByPath("ProtocolBuffer." + GrpName);
            List<IKVPNode> nodes = new List<IKVPNode>();
            if (child != null)
            {
                IKVPNode grandChild = child.GetFirstChild();
                nodes.Add(grandChild);
                if (grandChild != null)
                {
                    while (grandChild != null)
                    {
                        grandChild = grandChild.GetNextSibling();
                        if (null != grandChild)
                        {
                            nodes.Add(grandChild);
                        }
                        else
                        {
                            
                        }
                    }
                }
                else
                {
                    
                }
            }
            return nodes;
        }

        /// <summary>
        /// Update values to single parameters
        /// Differs only in the type of the parameter value.Here double value is set to parameters
        /// </summary>
        /// <param name="pdfPar"></param>
        /// <param name="rootNode"></param>
        /// <param name="oldValues"></param>
        /// <returns></returns>
        protected override IMutableKVPDocument UpdateSingleParameter(BaseParameter pdfPar, IMutableKVPDocument rootNode, Array oldValues)
        {
            float[] pdfValues = ((SingleParameter)pdfPar).Values;
            //if !ValuesEqual(pdfValues, newValues)
            {
                // fill in the oldValues array;
                oldValues = new float[pdfValues.Length];
                ((SingleParameter)pdfPar).Values.CopyTo(oldValues, 0);
                if (pdfPar.IsArrayType)
                {
                    if (pdfValues != null)
                    {
                        double[] doubleParameters = new double[pdfValues.Length];
                        for (int i = 0; i < pdfValues.Length; i++)
                            doubleParameters[i] = pdfValues[i];

                        DoubleVector doubleVectors = new DoubleVector(doubleParameters);
                        rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(doubleVectors));
                    }
                }
                else
                {
                    double modifiedValue = pdfValues[0];
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(modifiedValue));
                }
            }
            return rootNode;
        }
    }
}
#region Revision History
// 2019-Sep-13  Jitendra Dash
//              Created for coil parameters according to parameterArchives dll(Methods 2.0).
#endregion