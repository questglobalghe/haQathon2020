#region (c) Koninklijke Philips Electronics N.V. 2006
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: GridParameterEditor.cs
//
#endregion
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using Philips.PmsMR.Platform.NonAswglo;
using Philips.PmsMR.Platform.ParameterEditorUI;
using Philips.PmsMR.Platform.Logging;
using Philips.PmsMR.Platform.VTUserInterface;
using Philips.PmsMR.Platform.OSInterface;
using System.Collections.Generic;
using Philips.PmsMR.Scanning.IMethods;


namespace Philips.PmsMR.Methods.ParameterEditor
{
    /// <summary>
    /// Class to be used by the control parameter editor to diplay the control parameters
    /// </summary>
    public class GridParameterEditor : System.Windows.Forms.UserControl
    {
        /// <summary>
        /// logging member
        /// </summary>
        private SystemMessage sysMsg = new SystemMessage("PMED", "GridParameterEditor");
        
        /// <summary>
        /// logging member
        /// </summary>
        private TraceMessage traceMsg =
            new TraceMessage("PMED", "GridParameterEditor");
        /// <summary>
        /// specfial logging member for parameter values
        /// </summary>
        private TraceMessage traceParamValue =
            new TraceMessage("PMED", "ParameterValue");
        /// <summary>
        /// Parameter editor grid instance
        /// </summary>
        private IParameterPanel paramEditorGrid;
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        ///// <summary>
        ///// Editor pdf instance
        ///// </summary>
        //private IEditorPdf editorPdf;
        private IParameterSource parameterSource;

        /// <summary>
        /// Source of parameters for the editor
        /// </summary>
        public IParameterSource ParameterSource
        {
            get { return parameterSource; }
            set { parameterSource = value; }
        }
        /// <summary>
        /// Help text for the selected parameter
        /// </summary>
        private string helpText;

        /// <summary>
        /// normalBackColor
        /// </summary>
        private Color normalBackColor = Color.FromArgb(21, 21, 21);

        /// <summary>
        /// Event will be fired when any parameter value is changed
        /// </summary>
        public event EventHandler EventParameterValueChanged;
        /// <summary>
        /// Event will be fired when Help is requested
        /// </summary>
        public event EventHandler HelpVisibleChange;
        /// <summary>
        /// Event will be fired when Help is requested
        /// </summary>
        public event EventHandler ParameterSelectionChange;
        /// <summary>
        /// Event will be fired when parameters are changed dynamically
        /// </summary>
        public event EventHandler ParameterUpdated;

        /// <summary>
        /// Holds the current selected parameter
        /// </summary>
        private BaseParameter selectedUIParameter = null;

        /// <summary>
        /// Help text for the selected control parameter
        /// </summary>
        public string SelectedParameterHelpText
        {
            get
            {
                return helpText;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public string GrpName { get; set; }
        /// <summary>
        /// UIHelper used for getting the display names of the parameters
        /// </summary>
        private UIHelper uiHelper = null;

        /// <summary>
        /// ParameterArchive instance
        /// </summary>
        private IParameterArchives parameterArchives = null;        

        /// <summary>
        /// Initializes the class
        /// </summary>
        public GridParameterEditor(IParameterArchives archives)
        {
            parameterArchives = archives;
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();
            helpText = string.Empty;
            paramEditorGrid.ParHelpRequest += new EventHandler(RaiseHelpVisibleEvent);
            paramEditorGrid.ParameterSelectionChanged += new EventHandler(ParameterSelected);
            uiHelper = new UIHelper();
        }
        /// <summary>
        /// Sets the source of parameters for the editor
        /// </summary>
        /// <param name="source">
        /// source of parameters
        /// </param>
        public void SetParameterSource(IParameterSource source)
        {
            ParameterSource = source;
        }

        private bool isForCoil = false;
        /// <summary>
        /// 
        /// </summary>
        public bool IsForCoil
        {
            get { return isForCoil; }
            set { isForCoil = value; }
        }


        /// <summary>
        /// Activates the Parameter editor, initializes its controls
        /// </summary>        
        public void Activate()
        {
            if (!string.IsNullOrEmpty(GrpName))
            {
                IKVPDocument doc = ParameterSource.GetArchiveParameters(GrpName);
                paramEditorGrid.Parameters = PopulateUIParameters(doc);
                sysMsg.Info($"Populated UI parameters for {GrpName}, {doc.GetName()}");
            }

            RefreshPanels(false);
        }

        /// <summary>
        /// Deactivates the editor
        /// </summary>
        public virtual void Deactivate()
        {
            // do the clean up after committing the values in edit mode
            paramEditorGrid.CommitValues();
        }
        /// <summary> 
        /// Sets the handlers to the pdf suspended event
        /// </summary>
        /// <param name="handler">
        /// Handler that is passed
        /// </param>
        public void AttachSuspendedHandler(EventHandler handler)
        {
            UpdateGrid(true);
        }
        /// <summary>
        /// Sets the handlers to the pdf resumed event
        /// </summary>
        /// <param name="handler">
        /// Handler that is passed
        /// </param>
        public void AttachResumedHandler(EventHandler handler)
        {
            UpdateGrid(false);
        }
        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (paramEditorGrid != null)
            {
                paramEditorGrid.ParHelpRequest -= new EventHandler(RaiseHelpVisibleEvent);
                paramEditorGrid.ParameterSelectionChanged -= new EventHandler(ParameterSelected);
                EditorControl.Dispose();
                paramEditorGrid = null;
            }
            if(parameterArchives != null)
            {
                parameterArchives = null;
            }
            if (parameterSource != null)
            {
                parameterSource.Dispose();
                parameterSource = null;
            }
            if(uiHelper != null)
            {
                uiHelper.Dispose();
                uiHelper = null;
            }
            sysMsg = null;
            traceMsg = null;
            traceParamValue = null;
            if (disposing)
            {
                // and Dispose the components
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        private BaseParameter[] PopulateUIParameters(
           IKVPDocument methParameters)
        {
            BaseParameter[] uiParameters = null;
            try
            {
                List<IKVPNode> parameterNodes = GetNodes(methParameters);
                // make a new array of the uiParameters
                List<BaseParameter> parameterList = new List<BaseParameter>();

                foreach (IKVPNode node in parameterNodes)
                {
                    if (node != null)
                    {
                        BaseParameter uiParameter = ExtractParameters(node, parameterArchives, IsForCoil);
                        if (null != uiParameter)
                        {
                            parameterList.Add(uiParameter);
                        }
                    }
                }


                uiParameters = new BaseParameter[parameterList.Count];
                uiParameters = parameterList.ToArray();
            }
            catch (Exception ex)
            {
                sysMsg.Error("GridParameterEditor: PopulateUIParameters()" + ex.Message);
            }
            return uiParameters;
        }





        #region New Implementation With ParameterArchives.dll
        /// <summary>
        /// Used for create the base parameter from node
        /// </summary>
        /// <param name="node"></param>
        /// <param name="parameterArchiveInstance"></param>
        /// <param name="isFromCoil"></param>
        /// <returns></returns>
        protected BaseParameter ExtractParameters(IKVPNode node, IParameterArchives parameterArchiveInstance, bool isFromCoil = false)
        {

            BaseParameter uiParameter = null;
            string name = string.Empty;
            IParameterMetaData metadata = null;
            string fullAttrName = string.Empty;
            TypeInfo type = TypeInfo.TypeUnknown;
            bool isVisible = false;
            try
            {
                string path = node.GetPath();
                IKVPValueType val = node.GetValue();
                fullAttrName = path.Substring(path.IndexOf(".") + 1);
                CreateMetadata(parameterArchiveInstance, isFromCoil, out metadata, fullAttrName, out isVisible);
                name = GetUITagName(metadata);
                type = metadata.GetDataType();
                //Show parameters which are having Visibility true
                if (isVisible)
                {
                    if (string.IsNullOrEmpty(name))
                    {
                        name = node.GetName();
                    }
                    switch (type)
                    {
                        case TypeInfo.TypeUnknown:
                            break;
                        case TypeInfo.TypeInt64:
                        case TypeInfo.TypeInteger:
                            uiParameter = MakeNewUIIntParamter(name, metadata, val);
                            break;
                        case TypeInfo.TypeBool:
                        case TypeInfo.TypeEnum:
                            uiParameter = MakeNewUIEnumParameter(name, metadata, val);
                            break;
                        case TypeInfo.TypeFloat:
                        case TypeInfo.TypeDouble:
                            uiParameter = MakeNewUISingleParameter(name, metadata, val);
                            break;
                        case TypeInfo.TypeString:
                            uiParameter = MakeNewUIStringParameter(name, metadata, val);
                            break;
                        case TypeInfo.TypeComposite:
                            break;
                        default:
                            break;
                    }

                    SetParameterPath(isFromCoil, uiParameter, fullAttrName, isVisible, path);
                    SetUIParameterValue(metadata, uiParameter);
                    uiParameter.Visible = isVisible;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                sysMsg.Error("GridParameterEditor: ExtractValues()" + ex.Message);
            }
            return uiParameter;
        }
        private void SetParameterPath(bool isFromCoil, BaseParameter uiParameter, string fullAttrName, bool isVisible, string path)
        {
            if (isFromCoil)
            {
                path = fullAttrName;
            }
            uiParameter.ParameterPath = path;
            uiParameter.Visible = isVisible;
        }
        private void CreateMetadata(IParameterArchives parameterArchiveInstance, bool isFromCoil, out IParameterMetaData metadata, string fullAttrName, out bool isVisible)
        {
            if (!isFromCoil)
            {
                metadata = parameterArchiveInstance.GetParameterMetaData(fullAttrName);
                isVisible = metadata.GetVisible();
            }
            else
            {
                metadata = parameterArchiveInstance.GetCoilParameterMetadata(fullAttrName);
                isVisible = metadata.GetEnabled();
            }
        }

        /// <summary>
        /// Create String Parameter
        /// </summary>
        /// <param name="name"></param>
        /// <param name="metadata"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        protected virtual BaseParameter MakeNewUIStringParameter(string name, IParameterMetaData metadata, IKVPValueType val)
        {
            StringParameter uiStringParameter;
            List<string> stringValues = new List<string>();
            if (val.GetValueSize() > 1)
            {
                StringVector stringVec = val.GetStringArrayValue();
                for (int i = 0; i < stringVec.Count; i++)
                {
                    stringValues.Add(stringVec[i]);
                }
            }
            else
            {
                stringValues.Add(val.GetStringValue());
            }
            uiStringParameter = new StringParameter(name, stringValues.ToArray())
            {
                // set the BaseLine Values of the pdf parameter in the 
                // Default Values
                Values = stringValues.ToArray(),
                // Set VisibleCount to 1 more than ActualDimension with a maximum
                // of the maximum dimension.
                VisibleCount = Math.Min(metadata.GetActualDimension() + 1, stringValues.Count),
            };
            return uiStringParameter;
        }

        /// <summary>
        /// Create Single/Float parameters
        /// </summary>
        /// <param name="name"></param>
        /// <param name="metadata"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        protected virtual BaseParameter MakeNewUISingleParameter(string name, IParameterMetaData metadata, IKVPValueType val)
        {
            SingleParameter uiSingleParameter = null;
            List<float> floatValues = new List<float>();
            FloatRange[] floatRanges = GetFloatRange(metadata);
            if (val.GetValueSize() > 1)
            {
                FloatVector floatVec = val.GetFloatArrayValue();
                for (int i = 0; i < floatVec.Count; i++)
                {
                    floatValues.Add(floatVec[i]);
                }
            }
            else
            {
                floatValues.Add(val.GetFloatValue());
            }
            uiSingleParameter = new SingleParameter(name, floatValues.ToArray())
            {
                Ranges = floatRanges,
                // set the BaseLine Values of the pdf parameter in the 
                // Default Values
                Values = floatValues.ToArray(),
                DefaultValues = floatValues,
                Precision = metadata.GetAccuracy(),
                StepValue = (float)(metadata.GetAdjustValue()),
                // Set VisibleCount to 1 more than ActualDimension with a maximum
                // of the maximum dimension.
                VisibleCount = Math.Min(
                metadata.GetActualDimension() + 1, floatValues.Count)
            };
            return uiSingleParameter;
        }

        /// <summary>
        /// Create Integerparameters
        /// </summary>
        /// <param name="name"></param>
        /// <param name="metadata"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        protected virtual Int32Parameter MakeNewUIIntParamter(string name, IParameterMetaData metadata, IKVPValueType val)
        {
            Int32Parameter uiIntParameter = null;
            IntRange[] intRanges = GetIntRange(metadata);
            List<int> values = GetIntegerParameterValue(val);
            uiIntParameter = new Int32Parameter(name, values.ToArray())
            {
                Values = values.ToArray(),
                Ranges = intRanges,
                StepValue = Convert.ToInt32(metadata.GetAdjustValue()),
                VisibleCount = Math.Min(metadata.GetActualDimension() + 1, values.Count)
            };

            return uiIntParameter;
        }

        /// <summary>
        /// Get all float range values
        /// </summary>
        /// <param name="metadata"></param>
        /// <returns></returns>
        private FloatRange[] GetFloatRange(IParameterMetaData metadata)
        {
            FloatPairVector floatRangeValues = metadata.GetFloatRange();
            FloatRange[] ranges = new FloatRange[floatRangeValues.Count];
            if (floatRangeValues.Count > 0)
            {
                for (int i = 0; i < floatRangeValues.Count; i++)
                {
                    FloatPair pair = floatRangeValues[i];
                    FloatRange floatRange = new FloatRange(pair.first, pair.second);
                    ranges[i] = floatRange;
                }
            }
            return ranges;
        }

        /// <summary>
        /// Get all Integer range values
        /// </summary>
        /// <param name="metadata"></param>
        /// <returns></returns>
        private IntRange[] GetIntRange(IParameterMetaData metadata)
        {
            IntPairVector intpairs = metadata.GetIntegerRange();
            IntRange[] ranges = new IntRange[intpairs.Count];
            if (intpairs.Count > 0)
            {
                for (int i = 0; i < intpairs.Count; i++)
                {
                    IntPair pair = intpairs[i];
                    IntRange intRange = new IntRange(pair.first, pair.second);
                    ranges[i] = intRange;
                }
            }
            return ranges;
        }

        /// <summary>
        /// Creates Enum parameters
        /// </summary>
        /// <param name="parameterName"></param>
        /// <param name="metadata"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        protected virtual EnumParameter MakeNewUIEnumParameter(string parameterName, IParameterMetaData metadata, IKVPValueType val)
        {
            EnumParameter enumParams = null;
            try
            {
                string enumType = metadata.GetEnumDataType();
                EnumHelper helper = new EnumHelper();
                helper.GetUINamesForEnum(enumType);
                WStringVector strVector = helper.GetUINamesForEnum(enumType);
                List<int> values = GetIntegerParameterValue(val);
                Enumerator[] enumValues = new Enumerator[strVector.Count];
                for (int i = 0; i < strVector.Count; i++)
                {
                    enumValues[i] = new Enumerator(i.ToString(), strVector[i]);
                }

                enumParams = new EnumParameter(parameterName, enumValues, values.ToArray())
                {
                    Values = values.ToArray()
                };
            }
            catch (Exception ex)
            {
                sysMsg.Error("GridParameterEditor: MakeNewUIEnumParameter()" + ex.Message);
            }
            return enumParams;
        }

        private void SetUIParameterValue(IParameterMetaData metadata, BaseParameter baseParamter)
        {            
            baseParamter.Help = metadata.GetHelpTag();
            baseParamter.InConflict = metadata.GetConflict();
            baseParamter.ReadOnly = metadata.GetReadOnly();
            baseParamter.Tag = baseParamter;

            if (null != baseParamter)
            {
                baseParamter.ParameterChanged += new EventHandler(OnUIParameterChanged);
            }
        }

        private string GetUITagName(IParameterMetaData metadata)
        {
            string nameTag = metadata.GetNameTag();
            string uiNameText = nameTag;
            if (!string.IsNullOrEmpty(nameTag))
            {
                uiNameText = uiHelper.GetUINameForParameterName(nameTag);
            }
            if (string.IsNullOrEmpty(uiNameText))
            {
                uiNameText = nameTag;
            }
            return uiNameText;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parent"></param>
        /// <returns></returns>
        protected virtual List<IKVPNode> GetNodes(IKVPDocument parent)
        {
            List<IKVPNode> nodes = new List<IKVPNode>();
            IKVPNode child = parent.GetFirstChild();
            while (child != null)
            {
                IKVPNode grandChild = child.GetFirstChild();
                nodes.Add(grandChild);
                if (grandChild != null)
                {
                    while (grandChild != null)
                    {
                        grandChild = grandChild.GetNextSibling();
                        if (null != grandChild)
                        {
                            nodes.Add(grandChild);
                        }
                        else
                        {
                            //Next sibling is not available
                        }
                    }
                }
                else
                {
                    //No child parameter is not available
                }

                child = child.GetNextSibling();
            }
            return nodes;
        }

        /// <summary>
        /// Get Integer Parameter Values
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        protected List<int> GetIntegerParameterValue(IKVPValueType val)
        {
            List<int> values = new List<int>();
            if (val.GetValueSize() > 1)
            {
                IntVector intVec = val.GetIntegerArrayValue();
                Array[] intgerArray = new Array[intVec.Count];
                for (int i = 0; i < intVec.Count; i++)
                {
                    values.Add(intVec[i]);
                }
            }
            else
            {
                values.Add(val.GetIntegerValue());
            }
            return values;
        }

        #endregion

        /// <summary>
        /// Refresh the UI panel with the paramenters
        /// </summary>
        /// <param name="refreshPanels">
        /// if true, the RefreshUIParameters() will be called
        /// </param>
        protected void RefreshPanels(bool refreshPanels)
        {
            traceMsg.Info("RefreshPanels entered");
            if (refreshPanels)
            {
                // Refresh the parameters of editor panel and info panel
                RefreshUIParameters(paramEditorGrid.Parameters);
            }

            paramEditorGrid.UpdateChildren();
            traceMsg.Info("RefreshPanels - Exit");
        }

        private void RefreshUIParameters(BaseParameter[] parameters)
        {
            if (parameters != null)
            {
                traceMsg.Info(
                    "RefreshUIParameters, count = {0}",
                    parameters.GetLength(0));

                foreach (BaseParameter par in parameters)
                {
                    if (par != null)
                    {
                        par.Suspend();
                        RefreshUIParameter(par);
                        par.Resume();
                    }
                }
            }
            traceMsg.Info("RefreshUIParameters - Exit");
        }
        /// <summary>
        /// Apply the changes to the database
        /// </summary>
        /// <param name="GroupName"></param>
        public void ApplyParameterChanges(string GroupName)
        {
            parameterSource.SetParameters(null, GroupName);
        }

        private void RefreshUIParameter(BaseParameter uiPar)
        {
            traceMsg.Info("RefreshUIParameter");
            if (uiPar != null)
            {
                //need to check the need of this method
                // get the pdf parameter stored in the Tag property of 
                // the BaseParameter
                BaseParameter methParameter = (BaseParameter)uiPar.Tag;
                // Set the visibility property
                uiPar.Visible = methParameter.Visible;
                // Set the conflict property, because it matters even for 
                // invisible parameters
                uiPar.InConflict = methParameter.InConflict;
                // only update the visible parameters (reason: performance)
                if (uiPar.Visible)
                {
                    // Fill in the properties of the BaseParameter
                    uiPar.Help = methParameter.Help;
                    uiPar.ReadOnly = methParameter.ReadOnly;
                    uiPar.Name = methParameter.Name;
                    // fill in the type specific properties

                    //Need to check this implementation
                    if ((methParameter as Int32Parameter) != null)
                    {
                    }
                }
            }
            traceMsg.Info("RefreshUIParameter - Exit");
        }
        private void OnUIParameterChanged(object sender, EventArgs args)
        {
            if ((args is ParameterChangedEventArgs) &&
                (((ParameterChangedEventArgs)args).What ==
                ParameterChangedEventArgs.ChangeType.Changed))
            {
                Array oldValues = null;
                Array newValues = null;
                BaseParameter uiPar = (BaseParameter)sender;
                // Get the values from the UI parameter
                GetUIParameterValues(uiPar, ref newValues);
                // And set the values in the PDF parameter
                SetPdfParameterValue(
                    (BaseParameter)uiPar.Tag, newValues, ref oldValues);

            }
            //RefreshPanels(true)
            EventHandler handler = EventParameterValueChanged;
            if (handler != null)
            {
                handler(this, null);
            }
        }

        /// <summary>
        /// Update/Modify the parameters
        /// </summary>
        /// <param name="pdfPar"></param>
        /// <param name="newValues"></param>
        /// <param name="oldValues"></param>
        protected void SetPdfParameterValue(
            BaseParameter pdfPar, Array newValues, ref Array oldValues)
        {
            traceMsg.Info("SetPdfParameterValue -Entered");
            IMutableKVPDocument rootNode = KVPImplementation.CreateMutableKVPDocument();
            try
            {
                if ((!pdfPar.ReadOnly) && (newValues != null))
                {
                    //ToDo PdfData modifedParam = new PdfData()
                    // Set the values contained in the UIParameters 
                    // in the PDF parameters
                    if ((pdfPar as EnumParameter) != null)
                    {
                        rootNode = UpdateEnumParameter(pdfPar, oldValues, rootNode);
                    }
                    else if ((pdfPar as Int32Parameter) != null)
                    {
                        rootNode = UpdateIntParameter(pdfPar, oldValues, rootNode);

                    }
                    else if ((pdfPar as SingleParameter) != null)
                    {
                        rootNode = UpdateSingleParameter(pdfPar, rootNode, oldValues);
                    }
                    else if ((pdfPar as StringParameter) != null)
                    {
                        rootNode = UpdateStringParameter(pdfPar, rootNode, oldValues);
                    }
                    else
                    {
                        // do nothing
                    }

                    string logOldValues = ConvertArrayToString(oldValues);
                    string logNewValues = ConvertArrayToString(newValues);
                    parameterSource.SetParameters(rootNode, GrpName);

                    Array finalValues = GetPdfParameterValues(pdfPar);
                    string logFinalValues = ConvertArrayToString(finalValues);

                    sysMsg.Info("Changed Parameter details are:-");
                    sysMsg.Info("Parameter Name           : {0}", pdfPar.Name);
                    sysMsg.Info("Old Values are           : {0}", logOldValues);
                    sysMsg.Info("User modified Values are : {0}", logNewValues);
                    sysMsg.Info("Final Values are         : {0}", logFinalValues);
                }
                else
                {
                    sysMsg.Info("Parameter {0} can not be modified {1}", pdfPar.Name,
                                       ((pdfPar.ReadOnly) ? "as it is read only" : "as new values for parameter is null"));

                }
            }
            catch (Exception ex)
            {
                sysMsg.Error("GridParameterEditor: SetPdfParameterValue()" + ex.Message);
            }
            traceMsg.Info("SetPdfParameterValue -Exit");
        }

        private IMutableKVPDocument UpdateStringParameter(BaseParameter pdfPar, IMutableKVPDocument rootNode, Array oldValues)
        {
            string[] pdfValues = ((StringParameter)pdfPar).Values;

            //if !ValuesEqual(pdfValues, newValues)
            {
                // fill in the oldValues array;
                oldValues = new string[pdfValues.Length];
                pdfValues.CopyTo(oldValues, 0);
                if (pdfPar.IsArrayType)
                {
                    StringVector stringVec = new StringVector(pdfValues.Length);
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(stringVec));
                }
                else
                {
                    string modifiedValue = pdfValues[0];
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(modifiedValue));
                }
            }
            return rootNode;
        }

        /// <summary>
        /// Update the single parameters
        /// </summary>
        /// <param name="pdfPar"></param>
        /// <param name="rootNode"></param>
        /// <param name="oldValues"></param>
        /// <returns></returns>
        protected virtual IMutableKVPDocument UpdateSingleParameter(BaseParameter pdfPar, IMutableKVPDocument rootNode, Array oldValues)
        {
            float[] pdfValues = ((SingleParameter)pdfPar).Values;
            //if !ValuesEqual(pdfValues, newValues)
            {
                // fill in the oldValues array;
                oldValues = new float[pdfValues.Length];
                ((SingleParameter)pdfPar).Values.CopyTo(oldValues, 0);
                if (pdfPar.IsArrayType)
                {
                    FloatVector floatVectors = new FloatVector(pdfValues);
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(floatVectors));
                }
                else
                {
                    float modifiedValue = pdfValues[0];
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(modifiedValue));
                }
            }
            return rootNode;
        }

        IMutableKVPDocument UpdateIntParameter(BaseParameter pdfPar, Array oldValues, IMutableKVPDocument rootNode)
        {
            int[] pdfValues = ((Int32Parameter)pdfPar).Values;
            //if !ValuesEqual(pdfValues, newValues)
            {
                // fill in the oldValues array;
                oldValues = new int[pdfValues.Length];
                pdfValues.CopyTo(oldValues, 0);

                if (pdfPar.IsArrayType)
                {
                    IntVector vectors = new IntVector(pdfValues);
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(vectors));
                }
                else
                {
                    int modifiedValue = pdfValues[0];
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(modifiedValue));
                }


            }
            return rootNode;
        }

        IMutableKVPDocument UpdateEnumParameter(BaseParameter pdfPar, Array oldValues,IMutableKVPDocument rootNode)
        {
            int[] pdfValues = ((EnumParameter)pdfPar).Values;
            //if !ValuesEqual(pdfValues, newValues)
            {
                // fill in the oldValues array;                        
                oldValues = new int[pdfValues.Length];
                pdfValues.CopyTo(oldValues, 0);
                if (pdfPar.IsArrayType)
                {
                    IntVector vectors = new IntVector(pdfValues);
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(vectors));
                }
                else
                {
                    int modifiedValue = pdfValues[0];
                    rootNode.AddChildByPath((pdfPar).ParameterPath, new IKVPValueType(modifiedValue));
                }
            }
            return rootNode;
        }

        private bool ValuesEqual(Array arrayA, Array arrayB)
        {
            bool equal = true;
            if (arrayA.Length != arrayB.Length)
            {
                equal = false;
            }
            else
            {
                for (int i = 0; i < arrayA.Length; i++)
                {
                    if (!object.Equals(arrayA.GetValue(i), arrayB.GetValue(i)))
                    {
                        equal = false;
                        break;
                    }
                }
            }
            return equal;
        }

        private void GetUIParameterValues(
            BaseParameter uiPar, ref Array newValues)
        {
            if ((uiPar as EnumParameter) != null)
            {
                newValues = ((EnumParameter)uiPar).Values;
            }
            else if ((uiPar as Int32Parameter) != null)
            {
                newValues = ((Int32Parameter)uiPar).Values;
            }
            else if ((uiPar as SingleParameter) != null)
            {
                newValues = ((SingleParameter)uiPar).Values;
            }
            else if ((uiPar as StringParameter) != null)
            {
                newValues = ((StringParameter)uiPar).Values;
            }
            else
            {
                // nothing
            }
        }

        private void OnEditorUpdatedSafe(object sender, EventArgs args)
        {
            sysMsg.Info("OnEditorUpdatedSafe started");
            if (InvokeRequired)
            {
                sysMsg.Info("Invoking OnEditorUpdated");
                EventHandler deleg =
                    new EventHandler(OnEditorUpdated);
                Invoke(deleg, new object[] { sender, args });
            }
            else
            {
                OnEditorUpdated(sender, args);
            }
            sysMsg.Info("OnEditorUpdatedSafe finished");
        }

        private void OnEditorUpdated(object sender, EventArgs args)
        {
            traceMsg.Info("OnEditorUpdated started");
            RefreshPanels(true);
            EventHandler handler = EventParameterValueChanged;
            if (handler != null)
            {
                handler(this, null);
            }
            traceMsg.Info("OnEditorUpdated finished");
        }

        private void OnPDFPrepUpdatedSafe(object sender, EventArgs args)
        {
            sysMsg.Info("OnPDFPrepUpdatedSafe started");
            if (InvokeRequired)
            {
                sysMsg.Info("Invoking OnEditorUpdated");
                EventHandler deleg =
                    new EventHandler(OnPDFPrepUpdated);
                Invoke(deleg, new object[] { sender, args });
            }
            else
            {
                OnPDFPrepUpdated(sender, args);
            }
            sysMsg.Info("OnPDFPrepUpdatedSafe finished");
        }

        private void OnPDFPrepUpdated(object sender, EventArgs args)
        {
            traceMsg.Info("OnPDFPrepUpdated started");
            EventHandler handler = ParameterUpdated;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
            traceMsg.Info("OnPDFPrepUpdated finished");
        }

        private void OnEditorResumedSafe(object sender, EventArgs args)
        {
            sysMsg.Info("OnEditorResumedSafe started");
            if (InvokeRequired)
            {
                sysMsg.Info("Invoking OnEditorResumed");
                EventHandler deleg =
                    new EventHandler(OnEditorResumed);
                Invoke(deleg, new object[] { sender, args });
            }
            else
            {
                OnEditorResumed(sender, args);
            }
            sysMsg.Info("OnEditorResumedSafe finished");
        }

        private void OnEditorResumed(object sender, EventArgs args)
        {
            traceMsg.Info("OnEditorResumed started");
            // Disable the control parameter grid when parameter editor is resumed
            UpdateGrid(false);
            traceMsg.Info("OnEditorResumed finished");
        }

        private void OnEditorSuspendedSafe(object sender, EventArgs args)
        {
            sysMsg.Info("OnEditorSuspendedSafe started");
            if (InvokeRequired)
            {
                sysMsg.Info("Invoking OnEditorSuspended");
                EventHandler deleg =
                    new EventHandler(OnEditorSuspended);
                Invoke(deleg, new object[] { sender, args });
            }
            else
            {
                OnEditorSuspended(sender, args);
            }
            sysMsg.Info("OnEditorSuspendedSafe finished");
        }

        private void OnEditorSuspended(object sender, EventArgs args)
        {
            traceMsg.Info("OnEditorSuspended started");
            // Enable the control parameter grid when parameter editor is suspended
            UpdateGrid(true);
            traceMsg.Info("OnEditorSuspended finished");
        }

        /// <summary>
        /// Update the parameter editor grid with the state sent
        /// </summary>
        /// <param name="enabled">
        /// bool to determine whether the parameter editor needs to be resumed or suspended
        /// </param>
        private void UpdateGrid(bool enabled)
        {
            if (enabled)
            {
                paramEditorGrid.Resume();
            }
            else
            {
                paramEditorGrid.Suspend();
            }
        }

        private string ConvertArrayToString(Array values)
        {
            StringBuilder logValues = new StringBuilder();
            if (values != null)
            {
                foreach (object obj in values)
                {
                    logValues.Append(obj.ToString()).Append(",");
                }
            }
            //To remove the extra comma inserted at end
            return logValues.ToString().TrimEnd(',');

        }

        private Array GetPdfParameterValues(BaseParameter pdfPar)
        {
            Array values = null;
            if ((pdfPar as EnumParameter) != null)
            {
                values = ((EnumParameter)pdfPar).Values;
            }
            else if ((pdfPar as Int32Parameter) != null)
            {
                values = ((Int32Parameter)pdfPar).Values;
            }
            else if ((pdfPar as SingleParameter) != null)
            {
                values = ((SingleParameter)pdfPar).Values;
            }
            else if ((pdfPar as StringParameter) != null)
            {
                values = ((StringParameter)pdfPar).Values;
            }
            else
            {
                // do nothing
            }
            return values;
        }

        /// <summary>
        /// Fires event RaiseHelpVisibleEvent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RaiseHelpVisibleEvent(object sender, EventArgs e)
        {
            EventHandler handler = HelpVisibleChange;
            if (handler != null)
            {
                handler(this, null);
            }
        }

        /// <summary>
        /// Fires event RaiseHelpVisibleEvent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ParameterSelected(object sender, EventArgs e)
        {
            if (ParameterSelectionChange != null)
            {
                selectedUIParameter = paramEditorGrid.SelectedParameter;
                //get the help text
                helpText =
                    HelpUtil.GetHelpText(paramEditorGrid.SelectedParameter.Help);
                EventHandler handler = ParameterSelectionChange;
                if (handler != null)
                {
                    handler(this, null);
                }
            }
        }
        /// <summary>
        /// IParameterPanel cast to Control
        /// </summary>
        private Control EditorControl
        {
            get
            {
                return (Control)paramEditorGrid;
            }
        }
        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paramEditorGrid = new ParameterEditorControl();
            this.SuspendLayout();
            // 
            // paramEditorGrid
            // 
            this.EditorControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EditorControl.Location = new System.Drawing.Point(0, 0);
            this.EditorControl.Name = "paramEditorGrid";
            this.EditorControl.Size = new System.Drawing.Size(368, 368);
            this.EditorControl.TabIndex = 0;
            this.EditorControl.Text = "PropertyGrid";
            // 
            // CustomParameterEditor
            // 
            this.BackColor = normalBackColor;
            this.BorderStyle = BorderStyle.None;
            this.Controls.Add(this.EditorControl);
            this.Name = "CustomParameterEditor";
            this.Size = new System.Drawing.Size(368, 368);
            this.ResumeLayout(false);

        }
        #endregion
        /// <summary>
        /// This method checks if there are any conflicts in the parameters
        /// This check is needed before any updation is undertaken
        /// </summary>
        ///<returns>true if conflicts exist else false</returns>
        public bool ContainsConflicts()
        {
            traceMsg.Info("ContainsConflicts");

            return selectedUIParameter.InConflict;        
        }
    }
    /// <summary>
    /// Gives the help description for help tags
    /// </summary>
    public static class HelpUtil
    {
        #region String constants
        const string BoldTextStartNode = "<txtbold>";
        const string BoldTextEndNode = "</txtbold>";
        const string NewLineNode = "<br/>";
        const string UnderLineStartNode = "<txtunderline>";
        const string UnderLineEndNode = "</txtunderline>";

        private static SystemMessage sysMsg =
            new SystemMessage("PMED", "GridParameterEditor");

        #endregion
        /// <summary>
        /// Gets the formatted help text for the passed help tag
        /// </summary>
        /// <param name="helpTag">
        /// input help tag
        /// </param>
        /// <returns>
        /// formatted help text
        /// </returns>
        public static string GetHelpText(string helpTag)
        {
            string returnValue = string.Empty;
            if (!string.IsNullOrEmpty(helpTag))
            {
                try
                {
                    returnValue = UGGITranslator.Instance.TranslateToXML(helpTag);
                    //If there is no help string for the tag, following string is returned
                    // Unknown Message [<helpTag>]. Thus, presence of help tag in the returned
                    //string means no help string for the tag. In such cases, donot show any message
                    if (returnValue.IndexOf(helpTag) > 0)
                    {
                        returnValue = "";
                    }
                    else
                    {
                        returnValue = GetTextFromXml(returnValue);
                    }

                }
                catch (Exception ex)
                {
                    sysMsg.Error("HelpUtil: " + ex.Message);
                }
            }
            return returnValue;
        }
        /// <summary>
        /// Static constructor, to initialize the tanslator
        /// </summary>
        static HelpUtil()
        {

        }
        /// <summary>
        /// Gets the formatted text from the passed xml tet
        /// </summary>
        /// <param name="xmlText">
        /// input xml text
        /// </param>
        /// <returns>
        /// formatted text
        /// </returns>
        private static string GetTextFromXml(string xmlText)
        {
            //Input text:
            //"<txtbold>B0 reference radius [mm]</txtbold><br/><br/>The reference radius r0, 
            //<br/><br/><br/> used for describing the shape of the main field B0<br/>"

            //Output required:
            //"B0 reference radius [mm]\r\n The reference radius r0,\r\n used for describing the shape of the main field B0"

            //Replace <txtbold> and </txtbold> with empty string
            xmlText = xmlText.Replace(BoldTextStartNode, string.Empty);
            xmlText = xmlText.Replace(BoldTextEndNode, string.Empty);
            //Replace <txtunderline> and </txtunderline> with empty string
            xmlText = xmlText.Replace(UnderLineStartNode, string.Empty);
            xmlText = xmlText.Replace(UnderLineEndNode, string.Empty);

            //Replace "(<br/>)+" with "\r\n"
            string pattern = "(" + NewLineNode + ")+";
            xmlText = System.Text.RegularExpressions.Regex.Replace(
                xmlText, pattern, "\r\n");

            //remove white spaces and "\r\n" from start and end if there are any
            return xmlText.Trim().Trim("\r\n".ToCharArray());
        }
    }
}
#region Revision History
// 2006-Jun-29  Somanna CG
//              Initial version
//2006-Oct-11   Chandru
//              Remove link time dependency on PDF        
//              (only use pdf parameter interfaces)
// 2006-Oct-23  Chandru
//              ParameterEditorControl is used to get .NET property grid 
//              implementation for IParameterPanel
// 2006-Dec-14  Somanna C G
//              Changed impl of HelpUtil::GetTextFromXml() method. Used normal string
//              parsing instead of xml parsing.
// 2007-Jan-09  Somanna C G
//              PR: MR00051162 - Examcard crashes due to changing values in CPE
//              Handle PDF suspend and resume events
//2007-Jan-11   Somanna
//              Refactoring done for adding coil parameter editor    
//2007-Feb-19   Somanna C G
//              MR00054282  CPE: help text of some parameters not available
//              Changed the implemtation of HelpUtil::GetTextFromXml()
//2007-Apr-04   Somanna C G
//              PR: MR00055121  (Incorrect hardware parameters shown)
//              Added ParametersUpdated event and handle PDFPrepUpdated event
//2007-Sep-07   R. Korvers
//              Split off functions that do not need awasw_init
//              Change GeneralConfiguration to NonAswConfiguration
// 09-Oct-2008 M.Schaffrath
//      Remove instance for SoftwareOptionConfiguration, GeneralConfigurationm, HardwareOptionConfiguration,
//      CoilOptionConfiguration, SystemReferenceNumberConfiguration and DicomConfiguration.
// 2010-Mar-17 Chandru
//             MR00080372:Identical connected coils get switched after selection. 
//             Related to IEditorPdf.SetParameters
// 2010-Sep-29 Shailendra
//             MR00094413:Nasty behaviour of coil (or other) parameter editor
//             Added log entries in the SetPdfParameterValue function to track the parameter changes.
// 2011-Feb-09  John Hermans
//              TICS issues solved
// 2012-Mar-19  Anand K R
//              MR00114350 : Reversed the communication of enabling and disabling of params page. This reversal is
//              due to EC-Planscan communication redesign where Examcards is now the owner of mouse events
//              which in earlier case was controlled by Planscan. 
//              Control parameter editor control was earlier disabled when the editor was suspended. With the EC-Planscan
//              re-design, a suspend of Control parameter editor is called whenever the mouse is in Parameter Editor.
//              Hence in this scenario, the control parameter editor should not be suspended. Hence registering the 
//              EnableEditor method when suspend is called on control parameter editor.
// 2013-May-28 Frank Verburg for Serval 1
//             MR00122175 - Add ActualDimension
// 2017-Mar-30 Nithin Kamble
//             MR00199097 : Added a null check for empty help tags to avoid a crash
// 2018-Mar-16  Rohit Goynar
//              Coding standards for Tics Violations 
// 2019-Aug-08  Jitendra Dash
//              Code updated according to parameterArchives dll(Methods 2.0).
#endregion