﻿#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ConflictParameterGroup.cs
//

#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.Scanning.IMethods;
using Philips.PmsMR.ParameterEditor.Interfaces;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// ConflictParameterGroup which represents Conflict group
    /// </summary>
    public class ConflictParameterGroup : ParameterGroup
    {
        /// <summary>
        /// Constructor.
        /// It also sets index for current group to RightMostGroupIndex.
        /// </summary>
        public ConflictParameterGroup(IUnityContainer container, GroupInfo groupInfo, ParameterSessionInfo parameterSessionInfo)
            : base(container, groupInfo, parameterSessionInfo)
        {
        }

        /// <summary>
        ///  Indicate if conflict is present
        /// </summary>
        public override bool ConflictPresent
        {
            get { return ParameterSession.IsInConflict; }
        }
    }
}
