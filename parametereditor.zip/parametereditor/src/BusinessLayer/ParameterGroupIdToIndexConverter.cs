﻿#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterGroupIdToIndexConverter.cs
//

#endregion

using Philips.PmsMR.ParameterEditor.Interfaces;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Converts ParameterGroup Id to Index
    /// </summary>
    public static class ParameterGroupIdToIndexConverter
    {
        /// <summary>
        /// Converts ParameterGroup Id to Index
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static int Convert(int id)
        {
            int index = 0;
            switch (id)
            {
                case (int)GroupIds.Initial:
                    index = ParameterGroupConstants.TopMostGroupIndex + 1;
                    break;
                case (int)GroupIds.Summary:
                    index = ParameterGroupConstants.TopMostGroupIndex + 1;
                    break;
                case (int)GroupIds.Physio:
                    index = ParameterGroupConstants.TopMostGroupIndex + 2;
                    break;
                case (int)GroupIds.Conflicts:
                    index = ParameterGroupConstants.TopMostGroupIndex;
                    break;
                default:
                    index = id;
                    break;
            }
            return index;
        }
    }
}
