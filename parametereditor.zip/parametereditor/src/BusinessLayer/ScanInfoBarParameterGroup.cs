#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ScanInfoBarParameterGroup.cs
//
#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Specialization for ScanInfoBar parameter group
    /// </summary>
    public class ScanInfoBarParameterGroup : CustomParameterGroup
    {
        #region Private fields
        /// <summary>
        /// ScanInfoBar Xml Parameters information.
        /// </summary>
        private readonly XmlGroup _scanInfoBarGroup;
        #endregion

        /// <summary>
        /// Constructor.
        /// </summary>
        public ScanInfoBarParameterGroup(IUnityContainer _container, GroupInfo groupInfo, ParameterSessionInfo parameterSessionInfo)
            : base(_container, groupInfo, parameterSessionInfo)
        {
            _scanInfoBarGroup = XmlParseUtility.GetXmlGroup((int)GroupIds.ScanInfoParameterGroupId);
        }

        /// <summary>
        /// This group is always enabled for display and should be always populated
        /// </summary>
        protected override bool Enabled => true;

        /// <summary>
        /// To fetch parameters for ScanInfoBar
        /// </summary>
        protected override Dictionary<string, IParameterMetaData> GetGroupParameters()
        {
            var allParameters = GetParameterMetaDataForTab(InformationModel.MggSoftkeyAll);
            var infoParameters = GetParameterMetaDataForTab(InformationModel.MggSoftkeyInfo);


            Dictionary<string, IParameterMetaData> paramsMD = new Dictionary<string, IParameterMetaData>();
            var scanInfoParameters = _scanInfoBarGroup.InfoParametersList.Concat(_scanInfoBarGroup.ParametersList).ToList();

            if (scanInfoParameters.Exists(x => x.Contains(InformationModel.ExGeoCurStackId)))
            {
                ReplaceCurrentStackFieldWithValue(scanInfoParameters);
            }
            foreach (var item in allParameters.Keys.Where(x => scanInfoParameters.Contains(x)))
            {
                paramsMD.Add(item, allParameters[item]);
            }
            foreach (var item in infoParameters.Keys.Where(x => scanInfoParameters.Contains(x)))
            {
                if (!paramsMD.ContainsKey(item))
                {
                    paramsMD.Add(item, infoParameters[item]);
                }
            }
            foreach (var item in scanInfoParameters.Where(x => !paramsMD.ContainsKey(x)))
            {
                var parameterMetaData = ParameterSession.ScanProtocolMetaData.GetParameterMetaData(item);
                if (parameterMetaData != null)
                {
                    paramsMD.Add(item, parameterMetaData);
                }
            }

            return paramsMD;
        }



        /// <summary>
        /// Set All info parameters as Non Editable and Update Gap control parameters
        /// </summary>
        protected override ParameterGroupDto FillDtoParameterAttributes(ParameterGroupDto paramgroupDto)
        {
            FillSnrValue(paramgroupDto);
            UpdateAccelerationMethod(paramgroupDto.Parameters);
            if (!RoutineUi)
            {
                foreach (var parameter in paramgroupDto.Parameters)
                {
                    parameter.Value.Editable = false;
                }
            }
            return paramgroupDto;
        }
    }
}
#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2018-Apr-20  Vivek Saurav
//              Moved all the Parameters and InfoParameters values to the ParametersList.Xml
#endregion Revision History