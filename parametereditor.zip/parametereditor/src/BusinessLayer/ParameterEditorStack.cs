#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: ParameterEditorStack.cs
//

#endregion

using Philips.PmsMR.Scanning.IMethods;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// This class provides Stack to Edit Parameter.
    /// </summary>
    public class ParameterEditorStack 
    {
        #region private fields

      
        /// <summary>
        /// Activated group Id
        /// </summary>
        private int _activeGroupId;

        /// <summary>
        /// _stackId
        /// </summary>
        private int _stackId;


        /// <summary>
        /// _kvpDocument
        /// </summary>
        private IKVPDocument _kvpDocument;

        #endregion

        #region public fields
        /// <summary>
        /// ParameterPath
        /// </summary>
        public int ActiveGroupId
        {
            get
            {
                return _activeGroupId;
            }

            set
            {
                _activeGroupId = value;
            }
        }

        /// <summary>
        /// ParameterPath
        /// </summary>
        public int StackId
        {
            get
            {
                return _stackId;
            }

            set
            {
                _stackId = value;
            }
        }

        /// <summary>
        /// ParameterPath
        /// </summary>
        public IKVPDocument KvpDocument
        {
            get
            {
                return _kvpDocument;
            }

            set
            {
                _kvpDocument = value;
            }
        }
        #endregion
    }
}

#region Revision History

// 2019-Aug-03  Ravikumar B
//              Initial version

#endregion Revision History