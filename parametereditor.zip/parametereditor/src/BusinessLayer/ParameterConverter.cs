#region Copyright Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// FILENAME: ParameterConverter.cs
//
#endregion
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Platform.Logging;
using Philips.PmsMR.Platform.OSInterface;
using Philips.PmsMR.Scanning.IMethods;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    ///  Parameter Converter class is used to generate ParameterDto of specific type for 
    ///  given IPdfParameter
    /// </summary>
    public static class ParameterConverter
    {

        static readonly string[] Allowdisableparameters = {
            InformationModel.ExRespUserDefBhTimeSec,
            InformationModel.ExCardHeartPhaseControl,
            InformationModel.IfNrBreathholds,
            InformationModel.ExGeoCurStackId,
            InformationModel.ExCardGateDelayms,
            InformationModel.IfAbsoluteSnr,
            InformationModel.IfRelativeSnr
            };


        private static readonly string[] FilterParameterValues = {
            InformationModel.ExDynScanBeginTimesStr,
            InformationModel.ExDiffNrAveragesStr,
            InformationModel.ExDynScanBlockTimesStr,
            InformationModel.ExDynContrastPhaseNrDyns,
            InformationModel.ExDynContrastPhaseDuration,
            InformationModel.ExDynContrastPhaseBeginTimes,
            InformationModel.ExDiffBFactors
        };

        private static readonly Dictionary<string, string> FilterParameterStringValues = new Dictionary<string, string>
        {
            [InformationModel.ExDynScanBeginTimesStr] = "_",
            [InformationModel.ExDiffNrAveragesStr] = "",
            [InformationModel.ExDynScanBlockTimesStr] = "",
            [InformationModel.ExDynContrastPhaseNrDyns] = "0",
            [InformationModel.ExDynContrastPhaseDuration] = "",
            [InformationModel.ExDiffBFactors] = "0"
        };


        /// <summary>
        /// logging member
        /// </summary>
        private static readonly SystemMessage Log =
            new SystemMessage("PMED", "ParameterConverter");

        #region Populate Parameter Editor DTO

        /// <summary>
        /// A function to populate parameters
        /// </summary>
        /// <param name="paramsMD"></param>
        /// <param name="sessionInfo"></param>
        /// <param name="scanProtocalWrapper">UI helper for Name of the parameter</param>
        /// <param name="isCustomGroup"></param>
        /// <returns></returns>
        public static SerializableDictionary<string, BaseParameterDto> PopulateParameters(Dictionary<string, IParameterMetaData> paramsMD, ParameterSessionInfo sessionInfo, IScanProtocalWrapper scanProtocalWrapper,bool isCustomGroup)
        {
            SerializableDictionary<string, BaseParameterDto> parameters = new SerializableDictionary<string, BaseParameterDto>();

            foreach (var parameterMetaData in paramsMD)
            {
                BaseParameterDto dto = new Int32ParameterDto();
                if (IsValidParameter(parameterMetaData,isCustomGroup))
                {
                    switch (parameterMetaData.Value.GetDataType())
                    {
                        case TypeInfo.TypeUnknown:
                            break;
                        case TypeInfo.TypeInteger:
                            dto = PopulateInteger(sessionInfo, parameterMetaData, scanProtocalWrapper);
                            break;
                        case TypeInfo.TypeEnum:
                            dto = PopulateEnum(sessionInfo, parameterMetaData, scanProtocalWrapper);
                            break;
                        case TypeInfo.TypeFloat:
                            dto = PopulateFloat(sessionInfo, parameterMetaData, scanProtocalWrapper);
                            break;
                        case TypeInfo.TypeString:
                            dto = PopulateString(sessionInfo, parameterMetaData, scanProtocalWrapper);
                            break;
                        case TypeInfo.TypeComposite:
                            break;
                        default:
                            throw new ArgumentOutOfRangeException();
                    }

                    if (!parameters.ContainsKey(parameterMetaData.Key))
                    {
                        parameters.Add(parameterMetaData.Key, dto);
                    }
                }
            }
            return parameters;
        }

        private static bool IsValidParameter(KeyValuePair<string, IParameterMetaData> parameterMetaData,bool isCustomGroup)
        {
            return parameterMetaData.Value.GetVisible() || (isCustomGroup && AllowDisableParameters(parameterMetaData.Key));
        }

        private static bool AllowDisableParameters(string parameterMetaDataKey)
        {
            return Allowdisableparameters.Contains(parameterMetaDataKey);
        }

        private static void FillBaseParameterDto(ParameterSessionInfo sessionInfo, BaseParameterDto dto, KeyValuePair<string, IParameterMetaData> parameterMetaData, IScanProtocalWrapper scanProtocalWrapper)
        {
            dto.UniqueId = parameterMetaData.Key;
            if (parameterMetaData.Value.GetNameTag() == string.Empty)
            {
                dto.Name = parameterMetaData.Key;
            }
            else
            {
                dto.Name = scanProtocalWrapper.GetUINameForParameterName(parameterMetaData.Value.GetNameTag());
            }
            dto.Help = parameterMetaData.Value.GetHelpTag();
            dto.InConflict = parameterMetaData.Value.GetConflict();
            dto.Visible = parameterMetaData.Value.GetVisible();
            dto.Editable = !parameterMetaData.Value.GetReadOnly();
            dto.ValueElementCount = parameterMetaData.Value.GetDimension();
            dto.ActualDimension = parameterMetaData.Value.GetActualDimension();
        }
        private static BaseParameterDto PopulateString(ParameterSessionInfo sessionInfo, KeyValuePair<string, IParameterMetaData> parameterMetaData, IScanProtocalWrapper scanProtocalWrapper)
        {
            var sp = sessionInfo.ScanProtocol;
            var baselineProtocol = sessionInfo.BaselineProtocol;
            StringParameterDto dto = new StringParameterDto();
            FillBaseParameterDto(sessionInfo, dto, parameterMetaData, scanProtocalWrapper);
            var currentNodeValue = sp.GetChildByPath(parameterMetaData.Key);
            var baselineCurrentNodeValue = baselineProtocol.GetChildByPath(parameterMetaData.Key);

            var strVals = new string[scanProtocalWrapper.GetCurrentNodeValueSize(currentNodeValue)];
            var baselineStrVals = new string[scanProtocalWrapper.GetCurrentNodeValueSize(baselineCurrentNodeValue)];

            PopulateStringValues(parameterMetaData, scanProtocalWrapper, currentNodeValue, strVals, baselineCurrentNodeValue, baselineStrVals, dto);
            return dto;
        }

        private static void PopulateStringValues(KeyValuePair<string, IParameterMetaData> parameterMetaData, IScanProtocalWrapper scanProtocalWrapper,
            IKVPNode currentNodeValue, string[] strVals, IKVPNode baselineCurrentNodeValue, string[] baselineStrVals,
            StringParameterDto dto)
        {
            if (scanProtocalWrapper.GetCurrentNodeValueSize(currentNodeValue) > 1)
            {
                currentNodeValue.GetStringArrayValue().CopyTo(strVals);
                if (ApplyFilterOnValue(parameterMetaData.Key))
                {
                    strVals = FilterArrayValues(parameterMetaData.Key, strVals);
                }
            }
            else
            {
                strVals[0] = currentNodeValue.GetStringValue();
            }

            if (scanProtocalWrapper.GetCurrentNodeValueSize(baselineCurrentNodeValue) > 1)
            {
                baselineCurrentNodeValue.GetStringArrayValue().CopyTo(baselineStrVals);
                if (ApplyFilterOnValue(parameterMetaData.Key))
                {
                    baselineStrVals = FilterBaseLineArrayValues(parameterMetaData.Key, baselineStrVals, strVals.Length);
                }
            }
            else
            {
                baselineStrVals[0] = baselineCurrentNodeValue.GetStringValue();
            }

            dto.Values = new ObservableCollection<string>(strVals);
            dto.DefaultValues = new ObservableCollection<string>(baselineStrVals);
        }

        private static bool ApplyFilterOnValue(string parameterMetaDatakey)
        {
            return FilterParameterValues.Contains(parameterMetaDatakey);
        }


        private static string[] FilterBaseLineArrayValues(string parameterMetaDataKey, string[] baselineStrVals, int currentValsCount)
        {
            List<string> modifiedValue = FilterArrayValues(parameterMetaDataKey, baselineStrVals).ToList();
            if (currentValsCount > 0)
            {
                if (modifiedValue.Count < currentValsCount)
                {
                    while (modifiedValue.Count < currentValsCount)
                    {
                        modifiedValue.Add("");
                    }
                }
                else if (modifiedValue.Count > currentValsCount)
                {
                    modifiedValue = modifiedValue.Take(currentValsCount).ToList();
                }
            }
            return modifiedValue.ToArray();
        }

        private static string[] FilterArrayValues(string parameterMetaDataKey, string[] strVals)
        {
            List<string> modifiedValue = strVals.Where(val => val != FilterParameterStringValues[parameterMetaDataKey]).ToList();
            modifiedValue.Add(FilterParameterStringValues[parameterMetaDataKey]);
            return modifiedValue.ToArray();
        }


        private static BaseParameterDto PopulateFloat(ParameterSessionInfo sessionInfo, KeyValuePair<string, IParameterMetaData> parameterMetaData, IScanProtocalWrapper scanProtocalWrapper)
        {
            var sp = sessionInfo.ScanProtocol;
            var baselineProtocol = sessionInfo.BaselineProtocol;
            SingleParameterDto dto = new SingleParameterDto();
            FillBaseParameterDto(sessionInfo, dto, parameterMetaData, scanProtocalWrapper);
            var currentNodeValue = sp.GetChildByPath(parameterMetaData.Key);
            var baselineCurrentNodeValue = baselineProtocol.GetChildByPath(parameterMetaData.Key);
            //Populate Range
            FillPopulateRange(dto, parameterMetaData.Value);
            var floatVals = new float[scanProtocalWrapper.GetCurrentNodeValueSize(currentNodeValue)];
            var baselinefloatVals = new float[scanProtocalWrapper.GetCurrentNodeValueSize(baselineCurrentNodeValue)];

            if (scanProtocalWrapper.GetCurrentNodeValueSize(currentNodeValue) > 1)
            {
                currentNodeValue.GetFloatArrayValue().CopyTo(floatVals);
            }
            else
            {
                floatVals[0] = currentNodeValue.GetFloatValue();
            }

            if (scanProtocalWrapper.GetCurrentNodeValueSize(baselineCurrentNodeValue) > 1)
            {
                baselineCurrentNodeValue.GetFloatArrayValue().CopyTo(baselinefloatVals);
            }
            else
            {
                baselinefloatVals[0] = baselineCurrentNodeValue.GetFloatValue();
            }
            dto.Values = new ObservableCollection<float>(floatVals);
            dto.DefaultValues = new ObservableCollection<float>(baselinefloatVals);
            return dto;
        }
        private static BaseParameterDto PopulateEnum(ParameterSessionInfo sessionInfo, KeyValuePair<string, IParameterMetaData> parameterMetaData, IScanProtocalWrapper scanProtocalWrapper)
        {
            var sp = sessionInfo.ScanProtocol;
            var baselineProtocol = sessionInfo.BaselineProtocol;
            EnumParameterDto dto = new EnumParameterDto();
            FillBaseParameterDto(sessionInfo, dto, parameterMetaData, scanProtocalWrapper);
            var currentNodeValue = sp.GetChildByPath(parameterMetaData.Key);
            var baselineCurrentNodeValue = baselineProtocol.GetChildByPath(parameterMetaData.Key);

            //Populate Range
            FillEnumRange(dto, parameterMetaData.Value, scanProtocalWrapper);
            var enumVals = new int[scanProtocalWrapper.GetCurrentNodeValueSize(currentNodeValue)];
            var baselineIntVals = new int[scanProtocalWrapper.GetCurrentNodeValueSize(baselineCurrentNodeValue)];

            if (scanProtocalWrapper.GetCurrentNodeValueSize(currentNodeValue) > 1)
            {
                currentNodeValue.GetIntegerArrayValue().CopyTo(enumVals);
                if (ApplyFilterOnValue(parameterMetaData.Key))
                {
                    enumVals = FilterEnumArrayValues(parameterMetaData.Key, enumVals, sessionInfo, scanProtocalWrapper);
                }
            }
            else
            {
                enumVals[0] = currentNodeValue.GetIntegerValue();
            }

            if (scanProtocalWrapper.GetCurrentNodeValueSize(baselineCurrentNodeValue) > 1)
            {
                baselineCurrentNodeValue.GetIntegerArrayValue().CopyTo(baselineIntVals);
                if (ApplyFilterOnValue(parameterMetaData.Key))
                {
                    baselineIntVals = FilterEnumBaseLineArrayValues(parameterMetaData.Key, baselineIntVals, enumVals);
                }
            }
            else
            {
                baselineIntVals[0] = baselineCurrentNodeValue.GetIntegerValue();
            }

            dto.Values = new ObservableCollection<int>(enumVals);
            dto.DefaultValues = new ObservableCollection<int>(baselineIntVals);
            return dto;
        }

        private static int[] FilterEnumBaseLineArrayValues(string key, int[] baselineIntVals, int[] enumVals)
        {
            List<int> modifiedValue = new List<int>(baselineIntVals);
            if (InformationModel.ExDynContrastPhaseBeginTimes == key)
            {
                modifiedValue = modifiedValue.Take(enumVals.Length).ToList();
            }
            return modifiedValue.ToArray();
        }

        private static int[] FilterEnumArrayValues(string key, int[] enumVals, ParameterSessionInfo sessionInfo, IScanProtocalWrapper scanProtocalWrapper)
        {
            List<int> modifiedValue = new List<int>(enumVals);
            if (InformationModel.ExDynContrastPhaseBeginTimes == key)
            {
                var exDynContrastPhaseNrDyns = sessionInfo.ScanProtocolMetaData.GetParameterMetaData(InformationModel.ExDynContrastPhaseNrDyns);
                var exDynContrastPhaseNrDynsDto = PopulateInteger(sessionInfo,
                    new KeyValuePair<string, IParameterMetaData>(InformationModel.ExDynContrastPhaseNrDyns, exDynContrastPhaseNrDyns),
                    scanProtocalWrapper);
                var count = ((Int32ParameterDto)exDynContrastPhaseNrDynsDto).Values.Count;
                modifiedValue = modifiedValue.Take(count).ToList();
            }
            return modifiedValue.ToArray();
        }

        private static BaseParameterDto PopulateInteger(ParameterSessionInfo sessionInfo, KeyValuePair<string, IParameterMetaData> parameterMetaData, IScanProtocalWrapper scanProtocalWrapper)
        {
            var sp = sessionInfo.ScanProtocol;
            var baselineProtocol = sessionInfo.BaselineProtocol;
            Int32ParameterDto dto = new Int32ParameterDto();
            FillBaseParameterDto(sessionInfo, dto, parameterMetaData, scanProtocalWrapper);
            var currentNodeValue = sp.GetChildByPath(parameterMetaData.Key);
            var baselineCurrentNodeValue = baselineProtocol.GetChildByPath(parameterMetaData.Key);
            //Populate Range
            FillIntRange(dto, parameterMetaData.Key, parameterMetaData.Value);
            var intVals = new int[scanProtocalWrapper.GetCurrentNodeValueSize(currentNodeValue)];
            var baselineIntVals = new int[scanProtocalWrapper.GetCurrentNodeValueSize(baselineCurrentNodeValue)];

            PopulateIntegerValues(sessionInfo, parameterMetaData, scanProtocalWrapper, currentNodeValue, intVals, baselineCurrentNodeValue, baselineIntVals, dto);
            return dto;
        }

        private static void PopulateIntegerValues(ParameterSessionInfo sessionInfo, KeyValuePair<string, IParameterMetaData> parameterMetaData, IScanProtocalWrapper scanProtocalWrapper, IKVPNode currentNodeValue,
            int[] intVals, IKVPNode baselineCurrentNodeValue, int[] baselineIntVals, Int32ParameterDto dto)
        {
            if (scanProtocalWrapper.GetCurrentNodeValueSize(currentNodeValue) > 1)
            {
                currentNodeValue.GetIntegerArrayValue().CopyTo(intVals);
                if (ApplyFilterOnValue(parameterMetaData.Key))
                {
                    intVals = FilterIntArrayValues(parameterMetaData.Key, intVals, sessionInfo, scanProtocalWrapper);
                }
            }
            else
            {
                intVals[0] = currentNodeValue.GetIntegerValue();
            }

            if (scanProtocalWrapper.GetCurrentNodeValueSize(baselineCurrentNodeValue) > 1)
            {
                baselineCurrentNodeValue.GetIntegerArrayValue().CopyTo(baselineIntVals);
                if (ApplyFilterOnValue(parameterMetaData.Key))
                {
                    baselineIntVals = FilterIntBaseLineArrayValues(parameterMetaData.Key, baselineIntVals, intVals.Length, sessionInfo, scanProtocalWrapper);
                }
            }
            else
            {
                baselineIntVals[0] = baselineCurrentNodeValue.GetIntegerValue();
            }

            dto.Values = new ObservableCollection<int>(intVals);
            dto.DefaultValues = new ObservableCollection<int>(baselineIntVals);
        }

        private static int[] FilterIntBaseLineArrayValues(string parameterMetaDataKey, int[] baselineStrVals, int currentValsCount, ParameterSessionInfo sessionInfo, IScanProtocalWrapper scanProtocalWrapper)
        {
            List<int> modifiedValue = FilterIntArrayValues(parameterMetaDataKey, baselineStrVals,sessionInfo, scanProtocalWrapper).ToList();
            if (currentValsCount > 0)
            {
                if (modifiedValue.Count < currentValsCount)
                {
                    while (modifiedValue.Count < currentValsCount)
                    {
                        modifiedValue.Add(0);
                    }
                }
                else if (modifiedValue.Count > currentValsCount)
                {
                    modifiedValue = modifiedValue.Take(currentValsCount).ToList();
                }
            }
            return modifiedValue.ToArray();
        }

        private static int[] FilterIntArrayValues(string key, int[] strVals, ParameterSessionInfo sessionInfo, IScanProtocalWrapper scanProtocalWrapper)
        {
            if (InformationModel.ExDiffBFactors == key)
            {
                var exDiffNrWeighting = sessionInfo.ScanProtocolMetaData.GetParameterMetaData(InformationModel.ExDiffNrWeighting);
                var exDiffNrWeightingDto = PopulateInteger(sessionInfo,
                    new KeyValuePair<string, IParameterMetaData>(InformationModel.ExDiffNrWeighting, exDiffNrWeighting),
                    scanProtocalWrapper);
                var exDiffNrWeightingValue = ((Int32ParameterDto)exDiffNrWeightingDto).Values[0];
                List<int> modifiedValue = strVals.ToList().Take(exDiffNrWeightingValue).ToList();
                if (modifiedValue[modifiedValue.Count - 1] != 0)
                {
                    modifiedValue.Add(Convert.ToInt32(FilterParameterStringValues[key]));
                }
                return modifiedValue.ToArray();
            }
            else
            {
                var filterLimit = strVals.Reverse()
                    .TakeWhile(x => x.ToString() == FilterParameterStringValues[key]).Count();
                List<int> modifiedValue =
                    strVals.Take(strVals.Length - filterLimit).ToList();
                modifiedValue.Add(Convert.ToInt32(FilterParameterStringValues[key]));
                return modifiedValue.ToArray();
            }
        }

        #endregion
        #region Fill Ranges
        private static void FillIntRange(Int32ParameterDto dto, string key, IParameterMetaData parameterMetaData)
        {
            string rangeString = parameterMetaData.GetRange();
            string[] allRanges = rangeString.Split(',');
            int valueIndex = 0;
            int[] intRangesLower = new int[allRanges.Length];
            int[] intRangesUpper = new int[allRanges.Length];
            foreach (var range in allRanges)
            {
                // Range format could be -4.127-5.99. Hence start search from 1st position to skip negative sign if present
                int indexRangeSeparator = range.IndexOf('-', 1);
                string lowerRange = range.Substring(0, indexRangeSeparator);
                string upperRange = range.Substring(indexRangeSeparator + 1, range.Length - indexRangeSeparator - 1);
                float lowerRangeValue;
                float upperRangeValue;
                Single.TryParse(lowerRange, out lowerRangeValue);
                Single.TryParse(upperRange, out upperRangeValue);
                intRangesLower[valueIndex] = System.Convert.ToInt32(lowerRange);
                intRangesUpper[valueIndex] = System.Convert.ToInt32(upperRangeValue);
                valueIndex++;
            }
            if (key == "EX_SPY.phase_cycles")
            {
                var intRanges = new ObservableCollection<IntRange>();
                for (int index = 0; index < intRangesLower.Length; index++)
                {
                    intRanges.Add(new IntRange(intRangesLower[index], intRangesUpper[index]));
                }
                dto.Ranges = intRanges;
            }
            else
            {
                IntRange intRange = new IntRange(intRangesLower[0], intRangesUpper[intRangesUpper.Length - 1]);
                dto.Ranges = new ObservableCollection<IntRange> { intRange };
            }
            dto.StepValue = (int)parameterMetaData.GetAdjustValue();

        }

        /// <summary>
        /// FillEnumRange
        /// </summary>
        /// <param name="dto">EnumParameterDto</param>
        /// <param name="value">IParameterMetaData</param>
        /// <param name="scanProtocalWrapper">IScanProtocalWrapper</param>
        public static void FillEnumRange(EnumParameterDto dto, IParameterMetaData value, IScanProtocalWrapper scanProtocalWrapper)
        {
            string rangeString = value.GetRange();
            string[] allRanges = rangeString.Split(',');
            var intRanges = new ObservableCollection<IntRange>();
            foreach (var range in allRanges)
            {
                // Range format could be -4.127-5.99. Hence start search from 1st position to skip negative sign if present
                int indexRangeSeparator = range.IndexOf('-', 1);
                string lowerRange = range.Substring(0, indexRangeSeparator);
                string upperRange = range.Substring(indexRangeSeparator + 1, range.Length - indexRangeSeparator - 1);
                int lowerRangeValue;
                int upperRangeValue;
                int.TryParse(lowerRange, out lowerRangeValue);
                int.TryParse(upperRange, out upperRangeValue);
                intRanges.Add(new IntRange(lowerRangeValue, upperRangeValue));
            }
            dto.Ranges = intRanges;


            string enumDataType = value.GetEnumDataType();
            IntVector rangeOfEnum = scanProtocalWrapper.GetRangeForEnum(enumDataType) as IntVector;
            Enumerator[] arrEnum = new Enumerator[rangeOfEnum.Count];
            for (int index = 0; index < rangeOfEnum.Count; index++)
            {
                string enumName = scanProtocalWrapper.GetUINameForEnumValue(enumDataType, rangeOfEnum[index]);
                arrEnum[index] = new Enumerator(System.Convert.ToString(rangeOfEnum[index]), enumName);
            }
            dto.Enumerators = new ObservableCollection<Enumerator>(arrEnum);
        }
        private static void FillPopulateRange(SingleParameterDto dto, IParameterMetaData currentParameterMetaData)
        {
            string rangeString = currentParameterMetaData.GetRange();
            string[] allRanges = rangeString.Split(',');
            var floatRanges = new ObservableCollection<FloatRange>();
            foreach (var range in allRanges)
            {
                // Range format could be -4.127-5.99. Hence start search from 1st position to skip negative sign if present
                int indexRangeSeparator = range.IndexOf('-', 1);
                string lowerRange = range.Substring(0, indexRangeSeparator);
                string upperRange = range.Substring(indexRangeSeparator + 1, range.Length - indexRangeSeparator - 1);
                float lowerRangeValue;
                float upperRangeValue;
                float.TryParse(lowerRange, out lowerRangeValue);
                float.TryParse(upperRange, out upperRangeValue);
                floatRanges.Add(new FloatRange(lowerRangeValue, upperRangeValue));
            }
            dto.Ranges = floatRanges;
            dto.StepValue = (float)currentParameterMetaData.GetAdjustValue();
            dto.Precision = currentParameterMetaData.GetAccuracy();
        }

        #endregion
    }

}

#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2017-Nov-07  Shailendra Nalwaya
//              Fixed the issues related to JSON Serialization for component test.
//              Moved logic/initializations present in Parameter Level Dto to respective Dto converter code.
// 2017-Nov-22  Vivek Saurav
//              Introduced Validation of all variants of ParameterDto (Story ID- 23086)
// 2017-Nov-28  Vivek Saurav
//              Removed RefreshParam from all the Converter classes. (Story ID- 23086)
// 2017-Nov-11  Vivek Saurav
//              Added log for Validation failed (Story ID- 23086)
#endregion Revision History