﻿#region (c) Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: ScanProtocalWrapper.cs
//

#endregion

using Philips.PmsMR.ExamCards.ValidationContext;
using Philips.PmsMR.Scanning.IMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using Philips.PmsMR.Platform.Logging;
using Philips.PmsMR.Platform.NonAswglo;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// ScanProtocalWrapper for getting ScanProtocal related info
    /// </summary>
    public class ScanProtocalWrapper : IScanProtocalWrapper
    {
        #region private members
        /// <summary>
        /// Global config instance
        /// </summary>
        private static readonly NonAswConfiguration _nonAswConfiguration = new NonAswConfiguration();

        private static string _languageCode;

        private static readonly SystemMessage Log =
            new SystemMessage("PMED", "ScanProtocalWrapper");
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public ScanProtocalWrapper()
        {
            _languageCode = GetLanguageCode();
            Log.Info($"Language code that has been set is {_languageCode}");

        }
        /// <summary>
        /// ConvertStringVectorToDictionary
        /// </summary>
        /// <param name="paths"></param>
        /// <param name="pmd"></param>
        /// <returns></returns>
        public Dictionary<string, IParameterMetaData> ConvertStringVectorToDictionary(StringVector paths,
            IParameterMetadataPtrVector pmd)
        {
            var dict = new Dictionary<string, IParameterMetaData>();
            var size = paths.Count();

            for (var index = 0; index < size; index++)
            {
                dict[paths.ElementAt(index)] = pmd.ElementAt(index);
            }

            return dict;
        }


        /// <summary>
        /// GetUINameForTabName
        /// </summary>
        /// <param name="tabName"></param>
        /// <returns></returns>
        public string GetUINameForTabName(string tabName)
        {
            UIHelper uiHelper;
            try
            {
                uiHelper = new UIHelper(_languageCode);
                return uiHelper.GetUINameForTabName(tabName);
            }
            finally
            {
                uiHelper = null;
            }
        }

        /// <summary>
        /// GetUINameForParameterName
        /// </summary>
        /// <param name="getNameTag"></param>
        /// <returns></returns>
        public string GetUINameForParameterName(string getNameTag)
        {
            UIHelper uiHelper;
            try
            {
                uiHelper = new UIHelper(_languageCode);
                return uiHelper.GetUINameForParameterName(getNameTag);
            }
            finally
            {
                uiHelper = null;
            }
        }

        /// <summary>
        /// GetCurrentNodeValueSize
        /// </summary>
        /// <param name="currentNodeValue"></param>
        /// <returns></returns>
        public uint GetCurrentNodeValueSize(IKVPNode currentNodeValue)
        {
            return currentNodeValue.GetValueSize();
        }


        /// <summary>
        /// GetRangeForEnum
        /// </summary>
        /// <param name="enumDataType"></param>
        /// <returns></returns>
        public IEnumerable<int> GetRangeForEnum(string enumDataType)
        {
            EnumHelper enumHelper = new EnumHelper(_languageCode);
            return enumHelper.GetRangeForEnum(enumDataType);
        }


        /// <summary>
        /// GetUINameForEnumValue
        /// </summary>
        /// <param name="enumDataType"></param>
        /// <param name="rangeIndex"></param>
        /// <returns></returns>
        public string GetUINameForEnumValue(string enumDataType, int rangeIndex)
        {
            EnumHelper enumHelper = new EnumHelper(_languageCode);
            return enumHelper.GetUINameForEnumValue(enumDataType, rangeIndex);
        }

        /// <summary>
        /// GetConflictKey
        /// </summary>
        /// <param name="conflictGuidanceInfo"></param>
        /// <returns></returns>
        public string GetConflictKey(ParameterConflictGuidanceInfo conflictGuidanceInfo)
        {
            return conflictGuidanceInfo.conflictKey;
        }

        /// <summary>
        /// GetSuggestionInfoCount
        /// </summary>
        /// <param name="conflictGuidanceInfo"></param>
        /// <returns></returns>
        public int GetSuggestionInfoCount(ParameterConflictGuidanceInfo conflictGuidanceInfo)
        {
            return conflictGuidanceInfo.suggestionInfo.Count;
        }

        /// <summary>
        /// GetSuggestions
        /// </summary>
        /// <param name="conflictGuidanceInfo"></param>
        /// <returns></returns>
        public IEnumerable<SuggestionStruct> GetSuggestions(ParameterConflictGuidanceInfo conflictGuidanceInfo)
        {
            return conflictGuidanceInfo.suggestionInfo;
        }


        /// <summary>
        /// Get ConflictGuidance's Parameters
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public ConflictGuidanceParameters GetConflictGuidanceParameters(SuggestionStruct item)
        {
            return item?.parameters;
        }

        /// <summary>
        /// Get ConflictGuidance's Parameters
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public IEnumerable<ParameterStruct> GetConflictGuidanceParameterStructs(SuggestionStruct item)
        {
            var conflictGuidanceParameters = item?.parameters;
            if (conflictGuidanceParameters != null)
            {
                return (List<ParameterStruct>)conflictGuidanceParameters;
            }
            return null;
        }


        /// <summary>
        /// ParameterStruct's ToBeDisplayed
        /// </summary>
        /// <param name="parameterStruct"></param>
        /// <returns>ToBeDisplayed value</returns>
        public bool ParameterStructToBeDisplayed(ParameterStruct parameterStruct)
        {
            return parameterStruct.toBeDisplayed;
        }

        /// <summary>
        /// Get ParameterStruct's  type
        /// </summary>
        /// <param name="paramItem"></param>
        /// <returns>ParameterStruct's  type</returns>
        public string GetParameterStructType(ParameterStruct paramItem)
        {
            return paramItem.GetType().ToString();
        }

        /// <summary>
        /// Get ParameterStruct's SuggestedValue
        /// </summary>
        /// <param name="parameterStruct"></param>
        /// <returns>Suggested value</returns>
        public float GetParameterStructSuggestedValue(ParameterStruct parameterStruct)
        {
            return parameterStruct.suggestedValue;
        }

        /// <summary>
        /// Get ParameterStruct's ParameterId value 
        /// </summary>
        /// <param name="parameterStruct"></param>
        /// <returns>ParameterId value</returns>
        public string GetParameterStructParameterId(ParameterStruct parameterStruct)
        {
            return parameterStruct.parameterId;

        }

        /// <summary>
        /// Get ParameterStruct's SuggestionKey value
        /// </summary>
        /// <param name="item">SuggestionStruct</param>
        /// <returns>Suggestion Key Value</returns>
        public string GetParameterStructSuggestionKey(SuggestionStruct item)
        {
            return item.suggestionKey;
        }

        /// <summary>
        /// Get EnumName From Value using EnumHelper entity
        /// </summary>
        /// <param name="enumDataType">Enum Data Type</param>
        /// <param name="enumValue">Enum Value</param>
        /// <returns>Enum Name of enum data type</returns>
        public string GetEnumNameFromValue(string enumDataType, int enumValue)
        {
            EnumHelper enumHelper = null;
            try
            {
                enumHelper = new EnumHelper(_languageCode);
                return enumHelper.GetEnumNameFromValue(enumDataType, Convert.ToInt32(enumValue));
            }
            finally
            {
                enumHelper = null;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="scanProtocol"></param>
        /// <param name="coilLogic"></param>
        /// <returns></returns>
        public Coils GetCoils(IScanProtocol scanProtocol, ICoilLogic coilLogic)
        {
            return scanProtocol.GetCoils(coilLogic);
        }

        /// <summary>
        /// Create Validation Context
        /// </summary>
        /// <returns></returns>
        public IValidationContext CreateValidationContext()
        {
            return BasicPDFFactory.CreateValidationContext();
        }

        /// <summary>
        /// GetConflictGuidanceSuggestions
        /// </summary>
        /// <param name="conflictGuidanceInfo"></param>
        /// <returns>ConflictGuidanceSuggestions</returns>
        public ConflictGuidanceSuggestions GetConflictGuidanceSuggestions(ParameterConflictGuidanceInfo conflictGuidanceInfo)
        {
            return conflictGuidanceInfo.suggestionInfo;
        }

        /// <summary>
        /// GetCoilLogic
        /// </summary>
        /// <param name="validationContextWrapper"></param>
        /// <returns>ICoilLogic</returns>
        public ICoilLogic GetCoilLogic(ValidationContextWrapper validationContextWrapper)
        {
            return validationContextWrapper.GetCoilLogic();
        }

        /// <summary>
        /// Gets language code
        /// </summary>
        /// <returns></returns>
        public string GetLanguageCode()
        {
            return _nonAswConfiguration.LanguageCode;
        }
    }
}
#region Revision History
// 2019-Sept-30  Ramanjaneyulu SBV
//              Initial version
#endregion Revision History