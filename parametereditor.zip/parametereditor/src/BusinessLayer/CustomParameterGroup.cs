﻿#region (c) Koninklijke Philips Electronics N.V. 2021
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: CustomParameterGroup.cs
//
#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Base Custom Parameter Group 
    /// </summary>
    public abstract class CustomParameterGroup : ParameterGroup
    {

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="container">Container</param>
        /// <param name="groupInfo">GroupInfo from Pdf to populate group</param>
        /// <param name="parameterSessionInfo">Parameter Session Info</param>
        public CustomParameterGroup(IUnityContainer container, GroupInfo groupInfo, ParameterSessionInfo parameterSessionInfo) : base(container, groupInfo, parameterSessionInfo)
        {
        }




        /// <summary>
        /// Update Dto attributes for acceleration related parameters
        /// </summary>
        protected void UpdateAccelerationMethod(SerializableDictionary<string, BaseParameterDto> allSummaryParameters)
        {
            if (allSummaryParameters.ContainsKey(InformationModel.AccelerationMethod))
            {
                EnumParameterDto dto = allSummaryParameters[InformationModel.AccelerationMethod] as EnumParameterDto;
                if (dto != null)
                {
                    string enumKey = GetCurrentValueEnumKeyName(dto, EnumNames.MpuAcqAccelEnum);
                    var currentStack = GetCurrentStackValue();
                    if (enumKey == EnumNames.MpuAcqAccelSense)
                    {
                        SetParamDtoVisible(allSummaryParameters, InformationModel.SenseSRedFactor, true);
                        SetParamDtoVisible(allSummaryParameters, InformationModel.SensePRedFactor, true);
                        SetParamDtoVisible(allSummaryParameters, InformationModel.CsFactor, false);
                    }
                    else if (enumKey == EnumNames.MpuAcqAccelCsSense || enumKey == EnumNames.MpuAcqAccelCsSenseAi)
                    {
                        SetParamDtoVisible(allSummaryParameters, InformationModel.SenseSRedFactor, false);
                        SetParamDtoVisible(allSummaryParameters, InformationModel.SensePRedFactor, false);
                        SetParamDtoVisible(allSummaryParameters, InformationModel.CsFactor, true);
                    }
                    else
                    {
                        SetParamDtoVisible(allSummaryParameters, InformationModel.SenseSRedFactor, false);
                        SetParamDtoVisible(allSummaryParameters, InformationModel.SensePRedFactor, false);
                        SetParamDtoVisible(allSummaryParameters, InformationModel.CsFactor, false);
                    }
                }
            }
        }

        /// <summary>
        /// Method for setting visibility for particular parameter in parameter collection  
        /// </summary>
        /// <param name="parameters"></param>
        /// <param name="paramName"></param>
        /// <param name="visibleValue"></param>
        protected void SetParamDtoVisible(SerializableDictionary<string, BaseParameterDto> parameters,
            string paramName, bool visibleValue)
        {
            if (parameters.ContainsKey(paramName))
            {
                parameters[paramName].Visible = visibleValue;
            }
        }

    }
}
#region Revision History
// 2021-Jun-10  Ramanjaneyulu SBV
//              Initial version
#endregion Revision History