﻿#region Copyright Koninklijke Philips Electronics N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
//
// Filename: TextResourceUtility.cs
//
#endregion

using System;
using System.IO;
using System.Reflection;
using System.Diagnostics.CodeAnalysis;
using Philips.PmsMR.Platform.Logging;
using Philips.PmsMR.Platform.UIResourceManager;

namespace Philips.PmsMR.ParameterEditor.cultureresources
{
    /// <summary>
    /// Handles resources used for Pride 
    /// </summary>
    //TICS -5@113 : Class does not implement IDisposable
    [ExcludeFromCodeCoverage]
    public class TextResourceUtility
    {
        #region PrivateMember
        /// <summary>
        /// Singleton instance
        /// </summary>
        private static volatile TextResourceUtility _instance;
        /// <summary>
        /// Lock synchronization object 
        /// </summary>
        private static readonly object SyncLock = new object();
        /// <summary>
        /// Holds the info if the object is disposed or not.
        /// </summary>
        private bool _disposed;
        /// <summary>
        /// System Message
        /// </summary>
        private static readonly SystemMessage Log = new SystemMessage("ParameterEditor", "TextResourceUtility");
        /// <summary>
        /// Trace Message
        /// </summary>
        private static readonly TraceMessage Trace = new TraceMessage("ParameterEditor", "TextResourceUtility");
        /// <summary>
        /// ICultureResources
        /// </summary>
        private ICultureResources cultureResourcesInterface;

        /// <summary>
        /// Get the Culture resources
        /// </summary>
        public ICultureResources CultureResources
        {
            get
            {
                if (cultureResourcesInterface == null)
                {
                    // Only use the interface to retrieve culture dependent strings 
                    // in case there are strings registered for retrieval.
                    cultureResourcesInterface = ResourcesInterfaceManager.Instance().
                        GetCultureResourcesInterface();
                }
                return cultureResourcesInterface;
            }
        }

        /// <summary>
        /// instantiate TextResourceUtility object 
        /// </summary>
        /// <remarks>
        /// If the instance of TextResourceUtility is null then the text value displays as junk characters.
        /// </remarks>
        /// <returns>
        /// The Text values will be displayed if present or return junk values as characters.
        /// </returns>
        public static TextResourceUtility Instance
        {
            get
            {
                // Support multithreaded applications            
                // through 'Double checked locking'            
                // pattern which (once the instance            
                // exists) avoids locking each            
                // time the method is invoked

                if (_instance == null)
                {
                    Log.Info("Instance of TextResourceUtility is null, Assembly register has to be done atleast once.");
                }
                return _instance;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="resourceName"></param>
        /// <param name="assembly"></param>
        public static void Register(string resourceName, string assembly)
        {
            Trace.Info("Register : Enter");            
            lock (SyncLock)
            {
                if (_instance == null)
                {
                    _instance = new TextResourceUtility();
                    LoadTextResourceLocation(resourceName);                  
                }
            }
            Trace.Info("Register : Exit");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="resourceName"></param>
        public static void UnRegister(string resourceName)
        {
			Trace.Info("UnRegister : Enter");
			 try
            {
                Assembly cultureAssembly = Assembly.GetExecutingAssembly();
                Instance.UnregisterAssembly(resourceName,cultureAssembly);

            }
            catch (Exception ex)
            {
                Log.Error("Caught Exception UnRegistering resource: {0} Message: {1}", resourceName, ex.Message);
            }
            Trace.Info("UnRegister : Exit");
        }

        #endregion

        #region Private Method
        /// <summary>
        /// Releases the resources used by this instance.
        /// </summary>
        /// <param name="disposing">
        /// </param>
        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (!_disposed)
                {
                    _instance = null;
                    _disposed = true;
                }
            }
        }
        #endregion

        #region PublicMethod
        /// <summary>
        /// Register given assembly and resource name to UI resource manager
        /// </summary>
        /// <param name="resourceName">Name of the resource to be registered</param>
        /// <param name="assembly">Assembly in which the resource is present</param>
        public static void RegisterAssembly(string resourceName, Assembly assembly)
        {
            Trace.Info("RegisterAssembly : Enter");
            try
            {
                if (resourceName.EndsWith(".resources", StringComparison.OrdinalIgnoreCase))
                {
                    // Get the resourceName that ends with ".resources".
                    resourceName = resourceName.Substring(0, resourceName.LastIndexOf(".", StringComparison.OrdinalIgnoreCase));
                }
                // Register the resource.
                UIResourceManager.Instance().RegisterAssemblyResources(resourceName, assembly);
            }
            catch (Exception ex)
            {
                Log.Error("Caught Exception Registering resource: {0} Message: {1}", resourceName, ex.Message);
            }
            Trace.Info("RegisterAssembly : Exit");
        }

        /// <summary>
        /// Releases the resources used by this instance.
        /// </summary>
        public void Dispose()
        {
            lock (SyncLock)
            {
                Dispose(true);
            }
        }
        /// <summary>
        /// Unregisters the assembly.
        /// </summary>
        /// <param name="resourceName">
        /// Name of the resource to be unregistered
        /// </param>
        /// <param name="assembly">
        /// Assembly in which the resource is present
        /// </param>
        public void UnregisterAssembly(string resourceName, Assembly assembly)
        {
            Trace.Info("UnregisterAssembly : Enter");
            try
            {
                if (resourceName.EndsWith(".resources", StringComparison.OrdinalIgnoreCase))
                {
                    // Get the resourceName that ends with ".resources".
                    resourceName = resourceName.Substring(0, resourceName.LastIndexOf(".", StringComparison.OrdinalIgnoreCase));
                }
                if ((UIResourceManager.Instance().IsAssemblyResourceRegistered(resourceName, assembly)))
                {
                    UIResourceManager.Instance().UnregisterAssemblyResources(resourceName, assembly);
                }
                _instance = null;
            }
            catch (Exception ex)
            {
                Log.Error("Caught Exception Unregistering resource: {0} Message: {1}", resourceName, ex.Message);
            }
            Trace.Info("UnregisterAssembly : Exit");
        }

        /// <summary>
        /// Gives the string for the given keyvalue
        /// </summary>
        /// <param name="strId">
        /// name for which culture string is required
        /// </param>
        /// <returns>
        /// required string value
        /// </returns>
        public string GetString(string strId)
        {
            Trace.Info("GetString : Enter");
            string str = String.Empty;

            try
            {
                str = UIResourceManager.Instance().GetString(strId);
            }
            catch (Exception ex)
            {
                Log.Error("Caught Exception while getting string: {0} Message: {1}", strId, ex.Message);
            }

            Trace.Info("GetString : Exit");
            return str;
        }

        /// <summary>
        /// Load Text resource, Loads using current executing assembly
        /// </summary>
        /// <returns></returns>
        private static void LoadTextResourceLocation(string textResourceName)
        {
            Trace.Info("GetTextResourceLocation : Enter");
            try
            {
                Assembly cultureAssembly = Assembly.GetExecutingAssembly();
                RegisterAssembly(textResourceName, cultureAssembly);
            }
            catch (Exception ex)
            {
                Log.Error("Caught Exception : Message: {0}", ex.Message);
            }
            Trace.Info("GetTextResourceLocation : Exit");
        }
        #endregion
    }

    //TICS +5@113 : Class does not implement IDisposable
}
