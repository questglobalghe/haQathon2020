#region (c) Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: ParameterEditor.cs
//

#endregion

using Microsoft.Practices.ObjectBuilder2;
using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Philips.DI.Interfaces.Services.Messaging;
using Philips.PmsMR.Acquisition.AcqGlo;
using Philips.PmsMR.ExamCards.ValidationContext;
using Philips.PmsMR.Methods.CoilLogic;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.ParameterEditor.ServiceLayer;
using Philips.PmsMR.Platform.Aswglo;
using Philips.PmsMR.Platform.Logging;
using Philips.PmsMR.Platform.Mip;
using Philips.PmsMR.Platform.VTUserInterface;
using Philips.PmsMR.Scanning.IMethods;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Threading;
using System.Threading.Tasks;
using Philips.DI.Interfaces.Services.Messaging.Model;
using Philips.PmsMR.ParameterEditor.cultureresources;
using TypeInfo = Philips.PmsMR.Scanning.IMethods.TypeInfo;
using Philips.DI.Interfaces.Services.UserMessaging;
using Philips.DI.Interfaces.Services.UserMessaging.Model;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    //TICS -5@113: Ignore tics warning -"Does not implement IDisposable although it has a method 'protected override void Dispose" 
    /// <summary>
    /// This class updates the ParameterEditorDto on Pdf events and notify same to UI via ParameterEditor Service.
    /// This also provides interface to Edit Parameter or switch groups.
    /// It also communicate with PlanComponent to notify about error occured during 
    /// Pdf operation
    /// Exceptions are notified via ErrorOccured event to Planning Component.
    /// </summary>
    public class ParameterEditor : IParameterEditor, IPlanEditor, IDisposable
    {
        #region private fields

        /// <summary>
        /// <see cref="SystemMessage"/> object for logging messages.
        /// </summary>
        private readonly SystemMessage _log =
            new SystemMessage("PMED", "ParameterEditor");

        /// <summary>
        /// tracing member
        /// </summary>
        private readonly TraceMessage _trace =
            new TraceMessage("PMED", "ParameterEditor");

        /// <summary>
        /// <see cref="TraceMessage"/> object for tracing messages.
        /// Generation of dump of ParameterEditorDto 
        /// in JSON format will be enabled based on this trace channel
        /// </summary>
        private readonly TraceMessage _traceDto = new TraceMessage(
            "ParameterEditor",
            "ParameterEditorDto");
        /// <summary>
        /// Instance of ParameterEditorDto
        /// </summary>
        private ParameterEditorDto parameterEditor = null;

        /// <summary>
        /// 
        /// </summary>
        private bool _disposed = false;


        /// <summary>
        /// Holds the undo track
        /// </summary>
        private bool _skipAddToStack = false;

        /// <summary>
        /// Holds the Delta ScanProtocol,ScanInfo and their MetaData info.
        /// </summary>
        private IKVPDocument _deltaKVPNode;

        /// <summary>
        /// Dictionary of Parameter Stacks. It holds Stack number to Parameter map
        /// </summary>
        private List<ParameterEditorStack> _parameterStacks = new List<ParameterEditorStack>();

        /// <summary>
        /// Current Parameter Stack
        /// </summary>
        private int _currentParameterStack = -1;

        /// <summary>
        /// Instance of Parameter Group Factory to create instances of Parameter group using factory
        /// </summary>
        private ParameterGroupFactory _parameterGroupFactory;

        /// <summary>
        /// This is the list of custom groups which need to be added
        /// Custom groups are "ScanInfoBarParameterGroup" and  "InfoParameterGroup"
        /// </summary>
        private readonly IList<GroupInfo> _customGroups = new List<GroupInfo>();


        private SerializableDictionary<string, BaseParameterDto> _scanInfoSerializableDictionary = new SerializableDictionary<string, BaseParameterDto>();

        /// <summary>
        /// Last activated group Id
        /// </summary>
        private int _lastActiveGroupId = -1;

        /// <summary>
        /// last non conflicted group id
        /// </summary>
        private int _lastNonConflictedGroupId = -1;

        /// <summary>
        /// flag to identify whether last non conflicted group is filled or not.
        /// </summary>
        private bool _lastNonConflictedGroupFilled = false;

        /// <summary>
        /// Local variable to maintain all parameter groups information
        /// </summary>
        List<GroupInfo> _allGroups = new List<GroupInfo>();

        /// <summary>
        /// Local variable to maintain all lazy load groups information
        /// </summary>
        List<GroupInfo> _lazyGroups = new List<GroupInfo>();

        /// <summary>
        /// Conflict Info Dto
        /// </summary>
        private ConflictInfoDto _conflictInfoData;

        /// <summary>
        /// Coil selection info dto member
        /// </summary>
        private CoilSelectionDto _coilSelectionDto;

        /// <summary>
        /// ParameterEditorDto variable
        /// </summary>
        private ParameterEditorDto _editorDto;

        /// <summary>
        /// Constant to store default suggestion
        /// </summary>
        private const string DefaultSuggestion = "String.ScanDashboardUI.ConflictGuidanceView.DefaultSuggestion";

        /// <summary>
        /// Constant to store ascii value of A
        /// </summary>
        private const int AsciiForA = 65;

        /// <summary>
        /// objLock for thread safety
        /// </summary>
        private readonly object _objLock = new object();

        #endregion

        /// <summary>
        /// IScanProtocalWrapper - Wrapper class for holding all scan protocol related to method calls
        /// </summary>
        private IScanProtocalWrapper _scanProtocalWrapper;

        /// <summary>
        /// Holds the instance of ValidationContextWrapper.
        /// </summary>
        private readonly ValidationContextWrapper _validationContextWrapper = ValidationContextWrapper.Instance;
        /// <summary>
        /// MD Broker instance to start the ParameterEditor service
        /// </summary>
        private IBroker _parameterEditorBroker;

        /// <summary>
        /// Local field to maintain either all groups are loaded or not loaded
        /// </summary>
        private bool _allGroupsNotLoaded;

        private StringVector _tabNames;
        private StringVector TabNames => _tabNames ?? (_tabNames = _currentParameterSessionInfo?.ScanProtocolMetaData?.GetTabNames());

        /// <summary>
        /// Usermessaging instance
        /// </summary>
        private IUserMessaging _userMessage;


        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        public ParameterEditor(IUnityContainer container)
        {
            container.RegisterInstance(this as IParameterEditor, new ExternallyControlledLifetimeManager());
            XmlParseUtility.InitializeXmlParse();


            if (!container.IsRegistered<IScanProtocalWrapper>())
            {
                container.RegisterType<IScanProtocalWrapper, ScanProtocalWrapper>(new ContainerControlledLifetimeManager());
            }
            _scanProtocalWrapper = container.Resolve<IScanProtocalWrapper>();
            _parameterGroupFactory = container.Resolve<ParameterGroupFactory>();
            InitializeService(container);
            //Initialize custom groups of parameter editor
            InitializeCustomGroups();
            _userMessage = container.Resolve<IUserMessaging>();
            TextResourceUtility.Register(InformationModel.CultureResourcesFile, InformationModel.CultureAssemblyName);
        }

        #endregion

        #region IPlanEditor implementation


        /// Occurs when the parametereditor encounters an error that it cannot 
        /// handle and editing of current protocol should be cancelled.
        public event EventHandler ErrorOccured;
        /// <summary>
        /// Holds the ScanProtocol,ScanInfo and their MetaData info.
        /// </summary>
        private ParameterSessionInfo _currentParameterSessionInfo;

        /// <summary>
        /// Holds the last non conflicted state
        /// </summary>
        private IKVPDocument _lastNonConflictKvpDocument;


        /// <summary>
        /// Notify about conflict occured/resolved
        /// </summary>
        public event Action<bool> ConflictInfoUpdated;

        /// <summary>
        /// Notify PatientEngine that ScanProtocol is updated in edit session.
        /// </summary>
        public event EventHandler<IScanProtocol> ScanProtocolChanged;
        /// <summary>
        /// Based on the ParameterSessionInfo IsEditMode bool ParameterEditor will decide to show the parameters in view/edit mode.
        /// </summary>      
        /// <param name="currentParameterSessionInfo"></param>
        public void StartSession(ParameterSessionInfo currentParameterSessionInfo)
        {
            _log.Info($"StartSession  called  for Session Id :{currentParameterSessionInfo?.GetHashCode()} " +
                      $"For Scan Protocol {currentParameterSessionInfo?.ScanProtocol?.GetHashCode()} " +
                      $"With Edit Mode {currentParameterSessionInfo?.IsEditMode} " +
                      $"With IsInConflict {currentParameterSessionInfo?.IsInConflict}");
            PerformanceLoggingUtil.Enter("OPEN_PROTOCOL", "StartSession");
            _log.Info("::PERF_PAR_PERF_OPEN_PROTOCOL.ENTER");

            _tabNames = null;
            _currentParameterSessionInfo = null;
            _currentParameterStack = 0;
            _parameterStacks.Clear();
            if (currentParameterSessionInfo?.ScanProtocol == null)
            {
                _log.Info("Exiting the start session as parameter session info or scan protocol is null");
                return;
            }

            _currentParameterSessionInfo = currentParameterSessionInfo;

            if (!_currentParameterSessionInfo.IsInConflict)
            {
                _lastNonConflictKvpDocument = _currentParameterSessionInfo.ScanProtocol.Clone();
            }
            else
            {
                _lastNonConflictedGroupId = _lastActiveGroupId != (int)GroupIds.Conflicts
                    ? _lastActiveGroupId
                    : _lastNonConflictedGroupId;
                _lastActiveGroupId = (int)GroupIds.Conflicts;
                // When the new scan protocol is already in conflicted state, reset _lastNonConflictKvpDocument
                _lastNonConflictKvpDocument?.Dispose();
                _lastNonConflictKvpDocument = null;
            }

            _lastNonConflictedGroupId =
                _lastNonConflictedGroupId == -1 ? (int)GroupIds.Geometry : _lastNonConflictedGroupId;
            _editorDto = new ParameterEditorDto
            {
                ActiveGroupId = GetActiveGroupId(),
                ConflictPresent = _currentParameterSessionInfo.IsInConflict
            };

            // Assign conflictPresent to ConflictSaved when conflict already present in protocol.
            _editorDto.ConflictSaved = _editorDto.ConflictPresent;
            _log.Info($" _editorDto.ConflictSaved - {_editorDto.ConflictSaved}");

            if (_traceDto.Enabled)
            {
                //It dumps current scan protocol to file in Json Format 
                _currentParameterSessionInfo.DumpScanProtocol();
            }

            GetAllGroups();

            if (_currentParameterSessionInfo.IsEditMode)
            {
                AddStack(_currentParameterSessionInfo, true);
            }

            SetDefaultActiveGroup();

            PopulateInitialParameterEditorDto();

            PerformanceLoggingUtil.Exit();
            _log.Info("StartSession.EXIT");
        }

        private void AddStack(ParameterSessionInfo currentParameterSessionInfo, bool isInitialStack = false)
        {
            _log.Info("AddStack.Enter");
            if (currentParameterSessionInfo.IsEditMode)
            {
                ParameterEditorStack stack = new ParameterEditorStack();
                stack.StackId = _currentParameterStack;
                if (isInitialStack)
                {
                    if (currentParameterSessionInfo?.BaselineProtocol == null)
                    {
                        _log.Info("ParameterSessionInfo's BaselineProtocol property is null");
                        return;
                    }

                    _deltaKVPNode = currentParameterSessionInfo.BaselineProtocol.Clone();
                }

                stack.KvpDocument = currentParameterSessionInfo.ScanProtocol.Clone();

                stack.ActiveGroupId = GetActiveGroupId();
                _parameterStacks.Add(stack);
            }

            _log.Info("AddStack.Exit");
        }

        /// <summary>
        /// Sets the modified scanProtocolMetaData corresponding to updated scanProtocol or change in Validation Context so that ParameterEditor can refresh the UI.
        /// </summary>
        /// <param name="parameterSessionInfo"></param>      
        public void RefreshSession(ParameterSessionInfo parameterSessionInfo)
        {
            _log.Info($"Refresh Session called  for Session Id :{parameterSessionInfo?.GetHashCode()} " +
                    $"For Scan Protocol {parameterSessionInfo?.ScanProtocol?.GetHashCode()} " +
                    $"With Edit Mode {parameterSessionInfo?.IsEditMode} " +
                    $"With IsInConflict {parameterSessionInfo?.IsInConflict} ");
            PerformanceLoggingUtil.Enter("OPEN_PROTOCOL", "RefreshSession");
            if (parameterSessionInfo?.ScanProtocol == null)
            {
                _log.Info("Exiting the refresh session as parameter session info or scan protocol is null");
                return;
            }

            _tabNames = null;
            _currentParameterSessionInfo = parameterSessionInfo;

            if (!_currentParameterSessionInfo.IsInConflict && _currentParameterSessionInfo.IsEditMode)
            {
                _lastNonConflictKvpDocument?.Dispose();
                _lastNonConflictKvpDocument = null;
                _lastNonConflictKvpDocument = _currentParameterSessionInfo.ScanProtocol.Clone();
            }
            else
            {
                _log.Info("PERF_PAR_DISPLAY_SUGGESTION.ENTER");
            }


            _editorDto = new ParameterEditorDto
            {
                ActiveGroupId = GetActiveGroupId(),
                ConflictPresent = _currentParameterSessionInfo.IsInConflict
            };

            if (_skipAddToStack)
            {
                _skipAddToStack = false;
            }
            else if (_currentParameterSessionInfo.IsEditMode)
            {
                if (_parameterStacks.Count == 0)
                {
                    AddStack(_currentParameterSessionInfo, true);
                }
                else
                {
                    AddToUndoRedoResetStack();
                }
            }

            if (_traceDto.Enabled)
            {
                //It dumps current scan protocol to file in Json Format 
                _currentParameterSessionInfo.DumpScanProtocol();
            }
            GetAllGroups();
            PopulateInitialParameterEditorDto();
            PerformanceLoggingUtil.Exit();
            _log.Info("RefreshSession.EXIT");
        }


        /// <summary>
        /// To inform Parameter Editor that View or Edit session is ended.
        /// </summary>
        public void EndSession()
        {
            PerformanceLoggingUtil.Enter("OPEN_PROTOCOL", "EndSession");
            PopulateInitialParameterEditorDto();
            ErrorOccured?.Invoke(this, null);
            _editorDto = null;
            PerformanceLoggingUtil.Exit();
        }
        /// <summary>
        /// Update the ScanProtocol with modified values
        /// </summary>
        public void UpdateScanProtocol()
        {
            _log.Info("Raise UpdateScanProtocol event");
            ScanProtocolChanged?.Invoke(this, _currentParameterSessionInfo?.ScanProtocol);
        }

        /// <summary>
        /// Clear session 
        /// </summary>
        public void ClearSession()
        {
            _log.Info("ClearSession.ENTER");
            ResetSession();
            ParameterEditorUpdated?.Invoke(this, new ParameterEditorUpdateArgs(null, true));
            _log.Info("ClearSession.EXIT");
        }


        /// <summary>
        /// ResetSession
        /// </summary>
        public void ResetSession()
        {
            _log.Info("ResetSession.ENTER");
            _currentParameterStack = 0;
            _parameterStacks.Clear();
            _currentParameterSessionInfo = null;
            _tabNames = null;
            _deltaKVPNode?.Dispose();
            _deltaKVPNode = null;
            _lastNonConflictKvpDocument?.Dispose();
            _lastNonConflictKvpDocument = null;
            _editorDto = null;
            _log.Info("ResetSession.EXIT");
        }

        /// <summary>
        /// SetActive - Set parameter editor activate/deactivate for modifications
        /// </summary>
        /// <param name="isActive">true/false</param>
        public void SetActive(bool isActive)
        {
            _log.Info($"UpdateParameterEditorState.ENTER With State {isActive}");
            ParameterEditorEnabled?.Invoke(this, isActive);
            _log.Info("UpdateParameterEditorState.ENTER");
        }


        #endregion

        #region IParameterEditor implementation

        /// <summary>
        /// Event to communicate new ParameterEditorDto on PDF update
        /// </summary>
        public event EventHandler<ParameterEditorUpdateArgs> ParameterEditorUpdated;

        /// <summary>
        /// Event to enable or disable parameter editor
        /// </summary>
        public event EventHandler<bool> ParameterEditorEnabled;


        /// <summary>
        /// Update the parameter change to PDF
        /// </summary>
        /// <param name="paramId">Modified parameter id</param>
        /// <param name="newValues">New values for Parameter</param>
        public void SetParameter(string paramId, Array newValues)
        {
            PerformanceLoggingUtil.Enter("UPDATE_PARAMETER", "SetParameter");
            if (StaticInvoke.Instance.InvokeRequired)
            {
                _trace.Info(
                    "Thread[{0}]: SetParameter: Invoke is required",
                    Thread.CurrentThread.GetHashCode());
                StaticInvoke.Instance.BeginInvoke(new Action<string, Array>(SetParameter), new object[] { paramId, newValues });

            }
            else
            {
                _log.Info("SetParameter {0} : Enter.", paramId);

                if (_currentParameterSessionInfo != null)
                {
                    var newValueType = newValues.GetType().GetElementType().ToString();
                    _log.Info("Firing SetParameter.");
                    switch (newValueType)
                    {

                        case "System.Single":
                            SetCurrentFloatParameter(paramId, newValues);
                            break;
                        case "System.Int32":
                            SetCurrentIntParameter(paramId, newValues);
                            break;
                        case "System.String":
                            SetCurrentStringParameter(paramId, newValues);
                            break;
                        default:
                            break;
                    }
                    UpdateScanProtocol();
                }

                _log.Info("SetParameter : Exit.", paramId);
            }
            PerformanceLoggingUtil.Exit();
        }

        private void AddToUndoRedoResetStack()
        {
            _trace.Info("AddToUndoRedoResetStack.ENTER");
            _trace.Info($"{"oldstack : " + (_currentParameterStack.ToString())}");
            _currentParameterStack = _currentParameterStack + 1;
            if (_parameterStacks.Any(x => x.StackId == _currentParameterStack))
            {
                for (int i = _currentParameterStack; i <= _parameterStacks.Max(k => k.StackId); i++)
                {
                    _parameterStacks.Remove(_parameterStacks.FirstOrDefault(x => x.StackId == i));
                }

                AddStack(_currentParameterSessionInfo);
            }
            else
            {
                AddStack(_currentParameterSessionInfo);
            }

            _trace.Info($"{"newstack : " + (_currentParameterStack.ToString())}");

            foreach (var item in _parameterStacks)
            {
                _trace.Info($"{"newstackkey : " + (item.StackId.ToString())}");
            }
            _trace.Info("AddToUndoRedoResetStack.EXIT");
        }

        private void SetCurrentFloatParameter(string paramId, Array newValues)
        {
            _trace.Info("SetCurrentFloatParameter.ENTER");
            if (newValues.Length > 1)
            {
                FloatVector listNewVals = new FloatVector(newValues);
                IKVPValueType value = new IKVPValueType(listNewVals);
                IKVPValueType valueSingle = new IKVPValueType(value);
                _log.Info($"{paramId} : {newValues}");
                _currentParameterSessionInfo.ScanProtocol.GetChildByPath(paramId).SetValue(valueSingle);
                _currentParameterSessionInfo.ScanProtocol.SetCurrentParameter(paramId);
            }
            else
            {
                var newValueSingle = (float)newValues.GetValue(0);
                IKVPValueType valueSingle = new IKVPValueType(newValueSingle);
                _log.Info($"{paramId} : {newValueSingle}");
                _currentParameterSessionInfo.ScanProtocol.GetChildByPath(paramId).SetValue(valueSingle);
                _currentParameterSessionInfo.ScanProtocol.SetCurrentParameter(paramId);
            }
            _trace.Info("SetCurrentFloatParameter.EXIT");
        }



        private void SetCurrentIntParameter(string paramId, Array newValues)
        {
            _trace.Info("SetCurrentIntParameter.ENTER");
            if (newValues.Length > 1)
            {
                IntVector listNewVals = new IntVector(newValues);
                IKVPValueType value = new IKVPValueType(listNewVals);
                IKVPValueType valueInt = new IKVPValueType(value);
                _log.Info($"{paramId} : {newValues}");
                _currentParameterSessionInfo.ScanProtocol.GetChildByPath(paramId).SetValue(valueInt);
                _currentParameterSessionInfo.ScanProtocol.SetCurrentParameter(paramId);
            }
            else
            {
                var newValueInt = (int)newValues.GetValue(0);
                IKVPValueType valueInt = new IKVPValueType(newValueInt);
                _log.Info($"{paramId} : {newValueInt}");
                _currentParameterSessionInfo.ScanProtocol.GetChildByPath(paramId).SetValue(valueInt);
                _currentParameterSessionInfo.ScanProtocol.SetCurrentParameter(paramId);
            }
            _trace.Info("SetCurrentIntParameter.EXIT");
        }

        private void SetCurrentStringParameter(string paramId, Array newValues)
        {
            _trace.Info("SetCurrentStringParameter.ENTER");
            if (newValues.Length > 1)
            {
                StringVector listNewVals = new StringVector(newValues);
                IKVPValueType value = new IKVPValueType(listNewVals);
                IKVPValueType valueString = new IKVPValueType(value);
                _log.Info($"{paramId} : {newValues}");
                _currentParameterSessionInfo.ScanProtocol.GetChildByPath(paramId).SetValue(valueString);
                _currentParameterSessionInfo.ScanProtocol.SetCurrentParameter(paramId);
            }
            else
            {
                var newValueString = (string)newValues.GetValue(0);
                IKVPValueType valueString = new IKVPValueType(newValueString);
                _log.Info($"{paramId} : {newValueString}");
                _currentParameterSessionInfo.ScanProtocol.GetChildByPath(paramId).SetValue(valueString);
                _currentParameterSessionInfo.ScanProtocol.SetCurrentParameter(paramId);
            }
            _trace.Info("SetCurrentStringParameter.EXIT");
        }

        /// <summary>
        /// Update the current active group when user switched to new tab on UI to 
        /// populate new group
        /// </summary>
        /// <param name="groupId"></param>
        public void SetActiveGroup(int groupId)
        {
            _log.Info("SetActiveGroup.ENTER");
            PerformanceLoggingUtil.Enter("OPEN_PROTOCOL", "SetActiveGroup");

            //Store active group id
            _lastActiveGroupId = groupId;

            _lastNonConflictedGroupId = _currentParameterSessionInfo != null && !_currentParameterSessionInfo.IsInConflict ? _lastActiveGroupId : _lastNonConflictedGroupId;

            _log.Info("SetActiveGroup in dto {0}.", _lastActiveGroupId);
            if (_editorDto != null)
            {

                _editorDto.ActiveGroupId = _lastActiveGroupId;

            }
            PerformanceLoggingUtil.Exit();
            _log.Info("SetActiveGroup.EXIT");
        }

        /// <summary>
        /// Method to set parameter after resolving conflict.
        /// </summary>
        /// <param name="parameterId"> parameterId of the parameter to be set</param>
        /// <param name="newValue">The value to be set to the parameter</param>
        private void SetResolvedParameter(string parameterId, float newValue)
        {
            try
            {
                _trace.Info("SetResolvedParameter.ENTER");
                _trace.Info($"SetResolvedParameter() - ParameterId : {parameterId} : new value: {newValue}");
                var type = _currentParameterSessionInfo.ScanProtocol.GetChildByPath(parameterId).GetDataTypeInfo();

                IKVPValueType value = null;

                switch (type)
                {
                    case TypeInfo.TypeEnum:
                        var valueEnum = Convert.ToInt32(newValue);
                        value = new IKVPValueType(valueEnum);
                        break;

                    case TypeInfo.TypeFloat:
                        var valueFloat = Convert.ToSingle(newValue);
                        value = new IKVPValueType(valueFloat);
                        break;

                    case TypeInfo.TypeInteger:
                        var valueInt = Convert.ToInt32(newValue);
                        value = new IKVPValueType(valueInt);
                        break;

                    case TypeInfo.TypeString:
                        var valueString = Convert.ToString(newValue);
                        value = new IKVPValueType(valueString);
                        break;
                    default:
                        value = null;
                        break;
                }

                if (value != null)
                {
                    _currentParameterSessionInfo.ScanProtocol.GetChildByPath(parameterId).SetValue(value);
                    _currentParameterSessionInfo.ScanProtocol.SetCurrentParameter(parameterId);
                }
                else
                {
                    _log.Info($"No value retrieved for the parameterId : {parameterId}");
                }

                _trace.Info("SetResolvedParameter.EXIT");
            }
            catch (Exception ex)
            {
                _log.Error($"SetResolvedParameter() Error : {ex.Message} Stack: {ex.StackTrace}");
                throw;
            }
        }


        /// <summary>
        /// SetAdvanceParameterState
        /// </summary>
        /// <param name="advanceParameterOpenState"></param>
        public void SetAdvanceParameterState(bool advanceParameterOpenState)
        {
            _log.Info($"SetAdvanceParameterState.Enter With AdvanceParameterOpenState : {advanceParameterOpenState} and all groups not loaded : {_allGroupsNotLoaded}");
            if (advanceParameterOpenState && _allGroupsNotLoaded && _editorDto != null)
            {
                PopulateFullParameterEditorDto();
            }
            _log.Info("SetAdvanceParameterState.Exit");
        }

        /// <summary>
        /// Reset all Parameters 
        /// </summary>     
        public void ResetAll()
        {
            PerformanceLoggingUtil.Enter("PERF_SCANMODIFICATION_RESETALL", "Time taken to Reset All Changes");
            _log.Info("ResetAll.Enter");
            if (StaticInvoke.Instance.InvokeRequired)
            {
                _trace.Info(
                    "Thread[{0}]: ResetAll: Invoke is required",
                    Thread.CurrentThread.GetHashCode());
                StaticInvoke.Instance.BeginInvoke(new Action(ResetAll), new object[] { });
            }
            else
            {
                if (!IsSessionActive()) return;
                lock (_objLock)
                {
                    _log.Info($"{"oldstack reset : " + (_currentParameterStack.ToString())}");
                    _currentParameterSessionInfo.ScanProtocol.ApplyDelta(_deltaKVPNode);
                    _currentParameterStack = _currentParameterStack + 1;

                    if (_parameterStacks.Any(x => x.StackId == _currentParameterStack))
                    {
                        for (int i = _currentParameterStack; i <= _parameterStacks.Max(k => k.StackId); i++)
                        {
                            _parameterStacks.Remove(_parameterStacks.FirstOrDefault(x => x.StackId == i));
                        }

                        AddStack(_currentParameterSessionInfo);
                    }
                    else
                    {
                        AddStack(_currentParameterSessionInfo);
                    }

                    _log.Info($"{"reset newstack : " + (_currentParameterStack.ToString())}");

                    foreach (var item in _parameterStacks)
                    {
                        _log.Info($"{"reset newstackkey : " + (item.StackId.ToString())}");
                    }

                    _skipAddToStack = true;
                    UpdateScanProtocol();
                }
            }
            _log.Info("ResetAll.Exit");
            PerformanceLoggingUtil.Exit();
        }

        /// <summary>
        /// Resolve the given conflict using the suggestion provided
        /// </summary>
        /// <param name="conflictKey">Conflict key</param>
        /// <param name="suggestionKey">Suggestion Key</param>
        public void ResolveConflict(string conflictKey, string suggestionKey)
        {
            _log.Info("ResolveConflict.ENTER");
            _trace.Info($"Entering ResolveConflict() : SuggestionKey : {suggestionKey} : conflictKey : {conflictKey}");
            _log.Info($"currentParameterSessionInfo Hash Code : {_currentParameterSessionInfo?.GetHashCode()} - " +
                $"  Scan protocalMetadata Hash Code : {_currentParameterSessionInfo?.ScanProtocolMetaData?.GetHashCode()} - scanProtocalWrapper hashcode : {_scanProtocalWrapper?.GetHashCode()}");
            try
            {

                if (StaticInvoke.Instance.InvokeRequired)
                {
                    _trace.Info(
                        "Thread[{0}]: ResolveConflict: Invoke is required",
                        Thread.CurrentThread.GetHashCode());
                    StaticInvoke.Instance.BeginInvoke(new Action<string, string>(ResolveConflict), new object[] { conflictKey, suggestionKey });
                }
                else
                {
                    if (!IsSessionActive()) return;

                    _trace.Info("ResolveConflict(). Enter If invoke not required");

                    // If restore to previous values clicked, get the last non conflicted state
                    if (suggestionKey.Equals(DefaultSuggestion))
                    {
                        _log.Info("Restore to previous values clicked");
                        //Took the last non conflicted state and applied to currentParameterSessionInfo
                        _currentParameterSessionInfo.ScanProtocol.ApplyDelta(_lastNonConflictKvpDocument);
                        UpdateScanProtocol();
                        return;
                    }

                    SuggestionStruct suggestionData =
                        _scanProtocalWrapper.GetSuggestions(_currentParameterSessionInfo.ConflictGuidanceInfo).
                            SingleOrDefault(s => _scanProtocalWrapper.GetParameterStructSuggestionKey(s) == suggestionKey);
                    // Get the parameters from the suggestion data. For handling TICS warning to avoid usage of as done some changes here.

                    var parameterstructs = _scanProtocalWrapper.GetConflictGuidanceParameterStructs(suggestionData);
                    if (parameterstructs != null)
                    {
                        var parameters = parameterstructs.ToList();
                        if (parameters != null && parameters.Count > 0)
                        {
                            foreach (var parameter in parameters)
                            {
                                var paramId = _scanProtocalWrapper.GetParameterStructParameterId(parameter);
                                var suggestedValue =
                                    _scanProtocalWrapper.GetParameterStructSuggestedValue(parameter);
                                SetResolvedParameter(paramId, suggestedValue);
                            }
                        }
                    }
                    else
                    {
                        _log.Info($"Error in ResolveConflict() : Either _scanProtocalWrapper is null or Conflict guidance parameter structs returns null suggestions. _scanProtocalWrapper : {_scanProtocalWrapper} - parameterstructs: {parameterstructs}");
                        _log.Info($"currentParameterSessionInfo HashCode : {_currentParameterSessionInfo?.GetHashCode()} - ScanprotocolMetadata HashCode : {_currentParameterSessionInfo?.ScanProtocolMetaData?.GetHashCode()} - scanProtocalWrapper hashcode : {_scanProtocalWrapper?.GetHashCode()}");
                        //Dump scan protocol and scan protocol metadata into json file
                        _currentParameterSessionInfo.DumpScanProtocol();
                        //Dump entire Parameter Session Info object into json file
                        _currentParameterSessionInfo.DumpParameterSessionInfo(suggestionKey);
                    }
                    _trace.Info("Exiting ResolveConflict method successfully");
                    UpdateScanProtocol();
                }

            }
            catch (Exception e)
            {
                _log.Error($"Error in Parameter Editor:ResolveConflict method : {e}");
                DisplayPlanningAbortedMessage(InformationModel.ConflictErrorText);
                ErrorOccured?.Invoke(this, null);
            }
            finally
            {
                _log.Info("ResolveConflict.EXIT");
            }
        }

        /// <summary>
        /// Method to set smart select.
        /// </summary>
        /// <param name="isSmartSelect">Boolean value for smart select</param>
        public void SetSmartSelect(bool isSmartSelect)
        {
            try
            {
                _log.Info($"SetSmartSelect.ENTER : IsSmartSelect : {isSmartSelect}");
                if (!IsSessionActive()) return;
                if (isSmartSelect)
                {
                    _currentParameterSessionInfo.ScanProtocol?
                        .DisableStackSelect();
                }

                _currentParameterSessionInfo.ScanProtocol?
                    .SetAutoCoilSelect(isSmartSelect); // set whether smart or not
                UpdateScanProtocol();
            }
            catch (Exception ex)
            {
                _log.Error($"Error in SetSmartSelect() : Error message : {ex.Message} - Error trace: {ex.StackTrace}");
                throw;
            }
            finally
            {
                _log.Info("SetSmartSelect.EXIT");
            }
        }

        /// <summary>
        /// Method to set stack select.
        /// </summary>
        /// <param name="isStackSelect">Boolean value for stack select</param>
        public void SetStackSelect(bool isStackSelect)
        {
            try
            {
                _log.Info($"SetStackSelect.ENTER : isStackSelect : {isStackSelect}");
                if (!IsSessionActive()) return;
                if (isStackSelect)
                {
                    _currentParameterSessionInfo.ScanProtocol?
                        .SetAutoCoilSelect(!isStackSelect);

                    _currentParameterSessionInfo.ScanProtocol?
                        .EnableStackSelect();
                }
                else
                {
                    _currentParameterSessionInfo.ScanProtocol?
                        .DisableStackSelect();
                }

                UpdateScanProtocol();
            }
            catch (Exception ex)
            {
                _log.Error($"Error in SetStackSelect() : Error message : {ex.Message} - Error trace: {ex.StackTrace}");
                throw;
            }
            finally
            {
                _log.Info("SetStackSelect.EXIT");
            }
        }
        /// <summary>
        /// Method to set the coil in a stack
        /// </summary>
        /// <param name="stackIndex">The index of stack modified</param>
        /// <param name="stackDetails">Object of type StackDetailsDto</param>
        public void SetStackCoilSelection(uint stackIndex, StackDetailsDto stackDetails)
        {
            try
            {
                if (!IsSessionActive()) return;
                _log.Info($"SetStackCoilSelection.ENTER: stackIndex : {stackIndex}");
                var coilLogic = GetCoilLogic(_validationContextWrapper);
                var coilDetails = stackDetails?.CoilStackDetailsCollection;
                int stackCount = _coilSelectionDto.StackCount;

                // When both smart select and stack select is off, apply changes to all stacks
                if (!_coilSelectionDto.IsSmartSelect && !_coilSelectionDto.IsStackSelect)
                {
                    for (uint index = 0; index < stackCount; index++)
                    {
                        var selectedCoilList = new CoilSelectionElements();
                        SetSelectedCoilForSingleStack(coilDetails, index, coilLogic, selectedCoilList);
                    }
                }
                else
                {
                    var selectedCoilList = new CoilSelectionElements();
                    SetSelectedCoilForSingleStack(coilDetails, stackIndex, coilLogic, selectedCoilList);
                }

                UpdateScanProtocol();
            }
            catch (Exception ex)
            {
                _log.Error(
                    $"Error in SetStackCoilSelection() : Error message : {ex.Message} : Error stack : {ex.StackTrace}");
                throw;
            }
            finally
            {
                _log.Info("SetStackCoilSelection.EXIT");
            }
        }

        /// <summary>
        /// Method to set coil for one stack
        /// </summary>
        /// <param name="coilDetails"></param>
        /// <param name="stackIndex"></param>
        /// <param name="coilLogic"></param>
        /// <param name="selectedCoilList"></param>
        private void SetSelectedCoilForSingleStack(ObservableCollection<CoilDetailsDto> coilDetails, uint stackIndex,
            ICoilLogic coilLogic, CoilSelectionElements selectedCoilList)
        {
            var coilSelection =
                _currentParameterSessionInfo.ScanProtocol?.GetCoilSelectionStack(stackIndex, coilLogic);

            GetSelectedCoilsFromDto(coilDetails, selectedCoilList, coilSelection);
            coilSelection?.SetSelectedCoilElements(selectedCoilList);
            _currentParameterSessionInfo.ScanProtocol?.SetCoilSelectionStack(stackIndex, coilSelection,
                coilLogic);
        }

        /// <summary>
        /// Method to get the selected coils from the dto passed from UI
        /// </summary>
        /// <param name="coilDetails">Collection of type CoilDetailsDto</param>
        /// <param name="selectedCoilList">Collection of type string</param>
        /// <param name="coilSelection">Coil</param> 
        private void GetSelectedCoilsFromDto(ObservableCollection<CoilDetailsDto> coilDetails, CoilSelectionElements selectedCoilList, ICoilSelection coilSelection)
        {
            _trace.Info("GetSelectedCoilsFromDto.ENTER");
            var selectedElements = coilSelection.GetSelectedCoilElements();
            IEnumerable<CoilDetailsDto> coilList = coilDetails.Where(c => c.IsCoilSelected);
            _log.Info($"GetSelectedCoilsFromDto: coilList items :count ={coilList.Count()}");

            var connectedCoils = _validationContextWrapper.GetConnectedCoils();
            ArrayList newConnectedCoilsList = new ArrayList();

            // Create ConnectedWFCoil type from connected coils
            foreach (AGDEF_IRF_CONN_COIL_STRUCT coil in connectedCoils)
            {
                _log.Info($"GetSelectedCoilsFromDto: coilName={coil.coil_name} path={coil.conn_path}");
                ConnectedWFCoil coilswf = new ConnectedWFCoil();
                coilswf.id = coil.coil_name;
                coilswf.path = coil.conn_path;
                coilswf.inUse = coil.in_bore;
                newConnectedCoilsList.Add(coilswf);
            }

            ArrayList selectedWfCoilList = new ArrayList();
            foreach (ConnectedWFCoil item in newConnectedCoilsList)
            {
                if (coilList.Any(s => s.CoilName == item.id))
                {
                    _log.Info($"GetSelectedCoilsFromDto:selectedWfCoilList - coilName={item.id}");
                    selectedWfCoilList.Add(item);
                }
            }

            _log.Info($"GetSelectedCoilsFromDto: newConnectedCoilsList.count = {newConnectedCoilsList.Count}");

            var coilCombination = Philips.PmsMR.Methods.CoilLogic.CoilLogicFactory.GetCoilCombination();
            coilCombination.SetConnectedCoils(newConnectedCoilsList);
            GetListOfCoilsToBeSet(coilCombination, selectedWfCoilList, selectedCoilList);
            _trace.Info("GetSelectedCoilsFromDto.EXIT");
        }

        /// <summary>
        /// Method to get the list of coils to be set
        /// </summary>
        /// <param name="coilCombination">ICoilCombination object</param>
        /// <param name="selectedWfCoilList">ConnectedWFCoil type collection</param>
        /// <param name="selectedCoilList">CoilSelectionElements type collection</param>
        private void GetListOfCoilsToBeSet(ICoilCombination coilCombination, ArrayList selectedWfCoilList, CoilSelectionElements selectedCoilList)
        {
            try
            {
                _trace.Info("GetListOfCoilsToBeSet.ENTER");
                // Get clinical modes
                ClinicalMode[] clinicalFilteredModes = coilCombination?.GetFilteredClinicalModes(selectedWfCoilList);
                _log.Info($"GetListOfCoilsToBeSet: clinicalFilteredModes count= {clinicalFilteredModes?.Count()}");
                if (clinicalFilteredModes?.Length > 0)
                {
                    foreach (var item in clinicalFilteredModes)
                    {
                        _log.Info($"GetListOfCoilsToBeSet: clinicalModeName= {item.Name}");

                        GetClinicalModesSelections(item, selectedCoilList);
                    }

                    _log.Info($"GetListOfCoilsToBeSet: selectedCoilList={selectedCoilList.Count}");
                }
            }
            catch (Exception ex)
            {
                _log.Error($"GetListOfCoilsToBeSet: exception: {ex.Message} stacktrace: {ex.StackTrace}");
            }
            _trace.Info("GetListOfCoilsToBeSet.EXIT");
        }

        /// <summary>
        /// Method to get the selections from clinical mode and set to CoilSelectionElements list
        /// </summary>
        /// <param name="clinicalMode">ClinicalMode object</param>
        /// <param name="selectedCoilList">CoilSelectionElements type collection to save the coils to be set</param>
        private void GetClinicalModesSelections(ClinicalMode clinicalMode, CoilSelectionElements selectedCoilList)
        {
            try
            {
                _trace.Info("GetClinicalModesSelections.ENTER");
                var selections = clinicalMode.Selections;
                for (int selection = 0; selection < selections.Length; selection++)
                {
                    _log.Info($"GetClinicalModesSelections: Items in clinical modes selection - coilName={selections[selection].CoilID} path={selections[selection].SocketPath}");
                    for (int el = 0; el < selections[selection].ElementIds.Length; el++)
                    {
                        CoilSelectionElement elem = new CoilSelectionElement();
                        elem.coil = selections[selection].CoilID;
                        elem.socket = selections[selection].SocketPath;
                        elem.channel = selections[selection].ElementIds[el];
                        selectedCoilList.Add(elem);
                        _log.Info($"GetClinicalModesSelections: elements count= {selections[selection].ElementIds.Count()}: elem name ={selections[selection].ElementIds[el]}");
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error($"GetClinicalModesSelections: exception : {ex.StackTrace}");
            }
            _trace.Info("GetClinicalModesSelections.EXIT");
        }

        /// <summary>
        /// Undo Parameter
        /// </summary>    
        public void UndoParameter()
        {
            PerformanceLoggingUtil.Enter("UPDATE_PARAMETER", "UndoParameter");
            _log.Info("UndoParameter.ENTER");
            if (StaticInvoke.Instance.InvokeRequired)
            {
                _trace.Info(
                    "Thread[{0}]: UndoParameter: Invoke is required",
                    Thread.CurrentThread.GetHashCode());
                StaticInvoke.Instance.BeginInvoke(new Action(UndoParameter), new object[] { });
            }
            else
            {
                if (_currentParameterStack != -1)
                {

                    lock (_objLock)
                    {
                        _log.Info($"{"oldstack undo : " + (_currentParameterStack.ToString())}");
                        _currentParameterStack = _currentParameterStack - 1;
                        IKVPDocument undoParameterDelta = _parameterStacks
                            .FirstOrDefault(x => x.StackId == _currentParameterStack)?.KvpDocument;


                        if (undoParameterDelta != null)
                        {
                            _currentParameterSessionInfo.ScanProtocol.ApplyDelta(undoParameterDelta);

                            _log.Info($"{"undo newstack : " + (_currentParameterStack.ToString())}");

                            foreach (var item in _parameterStacks)
                            {
                                _log.Info($"{"undo newstackkey : " + (item.StackId.ToString())}");
                            }

                            _skipAddToStack = true;
                            UpdateScanProtocol();
                        }
                        else
                        {
                            _log.Info($"{"undo else : " + (_currentParameterStack.ToString())}");
                            _currentParameterStack = _currentParameterStack + 1;
                        }
                    }
                }
            }

            _log.Info("UndoParameter.EXIT");
            PerformanceLoggingUtil.Exit();
        }

        /// <summary>
        /// Redo Parameter
        /// </summary>    
        public void RedoParameter()
        {
            PerformanceLoggingUtil.Enter("UPDATE_PARAMETER", "RedoParameter");
            _log.Info("RedoParameter.ENTER");
            if (StaticInvoke.Instance.InvokeRequired)
            {
                _trace.Info(
                    "Thread[{0}]: RedoParameter: Invoke is required",
                    Thread.CurrentThread.GetHashCode());
                StaticInvoke.Instance.BeginInvoke(new Action(RedoParameter), new object[] { });
            }
            else
            {
                lock (_objLock)
                {
                    if (_currentParameterStack != -1)
                    {
                        _log.Info($"{"oldstack redo : " + (_currentParameterStack.ToString())}");
                        _currentParameterStack = _currentParameterStack + 1;
                        IKVPDocument redoParameterDelta = _parameterStacks
                            .FirstOrDefault(x => x.StackId == _currentParameterStack)?.KvpDocument;

                        if (redoParameterDelta != null)
                        {
                            _currentParameterSessionInfo.ScanProtocol.ApplyDelta(redoParameterDelta);

                            _log.Info($"{"redo newstack : " + (_currentParameterStack.ToString())}");

                            foreach (var item in _parameterStacks)
                            {
                                _log.Info($"{"redo newstackkey : " + (item.StackId.ToString())}");
                            }

                            _skipAddToStack = true;
                            UpdateScanProtocol();
                        }
                        else
                        {
                            _log.Info($"{"redo else : " + (_currentParameterStack.ToString())}");
                            _currentParameterStack = _currentParameterStack - 1;
                        }
                    }
                }
            }
            _log.Info("RedoParameter.Exit");
            PerformanceLoggingUtil.Exit();
        }

        /// <summary>
        /// Get Initial Model method implementation
        /// </summary>    
        public void GetInitialModel()
        {
            if (StaticInvoke.Instance.InvokeRequired)
            {
                _trace.Info("Thread[{0}]: GetInitialModel: Invoke is required", Thread.CurrentThread.GetHashCode());
                StaticInvoke.Instance.BeginInvoke(new Action(GetInitialModel), new object[] { });
            }
            else
            {
                _trace.Info("GetInitialModel : Enter");
                if (_editorDto != null)
                {
                    PopulateInitialParameterEditorDto();
                    ParameterEditorUpdated?.Invoke(this, new ParameterEditorUpdateArgs(_editorDto, true));
                }
                _trace.Info("GetInitialModel : Exit");
            }

        }
        #endregion

        #region Dispose Pattern

        /// <summary>
        /// Dispose method
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Dispose pattern
        /// </summary>
        /// <param name="disposing">
        /// Information if the object is being disposed by GC or user triggered.
        /// </param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (_parameterEditorBroker != null)
                    {
                        _parameterEditorBroker.Stop();
                        _parameterEditorBroker.Dispose();
                        _parameterEditorBroker = null;
                    }
                    ResetSession();
                    _scanProtocalWrapper = null;
                    _parameterGroupFactory = null;
                    TextResourceUtility.UnRegister(InformationModel.CultureResourcesFile);
                }
                _disposed = true;
            }
        }

        #endregion



        #region private methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupCode"></param>
        /// <returns></returns>
        private ParameterGroupDto CreateParameterGroupDto(string groupCode)
        {
            var parameterGroup = _parameterGroupFactory.GetParameterGroup(_currentParameterSessionInfo, groupCode);

            parameterGroup.Active = true;
            ParameterGroupDto parameterGroupDto = parameterGroup.PopulateGroup();
            SetConflictPresent(parameterGroupDto);
            foreach (var item in parameterGroupDto.Parameters)
            {
                if (!_scanInfoSerializableDictionary.ContainsKey(item.Key))
                {
                    _scanInfoSerializableDictionary.Add(item.Key, item.Value);
                }
            }
            return parameterGroupDto;
        }

        private void SetConflictPresent(ParameterGroupDto parameterGroupDto)
        {
            if (_currentParameterSessionInfo.IsInConflict)
            {
                //Get Conflict Parameters
                StringVector conflictParameters = new StringVector();
                conflictParameters = _currentParameterSessionInfo.ScanProtocolMetaData.GetConflictParameters();
                foreach (var conflictParameter in conflictParameters)
                {
                    if (parameterGroupDto.Parameters.ContainsKey(conflictParameter))
                    {
                        _editorDto.ConflictPresent = true;
                        parameterGroupDto.ConflictPresent = true;
                        break;
                    }
                }
            }
        }

        private IList<GroupInfo> GetAllGroups()
        {
            _trace.Info("GetAllGroups.ENTER");
            var tabNames = _currentParameterSessionInfo.ScanProtocolMetaData.GetTabNames();
            parameterEditor = new ParameterEditorDto();
            _scanInfoSerializableDictionary.Clear();
            _allGroups.Clear();
            foreach (var tabName in tabNames)
            {
                GroupInfo grp = new GroupInfo();
                if (_parameterGroupFactory.TabMappings.ContainsKey(tabName))
                {
                    grp.id = _parameterGroupFactory.TabMappings[tabName];
                }
                else
                {
                    grp.id = (int)GroupIds.None;
                }

                grp.name = _scanProtocalWrapper.GetUINameForTabName(tabName);
                grp.Code = tabName;
                if (!_allGroups.Exists(x => x.id == grp.id) && grp.id != (int)GroupIds.InfoParameterGroupId)
                {
                    _allGroups.Add(grp);
                }
            }

            _allGroups.AddRange(_customGroups);
            _trace.Info("GetAllGroups.EXIT");
            return _allGroups;
        }

        /// <summary>
        /// This initializes the list of custom groups which need to be added
        /// Custom groups are "ScanInfoBarParameterGroup" and  "InfoParameterGroup"
        /// </summary>
        private void InitializeCustomGroups()
        {
            //Add ScanInfoBar groups
            _customGroups.Add(new GroupInfo()
            {
                id = (int)GroupIds.ScanInfoParameterGroupId,
                name = "ScanInfoBarGroup",
            });
            //Add InfoParameter group
            _customGroups.Add(new GroupInfo() { id = (int)GroupIds.InfoParameterGroupId, name = "InfoParameters", Code = InformationModel.MggSoftkeyInfo });
        }


        /// <summary>
        /// Set default active group. It will set to the last active group if it is set.
        /// otherwise it will set to routine group if it is enabled
        /// if routine group is not there it will set to initial group
        /// </summary>
        private void SetDefaultActiveGroup()
        {
            //If parameter group has Geometry, display Geometry as default group

            if (_allGroups.Exists(x => x.id == (int)GroupIds.Geometry))
            {
                // set it to Routine
                if (_lastActiveGroupId == -1)
                {
                    _lastActiveGroupId = (int)GroupIds.Geometry;
                }
            }
            else if (_allGroups.Exists(x => x.id == (int)GroupIds.Postproc))
            {
                //Set to Delayed Recon
                _lastActiveGroupId = (int)GroupIds.Postproc;
            }
            else
            {
                //by default set it to initial
                _lastActiveGroupId = (int)GroupIds.Initial;
            }
            _editorDto.ActiveGroupId = _lastActiveGroupId;
        }


        /// <summary>
        /// Get current active group Id
        /// </summary>
        private int GetActiveGroupId()
        {
            return _lastActiveGroupId;
        }

        private void PopulateInitialParameterEditorDto()
        {
            _log.Info("PopulateInitialParameterEditorDto.ENTER");
            PerformanceLoggingUtil.Enter("OPEN_PROTOCOL", "PopulateInitialParameterEditorDto_forloopForGroups");
            ParameterGroupsHelper.Clear();
            _lazyGroups.Clear();

            if (!IsSessionActive())
            {
                return;
            }
            //Check if conflict is present. In case if conflict exists then fire event to Notify Planning Component about same
            ConflictInfoUpdated?.Invoke(_currentParameterSessionInfo.IsInConflict);
            //Get the list of parameter groups
            IList<ParameterGroupDto> parameterGroupDtos = new List<ParameterGroupDto>();

            //Fill scan info bar group parameters
            FillScanInfoBar();
            //Fill information group parameters
            FillInfoGroup();
            //Fill active group parameters
            FillActiveGroup(parameterGroupDtos);
            //Fill Physio group parameters
            FillPhysioGroup(parameterGroupDtos);
            //Fill summary active group parameters
            FillSummaryActiveGroup(parameterGroupDtos);
            // Fill last non conflicted Group dto incase of conflict
            FillLastNonConflictedGroup(parameterGroupDtos);

            //Fill Parameter Groups
            FillParameterGroups(parameterGroupDtos);

            //Update ParameterGroups in ParameterEditorDto
            if (parameterGroupDtos.Count > 0)
            {
                //Sort ParameterGroupDto by the view index order and assign it to ParameterEditorDto
                _editorDto.ParameterGroups =
                    new ObservableCollection<ParameterGroupDto>(parameterGroupDtos.OrderBy(x => x.Index));
            }
            else
            {
                _editorDto.ParameterGroups = new ObservableCollection<ParameterGroupDto>();
            }


            // Fill ConflictInfoDto
            LoadConflictInfoToDto();
            //SetUndoRedo
            SetUndoRedo(_currentParameterSessionInfo.IsEditMode);

            //Fill coil selection information
            LoadCoilSelectionToDto();

            if (_traceDto.Enabled)
            {
                //It dumps current dto to file in Json Format 
                ParameterEditorDtoSerializer.Dump(_editorDto);
            }

            _log.Info($"Raise ParameterEditorUpdated {this.GetHashCode()}");

            //Notify for ParameterEditorDto update
            _allGroupsNotLoaded = true;
            ParameterEditorUpdated?.Invoke(this, new ParameterEditorUpdateArgs(_editorDto, true));
            PerformanceLoggingUtil.Exit();
            ParameterGroupsHelper.Clear();
            _log.Info("PopulateInitialParameterEditorDto.EXIT");

        }

        /// <summary>
        /// fill parameter groups 
        /// </summary>
        /// <param name="parameterGroupDtos"></param>
        private void FillParameterGroups(IList<ParameterGroupDto> parameterGroupDtos)
        {
            foreach (var group in _allGroups)
            {
                if (group.id != (int)GroupIds.InfoParameterGroupId &&
                    group.id != (int)GroupIds.ScanInfoParameterGroupId &&
                    group.id != (int)GroupIds.Physio &&
                    group.id != (int)GroupIds.Summary &&
                    group.id != _lastActiveGroupId)
                {
                    if (group.id == _lastNonConflictedGroupId && _lastNonConflictedGroupFilled) continue;
                    var parameterGroupDto = new ParameterGroupDto();
                    parameterGroupDto.GroupId = group.id;
                    parameterGroupDto.Index = ParameterGroupIdToIndexConverter.Convert(group.id);
                    parameterGroupDto.Name = group.name;
                    parameterGroupDto.Parameters = new SerializableDictionary<string, BaseParameterDto>();
                    parameterGroupDtos.Add(parameterGroupDto);
                    _lazyGroups.Add(group);
                }
            }
        }

        private void FillSummaryActiveGroup(IList<ParameterGroupDto> parameterGroupDtos)
        {
            _trace.Info("FillSummaryActiveGroup.ENTER");
            var groupDto = CreateParameterGroupDtoById((int)GroupIds.Summary);
            if (groupDto != null)
            {
                parameterGroupDtos.Add(groupDto);
            }
            _trace.Info("FillSummaryActiveGroup.EXIT");
        }

        private void FillPhysioGroup(IList<ParameterGroupDto> parameterGroupDtos)
        {
            _trace.Info("FillPhysioGroup.ENTER");
            var groupDto = CreateParameterGroupDtoById((int)GroupIds.Physio);
            if (groupDto != null)
            {
                parameterGroupDtos.Add(groupDto);
            }
            _trace.Info("FillPhysioGroup.EXIT");
        }

        private void FillActiveGroup(IList<ParameterGroupDto> parameterGroupDtos)
        {
            _trace.Info("FillActiveGroup.ENTER");
            var groupDto = CreateParameterGroupDtoById(_lastActiveGroupId);
            _trace.Info($"last active group {_lastActiveGroupId}");
            if (groupDto != null)
            {
                parameterGroupDtos.Add(groupDto);
                _trace.Info($"last active group filled {_lastActiveGroupId}");
            }
            _trace.Info("FillActiveGroup.EXIT");
        }

        /// <summary>
        /// method to fill last conflicted group id in case of conflict
        /// </summary>
        /// <param name="parameterGroupDtos"></param>
        private void FillLastNonConflictedGroup(IList<ParameterGroupDto> parameterGroupDtos)
        {
            _trace.Info("FillLastNonConflictedGroup.ENTER");
            _lastNonConflictedGroupFilled = false;
            _trace.Info($"last non conflicted group {_lastNonConflictedGroupId}");
            var groupDto = _lastNonConflictedGroupId != -1 && _lastNonConflictedGroupId != _lastActiveGroupId ?
                CreateParameterGroupDtoById(_lastNonConflictedGroupId) : null;
            if (groupDto != null)
            {
                parameterGroupDtos.Add(groupDto);
                _lastNonConflictedGroupFilled = true;
                _trace.Info($"last non conflicted group filled {_lastNonConflictedGroupId}");
            }
            _trace.Info("FillLastNonConflictedGroup.EXIT");
        }

        private void FillInfoGroup()
        {
            _trace.Info("FillInfoGroup.ENTER");
            var infoGroupCode = _allGroups.FirstOrDefault(x => x.id == (int)GroupIds.InfoParameterGroupId).Code;
            if (Convert.ToString(infoGroupCode) != string.Empty && TabNames.Contains(infoGroupCode))
            {
                var infoParameterGroupDto = CreateParameterGroupDto(infoGroupCode);
                _editorDto.InfoParameterGroupDto = infoParameterGroupDto;
            }
            _trace.Info("FillInfoGroup.EXIT");
        }

        private ParameterGroupDto CreateParameterGroupDtoById(int groupId)
        {
            var activeGroupCode = _allGroups.FirstOrDefault(x => x.id == groupId);
            ParameterGroupDto groupDto = null;
            if (!(activeGroupCode.Equals(default(GroupInfo))))
            {
                groupDto = CreateParameterGroupDto(activeGroupCode.Code);
                activeGroupCode.parameterCount = groupDto.Parameters.Count;
                groupDto.Index = ParameterGroupIdToIndexConverter.Convert(groupId);
            }
            return groupDto;
        }

        private void PopulateFullParameterEditorDto()
        {
            _log.Info("PopulateFullParameterEditorDto.ENTER");
            PerformanceLoggingUtil.Enter("OPEN_PROTOCOL", "PopulateFullParameterEditorDto_forloopForGroups");

            if (!IsSessionActive())
            {
                _allGroupsNotLoaded = false;
                return;
            }

            //Get the list of parameter groups
            IList<ParameterGroupDto> parameterGroupDtos = new List<ParameterGroupDto>();

            //Fill Parameter Groups
            foreach (var group in _lazyGroups)
            {
                var activeGroupDto = CreateParameterGroupDto(group.Code);
                parameterGroupDtos.Add(activeGroupDto);
            }

            //Update ParameterGroups in ParameterEditorDto
            if (parameterGroupDtos.Count > 0)
            {
                //Sort ParameterGroupDto by the view index order and assign it to ParameterEditorDto
                _editorDto.ParameterGroups =
                    new ObservableCollection<ParameterGroupDto>(parameterGroupDtos.OrderBy(x => x.Index));
            }
            else
            {
                _editorDto.ParameterGroups = new ObservableCollection<ParameterGroupDto>();
            }



            if (_traceDto.Enabled)
            {
                //It dumps current dto to file in Json Format 
                ParameterEditorDtoSerializer.Dump(_editorDto);
            }

            _log.Info("Raise ParameterEditorUpdated with full");

            //Notify for ParameterEditorDto update
            _allGroupsNotLoaded = false;
            ParameterEditorUpdated?.Invoke(this, new ParameterEditorUpdateArgs(_editorDto, false));


            PerformanceLoggingUtil.Exit();
            _log.Info("PopulateFullParameterEditorDto.EXIT");

        }

        private bool IsSessionActive()
        {
            if (_editorDto == null)
            {
                _log.Info("Exiting from PopulateFullParameterEditorDto method as editorDto is null");
                return false;
            }

            if (_currentParameterSessionInfo == null)
            {
                _log.Info("Exiting from PopulateFullParameterEditorDto method as parameter session info is null");
                return false;
            }

            if (_currentParameterSessionInfo?.ScanProtocol == null)
            {
                _log.Info("Exiting from PopulateFullParameterEditorDto method as scan protocol is null");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Method to load the coil selection information from scan protocol
        /// </summary>
        private void LoadCoilSelectionToDto()
        {
            _trace.Info("LoadCoilSelectionToDto.ENTER");
            try
            {
                _trace.Info("Entering LoadCoilSelectionDto()");

                if (_currentParameterSessionInfo?.ScanProtocol != null)
                {
                    var smartSelect = _currentParameterSessionInfo.ScanProtocol.GetAutoCoilSelect();

                    _coilSelectionDto = new CoilSelectionDto
                    {
                        StackCount = _currentParameterSessionInfo.ScanProtocol.GetNrStacks(),
                        IsSmartSelect = smartSelect,
                        IsStackSelect = _currentParameterSessionInfo.ScanProtocol.IsStackSelectEnabled() //stack select
                    };
                    _trace.Info($"LoadCoilSelectionDto() : Stack count: " +
                              $"{_coilSelectionDto.StackCount} Is smart select: " +
                              $"{_coilSelectionDto.IsSmartSelect} IstackSelect : {_coilSelectionDto.IsStackSelect}");


                    //Get stack and coil information
                    var stackDetailsInfo = GetStackAndCoilInfo();
                    _coilSelectionDto.StackCollection = stackDetailsInfo;
                    _editorDto.CoilSelectionInfoDto = _coilSelectionDto;
                }
            }
            catch (Exception ex)
            {
                _log.Error($"LoadCoilSelectionDto() : {ex.Message} - stack trace - {ex.StackTrace}");
                throw;
            }
            finally
            {
                _trace.Info("LoadCoilSelectionToDto.EXIT");
            }
        }

        /// <summary>
        /// Method to get coil and stack details from scan protocol
        /// </summary>
        private ObservableCollection<StackDetailsDto> GetStackAndCoilInfo()
        {
            _trace.Info("GetStackAndCoilInfo.ENTER");
            int stackCount = _coilSelectionDto.StackCount;
            var stackDetailsInfo = new ObservableCollection<StackDetailsDto>();
            // iterating through stacks
            for (uint stackIndex = 0; stackIndex < stackCount; ++stackIndex)
            {
                try
                {
                    var coilStackDetailsInfo = new ObservableCollection<CoilDetailsDto>();
                    var frameOfReference = _validationContextWrapper?.GetFrameOfReference();
                    var coilSelection =
                        _currentParameterSessionInfo.ScanProtocol.GetCoilSelectionStack(stackIndex,
                            GetCoilLogic(_validationContextWrapper));


                    //Get stack details
                    var stackDetailsDtoInfo = GetStackDetails(stackIndex);

                    //If frame of reference is available, use GetConnectedCoils
                    _trace.Info($"Frame of reference: {frameOfReference.ToString()}");
                    if (!string.IsNullOrEmpty(frameOfReference))
                    {
                        var connectedCoils = _validationContextWrapper.GetConnectedCoils();

                        // Check if coils are selected
                        bool coilsAreSelected = _currentParameterSessionInfo.ScanProtocol.GetStackAutoCoilsSelected(stackIndex);

                        //When smart select is on and auto coils are not selected
                        if (_currentParameterSessionInfo.ScanProtocol.GetAutoCoilSelect() && !coilsAreSelected)
                        {
                            var coilLogic = _validationContextWrapper.GetCoilLogic();
                            GetConnectedCoilInfoWhenSmartMode(coilLogic, connectedCoils, coilStackDetailsInfo, stackIndex);
                        }
                        else
                        {
                            GetConnectedCoilsInfoWhenStackMode(coilSelection, connectedCoils, stackIndex,
                                coilStackDetailsInfo);
                        }
                    }
                    else
                    {
                        // If frame of reference not defined, use GetCoils().
                        var coils = _scanProtocalWrapper.GetCoils(_currentParameterSessionInfo.ScanProtocol,
                            GetCoilLogic(_validationContextWrapper));
                        GetCoilInfo(coilSelection, coils, coilStackDetailsInfo, stackIndex);
                    }

                    stackDetailsDtoInfo.CoilStackDetailsCollection = coilStackDetailsInfo;
                    _trace.Info($"after adding to stack details - coilstackdetailsinfo = {coilStackDetailsInfo.Count}");

                    stackDetailsInfo.Add(stackDetailsDtoInfo);
                }
                catch (Exception ex)
                {
                    _log.Error($"GetStackAndCoilInfo: exception: {ex.Message} stacktrace: {ex.StackTrace}");
                    DisplayPlanningAbortedMessage(InformationModel.EmptyCoilText);
                }
            }
            _trace.Info("GetStackAndCoilInfo.EXIT");
            return stackDetailsInfo;
        }

        /// <summary>
        /// Display Planning Aborted Message
        /// </summary>
        private void DisplayPlanningAbortedMessage(string planningAbortedMessageText)
        {
            UserMessageInterruptionLevel interruptionLevel = UserMessageInterruptionLevel.Medium;
            TextUserMessage planningAbortedMessage = new TextUserMessage(UserMessageCategory.Information, interruptionLevel);
            planningAbortedMessage.Title = TextResourceUtility.Instance?.GetString(InformationModel.PlanningAborted);
            planningAbortedMessage.Text = TextResourceUtility.Instance?.GetString(planningAbortedMessageText);
            _userMessage.Send(planningAbortedMessage);
        }

        /// <summary>
        /// Method to get the connected coils when smart select mode is on and auto coils are not selected
        /// </summary>
        /// <param name="coilSelection">ICoilSelection object</param>
        /// <param name="connectedCoils">Connected coils arrayList</param>
        /// <param name="stackIndex">stack index</param>
        /// <param name="coilStackDetailsInfo">collection of coils dto</param>
        private void GetConnectedCoilsInfoWhenStackMode(ICoilSelection coilSelection, IList connectedCoils, uint stackIndex, ObservableCollection<CoilDetailsDto> coilStackDetailsInfo)
        {
            _trace.Info("GetConnectedCoilsInfoWhenStackMode.ENTER");
            var selectedElements = coilSelection.GetSelectedCoilElements();
            var coilLogic = GetCoilLogic(_validationContextWrapper);
            int coilSelectionMode = _validationContextWrapper.ValidationContext.GetIntegerValue(InformationModel.CoilUiSelectionMode);
            _trace.Info($"GetConnectedCoilsInfoWhenStackMode - SelectedElements count - {selectedElements.Count()}");
            foreach (var item in selectedElements)
            {
                _trace.Info($"GetConnectedCoilsInfoWhenStackMode - SelectedElement coilName - {item.coil }");
            }

            // Iterate and get coil information for each stack
            foreach (AGDEF_IRF_CONN_COIL_STRUCT coil in connectedCoils)
            {
                var coilProperties = coilLogic.GetCoilProperties(coil.coil_name);
                var coilDetails = new CoilDetailsDto()
                {
                    CoilName = coil.coil_name,
                    CoilUIName = coilProperties.GetInstallName(),
                    ConnectorName = coil.conn_path.Split('/').Last(),
                    StackIndex = stackIndex,
                    IsCoilSelected = selectedElements.Any(s => s.coil == coil.coil_name),
                    IsCoilSelectable = coilSelectionMode == InformationModel.RestrictedMode ?
                        coilProperties.GetManualSelectable() : true
                };
                _trace.Info($"GetConnectedCoilsInfoWhenStackMode() - Coil name : {coilDetails.CoilName}, CoilUIName : {coilDetails.CoilUIName},Connector name : {coilDetails.ConnectorName }, IsCoilSelected :  {coilDetails.IsCoilSelected}");
                coilStackDetailsInfo.Add(coilDetails);
            }
            _trace.Info("GetConnectedCoilsInfoWhenStackMode.EXIT");
        }
        /// <summary>
        /// Method to get stack details from scan protocol
        /// </summary>
        /// <param name="stackIndex">Stack index</param>
        /// <returns>StackDetailsDto object</returns>
        private StackDetailsDto GetStackDetails(uint stackIndex)
        {
            _trace.Info("GetStackDetails.ENTER");
            // Getting stack information. Using index as stack name for now.
            int stackCount = _coilSelectionDto.StackCount;
            var stackDetailsDtoInfo = new StackDetailsDto();

            // When only one stack present no stack name will be shown
            if (stackCount > 1)
            {
                stackDetailsDtoInfo.StackIndex = stackIndex;
                stackDetailsDtoInfo.StackName = $"{(char)(AsciiForA + stackIndex)}";
                _trace.Info($"GetStackDetails() - Stack Name : {stackDetailsDtoInfo.StackName}");
            }
            _trace.Info("GetStackDetails.EXIT");
            return stackDetailsDtoInfo;
        }

        /// <summary>
        /// Method to get coil information for each stack
        /// </summary>
        /// <param name="coilSelection">ICoilSelection object</param>
        /// <param name="coils">Coils type object</param>
        /// <param name="coilStackDetailsInfo">Collection ofCoilDetailsDto</param>
        /// <param name="stackIndex">Stack index</param>
        private void GetCoilInfo(ICoilSelection coilSelection, Coils coils, ObservableCollection<CoilDetailsDto> coilStackDetailsInfo, uint stackIndex)
        {
            _trace.Info("GetCoilInfo.ENTER");
            var selectedElements = coilSelection.GetSelectedCoilElements();
            _trace.Info($"GetCoilInfo() SelectedElementsCount : {selectedElements.Count} ,Coil Count : {coils.Count}");
            var coilLogic = GetCoilLogic(_validationContextWrapper);
            int coilSelectionMode = _validationContextWrapper.ValidationContext.GetIntegerValue(InformationModel.CoilUiSelectionMode);

            // Iterate and get coil information for each stack
            foreach (var coil in coils)
            {
                var coilProperties = coilLogic.GetCoilProperties(coil.GetName());
                var coilDetails = new CoilDetailsDto()
                {
                    CoilName = coil.GetName(),
                    CoilUIName = coilProperties.GetInstallName(),
                    ConnectorName = coil.GetSocket().Split('/').Last(),
                    StackIndex = stackIndex,
                    IsCoilSelected = selectedElements.Any(s => s.coil == coil.GetName()),
                    IsCoilSelectable = coilSelectionMode == InformationModel.RestrictedMode ?
                        coilProperties.GetManualSelectable() : true
                };
                coilStackDetailsInfo.Add(coilDetails);
                _trace.Info($"GetCoilInfo() - Coil name : {coilDetails.CoilName},CoilUIName : {coilDetails.CoilUIName}, Connector name : {coilDetails.ConnectorName }, IsCoilSelected :  {coilDetails.IsCoilSelected}");
            }
            _trace.Info("GetCoilInfo.EXIT");
        }

        /// <summary>
        /// Method to get connected coil information for each stack
        /// </summary>
        /// <param name="coilLogic">ICoilLogic object</param>
        /// <param name="connectedCoils">ConnectedCoilsVector type object</param>
        /// <param name="coilStackDetailsInfo">Collection ofCoilDetailsDto</param>
        /// <param name="stackIndex">Stack index</param>
        private void GetConnectedCoilInfoWhenSmartMode(ICoilLogic coilLogic, IList connectedCoils, ObservableCollection<CoilDetailsDto> coilStackDetailsInfo, uint stackIndex)
        {

            _trace.Info("GetConnectedCoilInfoWhenSmartMode.ENTER");
            // Iterate and get coil information for each stack
            foreach (AGDEF_IRF_CONN_COIL_STRUCT coil in connectedCoils)
            {
                var coilProperties = coilLogic.GetCoilProperties(coil.coil_name);
                var coilDetails = new CoilDetailsDto()
                {
                    CoilName = coil.coil_name,
                    CoilUIName = coilProperties.GetInstallName(),
                    ConnectorName = coil.conn_path.Split('/').Last(),
                    StackIndex = stackIndex,
                    IsCoilSelected = coilProperties.GetAutoSelectable(),
                    IsCoilSelectable = false
                };
                _log.Info($"GetConnectedCoilInfoWhenSmartMode() - Coil name : {coilDetails.CoilName},CoilUIName : {coilDetails.CoilUIName}, Connector name : {coilDetails.ConnectorName }, IsCoilSelected :  {coilDetails.IsCoilSelected}");
                coilStackDetailsInfo.Add(coilDetails);
            }
            _trace.Info("GetConnectedCoilInfoWhenSmartMode.EXIT");
        }
        /// <summary>
        /// Method to Load the conflict info from parameterSessionInfo to ConflictInfoDto
        /// </summary>
        private void LoadConflictInfoToDto()
        {
            _trace.Info("LoadConflictInfoToDto.ENTER");
            try
            {
                _trace.Info("Entering LoadConflictInfoToDto()");
                ObservableCollection<SuggestionInfoDto> suggestionData = new ObservableCollection<SuggestionInfoDto>();

                //Get conflict information 
                if (_currentParameterSessionInfo?.ConflictGuidanceInfo == null) return;
                _conflictInfoData = new ConflictInfoDto
                {
                    ConflictKey = _scanProtocalWrapper.GetConflictKey(_currentParameterSessionInfo.ConflictGuidanceInfo)
                };

                if (_currentParameterSessionInfo.ConflictGuidanceInfo.suggestionInfo != null &&
                    _scanProtocalWrapper.GetSuggestionInfoCount(_currentParameterSessionInfo.ConflictGuidanceInfo) > 0)
                {

                    var suggestionCollection =
                        _scanProtocalWrapper.GetConflictGuidanceSuggestions(_currentParameterSessionInfo
                            .ConflictGuidanceInfo);
                    if (suggestionCollection != null)
                    {
                        _trace.Info("Suggestions to resolve conflict are as shown below");
                        _trace.Info($"suggestionCount - {suggestionCollection.Count}");
                        foreach (var item in suggestionCollection)
                        {
                            LoadSuggestionInfo(item, suggestionData);
                            _trace.Info($"Suggestion {suggestionData.Count} - {(suggestionData.Count > 0 ? suggestionData[suggestionData.Count - 1].SuggestionText : string.Empty)}");
                        }
                    }
                }

                if (_lastNonConflictKvpDocument != null)
                {
                    AddDefaultSuggestion(suggestionData);
                }

                _conflictInfoData.SuggestionInfoCollection = suggestionData;
                _trace.Info($"Suggestion Count = {_conflictInfoData.SuggestionInfoCollection.Count}");
                _editorDto.ConflictInfoData = _conflictInfoData;
            }
            catch (Exception e)
            {
                _log.Error($"Error in LoadConflictInfoToDto() : {e.Message}");
                throw;
            }
            finally
            {
                _trace.Info("LoadConflictInfoToDto.EXIT");
            }
        }

        /// <summary>
        /// Method to load correct suggestion information
        /// </summary>
        /// <param name="item">SuggestionStruct object</param>
        /// <param name="suggestionData">Collection of SuggestionInfoDto objects</param>
        /// <returns>SuggestionInfoDto</returns>
        private void LoadSuggestionInfo(SuggestionStruct item, ObservableCollection<SuggestionInfoDto> suggestionData)
        {
            _trace.Info("LoadSuggestionInfo.ENTER");
            try
            {
                var valueList = new ArrayList();
                foreach (var paramItem in _scanProtocalWrapper.GetConflictGuidanceParameters(item))
                {
                    var valueType = _scanProtocalWrapper.GetParameterStructType(paramItem);

                    GetSuggestionValueList(valueList, paramItem, valueType);
                }

                _trace.Info(
                    $"suggestionKey Before translate : {_scanProtocalWrapper.GetParameterStructSuggestionKey(item)}");
                var suggestion = new SuggestionInfoDto()
                {
                    SuggestionText =
                        String.Format(UGGITranslator.Instance.TranslateKey(
                            _scanProtocalWrapper.GetParameterStructSuggestionKey(item), valueList)),
                    SuggestionKey = _scanProtocalWrapper.GetParameterStructSuggestionKey(item)
                };

                suggestionData.Add(suggestion);
                _trace.Info($"suggestionKey After translate : {suggestion.SuggestionKey}");
            }
            catch (Exception ex)
            {
                _log.Error($"Suggestion Translation failed - errorMSg - {ex.Message} Stacktrace - {ex.StackTrace}");
                throw;
            }
            finally
            {
                _trace.Info("LoadSuggestionInfo.EXIT");
            }
        }

        /// <summary>
        /// Method to get the suggestion values and add to a list array for translation
        /// </summary>
        /// <param name="valueList">Arraylist of values</param>
        /// <param name="param">ParameterStruct object</param>
        /// <param name="valueType">value type</param>
        private void GetSuggestionValueList(ArrayList valueList, ParameterStruct param, string valueType)
        {
            if (_scanProtocalWrapper.ParameterStructToBeDisplayed(param))
            {
                _trace.Info("GetSuggestionValueList.ENTER");
                switch (valueType)
                {
                    case "System.Single":
                        double value =
                            Convert.ToDouble(_scanProtocalWrapper.GetParameterStructSuggestedValue(param));
                        value = Math.Round(value, 2);
                        _log.Info($"float val = {value}");
                        valueList.Add(new Argument(value));
                        break;
                    case "System.Int32":
                        int intVal = Convert.ToInt32(_scanProtocalWrapper.GetParameterStructSuggestedValue(param));
                        _log.Info($"int val = {intVal}");
                        valueList.Add(new Argument(intVal));
                        break;
                    case "System.String":
                        string strVal = Convert.ToString(_scanProtocalWrapper.GetParameterStructSuggestedValue(param));
                        _log.Info($"string val = {strVal}");
                        valueList.Add(new Argument(strVal));
                        break;
                    default:
                        var parameterMetaData = _currentParameterSessionInfo.ScanProtocolMetaData.GetParameterMetaData(param.parameterId);
                        if (parameterMetaData.GetDataType() == TypeInfo.TypeEnum)
                        {
                            var parameterDto = new EnumParameterDto();
                            ParameterConverter.FillEnumRange(parameterDto, parameterMetaData, _scanProtocalWrapper);
                            var suggestedValue = Convert.ToString(_scanProtocalWrapper.GetParameterStructSuggestedValue(param));
                            valueList.Add(new Argument(parameterDto.Enumerators
                                .FirstOrDefault(x => x.Key == suggestedValue)?.DisplayName));
                        }
                        else
                        {
                            var floatVal = Math.Round(_scanProtocalWrapper.GetParameterStructSuggestedValue(param), 2);
                            valueList.Add(new Argument(floatVal));
                        }

                        break;
                }
                _trace.Info("GetSuggestionValueList.EXIT");
            }
        }

        private void SetUndoRedo(bool isEditMode)
        {
            _trace.Info("SetUndoRedo.ENTER");
            if (isEditMode && _parameterStacks.Count != 0)
            {
                if (_parameterStacks.Max(k => k.StackId) == 0 || _currentParameterStack == 0)
                {
                    _editorDto.CanUndo = false;
                }
                else
                {
                    _editorDto.CanUndo = true;
                }


                if (_currentParameterStack < _parameterStacks.Max(k => k.StackId) && _currentParameterStack != -1)
                {
                    _editorDto.CanRedo = true;
                }
                else
                {
                    _editorDto.CanRedo = false;
                }
                _editorDto.CanReset = true;
            }
            else
            {
                _editorDto.CanUndo = false;
                _editorDto.CanRedo = false;
                _editorDto.CanReset = false;
            }
            _trace.Info("SetUndoRedo.EXIT");
        }

        /// <summary>
        /// Method to add default suggestion to suggestion list
        /// </summary>
        /// <param name="suggestionData"> Observable collection of type SuggestionInfoDto</param>
        private void AddDefaultSuggestion(ObservableCollection<SuggestionInfoDto> suggestionData)
        {
            _trace.Info("AddDefaultSuggestion.ENTER");
            //Create default option
            var suggestion = new SuggestionInfoDto() { SuggestionKey = DefaultSuggestion, SuggestionText = DefaultSuggestion };
            suggestionData.Add(suggestion);
            _trace.Info("AddDefaultSuggestion: Default suggestion added");
            _trace.Info("AddDefaultSuggestion.EXIT");
        }

        private void FillScanInfoBar()
        {
            _trace.Info("FillScanInfoBar.Start");
            //Fill ScanInfobarDto
            if (TabNames.Contains(InformationModel.MggSoftkeyAll) && TabNames.Contains(InformationModel.MggSoftkeyInfo))
            {
                var scanGroup = _parameterGroupFactory.GetScanInfoParameterGroup(_currentParameterSessionInfo);
                _editorDto.ScanInfoBarDto = scanGroup.PopulateGroup();
            }
            else
            {
                var scanGroup = XmlParseUtility.GetXmlGroup((int)GroupIds.ScanInfoParameterGroupId);
                var scanGroupParameterDtos = _scanInfoSerializableDictionary
                    .Where(x => scanGroup.InfoParametersList.Contains(x.Key));

                SerializableDictionary<string, BaseParameterDto> scanInfoParameterDtos =
                    new SerializableDictionary<string, BaseParameterDto>();
                foreach (var scanGroupParameterDto in scanGroupParameterDtos)
                {
                    scanInfoParameterDtos.Add(scanGroupParameterDto.Key, scanGroupParameterDto.Value);
                }

                _editorDto.ScanInfoBarDto = new ParameterGroupDto();
                _editorDto.ScanInfoBarDto.Parameters = new SerializableDictionary<string, BaseParameterDto>();
                _editorDto.ScanInfoBarDto.Parameters = scanInfoParameterDtos;
                _editorDto.ScanInfoBarDto.GroupId = (int)GroupIds.ScanInfoParameterGroupId;
            }
            _trace.Info("FillScanInfoBar.EXIT");
        }

        private ICoilLogic GetCoilLogic(ValidationContextWrapper validationContextWrapper)
        {
            return _scanProtocalWrapper.GetCoilLogic(validationContextWrapper);
        }

        /// <summary>
        /// Initialize the service Layer 
        /// </summary>
        private void InitializeService(IUnityContainer container)
        {
            var parameterEditorCallBack = container.Resolve<ParameterEditorCallbackHost>();
            var messagingService = container.Resolve<IMessagingService>();

            string endPointName = "ParameterEditorBroker";
            if (container.IsRegistered<string>("ParameterEditorBrokerKey"))
            {
                endPointName = container.Resolve<string>("ParameterEditorBrokerKey");
            }
            _parameterEditorBroker = messagingService.Proxy(endPointName).ConvertTo<IBroker>();
            _parameterEditorBroker.BrokerCallback = parameterEditorCallBack;
            _parameterEditorBroker.SynchronizeInvoker = StaticInvoke.Instance;
            _parameterEditorBroker.Start();
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~ParameterEditor()
        {
            Dispose(false);
        }
        #endregion
        //TICS +5@113:


    }
    //TICS +5@113:
}

#region Revision History

// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2019-Jan-14  Naresh Jadapalli
//              Implemented StartSession, RefreshSession, EndSession, ScanProtocolChanged and UpdateScanProtocol.
// 2019-Mar-15  Indira RamaKrishnan
//              ValidationResult Model changed to ParameterSessionInfo
// 2019-May-10  Anu Jothis
//             Populating conflict information to conflictInfDto.
//2019-July-25  Anu Jothis
//              Implemented coil selection. Story Id - 54058

//2019-Aug-27 Anu Jothis
//              Updated code for solving the suggestion translation issue
#endregion Revision History