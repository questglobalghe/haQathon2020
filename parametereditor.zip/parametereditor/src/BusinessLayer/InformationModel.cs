﻿#region (c) Koninklijke Philips Electronics N.V. 2020
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: InformationModel.cs
//
#endregion

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Class for constants
    /// </summary>
    public static class InformationModel
    {
        /// <summary>
        /// IfAbsoluteSNR - IF.absolute_SNR
        /// </summary>
        public const string IfAbsoluteSnr = "IF.absolute_SNR";

        /// <summary>
        /// IfRelativeSnr - IF.relative_SNR
        /// </summary>
        public const string IfRelativeSnr = "IF.relative_SNR";

        /// <summary>
        /// ExGeoCurStackId - "EX_GEO.cur_stack_id"
        /// </summary>
        public const string ExGeoCurStackId = "EX_GEO.cur_stack_id";

        /// <summary>
        /// ExRespUserDefBhTimeSec - "EX_RESP.user_def_bh_time_sec"
        /// </summary>
        public const string ExRespUserDefBhTimeSec = "EX_RESP.user_def_bh_time_sec";

        /// <summary>
        /// ExCardHeartPhaseControl - "EX_CARD.heart_phase_control"
        /// </summary>
        public const string ExCardHeartPhaseControl = "EX_CARD.heart_phase_control";

        /// <summary>
        /// IfNrBreathholds - "IF.nr_breathholds"
        /// </summary>
        public const string IfNrBreathholds = "IF.nr_breathholds";

        /// <summary>
        /// ExCardGateDelayms - "EX_CARD.gate_delay_ms"
        /// </summary>
        public const string ExCardGateDelayms = "EX_CARD.gate_delay_ms";

        /// <summary>
        /// ExDynScanBeginTimesStr - "EX_DYN.scan_begin_times_str"
        /// </summary>
        public const string ExDynScanBeginTimesStr = "EX_DYN.scan_begin_times_str";

        /// <summary>
        /// ExDynScanBlockTimesStr - "EX_DYN.scan_block_times_str"
        /// </summary>
        public const string ExDynScanBlockTimesStr = "EX_DYN.scan_block_times_str";

        /// <summary>
        /// ExDiffNrAveragesStr - "EX_DIFF.nr_averages_str"
        /// </summary>
        public const string ExDiffNrAveragesStr = "EX_DIFF.nr_averages_str";

        /// <summary>
        /// ExDynContrastPhaseNrDyns - "EX_DYN.contrastPhaseNrDyns"
        /// </summary>
        public const string ExDynContrastPhaseNrDyns = "EX_DYN.contrastPhaseNrDyns";

        /// <summary>
        /// ExDynContrastPhaseDuration - "EX_DYN.contrastPhaseDuration"
        /// </summary>
        public const string ExDynContrastPhaseDuration = "EX_DYN.contrastPhaseDuration";

        /// <summary>
        /// ExDynContrastPhaseBeginTimes - "EX_DYN.contrastPhaseBeginTimes"
        /// </summary>
        public const string ExDynContrastPhaseBeginTimes = "EX_DYN.contrastPhaseBeginTimes";

        /// <summary>
        /// ExDiffBFactors - "EX_DIFF.b_factors"
        /// </summary>
        public const string ExDiffBFactors = "EX_DIFF.b_factors";

        /// <summary>
        /// ExDiffNrWeighting - "EX_DIFF.nr_weightings"
        /// </summary>
        public const string ExDiffNrWeighting = "EX_DIFF.nr_weightings";

        /// <summary>
        /// Constant to store restricted mode coil selection UI mode.
        /// </summary>
        public const int RestrictedMode = 0;

        /// <summary>
        /// To get the Coil UI selection mode.
        /// </summary>
        public const string CoilUiSelectionMode = "ControlParameters.CGEN.coil_ui_selection_mode";

        /// <summary>
        /// AllParametersMetaData
        /// </summary>
        public const string MggSoftkeyAll = "MGG_SOFTKEY_ALL";

        /// <summary>
        /// InfoParametersMetaData
        /// </summary>
        public const string MggSoftkeyInfo = "MGG_SOFTKEY_INFO";

        /// <summary>
        /// Geometry table key
        /// </summary>
        public const string GeometryTabKey = "MGG_SOFTKEY_0";

        /// <summary>
        /// Contrast table key
        /// </summary>
        public const string ContrastTabKey = "MGG_SOFTKEY_1";

        /// <summary>
        /// Motion table key
        /// </summary>
        public const string MotionTabKey = "MGG_SOFTKEY_2";

        /// <summary>
        /// DynAng table key
        /// </summary>
        public const string DynAngTabKey = "MGG_SOFTKEY_3";

        /// <summary>
        /// Postproc table key
        /// </summary>
        public const string PostprocTabKey = "MGG_SOFTKEY_4";

        /// <summary>
        /// OffcAng table key
        /// </summary>
        public const string OffcAngTabKey = "MGG_SOFTKEY_5";

        /// <summary>
        /// Initial table key
        /// </summary>
        public const string InitialTabKey = "MGG_SOFTKEY_6";

        /// <summary>
        /// Conflicts table key
        /// </summary>
        public const string ConflictsTabKey = "MGG_SOFTKEY_CONFL";

        /// <summary>
        /// Summary table key
        /// </summary>
        public const string SummaryTabKey = "MGG_SOFTKEY_ROUTINE";

        /// <summary>
        /// Physio table key
        /// </summary>
        public const string PhysioTabKey = "MGG_SOFTKEY_PHYSIO";

        /// <summary>
        /// ScanInfo table key - Custom parameter group
        /// </summary>
        public const string ScanInfoTabKey = "MGG_SOFTKEY_SCANINFO";

        /// <summary>
        /// Other table key
        /// </summary>
        public const string OtherTabKey = "MGG_SOFTKEY_OTHER";

        /// <summary>
        /// parameter EX_GEO.fov
        /// </summary>
        public const string ExGeofov = "EX_GEO.fov";

        /// <summary>
        /// parameter EX_SPY.phase_cycles"
        /// </summary>
        public const string ExSpyPhaseCycles = "EX_SPY.phase_cycles";

        /// <summary>
        /// Parameter EX_ACQ.first_echo_time_enum"
        /// </summary>
        public const string ExAcqFirstEchoTimeEnum = "EX_ACQ.first_echo_time_enum";

        /// <summary>
        /// culture resources file
        /// </summary>
        public const string CultureResourcesFile = "Philips.PmsMR.ParameterEditor.Parametereditor_culture.resources";

        /// <summary>
        /// culture assembly for localization
        /// </summary>
        public const string CultureAssemblyName = "Philips.PmsMR.parametereditor.cultureresources_cs.dll";

         /// <summary>
        ///  Planning Aborted Text
        /// </summary>
        public const string PlanningAborted = "String.ParameterEditor.PanningAborted";

        /// <summary>
        /// Empty Coil Text
        /// </summary>
        public const string EmptyCoilText = "String.ParameterEditor.CoilEmpty";

        /// <summary>
        /// Conflict error text
        /// </summary>
        public const string ConflictErrorText = "String.ParameterEditor.ConflictError";

        /// <summary>
        /// Parameter EX_ACQ.accelerationMethod
        /// </summary>
        public const string AccelerationMethod = "EX_ACQ.accelerationMethod";

        /// <summary>
        /// Parameter EX_GEO.sense_s_red_factor
        /// </summary>
        public const string SenseSRedFactor = "EX_GEO.sense_s_red_factor";

        /// <summary>
        /// Parameter EX_GEO.sense_p_red_factor
        /// </summary>
        public const string SensePRedFactor = "EX_GEO.sense_p_red_factor";

        /// <summary>
        /// Parameter EX_ACQ.cs_factor
        /// </summary>
        public const string CsFactor = "EX_ACQ.cs_factor";
    }
}
#region Revision History
// 2020-Mar-05  Ramanjaneyulu SBV
//              Initial version
#endregion Revision History
