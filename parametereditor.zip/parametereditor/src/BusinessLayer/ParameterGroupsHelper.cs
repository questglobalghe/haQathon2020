﻿#region Copyright Koninklijke Philips Electronics N.V. 2021
//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// FILENAME: ParameterGroupsHelper.cs
//
#endregion

using Philips.PmsMR.Scanning.IMethods;
using System.Collections.Generic;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// ParameterGroupsHelper
    /// </summary>
    public static class ParameterGroupsHelper
    {
        /// <summary>
        /// AllParametersMetaData
        /// </summary>
        public static Dictionary<string, IParameterMetaData> AllParametersMetaData { get; set; }

        /// <summary>
        /// InfoParametersMetaData
        /// </summary>
        public static Dictionary<string, IParameterMetaData> InfoParametersMetaData { get; set; }


        /// <summary>
        /// Clear
        /// </summary>
        public static void Clear()
        {
            AllParametersMetaData = null;
            InfoParametersMetaData = null;
        }
    }
}
#region Revision History
// 2021-Jan-07  Ramanjaneyulu SBV
//              Initial version
#endregion Revision History