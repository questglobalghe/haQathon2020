#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterGroupFactory.cs
//
#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using System.Collections.Generic;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Factory to get instance of Parameter Group for given GroupInfo
    /// </summary>
    public class ParameterGroupFactory
    {
        const string ConstructorParameter = "groupInfo";
        const string ConstructorParameterSessionInfo = "parameterSessionInfo";
        const string ConstructorUiHelper = "uiHelper";

        private readonly IUnityContainer _container;
        private readonly IScanProtocalWrapper _scanProtocalWrapper;

        /// <summary>
        /// 
        /// </summary>
        public Dictionary<string, int> TabMappings { get; }

        private UIHelper uiHelper;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="container"></param>
        public ParameterGroupFactory(IUnityContainer container)
        {
            _container = container;
            _scanProtocalWrapper = _container.Resolve<IScanProtocalWrapper>();
            //ToDo : Need to remove index and use code in both backend and front end code base
            TabMappings = new Dictionary<string, int>()
            {
                {InformationModel.GeometryTabKey, (int)GroupIds.Geometry  },
                {InformationModel.ContrastTabKey, (int)GroupIds.Contrast  },
                {InformationModel.MotionTabKey, (int)GroupIds.Motion  },
                {InformationModel.DynAngTabKey, (int)GroupIds.DynAng },
                {InformationModel.PostprocTabKey, (int)GroupIds.Postproc },
                {InformationModel.OffcAngTabKey, (int)GroupIds.OffcAng },
                {InformationModel.InitialTabKey, (int)GroupIds.Initial },
                {InformationModel.MggSoftkeyAll,(int)GroupIds.Protocols },
                {InformationModel.ConflictsTabKey, (int)GroupIds.Conflicts },
                {InformationModel.SummaryTabKey, (int)GroupIds.Summary },
                {InformationModel.PhysioTabKey, (int)GroupIds.Physio },
                {InformationModel.MggSoftkeyInfo, (int)GroupIds.InfoParameterGroupId },
                {InformationModel.OtherTabKey, (int)GroupIds.Other}
            };

            var langCode = new ScanProtocalWrapper().GetLanguageCode();
            uiHelper = new UIHelper(langCode);
        }

        /// <summary>
        /// Get Scan Info Parameter Group info
        /// </summary>
        /// <param name="parameterSessionInfo">ParameterSessionInfo</param>
        /// <returns></returns>
        public virtual IParameterGroup GetScanInfoParameterGroup(ParameterSessionInfo parameterSessionInfo)
        {
            var groupInfo = new GroupInfo();
            groupInfo.id = (int)GroupIds.ScanInfoParameterGroupId;
            groupInfo.Code = InformationModel.ScanInfoTabKey;
            IParameterGroup group = _container.Resolve<ScanInfoBarParameterGroup>(new ParameterOverride(ConstructorParameter, groupInfo),
                new ParameterOverride(ConstructorParameterSessionInfo, parameterSessionInfo), new ParameterOverride(ConstructorUiHelper, uiHelper));
            return group;
        }



        /// <summary>
        /// Get ParameterGroup for provided group info
        /// </summary>
        /// <param name="parameterSessionInfo">ParameterSessionInfo</param>
        /// <param name="tabName"></param>
        /// <returns></returns>
        public virtual IParameterGroup GetParameterGroup(ParameterSessionInfo parameterSessionInfo, string tabName)
        {
            IParameterGroup group = null;
            GroupIds requestedId;
            if (TabMappings.ContainsKey(tabName))
            {
                requestedId = (GroupIds)TabMappings[tabName];
            }
            else
            {
                requestedId = GroupIds.None;
            }
            //Constructor parameter to resolve instance using parametrized 

            var groupInfo = new GroupInfo();
            groupInfo.id = (int)requestedId;
            groupInfo.Code = tabName;
            groupInfo.name = _scanProtocalWrapper.GetUINameForTabName(tabName);
            switch (requestedId)
            {
                case GroupIds.Physio:
                    group = _container.Resolve<PhysiologyParameterGroup>(new ParameterOverride(ConstructorParameter, groupInfo),
                    new ParameterOverride(ConstructorParameterSessionInfo, parameterSessionInfo), new ParameterOverride(ConstructorUiHelper, uiHelper));
                    break;
                case GroupIds.Summary:
                    group = _container.Resolve<SummaryParameterGroup>(new ParameterOverride(ConstructorParameter, groupInfo),
                        new ParameterOverride(ConstructorParameterSessionInfo, parameterSessionInfo), new ParameterOverride(ConstructorUiHelper, uiHelper));
                    break;
                case GroupIds.InfoParameterGroupId:
                    group = _container.Resolve<InfoParameterGroup>(new ParameterOverride(ConstructorParameter, groupInfo),
                        new ParameterOverride(ConstructorParameterSessionInfo, parameterSessionInfo), new ParameterOverride(ConstructorUiHelper, uiHelper));
                    break;
                case GroupIds.Conflicts:
                    group = _container.Resolve<ConflictParameterGroup>(new ParameterOverride(ConstructorParameter, groupInfo),
                        new ParameterOverride(ConstructorParameterSessionInfo, parameterSessionInfo), new ParameterOverride(ConstructorUiHelper, uiHelper));
                    break;
                default:
                    group = _container.Resolve<ParameterGroup>(new ParameterOverride(ConstructorParameter, groupInfo),
                        new ParameterOverride(ConstructorParameterSessionInfo, parameterSessionInfo), new ParameterOverride(ConstructorUiHelper, uiHelper));
                    break;
            }

            group.TabName = tabName;
            return group;
        }
    }
}
#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2020-May-19  Ramanjaneyulu SBV
//              Handling extra tabs in ScanProtocolMetadata
#endregion Revision History