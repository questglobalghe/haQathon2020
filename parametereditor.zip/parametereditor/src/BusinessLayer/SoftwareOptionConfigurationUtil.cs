#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: SoftwareOptionConfigurationUtil.cs
//

#endregion

using Philips.PmsMR.Platform.Aswglo;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{

    /// <summary>
    /// Utility class for SoftwareOptionConfiguration
    /// </summary>
    public class SoftwareOptionConfigurationUtil : ISoftwareOptionConfigurationUtil
    {
        /// <summary>
        /// Check Option is Available
        /// </summary>
        public virtual bool CheckOptionAvailable()
        {
            bool routineUiOptionEnabled;
            using (SoftwareOptionConfiguration options = new SoftwareOptionConfiguration())
            {
                routineUiOptionEnabled =
                        options.CheckOptionAvailable(Option.AWOPT_ROUTINE);
            }
            return routineUiOptionEnabled;
        }
    }
}

#region Revision History

// 2017-Nov-22  Vivek Saurav
//              Initial version (Story ID- 23086)

#endregion Revision History