#region (c) Koninklijke Philips Electronics N.V. 2018

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: XmlGroup.cs
//

#endregion

using System.Collections.Generic;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Specification for ParameterGroup information which is to be parsed in xml.
    /// </summary>
    public class XmlGroup
    {
        private List<string> _parametersList;
        private List<string> _infoparametersList;
        /// <summary>
        /// Group Id of the Xml Group (unique identifier)
        /// </summary>
        public int GroupId { get; set; }

        /// <summary>
        /// Parameters provided by PDF which can be edited
        /// </summary>
        public List<string> ParametersList
        {
            get { return _parametersList ?? (_parametersList = new List<string>()); }
            set { _parametersList = value; }
        }
        /// <summary>
        /// Info Parameters for scan provided by PDF
        /// </summary>
        public List<string> InfoParametersList
        {
            get { return _infoparametersList ?? (_infoparametersList = new List<string>()); }
            set { _infoparametersList = value; }
        }
    }
}

#region Revision History

// 2018-Apr-17  Vivek Saurav
//              Initial version

#endregion Revision History