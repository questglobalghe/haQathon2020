#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: SummaryParameterGroup.cs
//

#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Specialization for Summary parameter group
    /// </summary>
    public class SummaryParameterGroup : CustomParameterGroup
    {
        #region Private fields
        /// <summary>
        /// Summary Xml Parameters information.
        /// </summary>
        private readonly XmlGroup _summaryGroup;
        #region Routine Parameters
        private const string GapModeControl = "EX_GEO.slice_gap_mode";
        private const string GapControl = "EX_STACKS[{0}].slice_gap";
        private const string SliceGapInfo = "IF.act_slice_gap";
        #endregion
        #endregion

        /// <summary>
        /// Constructor.
        /// It also sets index for current group to LeftMostGroupIndex.
        /// </summary>
        public SummaryParameterGroup(IUnityContainer container, GroupInfo groupInfo, ParameterSessionInfo parameterSessionInfo)
            : base(container, groupInfo, parameterSessionInfo)
        {
            _summaryGroup = XmlParseUtility.GetXmlGroup((int)GroupIds.Summary);
        }


        /// <summary>
        /// To fetch parameters for Physiology group
        /// </summary>
        protected override Dictionary<string, IParameterMetaData> GetGroupParameters()
        {
            var allParameters = GetParameterMetaDataForTab(InformationModel.MggSoftkeyAll);
            var infoParameters = GetParameterMetaDataForTab(InformationModel.MggSoftkeyInfo);

            Dictionary<string, IParameterMetaData> paramsMd = new Dictionary<string, IParameterMetaData>();
            var summaryParameters = _summaryGroup.InfoParametersList.Concat(_summaryGroup.ParametersList).ToList();
            if (summaryParameters.Exists(x => x.Contains(InformationModel.ExGeoCurStackId)))
            {
                ReplaceCurrentStackFieldWithValue(summaryParameters);
            }
            foreach (var item in allParameters.Keys.Where(x => summaryParameters.Contains(x)))
            {
                paramsMd.Add(item, allParameters[item]);
            }

            if (infoParameters != null)
            {
                foreach (var item in infoParameters.Keys.Where(x => summaryParameters.Contains(x)))
                {
                    if (!paramsMd.ContainsKey(item))
                    {
                        paramsMd.Add(item, infoParameters[item]);
                    }
                }
            }

            return paramsMd;
        }

        /// <summary>
        /// Set All info parameters as Non Editable and Update Gap control parameters
        /// </summary>
        protected override ParameterGroupDto FillDtoParameterAttributes(ParameterGroupDto paramgroupDto)
        {
            foreach (string parameter in _summaryGroup.InfoParametersList)
            {
                if (paramgroupDto.Parameters.ContainsKey(parameter))
                {
                    paramgroupDto.Parameters[parameter].Editable = false;
                }
            }

            UpdateGapModeParameters(paramgroupDto.Parameters);
            UpdateAccelerationMethod(paramgroupDto.Parameters);

            if (!RoutineUi)
            {
                foreach (var parameter in paramgroupDto.Parameters)
                {
                    parameter.Value.Editable = false;
                }
            }

            return paramgroupDto;
        }



        /// <summary>
        /// Update Dto attributes for heart Phase related parameters
        /// </summary>
        void UpdateGapModeParameters(SerializableDictionary<string, BaseParameterDto> allSummaryParameters)
        {
            if (allSummaryParameters.ContainsKey(GapModeControl))
            {
                EnumParameterDto dto = allSummaryParameters[GapModeControl] as EnumParameterDto;
                if (dto != null)
                {
                    //Cal extension method of EnumParameterDto to fetch Enum key
                    string enumKey = GetCurrentValueEnumKeyName(dto, EnumNames.GapModeEnum);
                    var currentStack = GetCurrentStackValue();
                    //if it is user defined then use EX Parameter(HeartPhasesControl) 
                    //else display Info(MaxHeartPhases) Parameter
                    if (enumKey == EnumNames.GapModeUserDefined)
                    {
                        SetParamDtoVisible(allSummaryParameters, string.Format(GapControl, currentStack), true);
                        SetParamDtoVisible(allSummaryParameters, SliceGapInfo, false);
                    }
                    else
                    {
                        SetParamDtoVisible(allSummaryParameters, string.Format(GapControl, currentStack), false);
                        SetParamDtoVisible(allSummaryParameters, SliceGapInfo, true);
                    }
                }
            }
        }

    }
}

#region Revision History

// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2017-Aug-23  Ankit Singh Bhakuni
//              Added FillDtoParameterAttributes to toggle visibility of relevant controls based on 
//              parameter values.
// 2017-Oct-05  Ankita Kumari
//              Updated FillDtoParameterAttributes to set visibility of Gap Mode parameter.
// 2017-Nov-24  Vivek Saurav
//              Moved constant LeftMostGroupIndex to ParameterGroupConstants (Story ID- 23086)
// 2018-Apr-20  Vivek Saurav
//              Moved all the Parameters and InfoParameters values to the ParametersList.Xml
#endregion Revision History