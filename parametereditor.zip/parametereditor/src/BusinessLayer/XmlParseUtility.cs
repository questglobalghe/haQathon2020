#region (c) Koninklijke Philips Electronics N.V. 2018

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: XmlParseUtility.cs
//

#endregion

using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using Philips.PmsMR.Platform.Logging;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Utility class for Parsing of Parameters List(.xml)
    /// </summary>
    public static class XmlParseUtility
    {
        /// <summary>
        /// Logging Accessor
        /// </summary>
        private static readonly SystemMessage Log =new SystemMessage("ParameterEditor", "XmlParseUtility");
        /// <summary>
        /// Contains all Groups List Information from XML.
        /// </summary>
        private static List<XmlGroup> _allParameterGroups;
        /// <summary>
        /// Reads the Parameters xml and store all the parameter groups information.
        /// </summary>
        public static void InitializeXmlParse()
        {
            var parametersListSerializer = new XmlSerializer(typeof(List<XmlGroup>));
            using (var stream = new StreamReader("ParametersList.xml"))
            {
                _allParameterGroups = (List<XmlGroup>)parametersListSerializer.Deserialize(stream);
            }
        }
        /// <summary>
        /// Returns the parsed XmlGroup from the xml containing all the information.
        /// </summary>
        /// <param name="groupId">Indicates the GroupId of XmlGroup which method will return</param>
        /// <returns></returns>
        public static XmlGroup GetXmlGroup(int groupId)
        {
            var returnValue = _allParameterGroups?.FirstOrDefault(x => x.GroupId == groupId);
            if (returnValue == null)
            {
                Log.Error("ParameterGroup with id {0} does not exist in Parameters config file", groupId);
                return new XmlGroup();
            }
            return returnValue;
        }
    }
}

#region Revision History

// 2018-Apr-17  Vivek Saurav
//              Initial version
// 2018-May-25  Vivek Saurav
//              Added a fail safe solution for GetXmlGroup method when the Parameter Group is not present in Parameters config file.

#endregion Revision History