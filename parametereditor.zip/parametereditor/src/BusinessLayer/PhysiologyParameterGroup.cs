#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: PhysiologyParameterGroup.cs
//

#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Specialization for Physiology ParameterGroup
    /// </summary>
    public class PhysiologyParameterGroup : ParameterGroup
    {
        #region Private fields
        /// <summary>
        /// Physiology Xml Parameters information.
        /// </summary>
        private readonly XmlGroup _physioGroup;
        #endregion

        #region Physio Parameters
        private const string CardiacTriggerDelayControl = "EX_CARD.trig_delay";
        private const string TriggerDelayPeriod = "IF.no_trig_period_trig_del";
        private const string CardiacGateDelayControl = "EX_CARD.gate_delay_ms";
        private const string CardiacGateDelayControlInfo = "IF.act_gate_delay";
        private const string HeartPhasesControl = "EX_CARD.nr_heart_phases";
        private const string BreathholdControl = "EX_RESP.user_def_bh_time_sec";
        private const string MaxHeartPhases = "IF.max_heart_phases";
        private const string UserDefinedHeartPhasesControl = "EX_CARD.heart_phase_control";
        private const string CardiacTriggerDelayMode = "EX_CARD.trig_delay_enum";
        private const string CardiacGateDelayMode = "EX_CARD.gate_delay";
        #endregion
       
        /// <summary>
        /// Constructor.
        /// It also sets index for current group to LeftMostGroupIndex + 1.
        /// </summary>
        public PhysiologyParameterGroup(IUnityContainer _container, GroupInfo groupInfo, ParameterSessionInfo parameterSessionInfo)
            : base(_container, groupInfo, parameterSessionInfo)
        {
            _physioGroup = XmlParseUtility.GetXmlGroup((int)GroupIds.Physio);
        }

        /// <summary>
        /// To fetch parameters for Physiology group
        /// </summary>
        protected override Dictionary<string, IParameterMetaData> GetGroupParameters()
        {
            var allParameters = GetParameterMetaDataForTab(InformationModel.MggSoftkeyAll);
            var infoParameters = GetParameterMetaDataForTab(InformationModel.MggSoftkeyInfo);

           
            var physioParameters = _physioGroup.InfoParametersList.Concat(_physioGroup.ParametersList).ToList();
            
            var paramsMd = GetPhysiologyParameters(allParameters,  infoParameters, physioParameters);

            if (physioParameters.Contains(InformationModel.ExRespUserDefBhTimeSec) && !paramsMd.ContainsKey(InformationModel.ExRespUserDefBhTimeSec))
            {
                var parameterMetaData = ParameterSession.ScanProtocolMetaData.GetParameterMetaData(InformationModel.ExRespUserDefBhTimeSec);
                paramsMd.Add(InformationModel.ExRespUserDefBhTimeSec, parameterMetaData);
            }

            return paramsMd;
        }

        private static Dictionary<string, IParameterMetaData> GetPhysiologyParameters(Dictionary<string, IParameterMetaData> allParameters, Dictionary<string, IParameterMetaData> infoParameters, List<string> physioParameters)
        {
            Dictionary<string, IParameterMetaData> paramsMd = new Dictionary<string, IParameterMetaData>();
            foreach (var item in allParameters.Keys.Where(x => physioParameters.Contains(x)))
            {
                paramsMd.Add(item, allParameters[item]);
            }

            if (infoParameters != null)
            {
                foreach (var item in infoParameters.Keys.Where(x => physioParameters.Contains(x)))
                {
                    if (!paramsMd.ContainsKey(item))
                    {
                        paramsMd.Add(item, infoParameters[item]);
                    }
                }
            }

            return paramsMd;
        }

        /// <summary>
        /// Set All info parameters as Non Editable and Update HeartPhase, Cardiac parameters
        /// </summary>
        protected override ParameterGroupDto FillDtoParameterAttributes(ParameterGroupDto paramgroupDto)
        {
            foreach (string parameter in _physioGroup.InfoParametersList)
            {
                if (paramgroupDto.Parameters.ContainsKey(parameter))
                {
                    paramgroupDto.Parameters[parameter].Editable = false;
                }
            }



            UpdateHeartPhaseParameters(paramgroupDto.Parameters);
            UpdateGateDelayParameters(paramgroupDto.Parameters);
            UpdateTriggerDelayParameters(paramgroupDto.Parameters);
            UpdateBreathHoldDurationAttribute(paramgroupDto.Parameters);

            if (!RoutineUi)
            {
                foreach (var parameter in paramgroupDto.Parameters)
                {
                    parameter.Value.Editable = false;
                }
            }

            return paramgroupDto;
        }

        private void SetParamDtoVisible(SerializableDictionary<string, BaseParameterDto> allPhysioParameters, string paramName, bool visibleValue)
        {
            if (allPhysioParameters.ContainsKey(paramName))
            {
                allPhysioParameters[paramName].Visible = visibleValue;
            }
        }

        /// <summary>
        /// Update Dto attributes for heart Phase related parameters
        /// </summary>
        private void UpdateHeartPhaseParameters(SerializableDictionary<string, BaseParameterDto> allPhysioParameters)
        {
            if (allPhysioParameters.ContainsKey(UserDefinedHeartPhasesControl))
            {
                EnumParameterDto userDefinedHeartPhasesControlDto = allPhysioParameters[UserDefinedHeartPhasesControl] as EnumParameterDto;
                if (userDefinedHeartPhasesControlDto != null)
                {
                    //Cal extension method of EnumParameterDto to fetch Enum key
                    string enumKey = GetCurrentValueEnumKeyName(userDefinedHeartPhasesControlDto, EnumNames.HeartPhaseEnum);
                    //if it is user defined then use EX Parameter(HeartPhasesControl) 
                    //else display Info(MaxHeartPhases) Parameter
                    if (enumKey == EnumNames.HeartPhaseUserDefined)
                    {
                        SetParamDtoVisible(allPhysioParameters, HeartPhasesControl, true);
                        SetParamDtoVisible(allPhysioParameters, MaxHeartPhases, false);
                    }
                    else if (enumKey == EnumNames.HeartPhaseMaximum)
                    {
                        SetParamDtoVisible(allPhysioParameters, HeartPhasesControl, false);
                        SetParamDtoVisible(allPhysioParameters, MaxHeartPhases, true);
                    }
                    else
                    {
                        SetParamDtoVisible(allPhysioParameters, HeartPhasesControl, false);
                        SetParamDtoVisible(allPhysioParameters, MaxHeartPhases, false);
                    }

                    //Based on R5 behavior show ComboBox for UserDefinedHeartPhasesControl even if visibility is false
                    // it will be shown in disabled format
                    if (!userDefinedHeartPhasesControlDto.Visible)
                    {
                        userDefinedHeartPhasesControlDto.Visible = true;
                        userDefinedHeartPhasesControlDto.Editable = false;
                    }
                }

            }
        }

        /// <summary>
        /// Update Dto attributes for Trigger delay related parameters
        /// </summary>
        private void UpdateTriggerDelayParameters(SerializableDictionary<string, BaseParameterDto> allPhysioParameters)
        {
            if (allPhysioParameters.ContainsKey(CardiacTriggerDelayMode))
            {
                
                EnumParameterDto dto = allPhysioParameters[CardiacTriggerDelayMode] as EnumParameterDto;
                if (dto != null)
                {
                    string enumKey = GetCurrentValueEnumKeyName(dto, EnumNames.CardiacTriggerDelayEnum);
                    //if it is user defined then use EX Parameter(CardiacTriggerDelayControl) 
                    //else display Info(TriggerDelayPeriod) Parameter
                    if (enumKey == EnumNames.CardiacTriggerDelayUserDefined)
                    {
                        SetParamDtoVisible(allPhysioParameters, CardiacTriggerDelayControl, true);
                        SetParamDtoVisible(allPhysioParameters, TriggerDelayPeriod, false);
                    }
                    else
                    {
                        SetParamDtoVisible(allPhysioParameters, CardiacTriggerDelayControl, false);
                        SetParamDtoVisible(allPhysioParameters, TriggerDelayPeriod, true);
                    }
                }
            }
        }

        /// <summary>
        /// Update Dto attributes for Gate Delay related parameters
        /// </summary>
        private void UpdateGateDelayParameters(SerializableDictionary<string, BaseParameterDto> allPhysioParameters)
        {
            if (allPhysioParameters.ContainsKey(CardiacGateDelayMode))
            {
                EnumParameterDto dto = allPhysioParameters[CardiacGateDelayMode] as EnumParameterDto;
                if (dto != null)
                {
                    string enumKey = GetCurrentValueEnumKeyName(dto, EnumNames.CardiacGateDelayEnum);
                    //if it is user defined then use EX Parameter(CardiacGateDelayControl) 
                    //else display Info(CardiacGateDelayControlInfo) Parameter
                    if (enumKey == EnumNames.CardiacGateDelayUserDefined)
                    {
                        SetParamDtoVisible(allPhysioParameters, CardiacGateDelayControl, true);
                        SetParamDtoVisible(allPhysioParameters, CardiacGateDelayControlInfo, false);
                    }
                    else
                    {
                        SetParamDtoVisible(allPhysioParameters, CardiacGateDelayControl, false);
                        SetParamDtoVisible(allPhysioParameters, CardiacGateDelayControlInfo, true);
                    }
                }
            }
        }

        /// <summary>
        /// Update BreathHold Duration attribute
        /// </summary>
        /// <param name="allPhysioParameters"></param>
        private void UpdateBreathHoldDurationAttribute(SerializableDictionary<string, BaseParameterDto> allPhysioParameters)
        {
            if (allPhysioParameters.ContainsKey(BreathholdControl))
            {
                //Based on R5 behavior BreathHold duration is shown as disabled on UI even when visibility comes as false.
                if ((allPhysioParameters[BreathholdControl] != null) && !allPhysioParameters[BreathholdControl].Visible)
                {
                    allPhysioParameters[BreathholdControl].Editable = false;
                    allPhysioParameters[BreathholdControl].Visible = true;
                }
            }

        }

    }
}

#region Revision History

// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2017-Aug-23  Ankit Singh Bhakuni
//              Added FillDtoParameterAttributes to toggle visibility of relevant controls based on 
//              parameter values.
// 2017-Jul-03  Shailendra Nalwaya
//              Updated FillDtoParameterAttributes to set visibility of HeartPhase, Trigger Delay and 
//              GateDelay related parameters
// 2017-Nov-22  Vivek Saurav
//              Removed duplicate entries of CardiacTriggerDelayControl from exPhysioParameters (Story ID- 23086)
// 2018-Apr-20  Vivek Saurav
//              Moved all the Parameters and InfoParameters values to the ParametersList.Xml
#endregion Revision History