#region (c) Koninklijke Philips Electronics N.V. 2017
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: InfoParameterGroup.cs
//
#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Specialization for InfoParameterGroup.
    /// It holds the visible Info Parameters fetched from Pdf
    /// </summary>
    public class InfoParameterGroup : ParameterGroup
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public InfoParameterGroup(IUnityContainer container, GroupInfo groupInfo, ParameterSessionInfo parameterSessionInfo)
            : base(container, groupInfo, parameterSessionInfo)
        {
        }

        /// <summary>
        /// To fetch parameters for InfoParameter group
        /// </summary>
        protected override Dictionary<string, IParameterMetaData> GetGroupParameters()
        {
            //Use InfoParameters of PDF
            var paramsMetaDatas = GetParameterMetaDataForTab(TabName);

            if (paramsMetaDatas.ContainsKey(InformationModel.IfRelativeSnr) && !paramsMetaDatas.ContainsKey(InformationModel.IfAbsoluteSnr))
            {
                var parameterMetaData = ParameterSession.ScanProtocolMetaData.GetParameterMetaData(InformationModel.IfAbsoluteSnr);
                paramsMetaDatas.Add(InformationModel.IfAbsoluteSnr, parameterMetaData);
            }

            return paramsMetaDatas;
        }

        /// <summary>
        /// This group is always enabled for display
        /// </summary>
        protected override bool Enabled
        {
            get { return true; }
        }


        /// <summary>
        /// Set All info parameters as Non Editable
        /// </summary>
        /// <param name="paramgroupDto"></param>
        /// <returns></returns>
        protected override ParameterGroupDto FillDtoParameterAttributes(ParameterGroupDto paramgroupDto)
        {
            FillSnrValue(paramgroupDto);
            foreach (KeyValuePair<string, BaseParameterDto> parameter in paramgroupDto.Parameters)
            {
                parameter.Value.Editable = false;
            }

            var absoluteSnr = paramgroupDto.ParameterDtoCollection.FirstOrDefault(x => x.UniqueId == InformationModel.IfAbsoluteSnr);
            if (absoluteSnr != null)
            {
                paramgroupDto.ParameterDtoCollection.Remove(absoluteSnr);
            }

            if (paramgroupDto.Parameters.ContainsKey(InformationModel.IfAbsoluteSnr))
            {
                paramgroupDto.Parameters.Remove(InformationModel.IfAbsoluteSnr);
            }

            return paramgroupDto;
        }
    }
}

#region Revision History
// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
#endregion Revision History