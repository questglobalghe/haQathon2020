﻿#region (c) Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written permission of the copyright owner.
// 
// Filename: IScanProtocalWrapper.cs
//

#endregion

using Philips.PmsMR.ExamCards.ValidationContext;
using Philips.PmsMR.Scanning.IMethods;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// IScanProtocalWrapper - Wrapper interface.
    /// </summary>
    public interface IScanProtocalWrapper
    {
        /// <summary>
        /// ConvertStringVectorToDictionary
        /// </summary>
        /// <param name="paths"></param>
        /// <param name="pmd"></param>
        /// <returns></returns>
        Dictionary<string, IParameterMetaData> ConvertStringVectorToDictionary(StringVector paths,
            IParameterMetadataPtrVector pmd);

        /// <summary>
        /// GetUINameForTabName
        /// </summary>
        /// <param name="tabName"></param>
        /// <returns></returns>
        string GetUINameForTabName(string tabName);

        /// <summary>
        /// GetUINameForParameterName
        /// </summary>
        /// <param name="getNameTag"></param>
        /// <returns></returns>
        string GetUINameForParameterName(string getNameTag);



        /// <summary>
        /// GetCurrentNodeValueSize
        /// </summary>
        /// <param name="currentNodeValue"></param>
        /// <returns></returns>
        uint GetCurrentNodeValueSize(IKVPNode currentNodeValue);


        /// <summary>
        /// GetRangeForEnum
        /// </summary>
        /// <param name="enumDataType"></param>
        /// <returns></returns>
        IEnumerable<int> GetRangeForEnum(string enumDataType);

        /// <summary>
        /// GetUINameForEnumValue
        /// </summary>
        /// <param name="enumDataType"></param>
        /// <param name="rangeIndex"></param>
        /// <returns></returns>
        string GetUINameForEnumValue(string enumDataType, int rangeIndex);

        /// <summary>
        /// GetConflictKey
        /// </summary>
        /// <param name="conflictGuidanceInfo"></param>
        /// <returns></returns>
        string GetConflictKey(ParameterConflictGuidanceInfo conflictGuidanceInfo);


        /// <summary>
        /// GetSuggestionInfoCount
        /// </summary>
        /// <param name="conflictGuidanceInfo"></param>
        /// <returns></returns>
        int GetSuggestionInfoCount(ParameterConflictGuidanceInfo conflictGuidanceInfo);

        /// <summary>
        /// GetSuggestions
        /// </summary>
        /// <param name="conflictGuidanceInfo"></param>
        /// <returns></returns>
        IEnumerable<SuggestionStruct> GetSuggestions(ParameterConflictGuidanceInfo conflictGuidanceInfo);


        /// <summary>
        /// GetConflictGuidanceSuggestions
        /// </summary>
        /// <param name="conflictGuidanceInfo"></param>
        /// <returns>ConflictGuidanceSuggestions</returns>
        ConflictGuidanceSuggestions GetConflictGuidanceSuggestions(ParameterConflictGuidanceInfo conflictGuidanceInfo);


        /// <summary>
        /// GetConflictGuidanceParameters
        /// </summary>
        /// <param name="item"></param>
        /// <returns>ConflictGuidanceParameters</returns>
        ConflictGuidanceParameters GetConflictGuidanceParameters(SuggestionStruct item);

        /// <summary>
        /// List of ParameterStruct
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        IEnumerable<ParameterStruct> GetConflictGuidanceParameterStructs(SuggestionStruct item);


        /// <summary>
        /// ParameterStructToBeDisplayed
        /// </summary>
        /// <param name="parameterStruct"></param>
        /// <returns></returns>
        bool ParameterStructToBeDisplayed(ParameterStruct parameterStruct);

        /// <summary>
        /// GetParameterStructType
        /// </summary>
        /// <param name="parameterStruct"></param>
        /// <returns></returns>
        string GetParameterStructType(ParameterStruct parameterStruct);

        /// <summary>
        /// GetParameterStructSuggestedValue
        /// </summary>
        /// <param name="parameterStruct"></param>
        /// <returns></returns>
        float GetParameterStructSuggestedValue(ParameterStruct parameterStruct);

        /// <summary>
        /// GetParameterStructParameterId
        /// </summary>
        /// <param name="parameterStruct"></param>
        /// <returns></returns>
        string GetParameterStructParameterId(ParameterStruct parameterStruct);

        /// <summary>
        /// GetParameterStructSuggestionKey
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        string GetParameterStructSuggestionKey(SuggestionStruct item);

        /// <summary>
        /// GetEnumNameFromValue
        /// </summary>
        /// <param name="enumDataType"></param>
        /// <param name="enumValue"></param>
        /// <returns></returns>
        string GetEnumNameFromValue(string enumDataType, int enumValue);

        /// <summary>
        /// GetCoils
        /// </summary>
        /// <param name="scanProtocol">IScanProtocol</param>
        /// <param name="coilLogic">ICoilLogic</param>
        /// <returns></returns>
        Coils GetCoils(IScanProtocol scanProtocol, ICoilLogic coilLogic);

        /// <summary>
        /// CreateValidationContext
        /// </summary>
        /// <returns>ValidationContext</returns>
        IValidationContext CreateValidationContext();

        /// <summary>
        /// GetCoilLogic
        /// </summary>
        /// <param name="validationContextWrapper"></param>
        /// <returns></returns>
        ICoilLogic GetCoilLogic(ValidationContextWrapper validationContextWrapper);
    }
}
#region Revision History
// 2019-Sept-30  Ramanjaneyulu SBV
//              Initial version
#endregion Revision History