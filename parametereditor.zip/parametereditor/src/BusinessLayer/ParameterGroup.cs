#region (c) Koninklijke Philips Electronics N.V. 2017

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: ParameterGroup.cs
//

#endregion

using Microsoft.Practices.Unity;
using Philips.PmsMR.ParameterEditor.BusinessLayerInterfaces;
using Philips.PmsMR.ParameterEditor.Interfaces;
using Philips.PmsMR.Scanning.IMethods;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;

namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Base Implementation of Parameter Group.
    /// </summary>
    public class ParameterGroup : IParameterGroup
    {
        #region fields

        /// <summary>
        /// Id of the parameter group
        /// </summary>
        private readonly int _id;

        /// <summary>
        /// Name of the parameter group
        /// </summary>
        private readonly string _name;

        /// <summary>
        /// Code of the parameter group
        /// </summary>
        private readonly string _code;

        /// <summary>
        /// Indicate if current parameter group is active
        /// </summary>
        private bool _active;

        /// <summary>
        /// Index to represent current parameter group
        /// </summary>
        private readonly int _index;

        /// <summary>
        /// ParameterSessionInfo
        /// </summary>
        private ParameterSessionInfo _currentParameterSessionInfo;


        /// <summary>
        /// Unity Container
        /// </summary>
        private readonly IUnityContainer _container;

        private readonly IScanProtocalWrapper _scanProtocalWrapper;

        private ISoftwareOptionConfigurationUtil _softwareOptionConfigurationUtil;

        static readonly object SyncLock = new object();

        #endregion

        #region IParameterGroup implementation

        /// <summary>
        /// Id of Parameter Group
        /// </summary>
        protected IScanProtocalWrapper ScanProtocalWrapper => _scanProtocalWrapper;

        /// <summary>
        /// Id of Parameter Group
        /// </summary>
        public int Id => _id;

        /// <summary>
        /// Indicate if current parameter group is active
        /// </summary>
        public bool Active
        {
            get { return _active; }
            set { _active = value; }
        }

        /// <summary>
        ///  Indicate if conflict is present
        /// </summary>
        public virtual bool ConflictPresent => false;

        /// <summary>
        /// Routine UI - Enable / Disable scan info bar details
        /// </summary>
        public virtual bool RoutineUi => _softwareOptionConfigurationUtil.CheckOptionAvailable();

        /// <summary>
        /// Populate ParameterGroupDto for current parameter group
        /// </summary>
        /// <returns></returns>
        public virtual ParameterGroupDto PopulateGroup()
        {
            ParameterGroupDto dto = new ParameterGroupDto();

            //Fill Parameter Group details
            FillParameterGroupInfo(ref dto);
            bool isCustomGroup = CheckForCustomGroup(dto.Code);
            //Fill Parameters for Group if current group is active
            dto.Parameters = new SerializableDictionary<string, BaseParameterDto>();
            if (Enabled)
            {
                //Filter Group specific parameters based on visibility
                var parameters = GetGroupParameters();
                if ((parameters != null) && parameters.Any())
                {
                    dto.Parameters = ParameterConverter.PopulateParameters(parameters, _currentParameterSessionInfo, _scanProtocalWrapper, isCustomGroup);
                }
            }
            FillDtoParameterAttributes(dto);

            if (dto.Parameters.Count > 0)
            {

                dto.Visible = true;

            }
            else
            {
                dto.Visible = false;
            }
            return dto;
        }

        /// <summary>
        /// Set current group as active to PDF
        /// </summary>
        public virtual void SetActiveGroup()
        {
            if (!_active)
            {
                //Set current group as active group before making call to Pdf
                //Note:Please retain the order of setting active before making call to Pdf
                //else it can end up in recursion due to PDFUpdate call which repopulates parameter group
                //and sets active group again if no active group found
                _active = true;
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="container">Container</param>
        /// <param name="groupInfo">GroupInfo from Pdf to populate group</param>
        /// <param name="parameterSessionInfo">Parameter Session Info</param>
        public ParameterGroup(IUnityContainer container, GroupInfo groupInfo, ParameterSessionInfo parameterSessionInfo)
        {
            _container = container;
            _id = groupInfo.id;
            _name = groupInfo.name;
            _code = groupInfo.Code;
            _index = ParameterGroupIdToIndexConverter.Convert(groupInfo.id);
            _currentParameterSessionInfo = parameterSessionInfo;
            lock (SyncLock)
            {
                if (!container.IsRegistered<IScanProtocalWrapper>())
                {
                    container.RegisterType<IScanProtocalWrapper, ScanProtocalWrapper>(new ContainerControlledLifetimeManager());
                }

                _scanProtocalWrapper = container.Resolve<IScanProtocalWrapper>();
                if (!container.IsRegistered<ISoftwareOptionConfigurationUtil>())
                {
                    container.RegisterType<ISoftwareOptionConfigurationUtil, SoftwareOptionConfigurationUtil>();
                }

                _softwareOptionConfigurationUtil = container.Resolve<ISoftwareOptionConfigurationUtil>();
            }
        }

        #endregion

        #region protected methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tabName"></param>
        /// <returns></returns>
        protected Dictionary<string, IParameterMetaData> GetParameterMetaDataForTab(string tabName)
        {
            if (tabName == InformationModel.MggSoftkeyAll && ParameterGroupsHelper.AllParametersMetaData != null)
            {
                return ParameterGroupsHelper.AllParametersMetaData;
            }
            else if (tabName == InformationModel.MggSoftkeyInfo && ParameterGroupsHelper.InfoParametersMetaData != null)
            {
                return ParameterGroupsHelper.InfoParametersMetaData;
            }
            var dicParameterMetaData = FetchParameterMetaDataForTab(tabName);
            if (tabName == InformationModel.MggSoftkeyAll)
            {
                ParameterGroupsHelper.AllParametersMetaData = dicParameterMetaData;
            }
            else if (tabName == InformationModel.MggSoftkeyInfo)
            {
                ParameterGroupsHelper.InfoParametersMetaData = dicParameterMetaData;
            }

            return dicParameterMetaData;
        }

        private Dictionary<string, IParameterMetaData> FetchParameterMetaDataForTab(string tabName)
        {
            var tabHierarchy = _currentParameterSessionInfo.ScanProtocolMetaData.GetTabHierarchy(tabName);
            //Get Tab Elements
            var tabElements = _currentParameterSessionInfo.ScanProtocolMetaData.GetParametersPath(tabHierarchy);
            //Populate the Tab
            var dicParameterMetaData = _scanProtocalWrapper.ConvertStringVectorToDictionary(tabElements,
                _currentParameterSessionInfo.ScanProtocolMetaData.GetParameterMetaData(tabElements));
            return dicParameterMetaData;
        }

        /// <summary>
        /// Method to fill the DTO parameter attributes. 
        /// This method will be overloaded by each Parametergroup to handle their filling 
        /// off attributes.
        /// </summary>
        /// <param name="paramgroupDto"></param>
        /// <returns></returns>
        protected virtual ParameterGroupDto FillDtoParameterAttributes(ParameterGroupDto paramgroupDto)
        {
            // Return back the Dto unchanged.
            // Specific implementation should be overriden in subclasses.
            return paramgroupDto;
        }

        /// <summary>
        ///  PdfDataProvider instance to fetch parameters
        /// </summary>
        protected ParameterSessionInfo ParameterSession => _currentParameterSessionInfo;


        /// <summary>
        /// Enabled : It indicates if parameter group is enabled for display
        /// Population of parameter group is only done if group is enabled for display
        /// By default group which is active, is enabled for display
        /// </summary>
        protected virtual bool Enabled => _active;

        /// <summary>
        /// Name of the parameter group
        /// </summary>
        public string Name => _name;

        /// <summary>
        /// Tab Name
        /// </summary>
        public string TabName
        {
            get;
            set;
        }

        /// <summary>
        /// Get parameters for current group.
        /// Default logic to fetch parameters of current group is based on visibility.
        /// </summary>
        /// <returns></returns>
        protected virtual Dictionary<string, IParameterMetaData> GetGroupParameters()
        {
            return GetParameterMetaDataForTab(TabName);
        }

        /// <summary>
        /// Get Enum Key Name for current value of EnumParameterDto
        /// </summary>
        protected string GetCurrentValueEnumKeyName(EnumParameterDto dto, string enumDataType)
        {

            string enumValue = string.Empty;
            if (dto != null && dto.Values.Count > 0)
            {
                int selectedIndex = dto.Values[0];
                if (selectedIndex < dto.Enumerators.Count)
                {
                    enumValue = dto.Enumerators[selectedIndex].Key;
                }
            }
            int enumIntValue;
            var result = int.TryParse(enumValue, out enumIntValue);
            return _scanProtocalWrapper.GetEnumNameFromValue(enumDataType, enumIntValue);
        }

        /// <summary>
        /// Method for getting Current Stack Value
        /// </summary>
        /// <returns></returns>
        protected string GetCurrentStackValue()
        {
            string curStack = string.Empty;
            var parameterMetaData = ParameterSession.ScanProtocolMetaData.GetParameterMetaData(InformationModel.ExGeoCurStackId);
            if (parameterMetaData != null)
            {
                var item = new Dictionary<string, IParameterMetaData> { { InformationModel.ExGeoCurStackId, parameterMetaData } };
                var scanParams = ParameterConverter.PopulateParameters(item, ParameterSession, ScanProtocalWrapper, true);
                if (scanParams.Count > 0 && scanParams.ContainsKey(InformationModel.ExGeoCurStackId))
                {
                    curStack = Convert.ToString((scanParams[InformationModel.ExGeoCurStackId] as EnumParameterDto)?.Values[0]);
                }
            }
            return curStack;
        }

        /// <summary>
        /// ReplaceCurrentStackFieldWithValue
        /// </summary>
        /// <param name="parameters"></param>
        protected void ReplaceCurrentStackFieldWithValue(List<string> parameters)
        {
            var currentStack = GetCurrentStackValue();
            for (int i = 0; i < parameters.Count; i++)
            {
                if (parameters[i].Contains("[" + InformationModel.ExGeoCurStackId + "]"))
                {
                    parameters[i] = parameters[i].Replace(
                        InformationModel.ExGeoCurStackId, currentStack);
                }
            }
        }

        /// <summary>
        /// FillSnrValue
        /// </summary>
        /// <param name="paramgroupDto"></param>
        protected void FillSnrValue(ParameterGroupDto paramgroupDto)
        {
            if (paramgroupDto.Parameters.ContainsKey(InformationModel.IfRelativeSnr))
            {
                SingleParameterDto absoluteSnr = null;
                if (paramgroupDto.Parameters.ContainsKey(InformationModel.IfAbsoluteSnr))
                {
                    absoluteSnr = (SingleParameterDto)paramgroupDto.Parameters[InformationModel.IfAbsoluteSnr];
                }
                else
                {
                    var parameterMetaData = ParameterSession.ScanProtocolMetaData.GetParameterMetaData(InformationModel.IfAbsoluteSnr);
                    var item = new Dictionary<string, IParameterMetaData> { { InformationModel.IfAbsoluteSnr, parameterMetaData } };
                    var scanParams = ParameterConverter.PopulateParameters(item, ParameterSession, ScanProtocalWrapper, true);
                    if (scanParams != null)
                    {
                        absoluteSnr = (SingleParameterDto)scanParams[InformationModel.IfAbsoluteSnr];
                    }
                }

                if (absoluteSnr != null)
                {
                    var val = (float)Math.Round(absoluteSnr.Values[0] / absoluteSnr.DefaultValues[0], 2);
                    if (double.IsInfinity(val))
                    {
                        var parameter = paramgroupDto.ParameterDtoCollection.FirstOrDefault(x => x.UniqueId == InformationModel.IfRelativeSnr);
                        if (parameter != null)
                        {
                            var relativeSnrParameterDto = new StringParameterDto();
                            relativeSnrParameterDto.UniqueId = parameter.UniqueId;
                            relativeSnrParameterDto.Help = parameter.Help;
                            relativeSnrParameterDto.InConflict = parameter.InConflict;
                            relativeSnrParameterDto.Visible = parameter.Visible;
                            relativeSnrParameterDto.Editable = parameter.Editable;
                            relativeSnrParameterDto.Values = new ObservableCollection<string>() { "--" };
                            relativeSnrParameterDto.DefaultValues = new ObservableCollection<string>() { "--" };
                            relativeSnrParameterDto.Name = parameter.Name;
                            var insertIndex = paramgroupDto.ParameterDtoCollection.FindIndex(x =>
                                    x.UniqueId == InformationModel.IfRelativeSnr);
                            paramgroupDto.ParameterDtoCollection.Remove(parameter);
                            paramgroupDto.ParameterDtoCollection.Insert(insertIndex, relativeSnrParameterDto);
                            paramgroupDto.Parameters.Remove(InformationModel.IfRelativeSnr);
                            paramgroupDto.Parameters.Add(InformationModel.IfRelativeSnr, relativeSnrParameterDto);
                        }
                    }
                    else
                    {
                        ((SingleParameterDto)paramgroupDto.Parameters[InformationModel.IfRelativeSnr])
                            .Values = new ObservableCollection<float>(new[] { val });
                        var insertIndex = paramgroupDto.ParameterDtoCollection.FindIndex(x => x.UniqueId == InformationModel.IfRelativeSnr);
                        ((SingleParameterDto)paramgroupDto.ParameterDtoCollection[insertIndex])
                            .Values = new ObservableCollection<float>(new[] { val });
                    }
                }
            }
        }


        #endregion

        #region Private Methods

        /// <summary>
        /// Populate parameter group Info
        /// </summary>
        public void FillParameterGroupInfo(ref ParameterGroupDto dto)
        {
            dto.GroupId = _id;
            dto.Index = _index;
            dto.Name = _name;
            dto.ConflictPresent = ConflictPresent;
            dto.Code = _code;
        }

        private bool CheckForCustomGroup(string dtoCode)
        {
            if (dtoCode == InformationModel.PhysioTabKey || dtoCode == InformationModel.SummaryTabKey || dtoCode == InformationModel.ScanInfoTabKey)
            {
                return true;
            }

            return false;
        }

        #endregion
    }
}

#region Revision History

// 2017-Jul-03  Shailendra Nalwaya
//              Initial version
// 2017-Aug-23  Ankit Singh Bhakuni
//              Added FillDtoParameterAttributes to toggle visibility of relevant controls based on 
//              parameter values.
// 2017-Nov-22  Vivek Saurav
//              Updated PopulateGroup and SetActiveGroup methods to virtual(Story ID- 23086)
// 2017-Dec-11  Vivek Saurav
//              Added ParameterGroupIdToIndexConverter class(Story ID- 23086)
// 2020-Apr-29  Ramanjaneyulu SBV
//              Handle scenario when infinity value for relative SNR field and replace infinity with text '--'
// 2020-May-19  Ramanjaneyulu SBV
//              Added new field code for store tab group code
#endregion Revision History