﻿#region (c) Koninklijke Philips Electronics N.V. 2019

//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
// Filename: SoftwareOptionConfigurationUtil.cs
//

#endregion


namespace Philips.PmsMR.ParameterEditor.BusinessLayer
{
    /// <summary>
    /// Utility interface for SoftwareOptionConfiguration
    /// </summary>
    public interface ISoftwareOptionConfigurationUtil
    {
        /// <summary>
        /// Check Option is Available
        /// </summary>
        bool CheckOptionAvailable();
    }
}
#region Revision History

// 2019-Nov-11  Ramanjaneyulu SBV
//              Initial version

#endregion Revision History